# KAGE-ANA — INSTRUKSI GELOMBANG E
**Dari "Sandbox 2D yang benar" menuju "dunia yang terlihat, terdengar, dan bisa dipegang"**
Berlaku di atas paket `KageAna_Gerbang_1_Pilot` (hash L1 `9966aca7bc76c555`). Kitab Bagian 1 dan Lampiran A tetap berlaku, kecuali yang secara eksplisit diubah di dokumen ini (lihat E0.3). Dokumen ini adalah perintah kerja. Kamu berimprovisasi pada cara, bukan pada tujuan.

---

## E0. PENILAIAN GELOMBANG D (baca dulu, ini dasar pekerjaanmu)

### E0.1 Yang benar-benar maju (jangan dirusak)
- Pemecahan 12 modul dengan hash refactor-murni yang identik. Ini disiplin yang benar.
- Agensi keyakinan → niat → tindakan sudah ada: rantai orde 2 dan orde 3, serta salah paham (`WrongPerson`, `WrongPlace`) yang berujung denda ke orang yang salah. Ini bahan cerita terbaik yang pernah dihasilkan proyek ini.
- Tekanan hidup: Sōma yang diam kini menanggung sewa, makan, sita pikulan, dan putusnya jalur kelompok. Nisshi 16 butir terkurasi.
- Pelaporan sebelum/sesudah dengan angka, 5 cerita berjejak ID, daftar "belum dijalankan", dan 25 tes negatif.

### E0.2 Masalah yang saya temukan setelah membuka kodenya (jujur dan tajam)

1. **Kepadatan interaksi dicapai dengan pengisi kuota, bukan dengan kehidupan.**
   `SimEconomyAndPressureSystem.cs` baris ±337: blok "High-Density Meaningful EntityInteraction" berputar (round-robin) tiap jam, memilih NPC, lalu mencari mitra:
   a) NPC pertama yang kebetulan satu tempat, atau
   b) **jika tidak ada, NPC mana pun di desa yang tidak tidur, di mana pun ia berada** (interaksi lintas lokasi; fisik tidak mungkin);
   lalu jenis interaksi dipilih oleh `selector = (day + hour + i + partnerIdx) % 10`, bukan oleh hubungan, kebutuhan, atau kepribadian. Pertengkaran memindahkan 10 mon antara dua orang acak. Angka "8,73 interaksi/NPC/hari" benar, tetapi itu *angka target yang dipenuhi lewat modulus*, bukan emergensi. Itu persis penyakit "metrik yang bisa dipenuhi tanpa makna" yang sudah dua kali kita tangkap.
   Akibatnya: 6.721 kejadian, sebagian besar bising. Metrik "92,66% rumor non-rutin" ikut menggelembung karena pertengkaran dan tagihan utang buatan dihitung "non-rutin". Metrik salience tidak lagi membuktikan apa-apa.
2. **ID NPC keras (hard-coded) kembali** di kode sistem: 16 kemunculan `"ohana"/"haruki"/"daigo"/"mio"` di `SimEconomyAndPressureSystem.cs`, ditambah beberapa di modul lain. Ini melanggar aturan data-driven Kitab dan mengulang pelanggaran Gelombang C.
3. **Semua kebijakan, kecuali satu, berakhir dengan Kepercayaan Kelompok 0.** `HonestTrader` kehilangan jalur kelompok di Hari 21. Memang masuk akal sebagai konsekuensi, tetapi *jalan lanjut* (pemulihan) tidak ada, dan Kitab melarang jalan buntu. Pemain jujur dihukum seperti pemain malas.
4. **Dialog diegetik masih template.** Kamu sendiri sudah mengakuinya. Setelah 25 menit akan terasa mekanis. Ini bukan prioritas sampai ada suara dan wajah, tetapi harus dirancang ulang agar kompatibel dengan karakter 3D (E3).
5. **Respons pemain terhadap salah paham belum ada.** Cerita terbaik sistem ini ("Sabu didenda karena kesalahan Matsubei") membuat Sōma hanya jadi penonton. Itu pemborosan terbesar di game ini: *pemain harus bisa turun tangan* (E2.4).
6. **Sandbox tidak punya gamepad sama sekali** (`SandboxProgram.cs`: 0 rujukan). "Setup kontroler" yang ada hanya di lab WebGL lama dan skrip Unity lama (`_Legacy`), bukan di jalur produk. Jangan menganggap fitur ini sudah ada.
7. **Windows nyata masih belum terbukti.** Belum ada `HASIL_BANGUN.txt`, belum ada bukti dotnet untuk kode Gelombang D. Semua "lulus" masih lewat penerjemah. Pengguna harus menjalankan `BUAT_INSTALLER.bat` dulu (lihat E1.1).
8. **Risiko strategis terbesar: empat gelombang membangun mesin simulasi, tetapi proyek belum punya satu pun gambar yang membuat orang ingin bermain.** Orang menilai game dari apa yang dilihat dan didengar dalam 90 detik pertama. Sim sudah cukup kaya. **Mulai Gelombang E, sim DIBEKUKAN** (hanya perbaikan bug dan E2); kekuatan dipindah ke presentasi, input, platform, dan audio.
9. **Sim dikompilasi `net8.0` dan Adapter memakai `System.Text.Json`.** Unity 6 memakai profil .NET Standard 2.1 dan tidak membawa `System.Text.Json` secara bawaan. Ini jebakan yang akan meledak pada hari pertama impor ke Unity (lihat E1.2).

### E0.3 Keputusan yang diubah oleh dokumen ini
| Keputusan Kitab | Status | Alasan |
|---|---|---|
| D1 kamera (semula usulan orang pertama) | **BERUBAH: orang ketiga** (kamera membuntuti bahu + mode kamera dekat untuk dialog) | Karakter harus terlihat (desain anime, ekspresi, kostum yang berganti pedagang/shinobi). Orang pertama menyembunyikan seluruh investasi seni. Gamepad dan layar sentuh juga jauh lebih natural dengan orang ketiga. |
| Platform | **Windows + Android dari satu proyek Unity** | Permintaan pemilik. Menetapkan anggaran performa dan skema input sejak awal. |
| Sandbox 2D WinForms | **Tetap sebagai alat uji sim**, bukan produk | Tidak dikembangkan lebih jauh kecuali bug dan E2. |
| Nama | Tetap **KAGE-ANA** (lihat E7) | |

---

## E1. GERBANG SEBELUM LANJUT (urutan keras)

### E1.1 Bukti Windows
Jika pengguna belum mengirim `HASIL_BANGUN.txt` + `selftest.txt` dari `BUAT_INSTALLER.bat`, **jangan mulai E3 ke atas**. Kerjakan hanya E1.2, E2, dan perbaikan galat yang dilaporkan pengguna. Kemajuan nyata dimulai dari kompilasi nyata.

### E1.2 Portabilitas Sim ke Unity (kerjakan sekarang, murah, mencegah bencana)
- `KageAna.Sim.csproj`: ubah target menjadi **`netstandard2.1`** (atau multi-target `netstandard2.1;net8.0`), `LangVersion` 9. Buang semua fitur yang tidak ada di profil itu (mis. `record struct`, `init`-only yang butuh polyfill, `System.Text.Json`, `Span` penggunaan tidak aman). Tes tetap `net8.0`.
- Buat antarmuka `ISimDataSource` di dalam Sim dan **dua adapter**: (a) `SimJsonDataLoader` (System.Text.Json, untuk Sandbox/CLI/tes), (b) `UnitySimDataLoader` (Newtonsoft `com.unity.nuget.newtonsoft-json` atau `JsonUtility` + wadah), keduanya diuji untuk menghasilkan `SimDataBundle` yang **setara** (tes kesetaraan hash bundel).
- Tambah perintah CI: kompilasi proyek Sim dengan `netstandard2.1` (via penerjemah di sini; label jujur) dan pemindai statis yang menolak `System.Text.Json`, `UnityEngine`, `System.Drawing`, `System.Windows.Forms` di dalam `Runtime/Sim`.
- Anggaran: satu langkah sim (1 menit game) harus bisa selesai < 2 ms di ponsel kelas menengah. Tambahkan penghitung biaya per modul di `HeadlessSimRunner` (laporan: kejadian/hari, ms/langkah per modul, alokasi memori). Jika ada modul O(n²), atasi dengan LOD, jangan dengan harapan.

---

## E2. PERBAIKAN SIM (satu-satunya pekerjaan sim di gelombang ini)

### E2.1 Ganti pengisi kuota dengan **Niat Sosial** yang lahir dari kebutuhan
Hapus blok round-robin/`selector % 10`. Gantinya, tiap NPC punya *dorongan* (data-driven di JSON): `perlu_bayar`, `perlu_bicara`, `perlu_dagang`, `perlu_istirahat`, `rasa_penasaran`, `dendam`, `kasih_sayang`, `tugas_jadwal`. Tiap jam, NPC memilih satu niat sosial dengan skor `kebutuhan × kedekatan hubungan × kesempatan (siapa ada di tempat itu)`. Aturan keras:
- Interaksi hanya antar NPC **di tempat yang sama** (atau dengan "kirim pesan/kabar" yang punya waktu tempuh nyata dan pembawa kabar). **Hapus pencarian mitra lintas lokasi.**
- Jenis interaksi ditentukan oleh **tipe hubungan** di data (`kerabat`, `utang`, `saingan`, `kekasih`, `atasan–bawahan`, `rekan`, `asing`): orang asing hanya menyapa/menawar; pertengkaran hanya lahir dari `dendam`/`utang`/`saingan` yang melewati ambang, dan meninggalkan jejak (hubungan memburuk, ada pemicu yang dapat ditelusuri).
- Kepadatan **bukan target**. Hapus target ">= 8/NPC/hari". Ganti dengan metrik anti-pengisi: (1) rasio kejadian yang punya "mengapa" tertaut ke kebutuhan/hubungan = 100%; (2) rasio pasangan berulang (pasangan yang sama berinteraksi lagi tanpa pemicu baru) < 30%; (3) keragaman jenis interaksi (entropi) per NPC; (4) jumlah *kejadian yang tak dapat diprediksi dari jadwal saja* (kejadian yang hilang bila rantai sebab dihapus). Tiap metrik wajib punya tes negatif (sim palsu yang memenuhi kuota dengan modulus harus **ditolak** oleh metrik).
- Kepadatan akan turun dibanding 8,73. Itu benar. Kami lebih memilih 4 kejadian yang berarti daripada 8 yang bising. Laporkan jujur angkanya. Tuning agar dunia terasa hidup lewat *kebutuhan yang lebih beragam*, bukan kuota.

### E2.2 Hapus semua ID NPC yang keras
Pindahkan perilaku khusus (mis. penagihan sewa O-Hana, pencocokan buku Za) ke data: `roles`, `duties`, `relationships` di JSON NPC. Tambahkan pemindai CI: **kata `ohana|okiku|haruki|daigo|mio|kojiro|ryota|suzu|sabu|kanta|matsubei|chiyo|soan|gensai` (dan semua ID NPC dari JSON) dilarang muncul sebagai literal di `Runtime/Sim/**`** (kecuali berkas tes), dengan tes negatif.

### E2.3 Jalan lanjut untuk Kepercayaan Kelompok
Putusnya jalur bukan akhir. Buat tahap pemulihan: *Kontak Terputus → Ujian Kesetiaan (tugas kecil berisiko) → Dipercaya Kembali (dengan tanda hati-hati)*. Pemain `HonestTrader` bisa pulih lewat satu Kabar bernilai, bukan lewat menjadi informan penuh. Lintasan 28 hari baru dilaporkan untuk keempat kebijakan + satu kebijakan baru `Pemulih`. Pastikan tidak ada kebijakan yang berakhir tanpa pilihan lanjut.

### E2.4 Intervensi Sōma pada salah paham (ide yang kamu parkir: kerjakan sekarang)
Ini adalah kejutan pemain terbaik yang mungkin diberikan sistem ini. Tindakan Sōma: `Bersaksi`, `Menyerahkan Bukti` (benda/kabar yang ia miliki dengan ≥2 sumber independen), `Menyuap Penjaga`, `Menyebar Kabar Tandingan`, `Membiarkan`. Tiap pilihan memancarkan `WorldEvent` sumber `SoumaAction`, mengubah keyakinan NPC terkait lewat *mekanisme persepsi/ingatan yang sama* (bukan flag cerita), punya biaya (uang, kecurigaan, Wajah Asli bila terlalu terang-terangan), dan bisa gagal/berbalik (penjaga curiga mengapa pedagang tahu begitu banyak). Bukti: ≥3 skenario terlacak ID kejadian (berhasil, gagal, berbalik).

### E2.5 Keluaran E2
Laporan sebelum/sesudah dengan perintah yang sama (`--seed 7 --days 28`), metrik anti-pengisi baru, hash baru dijelaskan (perubahan perilaku), 5 cerita baru dari log *dengan ID*, dan pernyataan jujur apa yang masih lemah. Setelah E2 lulus CI: **bekukan sim** (tag `sim-freeze-E`).

---

## E3. PRODUK VISUAL: UNITY, 3D, ORANG KETIGA

> Kerjakan hanya setelah E1.1 terpenuhi. Kamu tidak bisa menjalankan Unity di sini. Maka yang kamu hasilkan adalah **proyek Unity yang benar secara statis, skrip bangun otomatis, dan dokumentasi verifikasi untuk pengguna**, dengan label jujur "BELUM DIBUKA DI UNITY ASLI".

### E3.1 Struktur
- Unity **6 LTS** (versi persis dari `ProjectVersion.txt`), URP, Input System, Cinemachine, **UniVRM** (karakter VRM), TextMeshPro. Tambahkan paket yang diperlukan ke `manifest.json` dengan versi pasti (jangan `latest`). Verifikasi nama paket UniVRM dan sumbernya dari dokumentasi resmi lewat pencarian; jika tidak dapat memastikan, tandai `PERLU DIVERIFIKASI` dan sediakan jalur impor manual `.unitypackage` di dokumen.
- Asmdef: `KageAna.Sim` (tanpa UnityEngine; dikompilasi netstandard2.1), `KageAna.Game` (jembatan Sim ↔ Unity: spawn NPC dari `Agents`, gerak ke `Place`, menerjemahkan `WorldEvent` ke animasi/suara/UI), `KageAna.Presentation`, `KageAna.Audio`, `KageAna.Input`, `KageAna.UI`. Hapus/arsipkan `_Legacy` ke `Archive/` (jangan dipakai di jalur produk).
- **Satu sumber kebenaran**: Unity hanya *menampilkan* keadaan Sim dan mengirim perintah. Tidak ada logika dunia di MonoBehaviour. Tes: jalankan sim melalui jembatan Unity dan lewat HeadlessRunner dengan seed sama → hash sama (tes PlayMode/EditMode).

### E3.2 Irisan vertikal pertama ("Satu Malam di Kaki Kastil") — kecil, indah, lengkap
Bukan seluruh dunia. **Satu distrik (Pasar Kaki Kastil + Nagaya + gang belakang)**, 8–10 NPC dari 26, siklus siang→malam 24 menit game yang dipercepat, cuaca dari Sim, dengan:
- Sōma bergerak, berinteraksi (tawar-menawar, Tanya NPC, mengintip, menyelinap, Wajah Asli), mengganti pakaian (Omote/Ura).
- Minimal 2 rantai salah paham dari sim yang **terlihat di dunia** (NPC berdebat, penjaga menegur orang yang salah, Sōma dapat campur tangan lewat E2.4).
- Siklus Omote→Ura berubah **secara visual dan audio** (E4, E5).
Tujuan uji: orang yang memegang gamepad 15 menit bisa menceritakan satu kejadian dan *menunjukkan siapa yang terlibat dari wajahnya*.

### E3.3 Anggaran performa (kontrak keras, karena Android)
| Target | PC | Android menengah (±Snapdragon 7-series/ Mali kelas sejenis) |
|---|---|---|
| Kecepatan bingkai | 60 fps | **30 fps stabil**, opsi 60 di perangkat kuat |
| Poligon karakter (utama) | ≤ 40k | **≤ 20k**, NPC latar ≤ 8k |
| Bahan/draw call per bingkai | — | ≤ 150 draw call, SRP Batcher aktif |
| Bayangan | Cascade 2–3 | 1 cascade, jarak pendek, atau bayangan blob untuk NPC latar |
| Pasca-proses | Bloom ringan, vignette, grain, warna | **Hanya** vignette + tone/color grade ringan; tanpa SSAO/DoF/motion blur |
| Tekstur | ≤ 2K karakter | ≤ 1K, ASTC |
| Memori | — | < 1,5 GB |
Setiap fitur visual di E4 wajib punya "versi PC" dan "versi Android" dalam satu pengaturan kualitas (`QualityTier`). Sediakan tombol pengukur performa (FPS, draw call, memori) di menu pengembang.

---

## E4. ARAH VISUAL (jujur dan spesifik)

**Rasa yang dituju:** *ukiyo-e hangat yang berubah menjadi sumi-e dingin saat malam*; indah, tenang, ada ancaman yang dibisikkan, bukan dikeraskan. Bukan "gelap-gelap seluruhnya" (itu murahan dan menyakitkan mata di layar ponsel di bawah matahari).

### E4.1 Palet (token warna; satukan di satu berkas `Palette.asset`, jangan hex acak di tempat lain)
| Peran | Nama | Hex | Pemakaian |
|---|---|---|---|
| Kertas siang | Washi (gading) | `#EFE6D2` | latar UI, langit siang pucat, cahaya hangat |
| Tinta | Sumi | `#1C1B1A` | garis kontur, teks utama |
| Biru utama | Ai-iro (nila) | `#27406B` | pakaian rakyat, bayangan siang, UI |
| Biru malam | Kon (nila gelap) | `#141B33` | langit malam, bayangan malam |
| Cahaya bulan | Tsuki | `#B9C7D8` | rim light, kabut malam |
| Lentera | Andon (kuning kemerahan) | `#E8A33D` | **satu-satunya sumber hangat di malam hari** |
| Aksen | Kaki (kesemek) | `#D2692E` | kain pedagang, penunjuk interaksi siang |
| Bahaya | Shu (vermilion) | `#B8321F` | kecurigaan, torii, **dipakai hemat** |
| Darah | Karat | `#5E1F18` | pekat dan kusam, tidak pernah merah cerah |
| Tanah/kayu | Kuri / Sugi | `#6B5A44` / `#A37E56` | bangunan, jalan |
| Hijau | Matcha-kusam | `#7A8B5C` | tanaman, jangan neon |

**Aturan:** malam = nila + bulan dingin, dengan *hanya lentera* yang hangat. Mata pemain selalu tertarik ke tempat yang hangat, sehingga lentera adalah alat komposisi dan petunjuk navigasi sekaligus. Merah (Shu) hanya muncul ketika ada risiko nyata; bila ada di mana-mana, ia kehilangan makna.

### E4.2 Gradasi langit/waktu (di-drive `WorldClock`, bukan animasi manual)
Fajar `#2A3150 → #E7B08A → #F3E3C3` (nila ke jingga lembut ke gading) · Siang `#BFD7E3 → #EFE6D2` · Petang `#E8A06A → #B56A5B → #3C3A5E` · Malam `#141B33 → #0B1020` dengan bulan `#B9C7D8` · Hujan: kurangi kejenuhan 30%, tambah kabut rendah biru-abu. Interpolasi lewat satu kurva `Gradient` per cuaca, dikalibrasi di tabel data.

### E4.3 Gaya render
- **Cel-shading 3 tingkat + garis tinta** lebar berubah (tebal di siluet, tipis di lipatan), warna garis = Sumi pekat, bukan hitam murni. Pada Android: garis lewat teknik *inverted hull* (murah), bukan pasca-proses.
- **Tekstur kertas** halus (overlay `multiply` kecil, 4–6%) pada UI dan sedikit pada langit; di Android pakai tekstur kecil yang diulang.
- **Siang vs malam sebagai dua "dunia"**: siang = garis lembut, warna hangat, bayangan nila; malam = kontras naik, garis lebih tebal, warna ditekan, lentera berpendar (bloom ringan atau sprite halo murah).
- Efek yang mendukung cerita (semuanya halus): kabut tipis di lorong malam; debu emas dalam berkas cahaya jendela siang; kunang-kunang musim panas; kelopak sakura saat Hanami; kertas lampion berayun saat angin; riak air hujan bercahaya lentera; napas putih di musim dingin.
- **Efek "terlihat curiga"**: vignette menutup perlahan, desaturasi ringan, detak jantung rendah di audio (jangan getar layar mengganggu). **Efek "Wajah Asli"**: satu bingkai frame-freeze kecil, garis kontur menebal, warna Shu menyentuh mata karakter, dan suara napas; setelah itu kembali; ini momen, jangan diulang jadi biasa.
- **Hindari**: bloom berlebihan, lens flare, chromatic aberration, kabut hitam pekat, filter sepia total, partikel di mana-mana. "Kurang adalah lebih."

### E4.4 Komposisi & kamera
- Kamera membuntuti bahu Sōma dengan jarak adaptif; di gang sempit menarik mendekat; saat percakapan, kamera dekat 2-bidikan (sudut bahu) dengan kedalaman bidang ringan **hanya di PC**.
- Aturan komposisi malam: jalur utama diterangi lentera berselang; bayangan menyisakan "jalur gelap" yang jelas bisa dilihat pemain; garis horizon rendah; atap-atap sebagai siluet ke langit bulan.
- Siang: pasar ramai berlapis (latar–tengah–depan), warna kain pedagang adalah titik fokus.

### E4.5 UI (diegetik dan sunyi)
- HUD minimal: tanda tangan hanko untuk status; ikon-ikon dari **kamon sederhana**, bukan ikon neon. Panel "Nisshi" seperti gulungan yang terbuka. "Kisah Hari Ini" seperti kertas pengumuman di papan (kōsatsu).
- Font: **Noto Serif JP / Shippori Mincho / Zen Antique** (lisensi OFL; periksa dan catat di `ASSETS_LICENSE.md`) untuk judul; font sans netral untuk teks panjang Bahasa Indonesia (keterbacaan di ponsel).
- Mode siang vs malam memiliki *tema UI* berbeda dari token palet (kertas terang vs tinta gelap).
- Ukuran sentuh ≥ 48 dp, skala UI 80–140%, teks ≥ 16 sp di ponsel, subtitle selalu tersedia.

---

## E5. AUDIO (musik, efek, suara; semuanya halus dan tidak mengganggu)

**Prinsip:** *keheningan adalah instrumen.* Pada banyak waktu tidak ada musik sama sekali, hanya ambience. Musik muncul untuk menandai perubahan (senja, ketegangan, kelegaan), lalu pergi. Tidak ada lagu yang berulang jelas di ingatan dalam 20 menit (jangan loop pendek).

### E5.1 Instrumentasi & suasana
- Siang (pasar): ambience kerumunan rendah, kayu & sandal di tanah, pedagang dari jauh (murmur tanpa kata yang dapat dikenali), burung, sesekali **koto/biwa** ringan.
- Petang → malam: **shakuhachi** panjang dan jarang, drone rendah halus; **taiko** hanya sebagai denyut jauh.
- Mengendap (stealth): musik hampir hilang; yang terdengar adalah napas, langkah (per permukaan: tanah, kayu, jerami, tatami, batu), kain, serangga malam.
- Bahaya: lapisan **adaptif** (stem) naik perlahan menurut `Suspicion`: ketukan rendah, senar `shamisen` staccato tipis; **tanpa jump-scare**, tanpa stinger keras.
- Festival (Obon, Setsubun, Hanami, Aki Matsuri): tema khas yang hangat dan ritmis, hanya saat festival.
- Momen emosional: sunyi lalu satu nada panjang.

### E5.2 Sistem audio (kode)
- Mixer dengan grup: `Master / BGM / Ambience / SFX / Voice / UI`, slider masing-masing + **bisu otomatis (ducking)** BGM −8 dB saat suara dialog. Default: BGM 55%, Ambience 70%, SFX 80%, Voice 100%.
- Adaptif: 3–4 stem per tema (dasar, ritme, ketegangan, harapan), crossfade 4–8 detik menurut `WorldClock`, `Weather`, `Suspicion`, `Wajah Asli`. Satu `AudioDirector` yang hanya membaca keadaan Sim.
- Pencegah kelelahan: variasi acak pitch ±3%, pemilihan klip tanpa pengulangan berurutan, jeda minimum antar-stinger.
- Aksesibilitas: setiap bunyi penting punya padanan visual (ikon arah), dan opsi mono, dan opsi "kurangi suara tiba-tiba".

### E5.3 Sumber aset (jujur soal hak cipta; ini proyek komersial)
- **Prototipe:** hasilkan sendiri secara prosedural dengan Python (NumPy): petikan senar (Karplus–Strong) untuk koto/biwa kasar, derau angin/air, denyut drum rendah, langkah per permukaan. Beri label `PLACEHOLDER` di nama berkas dan dalam `AUDIO_MANIFEST.csv`. Targetnya fungsi dan pencampuran, bukan kualitas akhir.
- **Final:** pilih salah satu atau kombinasi, dan catat bukti lisensi per berkas di `AUDIO_MANIFEST.csv` (judul, sumber, lisensi, tautan, tanggal akses, boleh-komersial ya/tidak, perlu-atribusi ya/tidak):
  a) komposer/perancang suara sungguhan (kontrak *work-for-hire/buyout* tertulis, penyerahan stem dan proyek);
  b) paket berlisensi komersial yang jelas (beli);
  c) CC0 (mis. koleksi domain publik) dengan bukti.
- **Jangan** memakai musik/SFX dari sumber yang tidak bisa dibuktikan lisensinya. **Jangan** memakai musik buatan generator AI untuk rilis komersial kecuali syarat lisensi layanan tersebut sudah dibaca dan dicatat (aturannya berubah-ubah; baca teksnya pada hari itu).
- Siapkan `AUDIO_BRIEF.md` untuk komposer: referensi suasana (tanpa menyalin karya), daftar tema (±8 komposisi inti + stem), durasi, format (WAV 48 kHz, loop-ready), dan anggaran perkiraan yang kamu hitung dengan asumsi eksplisit.

---

## E6. KARAKTER: DESAIN ANIME, 3D HIDUP, SUARA JEPANG ASLI

### E6.1 Prinsip
Kamu tidak dapat menghasilkan gambar atau suara dari dalam wadah ini tanpa layanan luar. Maka peranmu: **sutradara dan produser jalur kerja**, menyiapkan semua yang memungkinkan pengguna menghasilkan aset dengan alat yang ia punya (Gemini/generator gambar), lalu **mengintegrasikannya** ke Unity dengan benar. Jangan berpura-pura bisa menggambar atau mengisi suara. Jangan menjanjikan kualitas yang tidak dapat kamu buktikan.

### E6.2 Bible Karakter (tulis `CHARACTER_BIBLE.md` + `characters/*.json`)
Untuk 26 NPC + Sōma (tiga wajah: pedagang, shinobi, Wajah Asli), tiap karakter memuat: nama/pembacaan, peran, umur tampak, **siluet khas** (bentuk yang terbaca dalam bayangan), warna kunci (dari palet E4.1), kostum Omote & Ura, rambut, satu cacat/kebiasaan visual, **ekspresi dasar** (netral, senang, marah, sedih, curiga, malu, kaget), gaya gerak, nada suara, dan **arketipe emosi**.
**Ragam wajib** (jangan semuanya ganteng/cantik klise): *keren, seram, cantik, imut, datar (kūdere), ceria, konyol, tampan, tua bijak, pemalu, licik, garang berbaik hati.* Tabel sebaran yang tidak boleh dilanggar: tiap distrik punya setidaknya 2 arketipe berbeda; tidak ada dua karakter dengan siluet sama; rentang usia lebar (anak, remaja, dewasa, tua); keragaman bentuk tubuh. Hindari stereotip merendahkan; ini Jepang periode Sengoku, bukan parodi.
**Kontinuitas dengan sim:** sifat visual harus selaras dengan data (NPC pelit tidak berpakaian mewah tanpa alasan; hiasan sesuai ekonomi). Pelajari keluaran `SpeechHabit` dan `Attitude` di sim dan terjemahkan ke gerak/ekspresi.

### E6.3 Jalur gambar konsep (pengguna menjalankan, kamu menyiapkan)
- Buat **`PROMPT_PACK_KONSEP.md`**: untuk tiap karakter, prompt generator gambar yang konsisten (gaya satu arah: *anime watercolor-ink ukiyo-e hybrid, flat shading, garis tinta*), prompt negatif, tampilan depan/samping/belakang, lembar ekspresi 3×3, dan prompt "turnaround" untuk pemodelan. Sertakan kunci konsistensi (deskripsi baku wajah/rambut/kostum yang disalin persis ke tiap prompt) agar generator tidak mengubah wajah tiap kali.
- Sertakan **panduan kurasi untuk pengguna**: kriteria menerima/menolak gambar (tangan benar, siluet unik, palet sesuai, tidak meniru karakter berhak cipta; lihat aturan "jangan menggambar karakter yang sudah ada"), dan **folder penerimaan** (`incoming_concept/<id>/`) dengan skrip validasi (resolusi, rasio, nama berkas).
- Catat lisensi/ketentuan layanan pembuat gambar dalam `ASSETS_LICENSE.md` (baca ketentuan komersialnya pada hari itu; jangan mengasumsikan). Simpan prompt dan seed sebagai bukti asal.
- **Jangan** memakai gambar buatan generator yang menyerupai karakter berlisensi tertentu. Jika ada keraguan, tolak dan ulangi dengan prompt lain.

### E6.4 Dari gambar konsep ke 3D yang bisa berekspresi (jalur realistis, jujur)
Konversi gambar-ke-3D otomatis biasanya menghasilkan topologi buruk, wajah tak bisa berekspresi, dan tanpa rig. Itu yang membuat karakter "burik". Maka:
- **Jalur utama (dianjurkan): model berformat VRM** (humanoid + *expressions/blendshape* + *spring bone* untuk rambut dan kain). Dua cara membuatnya: (1) **VRoid Studio** (gratis; periksa syarat lisensi dan sumber bagian/tekstur *hari itu*, catat ke `ASSETS_LICENSE.md`; kustomisasi wajah, rambut, kostum, tekstur dari konsep), atau (2) memodelkan di Blender mengikuti spesifikasi VRM (artis 3D yang dipekerjakan). Kamu menulis spesifikasi 3D (`MODEL_SPEC_3D.md`): anggaran poligon (E3.3), jumlah tulang, daftar *expression* wajib (`Neutral, Happy, Angry, Sad, Surprised, Relaxed, Suspicious(kustom), Embarrassed(kustom), Blink L/R`, dan visem `aa ih ou ee oh` untuk sinkronisasi bibir), penamaan, tekstur (atlas 1K–2K), material toon MToon/URP.
- **Integrasi di Unity (kode yang kamu tulis):** pemuat VRM, `CharacterExpressionController` (menerjemahkan keadaan emosi sim → ekspresi + mikro-gerak: kedipan acak, mata mengikuti titik minat, napas, goyangan kepala), `LipSyncFromAudio` (visem dari klip suara, mode ringan untuk Android), `GestureLibrary` (animasi tubuh), `LookAtTarget`. Semuanya digerakkan dari **keadaan sim** (sikap NPC terhadap Sōma, keyakinannya, rasa curiganya) sehingga ekspresi bermakna, bukan hiasan.
- **Animasi tubuh:** gunakan pustaka animasi berlisensi jelas (mis. layanan animasi humanoid atau paket yang dibeli) lewat *retarget Humanoid*; tulis daftar gerakan wajib (jalan, lari, mengendap, memanjat, berdiri-diam bernapas, bicara bergesture beragam ×6, berdagang, menawar, ditolak, terkejut, mengangkat tangan, tunduk, menghormat, mengintai, menyergap, jatuh). Catat lisensi tiap paket. Animasi kecil khas karakter (tertawa konyol, batuk kakek) menambah kehidupan lebih besar daripada tambahan poligon.
- **Ekspresi yang hidup bukan ber-"loop":** gunakan *lapisan* (layer): dasar emosi + kedipan + gerak mata + napas + reaksi sesaat terhadap peristiwa. Hindari wajah beku saat bicara.
- Sediakan **"Model Uji" satu karakter** (dari VRoid atau model contoh berlisensi jelas) untuk memverifikasi seluruh rantai (pemuat, ekspresi, lip-sync, performa Android) sebelum mengejar semua 27 karakter.

### E6.5 Suara: pengisi suara orang Jepang asli
- **Tidak memakai suara sintetis sebagai suara final.** Untuk rilis, gunakan pengisi suara sungguhan, via kontrak tertulis. Siapkan:
  - `VOICE_CASTING.md`: untuk tiap karakter, deskripsi suara (rentang usia, warna, tempo, aksen: Sengoku/era lampau yang terbaca wajar, bukan anime moderen berlebihan), contoh arah akting, dan 2–3 baris audisi.
  - `VOICE_SCRIPT.csv`: kolom `id, karakter, situasi, teks_jepang, romaji, terjemahan_indonesia, arahan_emosi, durasi_maks, visem_perlu(ya/tidak)`. **Naskah Jepang harus diperiksa oleh penutur asli** (pengguna harus mencari pemeriksa) sebelum rekaman; tandai kolom `diperiksa_penutur_asli: BELUM`. Jangan memalsukan keyakinan akan ketepatan bahasa.
  - Prioritaskan **"bark" dan kalimat pendek** (sapaan, tawar, kaget, marah, takut, bisikan, tawa, batuk, napas) ±40–60 baris per karakter utama dan ±10–15 per NPC kecil. Percakapan panjang tetap berupa teks Indonesia dengan **gumaman/bark bersuara** (gaya yang lazim dan hemat). Teks selalu ada sebagai subtitle.
  - `VOICE_CONTRACT_CHECKLIST.md`: butir yang wajib ada dalam kontrak dengan pengisi suara (cakupan komersial seluruh dunia, platform termasuk Android/Windows, jangka waktu/selamanya, hak edit/pemotongan, kredit, penggunaan pada sekuel/promosi, larangan pelatihan model AI dari suara tanpa izin eksplisit, penyerahan berkas mentah, tarif per baris/menit). Sarankan pengguna berkonsultasi dengan ahli hukum; **kamu bukan penasihat hukum**.
  - Anggaran: hitung perkiraan biaya dari jumlah baris dan durasi dengan asumsi tarif yang kamu tunjukkan jelas (rentang), tanpa menyebutnya "harga pasti".
- **Untuk prototipe saja:** boleh memakai suara sintetis sebagai *penanda posisi* (placeholder) agar lip-sync, mixer, dan ducking bisa diuji. Namai `VO_PLACEHOLDER_*`, sebutkan batasannya, dan jangan dimasukkan ke paket yang diuji orang sebagai "suara final".
- Sistem di Unity: `VoiceBarkPlayer` (pilih baris menurut emosi + keyakinan + hubungan; cooldown agar tak berulang), dengan jalur ganti suara tanpa membangun ulang (tabel `id → klip`).

---

## E7. NAMA & NARASI

- **Nama:** pertahankan **KAGE-ANA (影穴)**. Alasan: ringkas, memuat bayangan + lubang/lorong persembunyian (relevan dengan kelompok, dead drop, dan Sōma), dan tidak lebay. Alternatif yang saya timbang (*Kage no Akindo* 影の商人 "pedagang bayangan") terlalu menjelaskan dan membuka seluruh premis di judul. **Subjudul untuk toko aplikasi (opsional):** *"Pedagang di siang hari. Bayangan di malam hari."* **Tugasmu:** buat daftar pemeriksaan nama (pencarian toko aplikasi, Steam, domain, merek dagang) sebagai `NAME_CHECK.md` untuk dijalankan pengguna. Jangan mengklaim "tidak ada pesaing bernama sama" tanpa bukti.
- **Narasi:** kekuatan terbesar proyek bukan jalan cerita yang panjang, tetapi *rahasia ganda yang tipis dan manusiawi*. Saran:
  - Sōma adalah orang yang *terlalu pandai membaca orang* karena pekerjaannya, dan itu membuatnya kesepian. Biarkan satu atau dua orang di desa (Muraku? O-Hana? Suzu?) *hampir* mengenalnya, tanpa pernah menjadi pahlawan. Ketegangannya adalah "berapa lama aku dapat menjaga dua kehidupan tanpa menyakiti orang yang kusayangi?"
  - Setiap Nisshi harus menyebut *harga emosional* di samping kejadian: "Kau mengirim kabar yang benar. Orang yang salah yang membayarnya."
  - Moralitas abu-abu: kabar yang kau bawa ke kelompok kadang menghancurkan orang baik. Tunjukkan satu akibat per bulan yang bisa dilacak kembali ke tindakan pemain.
  - Jangan menjelaskan lore lewat dialog panjang. Tempatkan petunjuk pada benda dan tempat (papan pengumuman, tagihan, surat yang robek).
- **Pertanyaan A.7 tetap milik pengguna.** Sampai dijawab, semuanya memakai `TEMP_`. Susun versi "formulir pendek" A.7 (maks. 5 pilihan ganda + isian) yang dapat dijawab pengguna dalam 10 menit.

---

## E8. INPUT: GAMEPAD, SENTUH, KEYBOARD+MOUSE (satu abstraksi)

Pengguna menyebut gamepad "sudah di-setup", tetapi di paket Gelombang D ia **hanya ada di lab WebGL lama dan skrip lama**. Anggap belum ada di jalur produk dan bangun benar.
- **Unity Input System** dengan `ActionMap` tunggal: `Gerak, Kamera, Interaksi, Tanya/Bicara, Mengendap, Lari, Sembunyi, BukaNisshi, Menu, Konfirmasi, Batal, Fokus(bidik pandang), WajahAsli, TindakanKhusus`. Tiga skema kontrol: Gamepad (Xbox/PlayStation/Switch Pro; deteksi otomatis dan label tombol menyesuaikan perangkat), Keyboard+Mouse, **Sentuh** (joystik virtual kiri, geser kanan untuk kamera, tombol aksi kontekstual satu jari; ukuran dan posisi dapat diatur; opsi kidal).
- **Pengalihan otomatis** skema saat perangkat terakhir berubah; petunjuk UI berganti ikon.
- Menu dan panduan harus dapat dinavigasi penuh dengan gamepad (fokus yang jelas, urutan navigasi logis, tanpa kursor wajib), dan penuh dengan sentuh.
- Getaran (rumble) halus: debar saat curiga, ketukan saat berhasil. Opsi mati-kan; tidak pernah dipakai untuk kejutan keras.
- Bluetooth dan USB: tidak ada kode khusus; Input System menangani perangkat. Sediakan `CARA_KONTROLER.md`: pemasangan Bluetooth di Android dan Windows, mode yang benar untuk tiap pengontrol, dan pemecahan masalah umum. Uji dengan Input Debugger; tulis daftar perangkat yang *belum diuji* secara jujur.
- Uji otomatis yang bisa dijalankan tanpa perangkat: simulasi input via `InputTestFixture` (EditMode/PlayMode) untuk setiap aksi pada ketiga skema.

---

## E9. ANDROID: APK (pengaturan alat mandiri, dengan batas yang jujur)

Kamu tidak dapat membangun APK di sini (tanpa Unity, tanpa Android SDK, tanpa internet). Maka kamu menyiapkan **otomatisasi yang berjalan di PC Windows pengguna**, dan semua klaim "berhasil" hanya boleh ditulis oleh skrip itu *setelah ia benar-benar menghasilkan berkas*.

### E9.1 Skrip pemasang alat: `SIAPKAN_ALAT_ANDROID.ps1` (+ pembungkus `.bat`)
Idempoten dan aman bila diulang; setiap langkah mencetak "LANGKAH n/N" dan berhenti dengan pesan jelas bila gagal:
1. Periksa Windows 10/11 64-bit, ruang disk (≥ 30 GB), RAM, dan koneksi. Tampilkan perkiraan ukuran unduhan dan **minta persetujuan pengguna** sebelum mengunduh.
2. Periksa/pasang **Unity Hub** (lewat `winget install` jika tersedia; jika tidak, tunjukkan halaman unduhan resmi dan hentikan dengan instruksi). Pasang editor **versi persis dari `ProjectVersion.txt`** dengan modul **Android Build Support + OpenJDK + Android SDK & NDK Tools** lewat antarmuka baris perintah Unity Hub (`-- --headless install ...`; periksa sintaks terbaru dari dokumentasi resmi lewat pencarian, jangan dari ingatan).
3. Aktivasi lisensi: Unity Personal memerlukan akun dan masuk lewat Hub. Skrip **tidak boleh menyimpan atau meminta kata sandi**; ia memberi tahu pengguna untuk masuk lewat Hub sekali, lalu melanjutkan. Jangan mencoba mengakali lisensi.
4. Keluaran: `HASIL_SIAPKAN_ALAT.txt` (versi, jalur, status tiap langkah).

### E9.2 Skrip bangun APK: `BUAT_APK.bat` → `Editor/BuildScripts/AndroidBuild.cs`
- `Unity.exe -batchmode -nographics -quit -projectPath ... -executeMethod KageAna.Editor.AndroidBuild.BuildDebugApk -logFile build_android.log` (periksa sintaks terkini dari dokumentasi).
- Pengaturan: IL2CPP, ARM64 (+ ARMv7 opsional), Min API sesuai Unity 6 (periksa nilai terbaru dari dokumentasi), Vulkan/OpenGLES3 otomatis, ASTC, `Application.targetFrameRate=30`, orientasi lanskap, ukuran APK dilaporkan.
- **Penandatanganan:** buat *keystore* debug lokal otomatis (`debug.keystore`, kata sandi acak disimpan di berkas lokal yang di-ignore Git) hanya untuk APK uji. Untuk rilis toko, tulis `RILIS_ANDROID.md` (keystore produksi disimpan pengguna sendiri, **AAB** untuk Google Play, Play App Signing); jangan membuat atau menyimpan kunci produksi.
- Setelah bangun, skrip memeriksa: berkas `.apk` ada dan > 0 byte, menghitung SHA-256, mencetak jalur, dan jika `adb` tersedia menawarkan `adb install -r`. Jika tidak, jelaskan cara menyalin APK ke ponsel dan mengizinkan "pasang dari sumber tidak dikenal" **untuk satu aplikasi pengelola berkas saja**, lalu mematikannya kembali.
- `CARA_UJI_ANDROID.md` (1 halaman): pasang APK, izin, kontroler Bluetooth, di mana log berada, cara mengirim laporan (menu "Kirim laporan uji" mengemas log + rekaman sesi ke penyimpanan yang dapat dibagikan lewat *share sheet*).
- Jalur otomatis cadangan: `.github/workflows/android.yml` (GameCI `unity-builder`, memerlukan lisensi Unity melalui *secrets*). Tandai "BELUM PERNAH DIJALANKAN" dan jelaskan keterbatasan lisensi.

### E9.3 Ketentuan Android lain
- Penyimpanan data game di `Application.persistentDataPath`; **tidak meminta izin yang tidak perlu**; tidak ada jaringan.
- Pemantau panas/baterai: sediakan opsi 30 fps dan "mode hemat" (kurangi bayangan dan partikel).
- Uji pada 2 profil sintetis di Editor (Device Simulator) untuk tata letak UI; daftar perangkat nyata yang belum diuji dicatat jujur.

---

## E10. URUTAN KERJA, GERBANG, DAN LAPORAN

1. **E1** (portabilitas sim + bukti Windows) → 2. **E2** (perbaikan sim; lalu dibekukan) → 3. **E8** (abstraksi input) dan **E3.1/E3.3** (struktur proyek Unity + anggaran) → 4. **E4 & E5** (palet/efek/audio prosedural) pada irisan vertikal **E3.2** dengan karakter *placeholder berbentuk kapsul* dulu → 5. **E6** (bible karakter, paket prompt, spesifikasi 3D, kode integrasi VRM dengan Model Uji) → 6. **E9** (alat & skrip APK) → 7. **E7** (naskah dan formulir A.7).
Alasan urutan: sim yang bersih dulu → arsitektur yang menjaga hash → presentasi dengan placeholder → aset mahal (karakter, suara) terakhir, saat jalur teknis terbukti.

**Aturan umum:** semua pemeriksa/penjaga baru punya tes negatif · CI tetap hijau · label kejujuran ("terverifikasi via terjemahan, BUKAN kompilator C#/Unity asli") · setiap aset punya baris lisensi · tidak ada kata terlarang di teks paket (Sandbox tetap berlabel "Sandbox Uji Sistem") · tidak ada karakter/aset yang meniru karya berhak cipta · `DECISIONS.md` mencatat tiap keputusan beserta alasannya terhadap Uji Hidup · ide di luar cakupan masuk `IDEAS.md`.

**Keluaran akhir (satu balasan, lalu BERHENTI):**
- Paket baru `KageAna_Gelombang_E` (zip).
- `LAPORAN_E.md`: sebelum/sesudah E2 dengan metrik anti-pengisi; 5 cerita baru dari log (ID kejadian); bukti hash/CI; apa yang dikerjakan di E3–E9 dan **apa yang BELUM terbukti** (Unity belum dibuka, APK belum dibangun, VRM belum dimuat, audio belum didengar, gamepad belum dipegang).
- Daftar tugas yang **hanya bisa dikerjakan pengguna** (urut prioritas, dengan perkiraan waktu): menjalankan `BUAT_INSTALLER.bat`; memasang Unity lewat `SIAPKAN_ALAT_ANDROID.ps1`; membuat gambar konsep dari `PROMPT_PACK_KONSEP.md`; menyiapkan satu model VRM uji; mencari pemeriksa bahasa Jepang dan pengisi suara; menjawab A.7; memeriksa nama.
- Bagian "apa yang masih lemah menurutmu" yang jujur.
