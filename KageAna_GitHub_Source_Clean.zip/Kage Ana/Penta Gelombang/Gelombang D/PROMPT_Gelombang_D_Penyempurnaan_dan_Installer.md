Gelombang C diterima sebagai KANDIDAT, BUKAN Gerbang 1. Pekerjaan berikutnya: membuat dunia
menghasilkan cerita yang BERARTI dan TERBACA oleh manusia. Kamu bebas merancang solusi terbaik
dan berimprovisasi; setiap keputusan desain dicatat singkat di DECISIONS.md beserta alasannya
terhadap tiga pertanyaan Uji Hidup. Jangan membangun fitur di luar tujuan di bawah (taruh di IDEAS.md).
Jika pengguna mengirim hasil_bangun.txt berisi error kompilasi, itu prioritas pertama.

TUJUAN UTAMA: seseorang yang bermain 20-45 menit dapat menceritakan satu kejadian spesifik yang tak
dirancang, tanpa kamu memberinya petunjuk.

KERJAKAN (urutan prioritas; kamu boleh menggabungkan atau menambah bila lebih baik):

1. KEBERMAKNAAN (SALIENCE). Beri tiap kejadian/ingatan skor kebermaknaan (kebaruan terhadap rutinitas,
   pelanggaran harapan, taruhan uang/nyawa/hubungan, rahasia, kedekatan dengan pendengar). Hal
   rutin hanya beredar lokal dan cepat pudar; hal bermakna menyebar jauh dan bertahan. Tabel
   penyebaran, peluruhan, dan ambang di JSON tuning. Bukti: distribusi topik rumor sebelum/sesudah,
   dan persentase rumor yang menyangkut kejadian non-rutin.

2. AGENSI: KEYAKINAN -> NIAT -> TINDAKAN. NPC bertindak atas keyakinannya (termasuk keyakinan yang
   keliru): menghindar, melapor ke penjaga, menaikkan/menurunkan harga, menolak melayani,
   mengonfrontasi, menutupi, membantu, menyebarkan lebih jauh. Tindakan itu memancarkan WorldEvent
   baru (sumber keadaan nyata) sehingga memicu orde kedua dan ketiga. Sertakan kasus salah
   paham (keyakinan salah menyebabkan tindakan salah). Bukti: >=5 rantai dengan akibat perilaku yang
   dapat dilihat Sōma, ditelusuri ID kejadiannya.

3. KEPADATAN HIDUP. Naikkan interaksi bermakna antar-NPC (percakapan, transaksi, bantuan, pertengkaran,
   kunjungan, tagihan). Target awal: >=8 interaksi per NPC per hari game, dengan LOD agar sim 28 hari
   tetap cepat di headless. Laporkan kejadian per hari sebelum/sesudah dan waktu eksekusi.

4. TEKANAN HIDUP & KESEIMBANGAN. Biaya hidup sungguhan (sewa, makan, pajak festival). Sōma yang diam
   tidak boleh aman: tunggakan sewa -> sikap Ohana -> ancaman pengusiran; pesanan kelompok terlewat
   -> Kepercayaan turun -> terputus. JANGAN jadikan game over: konsekuensi dan jalan lanjut.
   Hati tidak boleh jenuh oleh rutinitas: pengembalian menurun, perubahan besar hanya dari
   tindakan bermakna. Sesuaikan ekonomi agar tiap kebijakan menghasilkan lintasan berbeda dan
   menarik. Laporkan kurva uang/Hati/kecurigaan 28 hari per kebijakan.

5. NISSHI YANG BERARTI. 12-20 butir terkurasi per tahun, dipilih menurut dampak pribadi pada Sōma,
   kebermaknaan, dan keragaman (bukan 100+ butir). Kebijakan Idle harus menghasilkan Nisshi yang
   mencerminkan tunggakan/penurunan, bukan trivia NPC. Tulis dalam kalimat yang enak dibaca.

6. KETERBACAAN UNTUK MANUSIA (Sandbox). Orang asing harus bisa mengikuti cerita tanpa membaca kode:
   a) "Kisah Hari Ini": umpan kalimat biasa tentang hal yang sedang terjadi di dekat/berdampak pada Sōma,
      dengan tautan "mengapa" ke saksi dan sumbernya;
   b) bertanya pada NPC menghasilkan dialog diegetik: apa yang ia tahu, dari siapa, seberapa yakin;
   c) petunjuk awal tanpa modal (kartu 1 layar yang bisa ditutup + sorotan tempat menarik);
   d) kebijakan otomatis tidak lagi jadi cara bermain utama: mode manual adalah default, kebijakan
      adalah alat uji di menu pengembang.
   Rencanakan sesi pilot: tambahkan perekam sesi sederhana (jalur Sōma, tombol yang dipakai, kejadian yang
   disorot) ke berkas lokal agar saya dapat mengirimnya.

7. PROTOKOL UJI ANEKDOT v2. Tulis ulang docs/UJI_ANEKDOT.md: Pertanyaan pertama TANPA GIRING
   ("Ceritakan satu kejadian yang kamu ingat"); pertanyaan lain hanya SETELAH jawaban itu dicatat;
   kriteria lulus disederhanakan: kisah spesifik, dari pengalamannya sendiri, tak diarahkan, dan dapat
   dicocokkan ke log (rantai >=3 kejadian dicek oleh penilai, BUKAN dituntut diingat penguji).
   Sertakan PILOT 2 orang (20 menit) sebelum 5 orang, lembar catatan kebingungan, dan cara
   penilaian buta (penilai mencocokkan cerita ke log tanpa tahu kebijakan).

8. KESEHATAN KODE. Pecah SimPerceptionMemoryRumorSystem.cs (1884 baris) menjadi modul terpisah
   (EventBus/log, Persepsi, Ingatan, Rumor, Agensi, Ekonomi, Kecurigaan, Gig, Kisah, Festival,
   TindakanSoma, Nisshi) dengan antarmuka jelas dan tes per modul. Hash seed tidak boleh berubah
   karena refactor murni; jika berubah karena perubahan perilaku, jelaskan. Pertahankan Sim tanpa
   UnityEngine.

ATURAN: Kitab Bagian 1 dan Lampiran A tetap berlaku; pemeriksa/penjaga baru wajib punya tes negatif;
label "terverifikasi via terjemahan, BUKAN kompilator C# asli" tetap sampai pengguna mengirim bukti
dotnet; laporan jujur berisi daftar "belum dijalankan". Bagian [ISI-PENGGUNA] tetap TEMP_.

=====================================================================
TAHAP AKHIR (KERJAKAN SETELAH BUTIR 1-8 SELESAI DAN LULUS CI):
9. INSTALLER "PASANG LALU LANGSUNG JALAN" UNTUK UJI COBA
=====================================================================
Tujuan: pengguna (awam, Windows 10/11 64-bit, TANPA .NET/Unity/Python terpasang) mengklik SATU berkas
Setup, menekan Berikutnya beberapa kali, lalu aplikasi Sandbox Uji Sistem LANGSUNG terbuka dan siap diuji.
Tidak boleh ada langkah manual lain, tidak boleh ada jendela hitam yang membingungkan.

Kamu tidak bisa membangun/menjalankan Windows di sini. Maka kerjakan begini dan JUJUR soal batasnya:

9.1 SATU PERINTAH BANGUN DI PC PENGGUNA: `BUAT_INSTALLER.bat` (klik ganda). Isinya berurutan, setiap langkah
    mencetak "LANGKAH n/N: ..." dan berhenti dengan pesan jelas bila gagal (jangan pernah mencetak BERHASIL
    kalau berkas keluaran tidak benar-benar ada dan ukurannya > 0; periksa dengan kode keluar + cek berkas):
    a) cek `dotnet --version` (>= 8); jika tidak ada, cetak tautan unduh SDK .NET 8 dan berhenti;
    b) jalankan tes sim ringkas (`--selftest`, lihat 9.3); gagal = berhenti;
    c) `dotnet publish` Sandbox: Release, win-x64, SELF-CONTAINED, SATU BERKAS (PublishSingleFile,
       IncludeNativeLibrariesForSelfExtract, tanpa trimming agresif yang merusak WinForms), sehingga
       komputer penguji TIDAK perlu memasang .NET;
    d) salin hasil + data JSON + CARA_UJI_COBA.md + ikon ke folder `staging/`;
    e) bangun Setup.exe memakai Inno Setup jika `ISCC.exe` ditemukan (cek PATH, lalu
       `%ProgramFiles(x86)%\Inno Setup 6\`, lalu `%ProgramFiles%\Inno Setup 6\`);
       FALLBACK 1 jika tidak ada Inno Setup: bangun `KageAna_Pasang.exe` memakai IExpress (bawaan Windows,
       `iexpress.exe /N /Q berkas.sed`) yang mengekstrak lalu menjalankan `pasang.cmd` tersembunyi;
       FALLBACK 2: ZIP portabel berisi `Jalankan_Sandbox.bat` (cukup ekstrak lalu klik ganda).
       Cetak jelas jalur mana yang dipakai.
    f) hitung SHA-256 setiap keluaran ke `HASIL_BANGUN.txt` (+ versi, tanggal, versi dotnet, jalur yang dipakai,
       kode keluar tiap langkah), dan tampilkan ringkasan di akhir.
    Keluaran akhir: `Keluaran/KageAna_Sandbox_Uji_Setup.exe` (atau fallback), plus `HASIL_BANGUN.txt`.

9.2 INSTALLER (skrip Inno Setup `installer/KageAna.iss`, direvisi dari yang lama dan DIKOREKSI bila ada bug):
    - Halaman bahasa Indonesia; teks semuanya ramah awam. Judul: "Kage-Ana: Sandbox Uji Sistem".
      WAJIB patuhi aturan CI: jangan memakai kata terlarang ("playable", "build final", "game") di teks paket.
    - Pasang ke `%LOCALAPPDATA%\Programs\KageAna` dengan hak pengguna biasa (PrivilegesRequired=lowest;
      TIDAK meminta admin). Buat pintasan Start Menu + opsional Desktop.
    - Halaman terakhir: kotak centang "Jalankan Sandbox Uji Sistem sekarang" DICENTANG SECARA BAWAAN
      (`[Run] ... Flags: postinstall nowait skipifsilent`), dan "Buka petunjuk uji coba (1 halaman)" juga
      dicentang. Mode senyap (`/SILENT`) harus langsung menjalankan aplikasi juga lewat parameter yang jelas.
    - Uninstaller bersih; data sesi pengguna di `%LOCALAPPDATA%\KageAna\Sesi` TIDAK dihapus tanpa bertanya.
    - Penanganan upgrade: pasang ulang di atas versi lama tanpa kehilangan rekaman sesi.
    - Metadata versi, AppId tetap, ikon (buat ikon sederhana asli buatanmu, tanpa aset berhak cipta).
    - Catat di CARA_UJI_COBA.md: berkas tidak bertanda tangan digital, Windows SmartScreen dapat menampilkan
      "Windows protected your PC": klik "More info" lalu "Run anyway" (jelaskan dengan bahasa awam bahwa ini
      karena pembuatnya perorangan, bukan karena berbahaya, dan sarankan memeriksa SHA-256 dari HASIL_BANGUN.txt).

9.3 APLIKASI SIAP-INSTAL (perubahan pada Sandbox):
    - `--selftest`: jalankan simulasi headless 3 hari game dengan seed tetap, periksa invarian dasar, tulis
      hasil ke `%LOCALAPPDATA%\KageAna\selftest.txt`, keluar dengan kode 0/1 TANPA membuka jendela.
    - Saat start pertama: jendela utama muncul dalam waktu wajar; kartu petunjuk 1 layar (butir 6c) tampil;
      mode manual adalah default (butir 6d).
    - Penanganan galat global: pengecualian tak tertangani ditulis ke `%LOCALAPPDATA%\KageAna\Log\galat_*.txt`
      dan penguji melihat kotak pesan sopan berbahasa Indonesia ("Terjadi masalah. Berkas laporan ada di ...
      Kirimkan berkas itu kepada pembuatnya."), BUKAN tumpukan jejak mentah.
    - Menu "Bantuan": "Kirim laporan uji" -> mengemas rekaman sesi (butir 6) + log galat + info sistem
      (versi Windows, versi aplikasi, hash data) menjadi satu ZIP di Desktop, lalu membuka folder itu.
      JANGAN menyertakan data pribadi (nama pengguna Windows, jalur penuh) tanpa disamarkan.
    - Judul jendela memuat versi dan 8 karakter pertama hash bangun supaya laporan bisa dicocokkan.
    - Hanya satu instans berjalan (mutex); instans kedua memunculkan jendela pertama.
    - Pastikan berjalan di layar 1366x768 dan skala DPI 125%/150% (tidak ada kontrol terpotong).

9.4 JALUR ALTERNATIF OTOMATIS (bukan pengganti 9.1): sediakan `.github/workflows/installer.yml` yang di
    windows-latest menjalankan langkah yang sama (publish + Inno Setup via choco) dan mengunggah Setup.exe
    sebagai artefak. Tandai "BELUM PERNAH DIJALANKAN"; pengguna belum memakai GitHub, jadi ini opsional.

9.5 PENGUJIAN PADA INSTALLER (sebisanya di sini, dan beri label jujur):
    - Tes statis: parse `.iss`/`.sed`, pastikan semua berkas yang dirujuk ada di `staging/`, tidak ada jalur
      absolut milik mesin lain, tidak ada kata terlarang di string pengguna.
    - Tes negatif: hapus satu berkas data dari staging -> pemeriksa harus menolak; ganti versi tanpa ubah
      AppId -> pemeriksa memperingatkan.
    - CI menambah pemeriksaan "installer-lint" dengan tes negatifnya.
    - Daftar "BELUM DIJALANKAN DI WINDOWS ASLI": publish, Inno Setup/IExpress, instalasi, SmartScreen,
      peluncuran otomatis pascapasang, uninstall, DPI. Tulis juga langkah verifikasi 10 menit untuk
      pengguna (centang demi centang) dan apa yang harus dikirim balik jika ada yang gagal.

9.6 `CARA_UJI_COBA.md` (1 halaman, tanpa istilah teknis) diperbarui: 1) klik dua kali Setup, 2) abaikan/izinkan
    peringatan SmartScreen (gambar langkah dalam teks), 3) biarkan kotak "Jalankan sekarang" tercentang,
    4) mainkan 20 menit tanpa bantuan, 5) Bantuan -> Kirim laporan uji, 6) kirim ZIP ke pembuat.
    Sertakan satu baris "Jika aplikasi tidak terbuka / macet, lakukan ini" dengan lokasi log.

=====================================================================
KELUARAN AKHIR
=====================================================================
Paket "Gerbang 1 Pilot" berisi: kode sumber lengkap; BANGUN_PAKET.bat; BUAT_INSTALLER.bat; installer/ (.iss,
.sed, skrip pasca-pasang); Jalankan_Sandbox.bat (portabel); CARA_UJI_COBA.md; docs/UJI_ANEKDOT.md v2;
DECISIONS.md; IDEAS.md. Laporan: sebelum/sesudah butir 1-8; hasil/uraian butir 9 termasuk jalur bangun yang
tersedia dan apa yang TIDAK terbukti; contoh 5 cerita (paragraf pendek + ID kejadian); bagian "apa yang
masih lemah menurutmu" yang jujur; daftar "BELUM DIJALANKAN". STOP setelah laporan. Jangan membuat fitur
di luar butir 1-9.
