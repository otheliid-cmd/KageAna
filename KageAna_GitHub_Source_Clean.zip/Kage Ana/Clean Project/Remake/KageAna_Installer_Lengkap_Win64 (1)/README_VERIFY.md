# KAGE-ANA v3.0 — Verifikasi Lokal Kompilator C# Asli (`dotnet test` & `dotnet run`)

Sesuai **Keputusan Arsitektur C-07** dan **Perbaikan L1(a)–(b)**:
- Seluruh kode simulasi (`WorldClock`, `WeatherSystem`, `SimRandom`, `NoFreeKnowledgeGuard`, `HeadlessSimRunner`) dan unit test (`ClockAndWeatherSimTests`) ditulis **satu kali** dalam C# murni di bawah:
  - `unity_project/Assets/_Project/Runtime/Sim/**/*.cs`
  - `unity_project/Assets/_Project/Tests/EditMode/ClockAndWeatherSimTests.cs`
- Berkas proyek NUnit `unity_project/KageAna.Sim.Tests.csproj` dan berkas CLI `unity_project/KageAna.Sim.csproj` me-*link* (`<Compile Include="..." Link="..." />`) berkas-berkas `.cs` yang **sama persis** tanpa duplikasi kode.
- Di lingkungan container CI asisten, `dotnet` tidak terpasang sehingga seluruh hasil eksekusi di container diberi label **"terverifikasi via terjemahan, BUKAN kompilator C# asli"**. Kami tidak membangun sistem C# baru di atas penerjemah ini sampai Anda memverifikasinya dengan `dotnet` asli di mesin Anda.

## 1. Perintah Persis untuk Menjalankan Unit Test NUnit (`dotnet test`)

Jalankan perintah berikut dari akar repositori pada mesin Anda (memerlukan .NET 8 SDK):

```bash
dotnet test unity_project/KageAna.Sim.Tests.csproj --logger "console;verbosity=detailed"
```

### Yang Akan Diverifikasi oleh `dotnet test`:
1. `Test_Clock_10Hz_18RealMinutesPerDay_And_28DayEventCounts`: Memastikan `10 Hz`, `1 hari = 18 menit nyata = 10.800 tick`, `4` lonceng kuil per hari (`112` dalam 28 hari), tepat `28` `OnDayStart` (bukan 29), tepat `4` `OnSeasonChange` (bukan 5), `672` `OnHour`, dan `9` festival/peristiwa terjadwal.
2. `Test_DaySegments_Transitions`: Memastikan transisi 7 segmen waktu (`Dawn`, `Morning`, `Noon`, `Afternoon`, `Dusk`, `Night`, `LateNight`).
3. `Test_Calendar28Days_FourSeasons_And_Festivals`: Memastikan kalender 28 hari / 4 musim (`Spring` 1–7, `Summer` 8–14, `Autumn` 15–21, `Winter` 22–28) dan jadwal festival.
4. `Test_Weather_And_LightingPreset_Determinism`: Memastikan determinisme cuaca per seed, larangan `Snow` di luar `Winter`, dan resolusi `LightingPresetData`.
5. `Test_Weather_MaxStreak_AtMost3Days_UnlessWeightsForceSingleWeather`: Memastikan pada `seed 1..20 x 28 hari` tidak ada cuaca berturut-turut `> 3 hari` pada tabel bobot normal, tetapi mengizinkan `> 3 hari` apabila tabel bobot musim menghendaki 100% cuaca tunggal.
6. `Test_NoFreeKnowledgeGuard`: Memastikan invarian *No Free Knowledge* (`violations == 0` untuk fakta yang disaksikan, `violations == 1` untuk fakta tanpa saksi/rumor).
7. `Test_Print_Deterministic_Hash_For_User_Dotnet_Verification`: Mencetak baris `[DOTNET_VERIFY] SEED_7_28DAY_SIM_JSON={...}` yang memuat `"deterministicHash"` untuk `seed = 7` (28 hari).

## 2. Perintah Persis untuk Menjalankan Simulasi Headless 28 Hari (`dotnet run`)

Untuk langsung mencetak laporan JSON dua kali jalan (`run1` dan `run2`) pada `seed = 7` (28 hari):

```bash
dotnet run --project unity_project/KageAna.Sim.csproj -- --seed 7 --days 28
```

## 3. Hash Acuan (Terverifikasi via Terjemahan di Container — Mohon Cocokkan dengan Output `dotnet` Anda)

- **Seed `7` (28 Hari, `302.400` tick)**: `deterministicHash = "9966aca7bc76c555"`
