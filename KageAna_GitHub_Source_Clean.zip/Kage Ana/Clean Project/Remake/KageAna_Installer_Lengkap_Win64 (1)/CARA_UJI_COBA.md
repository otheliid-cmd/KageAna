# CARA UJI COBA (1 Halaman — Tanpa Istilah Teknis)
**Kage-Ana — Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)**

Selamat datang! Anda tidak perlu memasang program tambahan apa pun di komputer Windows 10/11 Anda. Cukup ikuti 6 langkah singkat di bawah ini:

### 1. Klik Dua Kali Berkas Pemasang (`KageAna_Sandbox_Uji_Setup.exe`)
Unduh atau buka folder paket, lalu klik dua kali pada berkas **`KageAna_Sandbox_Uji_Setup.exe`** (atau jika Anda menerima berkas `KageAna_Pasang.exe` / folder ZIP portabel, klik dua kali berkas tersebut).

### 2. Jika Muncul Layar Biru Windows SmartScreen, Izinkan Jalan
Karena aplikasi uji coba ini dibuat oleh pengembang perorangan dan belum membeli sertifikat tanda tangan digital komersial, Windows mungkin menampilkan jendela biru **"Windows protected your PC"**. Ini **bukan** karena berkas berbahaya. Lakukan langkah berikut:
```text
+-------------------------------------------------------+
| Windows protected your PC                             |
| Microsoft Defender SmartScreen prevented an           |
| unrecognized app from starting.                       |
|                                                       |
| [>> Klik tulisan "More info" (Info selengkapnya) <<]  |
|                                                       |
|          [ >> Lalu klik tombol "Run anyway" << ]      |
+-------------------------------------------------------+
```
*(Tips keamanan tambahan: Anda juga dapat mencocokkan kode unik SHA-256 berkas Setup dengan angka yang tertulis di dalam berkas `HASIL_BANGUN.txt`).*

### 3. Biarkan Kotak "Jalankan Sekarang" Tercentang
Tekan tombol **Berikutnya (Next)** hingga selesai. Pada halaman terakhir pemasang, biarkan kotak **"Jalankan Sandbox Uji Sistem sekarang"** tetap tercentang, lalu klik **Selesai (Finish)**. Jendela utama aplikasi akan langsung terbuka otomatis.

### 4. Coba Sendiri Selama 20 Menit Tanpa Bantuan
* Di dalam aplikasi, Anda berperan sebagai **Shinonome Soma** (pedagang keliling di Lembah Kurokawa).
* **Klik Kanan** pada lingkaran tempat di peta (atau tekan tombol arah **W / A / S / D**) untuk berjalan ke tempat yang disorot lingkaran emas (seperti Pasar Kaki Kastil atau Kedai Teh).
* **Klik Kiri** pada titik warga di peta, lalu tekan tombol **"Tanya NPC (Dialog)"** atau **"Berdagang"**, dan amati cerita yang muncul di kotak **"1. KISAH HARI INI"** di sebelah kanan.
* Anda bebas mencoba sendiri selama **20 menit** tanpa perlu bertanya kepada siapa pun.

### 5. Klik Menu "Bantuan -> Kirim laporan uji"
Setelah selesai mencoba selama 20 menit, klik menu **`Bantuan`** di pojok kiri atas jendela aplikasi, lalu pilih **`Kirim laporan uji (Kemas ZIP ke Desktop)`** (atau klik tombol hijau **`Kirim Laporan Uji`** di baris atas).

### 6. Kirim Berkas ZIP dari Desktop ke Pembuat
Folder **Desktop** Anda akan terbuka otomatis dan menyorot satu berkas bernama **`Laporan_Uji_KageAna_<tanggal>.zip`** (berkas ini hanya berisi catatan langkah di dalam simulasi dan **tidak** menyertakan nama pengguna atau data pribadi komputer Anda). Kirimkan berkas ZIP tersebut kepada pembuat aplikasi, lalu ceritakan satu kejadian yang paling Anda ingat!

---
**Jika aplikasi tidak terbuka / macet, lakukan ini:** Tekan tombol `Windows + R` di papan ketik, ketik `%LOCALAPPDATA%\KageAna\Log` lalu tekan Enter, dan kirimkan berkas `galat_*.txt` (atau `%LOCALAPPDATA%\KageAna\selftest.txt`) yang ada di dalamnya kepada pembuatnya.
