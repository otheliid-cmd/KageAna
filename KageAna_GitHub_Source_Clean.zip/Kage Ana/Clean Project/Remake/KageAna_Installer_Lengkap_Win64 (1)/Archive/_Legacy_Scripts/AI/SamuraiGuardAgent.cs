using UnityEngine;
using KageAna.Core;

namespace KageAna.AI
{
    /// <summary>
    /// Guard perception and state transitions (Patrol -> Suspicious -> Search -> Combat).
    /// </summary>
    public sealed class SamuraiGuardAgent : MonoBehaviour
    {
        public GuardAlertState CurrentState { get; private set; } = GuardAlertState.Patrol;
        public float Suspicion { get; private set; }
        public Vector3 LastKnownStimulusPosition { get; private set; }

        public void TickPerception(Vector3 playerPos, float playerLightExposure, bool isPlayerCrouching, float dt)
        {
            Vector3 toPlayer = playerPos - transform.position;
            float dist = toPlayer.magnitude;
            float angle = Vector3.Angle(transform.forward, toPlayer.normalized);

            float delta = StealthMechanicsCalculator.CalculateSuspicionDeltaPerSecond(
                dist, angle, playerLightExposure, isPlayerCrouching, Suspicion);

            Suspicion = Mathf.Clamp(Suspicion + delta * dt, 0f, 100f);
            if (delta > 0f)
            {
                LastKnownStimulusPosition = playerPos;
            }

            UpdateStateFromSuspicion();
        }

        public void ReceiveAcousticStimulus(Vector3 soundOrigin, float decibels)
        {
            float dist = Vector3.Distance(transform.position, soundOrigin);
            if (dist <= decibels * 0.55f)
            {
                Suspicion = Mathf.Clamp(Suspicion + 38f, 0f, 100f);
                LastKnownStimulusPosition = soundOrigin;
                UpdateStateFromSuspicion();
            }
        }

        private void UpdateStateFromSuspicion()
        {
            if (Suspicion >= 100f) CurrentState = GuardAlertState.Combat;
            else if (Suspicion >= 70f) CurrentState = GuardAlertState.Search;
            else if (Suspicion >= 30f) CurrentState = GuardAlertState.Suspicious;
            else CurrentState = GuardAlertState.Patrol;
        }
    }
}
