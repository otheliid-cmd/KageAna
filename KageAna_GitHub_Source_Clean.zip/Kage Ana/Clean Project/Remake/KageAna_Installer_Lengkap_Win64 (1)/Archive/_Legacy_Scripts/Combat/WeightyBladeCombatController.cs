using System.Collections;
using UnityEngine;
using KageAna.Core;

namespace KageAna.Combat
{
    public enum BladeAttackPhase { Idle, Windup, ActiveStrike, Recovery, Parrying }

    /// <summary>
    /// Handles 3-phase weighty Katana attacks, socketed hand transforms, and 65ms hit-stop.
    /// </summary>
    public sealed class WeightyBladeCombatController : MonoBehaviour
    {
        [SerializeField] private Transform rightHandWeaponSocket;
        [SerializeField] private TrailRenderer bladeSlashTrail;
        [SerializeField] private float windupSeconds = 0.15f;
        [SerializeField] private float activeStrikeSeconds = 0.12f;
        [SerializeField] private float recoverySeconds = 0.35f;
        [SerializeField] private float hitStopDurationSeconds = 0.065f;

        public BladeAttackPhase CurrentPhase { get; private set; } = BladeAttackPhase.Idle;

        public bool TryStartHeavySlash(float currentStamina, out float staminaCost)
        {
            staminaCost = 20f;
            if (CurrentPhase != BladeAttackPhase.Idle || currentStamina < staminaCost)
            {
                return false;
            }
            StartCoroutine(ExecuteSlashRoutine());
            return true;
        }

        private IEnumerator ExecuteSlashRoutine()
        {
            CurrentPhase = BladeAttackPhase.Windup;
            yield return new WaitForSeconds(windupSeconds);

            CurrentPhase = BladeAttackPhase.ActiveStrike;
            if (bladeSlashTrail != null) bladeSlashTrail.emitting = true;
            yield return new WaitForSeconds(activeStrikeSeconds);

            if (bladeSlashTrail != null) bladeSlashTrail.emitting = false;
            CurrentPhase = BladeAttackPhase.Recovery;
            yield return new WaitForSeconds(recoverySeconds);

            CurrentPhase = BladeAttackPhase.Idle;
        }

        public void TriggerHitStop()
        {
            StartCoroutine(HitStopRoutine());
        }

        private IEnumerator HitStopRoutine()
        {
            float prevScale = Time.timeScale;
            Time.timeScale = 0.05f;
            yield return new WaitForSecondsRealtime(hitStopDurationSeconds);
            Time.timeScale = prevScale;
        }
    }
}
