using System;
using UnityEngine;

namespace KageAna.Core
{
    public enum SurfaceMaterialType { Tatami, Wood, Stone, ClayTile, Gravel }
    public enum GuardAlertState { Patrol, Suspicious, Search, Combat, Returning }
    public enum GoreIntensityMode { Off, Low, High }

    /// <summary>
    /// Decoupled event channel replacing global mutable singletons.
    /// </summary>
    public sealed class GameEventChannel
    {
        public event Action<Vector3, float, SurfaceMaterialType> OnAcousticNoiseEmitted;
        public event Action<int, bool> OnLanternStateChanged;
        public event Action<GuardAlertState, float> OnHighestGuardStateChanged;
        public event Action<float, float> OnPlayerVitalityAndStaminaChanged;
        public event Action<string> OnContextualPromptChanged;

        public void EmitNoise(Vector3 worldPos, float decibels, SurfaceMaterialType surface)
            => OnAcousticNoiseEmitted?.Invoke(worldPos, decibels, surface);

        public void NotifyLanternChanged(int lanternId, bool isLit)
            => OnLanternStateChanged?.Invoke(lanternId, isLit);

        public void NotifyGuardState(GuardAlertState state, float suspicionNormalized)
            => OnHighestGuardStateChanged?.Invoke(state, suspicionNormalized);

        public void NotifyPlayerStats(float vitalityNormalized, float staminaNormalized)
            => OnPlayerVitalityAndStaminaChanged?.Invoke(vitalityNormalized, staminaNormalized);

        public void SetPrompt(string promptText)
            => OnContextualPromptChanged?.Invoke(promptText);
    }

    /// <summary>
    /// Pure calculation logic for stamina, acoustics, and AI suspicion so it can be unit-tested in EditMode.
    /// </summary>
    public static class StealthMechanicsCalculator
    {
        public static float CalculateStepDecibels(SurfaceMaterialType surface, bool isSprinting, bool isCrouching)
        {
            float baseDb = surface switch
            {
                SurfaceMaterialType.Tatami   => 4f,
                SurfaceMaterialType.Stone    => 11f,
                SurfaceMaterialType.Wood     => 14f,
                SurfaceMaterialType.ClayTile => 20f,
                SurfaceMaterialType.Gravel   => 26f,
                _                            => 12f
            };
            if (isCrouching) return baseDb * 0.25f;
            if (isSprinting) return baseDb * 1.75f;
            return baseDb;
        }

        public static float CalculateSuspicionDeltaPerSecond(
            float distanceMeters,
            float angleDegrees,
            float lightExposureZeroToOne,
            bool isPlayerCrouching,
            float currentSuspicion)
        {
            float maxRange = Mathf.Lerp(6.5f, 18.0f, lightExposureZeroToOne);
            if (isPlayerCrouching) maxRange *= 0.72f;

            if (distanceMeters > maxRange || angleDegrees > 75f)
            {
                return -14f; // Suspicion decays when out of sight cone
            }

            float distanceFactor = Mathf.Clamp01(1f - (distanceMeters / maxRange));
            float lightFactor = Mathf.Lerp(0.35f, 1.35f, lightExposureZeroToOne);
            return (28f + distanceFactor * 55f) * lightFactor;
        }
    }
}
