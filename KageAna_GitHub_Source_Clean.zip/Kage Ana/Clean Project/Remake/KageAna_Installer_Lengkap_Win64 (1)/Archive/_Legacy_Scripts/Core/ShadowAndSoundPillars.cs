using System;
using System.Collections.Generic;
using UnityEngine;

namespace KageAna.Core
{
    [Serializable]
    public struct InkRippleEvent
    {
        public Vector3 Origin;
        public float MaxRadius;
        public float CurrentRadius;
        public float Alpha;
        public bool IsLethalIaiSound;
    }

    [Serializable]
    public struct KageEchoSample
    {
        public float Timestamp;
        public Vector3 Position;
        public float Yaw;
        public bool EmittedSound;
    }

    /// <summary>
    /// Implements Pillar 1 (Shadow-Meld & Two-Way Lanterns), Pillar 2 (Sound as Ink & Listen Mode),
    /// and Pillar 3 (Kage-Echo 10-second death replay decoy).
    /// </summary>
    public sealed class ShadowAndSoundPillars : MonoBehaviour
    {
        public float ShadowStrength { get; private set; } = 0.8f;
        public bool IsListenModeActive { get; private set; }
        public List<InkRippleEvent> ActiveInkRipples { get; } = new List<InkRippleEvent>();
        public List<KageEchoSample> RecordedBuffer { get; } = new List<KageEchoSample>();
        public List<KageEchoSample> ActiveEchoPlayback { get; private set; } = new List<KageEchoSample>();

        public float UpdateShadowStrength(float lightExposureZeroToOne)
        {
            ShadowStrength = Mathf.Clamp01(1.0f - lightExposureZeroToOne);
            return ShadowStrength;
        }

        public bool TryShadowMeld(
            Vector3 playerPos,
            Vector3 lookForward,
            IReadOnlyList<Vector3> shadowPoolCenters,
            float maxMeldRange,
            ref float stamina,
            float staminaCost,
            out Vector3 destination)
        {
            destination = playerPos;
            if (ShadowStrength < 0.55f || stamina < staminaCost)
            {
                return false;
            }

            float bestScore = float.MaxValue;
            bool found = false;
            for (int i = 0; i < shadowPoolCenters.Count; i++)
            {
                Vector3 pool = shadowPoolCenters[i];
                Vector3 toPool = pool - playerPos;
                float dist = toPool.magnitude;
                if (dist > 2.0f && dist <= maxMeldRange)
                {
                    float dot = Vector3.Dot(toPool.normalized, lookForward);
                    if (dot > 0.65f)
                    {
                        float score = dist * (1.2f - dot * 0.5f);
                        if (score < bestScore)
                        {
                            bestScore = score;
                            destination = pool;
                            found = true;
                        }
                    }
                }
            }

            if (found)
            {
                stamina -= staminaCost;
            }
            return found;
        }

        public void SpawnInkRipple(Vector3 origin, float maxRadius, bool isLethalIai = false)
        {
            ActiveInkRipples.Add(new InkRippleEvent
            {
                Origin = origin,
                MaxRadius = maxRadius,
                CurrentRadius = 0.25f,
                Alpha = 1.0f,
                IsLethalIaiSound = isLethalIai
            });
        }

        public void TickInkRipples(float dt)
        {
            for (int i = ActiveInkRipples.Count - 1; i >= 0; i--)
            {
                InkRippleEvent r = ActiveInkRipples[i];
                r.CurrentRadius += dt * (r.MaxRadius * 1.6f);
                r.Alpha = Mathf.Clamp01(1.0f - (r.CurrentRadius / r.MaxRadius));
                if (r.CurrentRadius >= r.MaxRadius)
                {
                    ActiveInkRipples.RemoveAt(i);
                }
                else
                {
                    ActiveInkRipples[i] = r;
                }
            }
        }

        public void RecordPlayerSample(float nowSeconds, Vector3 pos, float yaw, bool madeSound)
        {
            RecordedBuffer.Add(new KageEchoSample
            {
                Timestamp = nowSeconds,
                Position = pos,
                Yaw = yaw,
                EmittedSound = madeSound
            });
            while (RecordedBuffer.Count > 0 && (nowSeconds - RecordedBuffer[0].Timestamp) > 10.0f)
            {
                RecordedBuffer.RemoveAt(0);
            }
        }

        public void ConvertRecordingToActiveEchoOnDeath()
        {
            ActiveEchoPlayback = new List<KageEchoSample>(RecordedBuffer);
            RecordedBuffer.Clear();
        }
    }
}
