using UnityEngine;
using KageAna.Core;

namespace KageAna.Locomotion
{
    [RequireComponent(typeof(CharacterController))]
    public sealed class FirstPersonStealthLocomotion : MonoBehaviour
    {
        [Header("Locomotion Speeds (m/s)")]
        [SerializeField] private float walkSpeed = 3.6f;
        [SerializeField] private float sprintSpeed = 7.4f;
        [SerializeField] private float crouchSpeed = 1.9f;
        [SerializeField] private float jumpVelocity = 6.8f;
        [SerializeField] private float gravity = -19.62f;

        [Header("Stamina & Mantle")]
        [SerializeField] private float maxStamina = 100f;
        [SerializeField] private float mantleReachMeters = 1.5f;
        [SerializeField] private LayerMask climbableLedgeMask;

        public float CurrentStamina { get; private set; } = 100f;
        public bool IsCrouching { get; private set; }
        public bool IsSprinting { get; private set; }

        private CharacterController _controller;
        private Vector3 _velocity;
        private GameEventChannel _events;

        public void Initialize(GameEventChannel eventChannel)
        {
            _events = eventChannel;
        }

        private void Awake()
        {
            _controller = GetComponent<CharacterController>();
            CurrentStamina = maxStamina;
        }

        public void TickMovement(Vector2 moveInput, bool sprintHeld, bool crouchHeld, bool jumpPressed, SurfaceMaterialType groundSurface, float dt)
        {
            IsCrouching = crouchHeld;
            IsSprinting = sprintHeld && !IsCrouching && moveInput.sqrMagnitude > 0.05f && CurrentStamina > 5f;

            float speed = IsCrouching ? crouchSpeed : (IsSprinting ? sprintSpeed : walkSpeed);
            Vector3 moveDir = (transform.right * moveInput.x + transform.forward * moveInput.y).normalized;
            _controller.Move(moveDir * (speed * dt));

            if (IsSprinting)
            {
                CurrentStamina = Mathf.Max(0f, CurrentStamina - 12f * dt);
            }
            else if (_controller.isGrounded)
            {
                CurrentStamina = Mathf.Min(maxStamina, CurrentStamina + 18f * dt);
            }

            if (_controller.isGrounded && moveInput.sqrMagnitude > 0.1f)
            {
                float db = StealthMechanicsCalculator.CalculateStepDecibels(groundSurface, IsSprinting, IsCrouching);
                _events?.EmitNoise(transform.position, db, groundSurface);
            }

            if (jumpPressed && _controller.isGrounded && CurrentStamina >= 10f)
            {
                _velocity.y = jumpVelocity;
                CurrentStamina -= 10f;
            }
            else if (jumpPressed && !_controller.isGrounded)
            {
                TryMantleClimbableLedge();
            }

            _velocity.y += gravity * dt;
            _controller.Move(_velocity * dt);
            if (_controller.isGrounded && _velocity.y < 0f)
            {
                _velocity.y = -2f;
            }

            _events?.NotifyPlayerStats(1.0f, CurrentStamina / maxStamina);
        }

        private void TryMantleClimbableLedge()
        {
            Vector3 chestOrigin = transform.position + Vector3.up * 1.25f;
            if (Physics.Raycast(chestOrigin, transform.forward, out RaycastHit hit, mantleReachMeters, climbableLedgeMask))
            {
                _velocity.y = 5.2f;
            }
        }
    }
}
