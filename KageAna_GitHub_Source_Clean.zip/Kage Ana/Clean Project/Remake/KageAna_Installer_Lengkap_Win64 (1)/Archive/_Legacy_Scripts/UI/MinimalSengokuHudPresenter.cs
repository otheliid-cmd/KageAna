using UnityEngine;
using KageAna.Core;

namespace KageAna.UI
{
    /// <summary>
    /// Enforces ART_BIBLE.md Rule 6: Maximum 4 non-overlapping HUD elements during active play.
    /// </summary>
    public sealed class MinimalSengokuHudPresenter : MonoBehaviour
    {
        public const int MaxAllowedActiveHudWidgets = 4;

        private GameEventChannel _events;
        public float DisplayedVitality { get; private set; } = 1f;
        public float DisplayedStamina { get; private set; } = 1f;
        public GuardAlertState DisplayedAlertState { get; private set; } = GuardAlertState.Patrol;
        public string ActivePrompt { get; private set; } = string.Empty;

        public void Bind(GameEventChannel channel)
        {
            _events = channel;
            _events.OnPlayerVitalityAndStaminaChanged += (v, s) => { DisplayedVitality = v; DisplayedStamina = s; };
            _events.OnHighestGuardStateChanged += (st, _) => { DisplayedAlertState = st; };
            _events.OnContextualPromptChanged += p => { ActivePrompt = p ?? string.Empty; };
        }
    }
}
