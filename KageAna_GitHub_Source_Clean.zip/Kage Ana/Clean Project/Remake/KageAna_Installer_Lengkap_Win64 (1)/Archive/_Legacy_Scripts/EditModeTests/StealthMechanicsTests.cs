using NUnit.Framework;
using KageAna.Core;

namespace KageAna.Tests.EditMode
{
    public sealed class StealthMechanicsTests
    {
        [Test]
        public void CrouchStepDecibels_AreSignificantlyLowerThanSprint()
        {
            float crouchDb = StealthMechanicsCalculator.CalculateStepDecibels(SurfaceMaterialType.Gravel, false, true);
            float sprintDb = StealthMechanicsCalculator.CalculateStepDecibels(SurfaceMaterialType.Gravel, true, false);
            Assert.Less(crouchDb, 8f);
            Assert.Greater(sprintDb, 40f);
        }

        [Test]
        public void SuspicionDelta_IsNegativeWhenOutOfVisionCone()
        {
            float delta = StealthMechanicsCalculator.CalculateSuspicionDeltaPerSecond(
                distanceMeters: 10f,
                angleDegrees: 110f,
                lightExposureZeroToOne: 1.0f,
                isPlayerCrouching: false,
                currentSuspicion: 50f);
            Assert.Less(delta, 0f);
        }

        [Test]
        public void ShadowAndCrouch_ReduceEffectiveDetectionRange()
        {
            float litStandingDelta = StealthMechanicsCalculator.CalculateSuspicionDeltaPerSecond(
                distanceMeters: 12f, angleDegrees: 15f, lightExposureZeroToOne: 1.0f, isPlayerCrouching: false, currentSuspicion: 0f);
            float darkCrouchingDelta = StealthMechanicsCalculator.CalculateSuspicionDeltaPerSecond(
                distanceMeters: 12f, angleDegrees: 15f, lightExposureZeroToOne: 0.0f, isPlayerCrouching: true, currentSuspicion: 0f);
            Assert.Greater(litStandingDelta, 0f);
            Assert.Less(darkCrouchingDelta, 0f);
        }
    }
}
