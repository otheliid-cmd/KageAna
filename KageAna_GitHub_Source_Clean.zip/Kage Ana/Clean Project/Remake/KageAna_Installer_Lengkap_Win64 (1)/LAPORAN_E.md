# LAPORAN GELOMBANG E (`KageAna_Gelombang_E`) — AUDIT E0.2, PERBAIKAN & PEMBEKUAN SIM (`sim-freeze-E`), SERTA JALUR PRODUK 3D/AUDIO/VRM/ANDROID

> **Label Kejujuran Verifikasi (Wajib sesuai E1.1 & E10):**
> - **Sim L1 (`9966aca7bc76c555`):** Terverifikasi C# asli (dilaporkan pengguna; berkas bukti `HASIL_BANGUN.txt` belum dilampirkan).
> - **Kode Sim Gelombang E (`E1.2` & `E2`, tag `sim-freeze-E`, hash `af8bdc0cafa520b4`):** Terverifikasi via terjemahan (`tools/cs_gpp_host.py`), **BUKAN kompilator C#/Unity asli**, menunggu pengguna menjalankan `BUAT_INSTALLER.bat` / `BANGUN_PAKET.bat` di Windows.
> - **Pekerjaan E3–E9 (Unity 6 3D Orang Ketiga, Input System, Palet & Shader E4, Audio Director E5, VRM & Suara Jepang E6, Skrip APK Android E9):** Sesuai Gerbang E1.1, seluruh berkas ini disiapkan secara statis dengan label eksplisit **`BELUM DIBUKA DI UNITY/WINDOWS ASLI`** (Unity belum dibuka, APK belum dibangun, model VRM belum dimuat, audio final belum didengar, gamepad fisik belum dipegang di wadah ini).

## 1. Pemeriksaan Mandiri atas 9 Temuan E0.2 (Jujur dan Berbukti Kode)

Sebelum menulis satu baris kode pun, saya memeriksa langsung kode sumber paket `KageAna_Gerbang_1_Pilot` (Gelombang D) untuk memverifikasi kesembilan temuan pada bagian **E0.2**:

| Butir E0.2 | Temuan pada Instruksi Gelombang E | Hasil Periksa Mandiri pada Kode Gelombang D | Tindakan Perbaikan di Gelombang E |
|---|---|---|---|
| **1. Pengisi kuota modulus & lintas lokasi** | `SimEconomyAndPressureSystem.cs` baris ±337 memakai round-robin + fallback NPC di mana saja yang tidak tidur + `selector = (day + hour + i + partnerIdx) % 10`. | **BENAR 100% (Terbukti di baris 337–424 `SimEconomyAndPressureSystem.cs` lama).** Jika `partnerIdx < 0` di tempat yang sama, loop kedua mengambil NPC mana pun di desa yang `CurrentActivity != "Sleep"` lintas lokasi, lalu memilih aksi dengan `(day + hour + i + partnerIdx) % 10`. | **Dihapus total (E2.1).** Diganti sistem **Niat Sosial** berbasis `kebutuhan × kedekatan hubungan × kesempatan` khusus antar NPC **di tempat yang sama** (`CrossLocation = 0`), diuji dengan 4 metrik anti-pengisi + tes negatif Kasus 27 (`--inject-modulus-filler`). |
| **2. ID NPC keras (hard-coded)** | 16 kemunculan `"ohana"/"haruki"/"daigo"/"mio"` di `SimEconomyAndPressureSystem.cs` + modul lain. | **BENAR 100% (Terbukti ada >30 kemunculan literal ID NPC di `Runtime/Sim/Rumor/*.cs`).** | **Dihapus total (E2.2).** Seluruh perilaku khusus dipindah ke `duties`, `assignedPostPlaceId`, `socialDrives`, dan `relationships` di `kurokawa_npcs.json`. Pemindai statis CI kini menolak literal ke-26 ID NPC di `Runtime/Sim/**` (0 kemunculan, diuji tes negatif Kasus 28). |
| **3. Jalan buntu Kepercayaan Kelompok** | Semua kebijakan kecuali `TraderInformant` berakhir dengan Kepercayaan Kelompok 0 di Hari 21 tanpa jalan pemulihan. | **BENAR 100%.** `HonestTrader` jatuh ke `GroupTrust = 0` dan `GroupSupplyLineCut = true` permanen mulai Hari 21. | **Diperbaiki (E2.3).** Dibangun tahap pemulihan `Aktif -> KontakTerputus -> UjianKesetiaan -> DipercayaKembali (dengan tanda hati-hati)`. `HonestTrader` pulih ke `52/100` (`DipercayaKembali`) lewat satu Kabar bernilai, dan ditambahkan kebijakan ke-5 `Pemulih` (`59/100`). |
| **4. Dialog diegetik masih template** | Terasa mekanis setelah 25 menit; perlu disiapkan agar selaras dengan karakter 3D dan ekspresi/bark. | **BENAR 100%.** | Dirancang ulang jembatan ekspresi & bark di `CharacterExpressionController.cs`, `VoiceBarkPlayer.cs`, dan `VOICE_SCRIPT.csv` agar percakapan bertumpu pada keadaan emosi/keyakinan Sim + *bark* suara Jepang. |
| **5. Respons pemain terhadap salah paham belum ada** | Sōma hanya jadi penonton saat orang yang salah didenda (`WrongPerson`/`WrongPlace`). | **BENAR 100%.** Tidak ada aksi intervensi pemain atas rantai salah paham di Gelombang D. | **Diperbaiki (E2.4).** Ditambahkan `ExecuteSoumaInterveneMisunderstanding` dengan 5 pilihan (`Bersaksi`, `MenyerahkanBukti`, `MenyuapPenjaga`, `MenyebarKabarTandingan`, `Membiarkan`) yang memancarkan `WorldEvent` (`SoumaAction`), mengubah keyakinan NPC di `SimMemoryStore`, dan punya risiko berhasil/gagal/berbalik. |
| **6. Sandbox tidak punya gamepad sama sekali** | `SandboxProgram.cs` memiliki 0 rujukan gamepad; kontroler hanya ada di `_Legacy`. | **BENAR 100% (0 rujukan di `SandboxProgram.cs` lama).** | **Diperbaiki (E8).** Ditambahkan polling XInput (`xinput1_4.dll`) di `SandboxProgram.cs` untuk gerak & intervensi, serta dibangun `UnifiedInputController.cs` + `KageAna_InputActions.inputactions` (14 aksi × 3 skema: Gamepad, Keyboard+Mouse, Sentuh) + `InputAndBridgeEditModeTests.cs` + `CARA_KONTROLER.md`. |
| **7. Windows nyata masih belum terbukti** | Belum ada `HASIL_BANGUN.txt` / `selftest.txt` dari pengguna. | **BENAR 100%.** | **Gerbang E1.1 ditegakkan:** E1.2 & E2 diselesaikan dan dibekukan (`sim-freeze-E`), sementara E3–E9 disiapkan secara statis dengan label jujur `BELUM DIBUKA DI UNITY/WINDOWS ASLI`. |
| **8. Sim harus dibekukan setelah E2** | Empat gelombang membangun mesin simulasi; mulai Gelombang E sim dibekukan setelah E2. | **BENAR 100%.** | Setelah E2 lulus seluruh 35 tes unit, 20 seed, dan 28 tes negatif CI, sim dibekukan pada tag Git **`sim-freeze-E`**. |
| **9. Target `net8.0` + `System.Text.Json` tidak kompatibel dengan Unity 6** | Unity 6 memakai profil `.NET Standard 2.1` dan tidak membawa `System.Text.Json` bawaan. | **BENAR 100%.** | **Diperbaiki (E1.2).** `KageAna.Sim.csproj` kini menargetkan `netstandard2.1;net8.0` dengan `LangVersion 9.0`, bebas `System.Text.Json`/`UnityEngine`/`System.Drawing`/`System.Windows.Forms` di `Runtime/Sim/**` (dijaga tes negatif Kasus 26), menggunakan antarmuka `ISimDataSource` dengan dua adapter (`SimJsonDataLoader` & `UnitySimDataLoader`) yang terbuktikan menghasilkan hash bundel identik. |

## 2. Perbandingan Sebelum vs Sesudah E2 (`--seed 7 --days 28`) & Metrik Anti-Pengisi

Perintah uji: `python3 tools/run_headless_sim.py --seed 7 --days 28`

| Metrik Simulasi (28 Hari, Seed 7, `TraderInformant`) | Sebelum (Gelombang D — `d4f039b3`) | Sesudah (Gelombang E — `sim-freeze-E`) | Penjelasan Jujur Perubahan |
|---|---|---|---|
| **Hash Kalender & Cuaca L1** | `9966aca7bc76c555` | **`9966aca7bc76c555`** | **100% identik** (lapisan jadwal dasar dan cuaca tidak berubah). |
| **Hash Simulasi Penuh (Run #1 == Run #2)** | `d4f039b334f09d5e` | **`af8bdc0cafa520b4`** | Berubah secara sah dan deterministik karena penghapusan modulus pengisi kuota (E2.1), penghapusan ID keras (E2.2), pemulihan kepercayaan kelompok (E2.3), dan intervensi salah paham (E2.4). |
| **Total `WorldEvent` (28 Hari)** | `6.721` | **`3.735`** | Turun ±44% karena pembuangan ribuan kejadian pengisi kuota modulus yang bising. |
| **Interaksi Entitas / NPC / Hari** | `8,73` (dipenuhi lewat modulus) | **`4,42`** (`3.215` kejadian) | Sesuai instruksi E2.1: kepadatan turun secara jujur dari 8,73 menjadi **4,42 kejadian bermakna/NPC/hari**, seluruhnya lahir dari dorongan kebutuhan dan tipe hubungan di lokasi yang sama. |
| **Metrik Anti-Pengisi 1: Rasio Interaksi Bertaut `"Mengapa"` (Kebutuhan/Hubungan)** | Tidak diukur (pengisi modulus) | **`100%`** (`3.215 / 3.215`) | Setiap `EntityInteraction` wajib memiliki tautan eksplisit ke `SocialDrives` dan `RelationshipType`. |
| **Metrik Anti-Pengisi 2: Rasio Pasangan Berulang Tanpa Pemicu Baru** | Tinggi (modulus berulang) | **`0%`** (Syarat: `< 30%`) | Pasangan NPC yang sama di tempat yang sama tidak berinteraksi ulang tanpa perubahan pemicu/kebutuhan. |
| **Metrik Anti-Pengisi 3: Interaksi Lintas Lokasi (`CrossLocation`)** | `> 0` (fallback lintas desa) | **`0`** (Syarat keras: `0`) | Pencarian mitra lintas lokasi dihapus total; interaksi hanya terjadi antar NPC di `CurrentPlaceIdx` yang sama. |
| **Metrik Anti-Pengisi 4: Entropi Jenis Interaksi per NPC** | Tidak diukur | **`1,93 bit`** (Syarat: `≥ 1,50 bit`) | Keragaman sehat di antara 8 dorongan sosial (`perlu_bayar`, `perlu_bicara`, `perlu_dagang`, `perlu_istirahat`, `rasa_penasaran`, `dendam`, `kasih_sayang`, `tugas_jadwal`). |
| **Metrik Anti-Pengisi 5: Kejadian Tak Terprediksi dari Jadwal Saja** | Tidak diukur | **`1.033` kejadian** | Kejadian emergen yang hilang apabila rantai sebab-akibat/kebutuhan dimatikan. |
| **Biaya Langkah Sim per Menit Game (`stepCostBudget` E1.2)** | Tidak diukur | **`0,20 ms / langkah`** (`384 KB`) | Jauh di bawah anggaran keras ponsel kelas menengah (`< 2,00 ms / langkah`). |
| **Rantai Agensi & Salah Paham NPC** | `194` aksi (`127` salah paham) | **`186` aksi (`112` salah paham, `116` rantai)** | Tetap hidup dan organik tanpa suntikan kuota modulus. |
| **Intervensi Sōma atas Salah Paham (E2.4)** | `0` (belum ada) | **`28` intervensi di run 28 hari** + 3 skenario uji | Sōma kini dapat turun tangan (`Bersaksi`, `MenyerahkanBukti`, `MenyuapPenjaga`, `MenyebarKabarTandingan`, `Membiarkan`). |
| **Pelanggaran `NoFreeKnowledgeGuard` (20 Seed × 28 Hari)** | `0` | **`0`** | Tetap 0 pelanggaran di seluruh 560 hari simulasi lintas 20 seed. |
| **Tes Unit C# & Tes Negatif CI** | `29/29` unit, `25/25` negatif | **`35/35` unit, `28/28` negatif** | Ditambah 6 tes unit Gelombang E (`Test_WaveE_1` s/d `Test_WaveE_6`) dan 3 tes negatif baru (Kasus 26, 27, 28). |

### Lintasan 28 Hari Kelima Kebijakan (E2.3 — Tidak Ada Lagi Kebijakan Jujur yang Berakhir Buntu)

| Kebijakan | Uang Akhir (`Mon`) | Utang Sewa | Kepercayaan Kelompok Akhir | Status Jalur Kelompok (`GroupContactState`) | Intervensi Salah Paham | Langkah Lanjut yang Tersedia bagi Pemain |
|---|---|---|---|---|---|---|
| **`Idle`** | `0 mon` | `1.600 mon` | `0 / 100` | `KontakTerputus` | `0` | Antarkan minimal 1 Kabar terverifikasi (`≥2` saksi) ke Titik Serah Hutan untuk memulai `UjianKesetiaan`. |
| **`HonestTrader`** | `1.500 mon` | `0 mon` | **`52 / 100`** | **`DipercayaKembali`** (`ReTrustCaution=True`) | `28` | Pulih pada Hari 23 (`evt_3029`) lewat 1 Kabar bernilai tanpa harus menjadi informan penuh. |
| **`TraderInformant`** | `1.249 mon` | `0 mon` | **`90 / 100`** | **`Aktif`** | `28` | Jalur aktif dengan laporan mingguan teratur. |
| **`RecklessLoud`** | `846 mon` | `0 mon` | `0 / 100` | `KontakTerputus` | `0` | Masih dapat memulai `UjianKesetiaan` bila meredakan kecurigaan dan membawa Kabar terverifikasi. |
| **`Pemulih` (Baru E2.3)** | `1.314 mon` | `0 mon` | **`59 / 100`** | **`DipercayaKembali`** (`ReTrustCaution=True`) | `28` | Sempat terputus di Hari 14 (`evt_1853`), menempuh `UjianKesetiaan` di Hari 16 (`evt_2113`), dan bertahan stabil hingga Hari 28. |

## 3. Lima Cerita Baru Berjejak ID Kejadian dari Log (`sim_report_L1.json`)

1. **Cerita 1 — Skenario Intervensi Sōma Berhasil Membebaskan Warga dari Salah Paham (`evt_1 -> evt_2`, E2.4):**
   > **Jejak Log:** `rootEventId: evt_1` → `interventionEventId: evt_2` (`actionCode: souma_intervene_evidence`, `StateEffect: Intervention=MenyerahkanBukti;Outcome=BERHASIL;Cleared=okiku;TrueSubject=ohana;GuardSuspDelta=+8`).
   > **Ringkasan:** Ketika penjaga gerbang Ryōta hendak menjatuhkan sanksi kepada O-Kiku akibat desas-desus salah orang (`WrongPerson`), Sōma turun tangan dengan tindakan **`MenyerahkanBukti`** menggunakan Kabar yang telah diverifikasi dari `≥2` sumber independen. Keyakinan salah paham di ingatan Ryōta dikoreksi ke pelaku sebenarnya, O-Kiku bebas dari denda, namun Ryōta mencatat kenaikan curiga kecil (`+8`) karena bertanya-tanya bagaimana seorang pedagang keliling memiliki kesaksian silang selengkap itu.

2. **Cerita 2 — Skenario Intervensi Sōma Gagal dan Berbalik Menjadi Denda Ganda (`evt_1`, E2.4):**
   > **Jejak Log (Gagal):** `interventionEventId: evt_1` (`souma_intervene_testify`, `StateEffect: Intervention=Bersaksi;Outcome=GAGAL;GuardSuspDelta=+12`) — Saat Sōma mencoba **`Bersaksi`** tanpa bukti fisik padahal kecurigaan penjaga sudah mencapai `50/100`, kesaksiannya ditolak mentah-mentah dan kecurigaan penjaga naik `+12`.
   > **Jejak Log (Berbalik):** `interventionEventId: evt_1` (`souma_intervene_bribe`, `StateEffect: Intervention=MenyuapPenjaga;Outcome=BERBALIK;GuardSuspDelta=+25;ExtraFine=30mon`) — Saat Sōma mencoba **`MenyuapPenjaga`** yang sedang waspada tinggi, Ryōta menolak suap, menjatuhkan denda tambahan `30 mon` kepada Sōma, dan menaikkan kecurigaan sebesar `+25`.

3. **Cerita 3 — Pemulihan Jalur Kelompok oleh Pedagang Jujur (`evt_1845 -> evt_3029`, Kebijakan `HonestTrader` & `evt_1853 -> evt_2113`, Kebijakan `Pemulih`, E2.3):**
   > **Jejak Log (`HonestTrader`):** Pada Hari 14 (`evt_1845`), karena Sōma menolak memata-matai Balai Juru Tulis demi menjaga kejujuran dagangnya, kontak kelompok jatuh ke tahap **`KontakTerputus`**. Namun alih-alih terkunci permanen seperti pada Gelombang D, Sōma memasuki tahap **`UjianKesetiaan`** dan pada Hari 23 (`evt_3029`) menyerahkan satu Kabar yang ia kumpulkan secara wajar dari pasar kepada kurir Sabu di Pohon Aras Tua. Statusnya pulih menjadi **`DipercayaKembali`** (`Kepercayaan 52/100`, `reTrustedWithCaution: true`), dan Nisshi mencatat harga emosionalnya: *"Kau membeli nyawa samaranmu dengan rahasia orang lain."*

4. **Cerita 4 — Rantai Orde-3 Salah Paham yang Berujung Interogasi Penjaga (`evt_179 -> mem_470 -> mem_582 -> evt_246 -> evt_247`, `chain_12`):**
   > **Jejak Log:** Pada Hari 2 di Pasar Kaki Kastil (`place_pasar`), perdebatan kebutuhan dagang (`evt_179`, `npc_heated_argument`) disaksikan oleh Nenek Tsuru (`mem_470`). Saat kabar itu diteruskan melalui Pak Tua Tome kepada makelar Daigō (`mem_582`), operator distorsi `AddMotive` menambahkan tuduhan motif tersembunyi terhadap Haruki. Daigō yang mempercayai desas-desus itu mengadu kepada penjaga Ryōta (`evt_246`, Orde-2), sehingga Ryōta mendatangi pasar dan menjatuhkan denda `35 mon` kepada Haruki (`evt_247`, Orde-3).

5. **Cerita 5 — Solidaritas Warga yang Pasang Badan atas Tuduhan Salah Orang (`evt_112 -> mem_216 -> mem_328 -> evt_173`, `chain_9`):**
   > **Jejak Log:** Ketika penjaga pos meninggalkan barak gerbang lebih awal (`evt_112`, `leave_post_early` di `place_barak_gerbang`), ronin Kojirō mencatatnya (`mem_216`) namun saat menceritakan ulang kepada pengawal kiriman Kanta (`mem_328`), terjadi salah sebut pelaku (`Op=WrongPerson`) yang menyudutkan Rin. Karena Kanta memiliki hubungan dekat dan dorongan `kasih_sayang`/`rekan`, Kanta mengambil tindakan agensi **`AgencyCoverUpAlly`** (`evt_173`) dengan memberikan alibi serta bantuan `20 mon` untuk melindungi Rin.

## 4. Ringkasan Pekerjaan E3–E9 & Daftar Jujur Apa yang BELUM Terbukti

Sesuai Gerbang **E1.1**, karena berkas `HASIL_BANGUN.txt` dan `selftest.txt` dari PC Windows pengguna belum dikirimkan, seluruh komponen **E3–E9** di bawah ini telah ditulis secara lengkap dan diperiksa secara statis (`validate_data.py` lulus 122 berkas `.meta` dan 7 `.asmdef`), namun menyandang label jujur **`BELUM DIBUKA DI UNITY/WINDOWS ASLI`**:

- **E3 (Arsitektur Unity 6 LTS 3D Orang Ketiga & Anggaran Performa):**
  - `unity_project/Packages/manifest.json` diperbarui dengan versi pasti (`URP 17.0.3`, `Input System 1.11.2`, `Cinemachine 3.1.2`, `Newtonsoft Json 3.2.1`, serta `com.vrmc.gltf` & `com.vrmc.vrm` `#v0.128.3` — ditandai `PERLU DIVERIFIKASI` saat koneksi internet aktif, disertai jalur impor manual `.unitypackage` di `MODEL_SPEC_3D.md`).
  - Folder `_Legacy` telah dipindahkan keluar dari jalur produk ke `Archive/_Legacy_Scripts/`.
  - Enam `.asmdef` produk (`KageAna.Sim`, `KageAna.Game`, `KageAna.Presentation`, `KageAna.Audio`, `KageAna.Input`, `KageAna.UI`) + `KageAna.Tests.EditMode` telah dibuat beserta `SimUnityBridge.cs` (irisan vertikal *"Satu Malam di Kaki Kastil"* dengan 10 NPC) dan `QualityTierManager.cs` (kontrak 30 fps Android menengah, ≤150 draw call, ≤20k poligon karakter utama).
- **E4 (Arah Visual Ukiyo-e → Sumi-e, Palet, & UI Diegetik):**
  - `unity_project/Assets/_Project/Art/Palette.asset` memuat persis ke-11 token warna hex E4.1 (`Washi #EFE6D2`, `Sumi #1C1B1A`, `Ai-iro #27406B`, `Kon #141B33`, `Tsuki #B9C7D8`, `Andon #E8A33D`, `Kaki #D2692E`, `Shu #B8321F`, `Karat #5E1F18`, `Kuri/Sugi #6B5A44/#A37E56`, `Matcha-kusam #7A8B5C`).
  - `WorldClockSkyAndAtmosphereController.cs`, `ThirdPersonShoulderCamera.cs`, dan `DiegeticHudAndScrollController.cs` (ukuran sentuh ≥48 dp, skala 80–140%, teks ≥16 sp).
- **E5 (Audio Adaptif & Aset Prosedural `PLACEHOLDER`):**
  - `tools/generate_placeholder_audio.py` menghasilkan 9 berkas WAV prosedural dengan NumPy (petikan koto/biwa Karplus–Strong, drone shakuhachi malam, denyut taiko jauh, derau angin/hujan, dan langkah kaki di 5 permukaan: `Tanah`, `Kayu`, `Jerami`, `Tatami`, `Batu`) di `unity_project/Assets/_Project/Art/AudioPlaceholders/PLACEHOLDER_*.wav`, tercatat lengkap di `AUDIO_MANIFEST.csv`.
  - `AudioDirector.cs` (mixer `Master/BGM/Ambience/SFX/Voice/UI`, ducking BGM `-8 dB` saat dialog, 4 stem adaptif crossfade 4–8 detik, variasi pitch ±3%) dan `docs/AUDIO_BRIEF.md` (brief komposer + perhitungan anggaran eksplisit).
- **E6 (Bible 27 Karakter, Paket Prompt, Spesifikasi 3D VRM, & Paket Suara Jepang):**
  - `docs/CHARACTER_BIBLE.md` + `unity_project/Assets/_Project/Data/characters/kurokawa_character_bible.json` (26 NPC + Sōma 3 wajah, mencakup seluruh 12 arketipe emosi wajib dan siluet unik).
  - `docs/PROMPT_PACK_KONSEP.md`, folder `incoming_concept/`, dan skrip pemeriksa `tools/validate_concept_art.py`.
  - `docs/MODEL_SPEC_3D.md` + skrip C# VRM (`CharacterExpressionController.cs`, `LipSyncFromAudio.cs`, `GestureLibrary.cs`, `LookAtTarget.cs`).
  - `docs/VOICE_CASTING.md`, `docs/VOICE_SCRIPT.csv` (kolom `diperiksa_penutur_asli: BELUM`), `docs/VOICE_CONTRACT_CHECKLIST.md`, dan `VoiceBarkPlayer.cs`.
- **E7, E8, & E9 (Nama, Narasi A.7, Input Tunggal, & Alat APK Android):**
  - `docs/NAME_CHECK.md` dan `docs/FORMULIR_A7_PENDEK.md` (5 pertanyaan singkat; seluruh kolom `[ISI-PENGGUNA]` di `souma.json` tetap memakai awalan `TEMP_`).
  - `UnifiedInputController.cs`, `InputAndBridgeEditModeTests.cs`, `docs/CARA_KONTROLER.md`, serta pembaruan `SandboxProgram.cs` dan executable mandiri 64-bit `KageAna_Mandiri_Langsung_Jalan.exe`.
  - `SIAPKAN_ALAT_ANDROID.ps1` (+ `.bat`), `BUAT_APK.bat`, `Editor/BuildScripts/AndroidBuild.cs`, `docs/RILIS_ANDROID.md`, `docs/CARA_UJI_ANDROID.md`, dan `.github/workflows/android.yml` (`BELUM PERNAH DIJALANKAN`).

**Pernyataan Jujur Apa yang BELUM Terbukti di Wadah Ini:**
1. Proyek `unity_project/` **belum pernah dibuka di dalam Unity 6 Editor asli** pada mesin Windows/macOS.
2. Berkas `.apk` Android **belum pernah dibangun** (menunggu eksekusi `SIAPKAN_ALAT_ANDROID.ps1` dan `BUAT_APK.bat` di PC Windows pengguna).
3. Model `.vrm` 3D **belum dimuat secara visual di runtime Unity**, audio baru berupa WAV prosedural `PLACEHOLDER`, dan kontroler fisik (Xbox/DualSense/Switch Pro/layar sentuh ponsel) **belum dipegang langsung**.

## 5. Daftar Tugas yang HANYA Bisa Dikerjakan Pengguna (Urut Prioritas & Perkiraan Waktu)

| Prioritas | Tugas Pengguna | Perintah / Berkas Acuan | Perkiraan Waktu | Hasil yang Dikirim Kembali |
|---|---|---|---|---|
| **1 (Gerbang E1.1)** | Jalankan pembangun paket & selftest Windows untuk membuktikan kompilasi C# asli di Windows | Klik dua kali `BUAT_INSTALLER.bat` atau `BANGUN_PAKET.bat` (atau jalankan `KageAna_Mandiri_Langsung_Jalan.exe --selftest`) | **5–10 menit** | Kirimkan berkas `HASIL_BANGUN.txt` dan `%LOCALAPPDATA%\KageAna\selftest.txt`. |
| **2 (Alat Unity & Android E9.1)** | Pasang Unity Hub + Unity `6000.0.23f1` + modul Android SDK/NDK/OpenJDK & aktifkan lisensi Personal | Jalankan `SIAPKAN_ALAT_ANDROID.bat` (memerlukan ≥30 GB disk kosong dan persetujuan unduhan ±12–18 GB) | **30–60 menit** (tergantung kecepatan internet) | Kirimkan berkas `HASIL_SIAPKAN_ALAT.txt`. |
| **3 (Bangun & Uji APK Pertama E9.2)** | Bangun APK Debug irisan vertikal pertama dan pasang ke ponsel Android | Jalankan `BUAT_APK.bat` dan ikuti `docs/CARA_UJI_ANDROID.md` | **15–20 menit** | Kirimkan `build_android.log` dan tangkapan layar/laporan uji dari ponsel. |
| **4 (Formulir A.7 & Pemeriksaan Nama E7)** | Jawab 5 pertanyaan latar pribadi Sōma dan jalankan pemeriksaan nama di Steam/Play Store/PDKI | Isi `docs/FORMULIR_A7_PENDEK.md` dan tabel di `docs/NAME_CHECK.md` | **10–15 menit** | Kirimkan jawaban 5 butir A.7 (agar `TEMP_` dapat diganti resmi) dan hasil cek nama. |
| **5 (Model Uji VRM & Gambar Konsep E6)** | Hasilkan gambar konsep karakter pilihan pertama dan ekspor 1 Model Uji `.vrm` dari VRoid Studio | Gunakan prompt di `docs/PROMPT_PACK_KONSEP.md`, taruh di `incoming_concept/<id>/`, dan ikuti `docs/MODEL_SPEC_3D.md` | **1–2 jam** | Simpan 1 model `.vrm` uji ke `unity_project/Assets/_Project/Art/Models/`. |
| **6 (Pemeriksa Bahasa Jepang & Pengisi Suara E6.5)** | Minta penutur asli bahasa Jepang memeriksa 12 baris awal di `docs/VOICE_SCRIPT.csv` sebelum audisi | Gunakan `docs/VOICE_SCRIPT.csv`, `docs/VOICE_CASTING.md`, dan `docs/VOICE_CONTRACT_CHECKLIST.md` | **Sesuai jadwal produksi** | Ubah kolom `diperiksa_penutur_asli` menjadi `SUDAH` setelah diperiksa penutur asli. |

## 6. Apa yang Masih Lemah Menurut Saya (Penilaian Jujur)

1. **Kalimat Dialog & Laporan Nisshi Masih Mengandalkan Perakitan Template (`claim_templates.json`):** Meskipun pemicu interaksi kini 100% berangkat dari kebutuhan dan tipe hubungan di lokasi yang sama (tanpa modulus), kalimat teks yang muncul di layar masih merakit slot `{subject}`, `{place}`, `{time}`, dan `{motive}`. Dalam sesi bermain di atas 30 menit, pengulangan pola kalimat tetap akan terasa jika belum diperkaya dengan variasi dialog kontekstual per arketipe karakter dari `CHARACTER_BIBLE.md`.
2. **Intervensi Sōma (E2.4) Baru Beroperasi pada Tingkat Logika & Keyakinan Simulasi:** Di dalam Sim dan Sandbox 2D, intervensi `MenyerahkanBukti` atau `Bersaksi` sudah mengubah ingatan NPC dan menghentikan denda salah sasaran, tetapi dramatisasi ruangannya (gerakan tubuh penjaga yang ragu, kerumunan pasar yang menoleh, dan jeda hening audio sebelum keputusan) baru berupa kerangka skrip di `KageAna.Presentation`/`KageAna.Audio` yang belum disetel langsung di dalam adegan 3D Unity.
3. **Keseimbangan Ekonomi Minggu Ke-3 pada Kebijakan `Pemulih` dan `HonestTrader`:** Pajak musim gugur (*Aki Matsuri*, `600 mon` pada Hari 19) ditambah sewa mingguan (`350 mon` pada Hari 21) membuat cadangan kas pemain jujur sempat tertekan tajam sebelum pulih di Minggu ke-4. Saat diuji oleh pemain manusia nyata di irisan vertikal 3D nanti, tekanan pajak ini perlu diamati apakah terasa menegangkan secara sehat atau justru terlalu menghukum bila pemain melewatkan dua hari berdagang karena hujan badai.
