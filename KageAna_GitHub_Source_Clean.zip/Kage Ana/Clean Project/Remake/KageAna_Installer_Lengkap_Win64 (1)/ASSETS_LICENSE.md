# ASSETS_LICENSE.md — Asset Provenance & License Registry

> **Rule (Section 1.3 #10 & Section 10.3):** Every asset (mesh, texture, font, audio clip, shader) must be registered here **before** inclusion in the repository.
> - No real human face photographs or 3D scans of real people.
> - No assets with `"non-commercial only"` licenses.
> - No browser TTS in commercial builds.
> - All procedural placeholder meshes, textures, and synthesized audio must carry the `TEMP_` prefix until replaced after Gate 1 (*Uji Anekdot*).

| Asset Path / Identifier | Category | Origin / Author | License | Status |
|---|---|---|---|---|
| `TEMP_ProceduralTextures` (`webgl_vertical_slice/src/renderer/ProceduralTextures.js`) | 2D Albedo / Lattice Maps (512x512 `LINEAR_MIPMAP_LINEAR`) | In-house procedural generator | MIT / Proprietary | `TEMP_` (Frozen Look-Dev Lab `LAB_`) |
| `TEMP_ProceduralMeshes` (`webgl_vertical_slice/src/renderer/MeshBuilder.js`) | 3D Blockout Primitives & Articulated Characters | In-house procedural generator | MIT / Proprietary | `TEMP_` (Frozen Look-Dev Lab `LAB_`) |
| `TEMP_LayeredWebAudio` (`webgl_vertical_slice/src/game/GameplayControllers.js`) | Synthesized Web Audio SFX & BGM | In-house procedural synthesizer | MIT / Proprietary | `TEMP_` (Frozen Look-Dev Lab `LAB_`) |
| `UkiyoENoirCelOutline.shader` (`unity_project/Assets/_Project/Art/Shaders/`) | Unity URP HLSL Shader | In-house shader code | MIT / Proprietary | Active Baseline Shader |
| `legacy/KageAna_v0.7_Legacy_Mechanics_Archive.zip` | Archived C# Prototype Scripts | In-house C# code | MIT / Proprietary | Archived Reference (`legacy/`) |


## Catatan Lisensi Tambahan Gelombang E (Font, VRM/VRoid, Generator Konsep, Audio Placeholder)
1. **Font UI Diegetik (E4.5):**
   - **Noto Serif JP**, **Shippori Mincho**, dan **Zen Antique**: berlisensi **SIL Open Font License 1.1 (OFL-1.1)** — bebas digunakan secara komersial di dalam bundel aplikasi Windows & Android selama tidak dijual tersendiri sebagai berkas font.
2. **Paket UniVRM & Model Uji VRoid Studio (E3.1 & E6.4):**
   - **UniVRM (`com.vrmc.gltf`, `com.vrmc.vrm` v0.128.3):** berlisensi **MIT License** (`https://github.com/vrm-c/UniVRM`).
   - **VRoid Studio Stable Ver.:** berdasarkan panduan resmi Pixiv (`https://vroid.com/en/studio/guidelines`), model 3D yang diekspor dari VRoid Studio dapat dipakai untuk proyek komersial, namun item preset bawaan dimiliki oleh Pixiv (bukan CC0) dan tidak boleh didistribusikan ulang sebagai paket aset mentah; sampel `AvatarSample_A..Z` berlisensi **CC0**. Pengguna wajib memeriksa kembali ketentuan layanan pada hari ekspor (`PERLU DIVERIFIKASI SAAT RILIS`).
3. **Gambar Konsep (`PROMPT_PACK_KONSEP.md` — E6.3):**
   - Seluruh gambar yang dihasilkan pengguna wajib dicatat *prompt*, *seed*, tanggal pembuatan, dan ketentuan komersial layanan generator pada hari pembuatan, serta diverifikasi bebas kemiripan dengan karakter berhak cipta.
4. **Audio Prosedural (`unity_project/Assets/_Project/Art/AudioPlaceholders/PLACEHOLDER_*.wav` — E5.3):**
   - Dihasilkan secara matematis dengan skrip Python + NumPy (`tools/generate_placeholder_audio.py`), berstatus **CC0 / PLACEHOLDER INTERNAL** (bukan aset rilis final). Detail per berkas tercatat di `AUDIO_MANIFEST.csv`.
