# ARCHITECTURE.md — Technical Architecture v3.0 (Unity 6 + URP)

> **Synchronized with Sections 11 and 12 of `KageAna_Kitab_Dunia_dan_Instruksi_Maha_Lengkap.md`.**

---

## 1. Repository & Directory Structure (Section 11.1)

```
unity_project/
  Assets/_Project/
    Data/                 # SINGLE SOURCE OF TRUTH (JSON / ScriptableObject)
      npcs/ places/ gigs/ stories/ rumors/ items/ clothing/ festivals/ tuning/ lighting/
    Runtime/
      Sim/                # PURE C# — ZERO UnityEngine.GameObject DEPENDENCY (Headless-able)
        Clock/ Npc/ Memory/ Rumor/ Suspicion/ Economy/ Gig/ Story/ Weather/ Save/
      View/               # Presents SimState (NPC views, diegetic UI, VFX)
      Player/             # Input, camera, locomotion, contextual actions
      World/              # District additive streaming, NavMesh, smart object anchors
      UI/ Audio/ Debug/
    Scripts/_Legacy/      # Preserved v2.0 MonoBehaviour scripts (non-canonical reference)
    Art/                  # Final assets (built only after Gate 1 passes)
    Tests/EditMode/ Tests/PlayMode/
tools/
  validate_data.py        # Schema + cross-reference + schedule + gig approach validator
  test_handedness.py      # 4-part handedness regression test suite (Section 12.6)
  test_fix.js             # Node/JS math, projection, and input handedness verifier
  run_headless_sim.py     # Deterministic seed-based headless simulation runner (Section 12.2)
  run_ci.py               # Unified CI pipeline runner (validator + handedness + red-flags + sim)
  sync_data.py            # Syncs canonical JSON data for the frozen WebGL lab
  build_standalone.py     # Generates derivative standalone HTML for the frozen WebGL lab
webgl_vertical_slice/     # FROZEN Look-Dev Laboratory (LAB_ — do not modify)
docs/
  schemas/                # JSON Schema definitions for all canonical Data domains
DECISIONS.md IDEAS.md ASSETS_LICENSE.md ART_BIBLE.md AGENTS.md CLAUDE.md
```

---

## 2. Core Architectural Laws (Section 11.2)

1. **`Sim` Separated from `View`:** `Runtime/Sim` depends only on pure C# and canonical data. `Runtime/View` reads `SimState` and dispatches commands.
2. **Seed & Determinism:** All randomness in `Sim` uses `SimRandom(seed, stream)`. `UnityEngine.Random` and unseeded RNG are strictly prohibited in `Sim`. Running a 28-day simulation twice with the same seed produces bit-identical `sim_log.jsonl` and `SIM REPORT` outputs.
3. **Typed Event Bus:** Struct-based events (`NpcSawEvent`, `RumorHeardEvent`, `ViolenceEvent`, `GigStateChanged`, etc.) logged to `sim_log.jsonl`.
4. **No Free Knowledge Law:** NPCs know only what they directly saw, heard, were told via the rumor graph, or inferred from physical traces. `GameObject.Find` or reading global player state from NPC logic is a critical violation (`violations > 0` fails CI).
5. **Simulation LOD (Section 8.12):**
   - `L0 Full` (`<= 40m` from player): `10 Hz` (perception, navigation, animation, interaction).
   - `L1 Light` (`40–120m`): `2 Hz` (schedule, coarse navigation).
   - `L2 Abstract` (`> 120m` / off-screen): `1 tick per game minute` (place & status updates; memories and rumors still propagate).
6. **Left-Handed Coordinate & Handedness Convention (Section 1.3 #11 & Section 12.6):**
   - World space is left-handed: `+X` = screen-right, `+Y` = up, `+Z` = forward at `yaw = 0`.
   - `forward = (sin yaw, cos yaw)`, `right = (cos yaw, -sin yaw)`.
   - Every camera/render/input change must pass `tools/test_handedness.py` (Mathematical, Projection NDC, Input Delta, and Visual `"R"` Marker tests).
