# KAGE-ANA (影穴) — Art Bible v3.0 (Ukiyo-e Noir / Sumi-e Woodblock & Realita Shinobi Lampiran A)

Dokumen ini menyatukan aturan visual **Kitab Dunia Bagian 10** dan pembaruan **Lampiran A (Shinonome Sōma & Realita Shinobi, A.1 #4–6, A.4.4, A.6)**.

## 1. Empat Warna Inti + Satu Aksen Kedua (Disiplin Palet Cetak Kayu)

| Peran Warna | Nama Kanonis | Kode HEX | Aturan Penggunaan |
| :--- | :--- | :--- | :--- |
| **1. Kertas Dasar (Terang)** | *Washi Cream* | `#EAE0C8` | Bidang kertas *shōji*, langit cakrawala *bokashi* siang/sore, kabut latar, dan pakaian siang warga. |
| **2. Tinta Utama (Gelap)** | *Sumi Blue-Black* | `#101622` | Garis tepi kuas *sumi-e*, siluet kayu bakar (*yakisugi*), bayangan pekat. **Catatan Penting (Lampiran A.1 #4):** Tidak boleh digunakan sebagai warna pakaian hitam pekat (*#000000* dilarang). |
| **3. Aksen Bahaya & Stempel** | *Cinnabar Red (Shu-iro)* | `#C8232C` | Gerbang *torii*, segel *hanko*, percikan darah tinta, penanda bahaya/target, dan ketegangan *Wajah Asli*. |
| **4. Cahaya Hangat** | *Lantern Gold (Andon)* | `#F5B041` | Cahaya lentera batu/kertas, bara api, pantulan air malam, dan kehangatan kehidupan pasar (*Omote*). |
| **5. Pakaian Malam & Penjaga** | *Ai-Zome Dark Indigo* & *Ash-Brown* | `#1F3A60` / `#3A342C` | **Pengganti Shōzoku Hitam (Lampiran A.1 #4 & A.4.4):** Pakaian kerja malam Sōma dan seragam penjaga memakai indigo gelap (`#1F3A60`) dan abu-cokelat tanah (`#3A342C`) yang menyatu dengan cahaya bulan dan bayangan pepohonan. |

## 2. Aturan Kostum & Peralatan Shinonome Sōma (Menimpa Kitab 9.6)

1. **Dilarang Memakai "Shōzoku Hitam" Total (`#000000`)**:
   - Citra ninja serba-hitam adalah konvensi panggung abad ke-20. Sesuai *Bansenshūkai* / *Shōninki* (`Lampiran A.1 #4`), pakaian malam Sōma menggunakan **indigo gelap (`#1F3A60`)** atau **abu-cokelat (`#3A342C`)** senada langit malam dan tanah lembah.
2. **Pakaian Siang (*Omote* — Pedagang Keliling)**:
   - *Kosode* pedagang berbahan rami/katun dengan warna tanah/indigo lembut, dipadukan dengan **caping anyaman bambu (*sugegasa*)**, **kotak pikul (*oi-bako* / *tenbin-bako*)**, dan **tongkat pikul (*tenbin-bō*)**.
3. **Senjata & Alat Nyata (`Lampiran A.1 #5–7` & `A.4.4`)**:
   - **Tidak ada *ninjatō* lurus berpelindung persegi**: Senjata utama Sōma adalah **pedang biasa (*wakizashi* atau *katana*)** yang tampak lazim atau **disembunyikan di dalam kotak/pikulan dagangan**.
   - **Kunai sebagai Perkakas**: Secara visual digambarkan sebagai besi penyungkil/sekop daun tebal untuk memanjat tembok batu dan mencongkel kunci/pintu kayu, bukan pisau lempar tipis.
   - **Shadow-Meld sebagai Lisensi Artistik (`Lampiran A.1 #10`)**: Diwujudkan lewat perendaman siluet ke dalam kolam bayangan dan sapuan tinta *sumi-e*, tanpa partikel sihir/mistik.
4. **Visual *Wajah Asli* (`Lampiran A.4.3`)**:
   - **Bukan transformasi ganti kostum**: Ketika *Wajah Asli* retak atau terbuka di siang/malam hari, yang berubah secara visual adalah **postur tubuh (merendah dan siap menerkam), arah tatapan mata, nada suara (jatuh ke register *Ura* yang datar), dan kepekatan garis tinta bayangan**, diikuti kotak dagangan yang dilepas atau jatuh ke tanah.

## 3. Daftar Aset Kanonis (Kitab 10.5 + Tambahan Wajib Lampiran A.6)

Seluruh aset sementara pada tahap *blockout* wajib diberi awalan `TEMP_` pada `ASSETS_LICENSE.md`.

### A. Aset Protagonis (`Shinonome Sōma`) & Perangkat Dagang (`Lampiran A.6 #10.5`)
1. **`SM_Player_Souma_Merchant` & `SM_Player_Souma_NightIndigo`**: Rig karakter Sōma dengan *kosode* pedagang siang dan pakaian kerja malam indigo gelap (`#1F3A60`) / abu-cokelat (`#3A342C`) — **tanpa hitam total**.
2. **`SM_Prop_KotakPikul_Oibako`**: Kotak pikul kayu pedagang bertingkat dengan kompartemen rahasia penyembunyi *wakizashi/katana*.
3. **`SM_Prop_TongkatPikul_Tenbinbo`**: Tongkat pikul kayu keras yang dapat dilepas sebagai tongkat bela diri darurat.
4. **`SM_Prop_Caping_Sugegasa`**: Topi caping anyaman pedagang keliling (menyembunyikan garis pandang mata saat merunduk).
5. **`SM_Prop_Timbangan_Hakari`**: Timbangan gantung perunggu/kayu dan sempoa (*soroban*) untuk transaksi pasar.
6. **Aset Visual 8 Kategori Dagangan (`SM_Ware_01` s/d `SM_Ware_08`)**:
   - `(1)` Bungkusan obat & botol ramuan keramik (`ware_obat_ramuan`)
   - `(2)` Gulungan kain tenun & ikatan benang (`ware_kain_benang`)
   - `(3)` Keranjang ikan kering & karung garam (`ware_ikan_garam`)
   - `(4)` Tumpukan kertas *washi*, batu tinta *suzuri*, & lilin (`ware_kertas_tinta_lilin`)
   - `(5)` Panci besi, pisau dapur, & perkakas tukang (`ware_dapur_perkakas`)
   - `(6)` Guci *sake* & baki kudapan (`ware_sake_kudapan`)
   - `(7)` Ikatan kayu bakar & keranjang arang (`ware_arang_kayu`)
   - `(8)` Topeng rubah/tengu festival, lentera kertas, & jimat *ofuda* (`ware_barang_festival`)
7. **Animasi & Viewmodel Khusus Sōma (`A.6 #10.5`)**:
   - `Anim_Souma_Sell_Offer` & `Anim_Souma_Bargain_Weigh`: Menimbang barang, menyerahkan dagangan, dan menawar dengan gestur hangat (*Omote*).
   - `Anim_Souma_ConcealBlade_InWares` & `Anim_Souma_DrawFromWares`: Menyembunyikan dan mencabut *wakizashi/katana* dari dalam kotak pikul/tongkat pikul.
   - `Anim_Souma_TrueFace_Retak` & `Anim_Souma_TrueFace_Terbuka`: Perubahan postur bahu/kepala, tangan meraba gagang tersembunyi di dagangan (Tahap 1 *Retak*), dan pelepasan kotak pikul diikuti tebasan 1–3 detik (Tahap 2 *Terbuka*).

### B. Aset Arsitektur, Pencahayaan, & Alat Shinobi (Kitab 10.5)
1. Bangunan modular Lembah Kurokawa (*Minka*, *Nagaya*, Kedai Teh O-Hana, Apotek Sōan, Kuil Lonceng Takeda, Gudang Dermaga, Pos Gerbang Selatan, Balai Juru Tulis Benteng).
2. Alat shinobi historis (`A.1 #6–7`): *Kunai* (perkakas panjat/congkel), tangga lipat bambu/tali, *kaginawa*, tabung asap & api mesiu, serta bungkusan ramuan/racun.
3. Tabel `LightingPreset` 49 kombinasi (`7 segmen waktu × 7 cuaca` di `Data/lighting/lighting_presets.json`).
