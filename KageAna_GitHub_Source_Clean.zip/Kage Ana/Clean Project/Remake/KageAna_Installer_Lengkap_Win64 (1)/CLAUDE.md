See [AGENTS.md](./AGENTS.md) for all project rules, architecture, and sequential task instructions.
