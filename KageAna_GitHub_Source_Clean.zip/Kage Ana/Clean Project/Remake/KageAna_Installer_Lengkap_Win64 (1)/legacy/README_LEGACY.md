# Legacy Prototype Archive (`v0.1` – `v0.7`)

- `KageAna_v0.7_Legacy_Mechanics_Archive.zip` preserves the pure gameplay scripts from `v0.7` (social deduction clues, anatomical zones, weapon disarm, shrine revival) with all unlicensed `base64` human scans removed.
- These mechanics are archived as design reference for the post-slice Social Sandbox mode (`G6` in the competitive roadmap).
