// 512x512 Stylized Ukiyo-e Woodblock Textures with LINEAR_MIPMAP_LINEAR (Fixes Critique A.5 & Implements G5 Shoji Silhouettes)

function createMipTexture(gl, size, drawFn) {
  const c = document.createElement('canvas');
  c.width = size;
  c.height = size;
  const ctx = c.getContext('2d');
  drawFn(ctx, size);

  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
  gl.generateMipmap(gl.TEXTURE_2D);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
  return tex;
}

window.buildAllProceduralTextures = function buildAllProceduralTextures(gl) {
  // 1. Hand-Painted Ink Cedar Wood (Sugi)
  const wood = createMipTexture(gl, 512, (ctx, s) => {
    ctx.fillStyle = '#5c412c';
    ctx.fillRect(0, 0, s, s);
    for (let y = 0; y < s; y += 64) {
      ctx.fillStyle = (y / 64) % 2 === 0 ? '#543b27' : '#664932';
      ctx.fillRect(0, y, s, 60);
      ctx.fillStyle = '#141822';
      ctx.fillRect(0, y + 60, s, 4);
      ctx.strokeStyle = 'rgba(16, 22, 34, 0.42)';
      ctx.lineWidth = 2.0;
      for (let g = 8; g < 54; g += 11) {
        ctx.beginPath();
        ctx.moveTo(0, y + g);
        ctx.bezierCurveTo(s * 0.3, y + g + 5, s * 0.7, y + g - 5, s, y + g);
        ctx.stroke();
      }
    }
  });

  // 2. Curved Kawara Slate Roof Tiles with Wave Contours
  const kawara = createMipTexture(gl, 512, (ctx, s) => {
    ctx.fillStyle = '#1b2230';
    ctx.fillRect(0, 0, s, s);
    for (let x = 0; x < s; x += 64) {
      const grad = ctx.createLinearGradient(x, 0, x + 64, 0);
      grad.addColorStop(0.0, '#0e131c');
      grad.addColorStop(0.45, '#2b3548');
      grad.addColorStop(0.85, '#181f2c');
      grad.addColorStop(1.0, '#0c1018');
      ctx.fillStyle = grad;
      ctx.fillRect(x, 0, 64, s);
    }
    ctx.strokeStyle = '#0c1018';
    ctx.lineWidth = 4;
    for (let y = 0; y < s; y += 64) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(s, y);
      ctx.stroke();
    }
  });

  // 3. Crisp Washi Cream Shoji Screen Lattice
  const shoji = createMipTexture(gl, 512, (ctx, s) => {
    ctx.fillStyle = '#eae0c8';
    ctx.fillRect(0, 0, s, s);
    // Warm inner lantern glow gradient
    const glow = ctx.createRadialGradient(s * 0.5, s * 0.42, 20, s * 0.5, s * 0.42, s * 0.48);
    glow.addColorStop(0, '#f7d794');
    glow.addColorStop(1, '#e6dbc2');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, s, s * 0.70);
    // Lower dark timber wainscot
    ctx.fillStyle = '#382619';
    ctx.fillRect(0, s * 0.70, s, s * 0.30);
    // Crisp dark Sumi lattice mullions
    ctx.fillStyle = '#181412';
    for (let x = 0; x < s; x += 64) ctx.fillRect(x, 0, 6, s);
    for (let y = 0; y < s * 0.70; y += 48) ctx.fillRect(0, y, s, 5);
  });

  // 4. Shoji Screen with Projected Occupant Silhouette (Pillar 1 / G5 — Siluet di balik shoji!)
  const shojiSilhouette = createMipTexture(gl, 512, (ctx, s) => {
    ctx.fillStyle = '#f2d084';
    ctx.fillRect(0, 0, s, s);
    const glow = ctx.createRadialGradient(s * 0.5, s * 0.40, 15, s * 0.5, s * 0.40, s * 0.52);
    glow.addColorStop(0, '#ffe299');
    glow.addColorStop(1, '#d8be82');
    ctx.fillStyle = glow;
    ctx.fillRect(0, 0, s, s * 0.72);

    // Draw Projected Samurai/Occupant Shadow Silhouette behind the Shoji paper!
    ctx.fillStyle = 'rgba(18, 20, 28, 0.74)';
    // Sitting/Standing Samurai silhouette with chonmage topknot & katana
    ctx.beginPath();
    ctx.arc(s * 0.48, s * 0.25, 34, 0, Math.PI * 2); // Head
    ctx.fill();
    ctx.fillRect(s * 0.46, s * 0.14, 16, 26); // Topknot
    ctx.beginPath();
    ctx.moveTo(s * 0.34, s * 0.70);
    ctx.lineTo(s * 0.38, s * 0.32);
    ctx.lineTo(s * 0.60, s * 0.32);
    ctx.lineTo(s * 0.65, s * 0.70);
    ctx.closePath();
    ctx.fill();
    // Katana silhouette at waist
    ctx.strokeStyle = 'rgba(18, 20, 28, 0.80)';
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(s * 0.28, s * 0.56);
    ctx.lineTo(s * 0.72, s * 0.44);
    ctx.stroke();

    // Lower wainscot & Shoji lattice over the silhouette
    ctx.fillStyle = '#382619';
    ctx.fillRect(0, s * 0.70, s, s * 0.30);
    ctx.fillStyle = '#181412';
    for (let x = 0; x < s; x += 64) ctx.fillRect(x, 0, 6, s);
    for (let y = 0; y < s * 0.70; y += 48) ctx.fillRect(0, y, s, 5);
  });

  // 5. Ishigaki Flagstone & Masonry
  const stone = createMipTexture(gl, 512, (ctx, s) => {
    ctx.fillStyle = '#5a6270';
    ctx.fillRect(0, 0, s, s);
    const rows = 8;
    const rh = s / rows;
    for (let r = 0; r < rows; r++) {
      const y = r * rh;
      const offset = (r % 2) * 64;
      for (let x = -64; x < s; x += 128) {
        ctx.fillStyle = ((x + r * 31) % 3 === 0) ? '#687080' : '#4e5563';
        ctx.fillRect(x + offset + 3, y + 3, 122, rh - 6);
        ctx.strokeStyle = '#181c24';
        ctx.lineWidth = 4;
        ctx.strokeRect(x + offset + 3, y + 3, 122, rh - 6);
      }
    }
  });

  // 6. Brush-Painted Courtyard Earth & Moss
  const ground = createMipTexture(gl, 512, (ctx, s) => {
    ctx.fillStyle = '#3a423b';
    ctx.fillRect(0, 0, s, s);
    ctx.strokeStyle = 'rgba(20, 26, 22, 0.45)';
    ctx.lineWidth = 5;
    for (let i = 0; i < 48; i++) {
      const y = (i * 23) % s;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.bezierCurveTo(s * 0.33, y + 14, s * 0.66, y - 14, s, y);
      ctx.stroke();
    }
  });

  // 7. Woven Kimono / Armor Cloth with Traditional Pattern
  const cloth = createMipTexture(gl, 512, (ctx, s) => {
    ctx.fillStyle = '#e6dec8';
    ctx.fillRect(0, 0, s, s);
    ctx.strokeStyle = 'rgba(16, 22, 34, 0.25)';
    ctx.lineWidth = 3;
    for (let y = 0; y < s; y += 32) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(s, y); ctx.stroke();
    }
    for (let x = 0; x < s; x += 32) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, s); ctx.stroke();
    }
  });

  return { wood, kawara, shoji, shojiSilhouette, stone, ground, cloth };
};
