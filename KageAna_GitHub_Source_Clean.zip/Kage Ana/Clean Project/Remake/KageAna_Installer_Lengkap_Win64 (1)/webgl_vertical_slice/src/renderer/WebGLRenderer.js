// WebGL GPU 3D Renderer v2.0: Bokashi Sky Pass + 1024x1024 Shadow Map FBO + Ukiyo-e Cel Pass + Variable Ink Outlines

function compileProgram(gl, vsSource, fsSource) {
  const vs = gl.createShader(gl.VERTEX_SHADER);
  gl.shaderSource(vs, vsSource);
  gl.compileShader(vs);
  if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) {
    throw new Error('Vertex shader error: ' + gl.getShaderInfoLog(vs));
  }
  const fs = gl.createShader(gl.FRAGMENT_SHADER);
  gl.shaderSource(fs, fsSource);
  gl.compileShader(fs);
  if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) {
    throw new Error('Fragment shader error: ' + gl.getShaderInfoLog(fs));
  }
  const prog = gl.createProgram();
  gl.attachShader(prog, vs);
  gl.attachShader(prog, fs);
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) {
    throw new Error('Shader link error: ' + gl.getProgramInfoLog(prog));
  }
  return prog;
}

window.hexToRgbNormalized = function hexToRgbNormalized(hex) {
  const clean = (hex || '#ffffff').replace('#', '');
  const num = parseInt(clean, 16);
  return [
    ((num >> 16) & 255) / 255,
    ((num >> 8) & 255) / 255,
    (num & 255) / 255
  ];
};

const WebGLRenderer = window.WebGLRenderer = class WebGLRenderer {
  constructor(canvas) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl2', { antialias: true, preserveDrawingBuffer: true }) ||
               canvas.getContext('webgl',  { antialias: true, preserveDrawingBuffer: true });
    if (!gl) throw new Error('WebGL GPU context unavailable.');
    this.gl = gl;
    this.renderScale = 1.0;
    this.debugMode = 0;   // 0 = Normal, 1 = Black Silhouette Test [F3], 2 = Grayscale Value Test [F4]
    this.listenMode = 0;  // 1 = "Mata Telinga" Sound-Ink Washi Mode [V / Tab]
    this.photoMode = 0;   // 1 = Ukiyo-e Woodblock Photo Mode [P]
    this.timePreset = 'SORE';

    this.skyProg = compileProgram(gl, window.SKY_VS, window.SKY_FS);
    this.shadowProg = compileProgram(gl, window.SHADOW_VS, window.SHADOW_FS);
    this.celProg = compileProgram(gl, window.CEL_VS, window.CEL_FS);
    this.outlineProg = compileProgram(gl, window.OUTLINE_VS, window.OUTLINE_FS);

    // Full-screen Quad Buffer for Bokashi Woodblock Sky
    this.skyQuadBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyQuadBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, 1]), gl.STATIC_DRAW);

    this.textures = window.buildAllProceduralTextures(gl);
    this.meshes = window.createStandardMeshes(gl);
    this.initShadowFramebuffer(1024);

    this.projMat = window.Mat4.create();
    this.viewMat = window.Mat4.create();
    this.viewProjMat = window.Mat4.create();
    this.lightProjMat = window.Mat4.create();
    this.lightViewMat = window.Mat4.create();
    this.lightVPMat = window.Mat4.create();
    this.modelMat = window.Mat4.create();

    this.lastDrawCalls = 0;
    this.lastTriangles = 0;

    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  initShadowFramebuffer(size) {
    const gl = this.gl;
    this.shadowSize = size;
    this.shadowFBO = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFBO);

    this.shadowTex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, this.shadowTex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, size, size, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);

    this.shadowDepthRB = gl.createRenderbuffer();
    gl.bindRenderbuffer(gl.RENDERBUFFER, this.shadowDepthRB);
    gl.renderbufferStorage(gl.RENDERBUFFER, gl.DEPTH_COMPONENT16, size, size);

    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, this.shadowTex, 0);
    gl.framebufferRenderbuffer(gl.FRAMEBUFFER, gl.DEPTH_ATTACHMENT, gl.RENDERBUFFER, this.shadowDepthRB);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
  }

  resize() {
    const dpr = Math.min(2.0, window.devicePixelRatio || 1.0) * this.renderScale;
    this.width = Math.max(640, Math.floor(window.innerWidth * dpr));
    this.height = Math.max(360, Math.floor(window.innerHeight * dpr));
    this.canvas.width = this.width;
    this.canvas.height = this.height;
  }

  getLightingConfig() {
    // Art Bible v2 Disciplined 3-Plane Value Hierarchy (High-Value Misty Horizon, Crisp Midground, Dark Ink Foreground)
    if (this.timePreset === 'MALAM') {
      return {
        lightDir: [0.42, 0.72, -0.55],
        lightColor: [0.64, 0.74, 0.90],
        ambientColor: [0.22, 0.27, 0.36],
        rimColor: [0.95, 0.75, 0.35],
        fogColor: [0.46, 0.51, 0.60], // Soft moonlit mist separates dark silhouettes in background!
        fogDensity: 0.017
      };
    }
    return {
      lightDir: [-0.65, 0.48, -0.58],
      lightColor: [1.08, 0.96, 0.80],
      ambientColor: [0.34, 0.36, 0.42],
      rimColor: [0.96, 0.70, 0.26],
      fogColor: [0.76, 0.71, 0.61], // Warm Washi Bokashi horizon mist so buildings & guards pop with crisp contrast!
      fogDensity: 0.016
    };
  }

  bindMesh(prog, mesh) {
    const gl = this.gl;
    const posLoc = gl.getAttribLocation(prog, 'aPosition');
    if (posLoc >= 0) {
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.posBuf);
      gl.enableVertexAttribArray(posLoc);
      gl.vertexAttribPointer(posLoc, 3, gl.FLOAT, false, 0, 0);
    }
    const normLoc = gl.getAttribLocation(prog, 'aNormal');
    if (normLoc >= 0) {
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normBuf);
      gl.enableVertexAttribArray(normLoc);
      gl.vertexAttribPointer(normLoc, 3, gl.FLOAT, false, 0, 0);
    }
    const uvLoc = gl.getAttribLocation(prog, 'aUV');
    if (uvLoc >= 0) {
      gl.bindBuffer(gl.ARRAY_BUFFER, mesh.uvBuf);
      gl.enableVertexAttribArray(uvLoc);
      gl.vertexAttribPointer(uvLoc, 2, gl.FLOAT, false, 0, 0);
    }
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.idxBuf);
  }

  renderBokashiSky(camera) {
    const gl = this.gl;
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    gl.useProgram(this.skyProg);

    const posLoc = gl.getAttribLocation(this.skyProg, 'aQuadPos');
    gl.bindBuffer(gl.ARRAY_BUFFER, this.skyQuadBuf);
    gl.enableVertexAttribArray(posLoc);
    gl.vertexAttribPointer(posLoc, 2, gl.FLOAT, false, 0, 0);

    gl.uniform1f(gl.getUniformLocation(this.skyProg, 'uCameraYaw'), camera.yaw);
    gl.uniform1f(gl.getUniformLocation(this.skyProg, 'uCameraPitch'), camera.pitch);
    gl.uniform1i(gl.getUniformLocation(this.skyProg, 'uIsNight'), this.timePreset === 'MALAM' ? 1 : 0);
    gl.uniform1i(gl.getUniformLocation(this.skyProg, 'uListenMode'), this.listenMode);
    gl.uniform1i(gl.getUniformLocation(this.skyProg, 'uDebugMode'), this.debugMode);

    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST);
  }

  renderScene(camera, worldDrawItems, viewmodelItems, lanterns) {
    const gl = this.gl;
    // Shadow pass and sky use the standard counter-clockwise winding.
    gl.frontFace(gl.CCW);
    const lightCfg = this.getLightingConfig();
    let drawCalls = 0;
    let triangles = 0;

    // 1. Directional Shadow Map Pass
    const lDir = lightCfg.lightDir;
    window.Mat4.ortho(this.lightProjMat, -32, 32, -32, 32, 1.0, 90.0);
    window.Mat4.lookAt(
      this.lightViewMat,
      [lDir[0] * 38, lDir[1] * 38, lDir[2] * 38],
      [0, 0, 0],
      [0, 1, 0]
    );
    window.Mat4.multiply(this.lightVPMat, this.lightProjMat, this.lightViewMat);

    gl.bindFramebuffer(gl.FRAMEBUFFER, this.shadowFBO);
    gl.viewport(0, 0, this.shadowSize, this.shadowSize);
    gl.clearColor(1.0, 1.0, 1.0, 1.0);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);
    gl.cullFace(gl.BACK);

    gl.useProgram(this.shadowProg);
    const uLightMVPLoc = gl.getUniformLocation(this.shadowProg, 'uLightMVP');
    const uShadowModelLoc = gl.getUniformLocation(this.shadowProg, 'uModel');
    gl.uniformMatrix4fv(uLightMVPLoc, false, this.lightVPMat);

    for (let i = 0; i < worldDrawItems.length; i++) {
      const item = worldDrawItems[i];
      if (item.noShadow) continue;
      const mesh = this.meshes[item.mesh];
      if (!mesh) continue;
      window.Mat4.fromTRS(this.modelMat, item.x, item.y, item.z, item.rx || 0, item.ry || 0, item.rz || 0, item.sx, item.sy, item.sz);
      gl.uniformMatrix4fv(uShadowModelLoc, false, this.modelMat);
      this.bindMesh(this.shadowProg, mesh);
      gl.drawElements(gl.TRIANGLES, mesh.indexCount, gl.UNSIGNED_SHORT, 0);
      drawCalls++;
    }

    // 2. Main Screen Pass: Render Bokashi Woodblock Sky + Cel-Shaded World + Variable Ink Outlines
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    gl.viewport(0, 0, this.width, this.height);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    this.renderBokashiSky(camera);
    drawCalls++;

    window.Mat4.perspective(this.projMat, 62 * Math.PI / 180, this.width / this.height, 0.12, 110.0);
    // HANDEDNESS FIX (v2.0.1): gameplay code uses a left-handed convention (forward = (sin yaw, cos yaw),
    // right = (cos yaw, -sin yaw), i.e. +X is screen-right). Mat4.lookAt is right-handed, which mirrored the
    // image horizontally (mouse right -> view turned left, right-hand katana drawn on the left).
    // Mirroring clip-space X restores the intended orientation; triangle winding flips, so use CW front faces.
    this.projMat[0] = -this.projMat[0];
    gl.frontFace(gl.CW);
    const cosP = Math.cos(camera.pitch), sinP = Math.sin(camera.pitch);
    const fwdX = Math.sin(camera.yaw) * cosP;
    const fwdY = sinP;
    const fwdZ = Math.cos(camera.yaw) * cosP;
    window.Mat4.lookAt(
      this.viewMat,
      [camera.x, camera.y, camera.z],
      [camera.x + fwdX, camera.y + fwdY, camera.z + fwdZ],
      [Math.sin(camera.roll || 0), Math.cos(camera.roll || 0), 0]
    );
    window.Mat4.multiply(this.viewProjMat, this.projMat, this.viewMat);

    this.drawPassWithCelAndOutlines(worldDrawItems, lightCfg, camera, lanterns, (dc, tr) => {
      drawCalls += dc;
      triangles += tr;
    });

    // 3. First-Person 3D Viewmodel Hands, Cloth Wraps, Kuji-in Seals & Katana
    if (viewmodelItems && viewmodelItems.length > 0 && this.debugMode !== 1) {
      gl.clear(gl.DEPTH_BUFFER_BIT);
      this.drawPassWithCelAndOutlines(viewmodelItems, lightCfg, camera, lanterns, (dc, tr) => {
        drawCalls += dc;
        triangles += tr;
      });
    }

    gl.frontFace(gl.CCW);
    this.lastDrawCalls = drawCalls;
    this.lastTriangles = Math.round(triangles);
  }

  drawPassWithCelAndOutlines(items, lightCfg, camera, lanterns, onStats) {
    const gl = this.gl;
    let dc = 0, tris = 0;

    gl.useProgram(this.celProg);
    gl.cullFace(gl.BACK);

    gl.uniformMatrix4fv(gl.getUniformLocation(this.celProg, 'uViewProj'), false, this.viewProjMat);
    gl.uniformMatrix4fv(gl.getUniformLocation(this.celProg, 'uLightVP'), false, this.lightVPMat);
    gl.uniform3fv(gl.getUniformLocation(this.celProg, 'uLightDir'), lightCfg.lightDir);
    gl.uniform3fv(gl.getUniformLocation(this.celProg, 'uLightColor'), lightCfg.lightColor);
    gl.uniform3fv(gl.getUniformLocation(this.celProg, 'uAmbientColor'), lightCfg.ambientColor);
    gl.uniform3fv(gl.getUniformLocation(this.celProg, 'uRimColor'), lightCfg.rimColor);
    gl.uniform3fv(gl.getUniformLocation(this.celProg, 'uFogColor'), lightCfg.fogColor);
    gl.uniform1f(gl.getUniformLocation(this.celProg, 'uFogDensity'), lightCfg.fogDensity);
    gl.uniform3f(gl.getUniformLocation(this.celProg, 'uCameraPos'), camera.x, camera.y, camera.z);
    gl.uniform1i(gl.getUniformLocation(this.celProg, 'uDebugMode'), this.debugMode);
    gl.uniform1i(gl.getUniformLocation(this.celProg, 'uListenMode'), this.listenMode);
    gl.uniform1i(gl.getUniformLocation(this.celProg, 'uPhotoMode'), this.photoMode);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, this.shadowTex);
    gl.uniform1i(gl.getUniformLocation(this.celProg, 'uShadowMap'), 1);

    const flicker = 0.94 + Math.sin(performance.now() * 0.014) * 0.06;
    for (let i = 0; i < 6; i++) {
      const l = lanterns && lanterns[i];
      const lx = l ? l.x + (l.shiftOffset || 0) : 0;
      gl.uniform3f(gl.getUniformLocation(this.celProg, `uLanternPos[${i}]`), lx, l ? 1.5 : -99, l ? l.z : 0);
      gl.uniform1f(gl.getUniformLocation(this.celProg, `uLanternIntensity[${i}]`), (l && l.lit) ? flicker : 0.0);
    }

    const uModelLoc = gl.getUniformLocation(this.celProg, 'uModel');
    const uBaseColLoc = gl.getUniformLocation(this.celProg, 'uBaseColor');
    const uEmissiveLoc = gl.getUniformLocation(this.celProg, 'uEmissive');
    const uIsCharLoc = gl.getUniformLocation(this.celProg, 'uIsCharacter');
    const uAlbedoLoc = gl.getUniformLocation(this.celProg, 'uAlbedoMap');

    gl.activeTexture(gl.TEXTURE0);
    gl.uniform1i(uAlbedoLoc, 0);

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      const mesh = this.meshes[item.mesh];
      if (!mesh) continue;

      window.Mat4.fromTRS(this.modelMat, item.x, item.y, item.z, item.rx || 0, item.ry || 0, item.rz || 0, item.sx, item.sy, item.sz);
      gl.uniformMatrix4fv(uModelLoc, false, this.modelMat);

      const rgb = item.rgb || window.hexToRgbNormalized(item.color || '#ffffff');
      gl.uniform3f(uBaseColLoc, rgb[0], rgb[1], rgb[2]);
      gl.uniform1f(uEmissiveLoc, item.emissive || 0.0);
      gl.uniform1i(uIsCharLoc, item.isCharacter ? 1 : 0);

      const tex = this.textures[item.tex || 'wood'] || this.textures.wood;
      gl.bindTexture(gl.TEXTURE_2D, tex);

      this.bindMesh(this.celProg, mesh);
      gl.drawElements(gl.TRIANGLES, mesh.indexCount, gl.UNSIGNED_SHORT, 0);
      dc++;
      tris += mesh.indexCount / 3;
    }

    // Variable-Weight Sumi-e Brush Ink Outlines
    if (this.debugMode !== 1) {
      gl.useProgram(this.outlineProg);
      gl.cullFace(gl.FRONT);
      gl.uniformMatrix4fv(gl.getUniformLocation(this.outlineProg, 'uViewProj'), false, this.viewProjMat);
      gl.uniform3f(gl.getUniformLocation(this.outlineProg, 'uOutlineColor'), 0.05, 0.07, 0.11);
      gl.uniform3f(gl.getUniformLocation(this.outlineProg, 'uCameraPos'), camera.x, camera.y, camera.z);
      const uOutModelLoc = gl.getUniformLocation(this.outlineProg, 'uModel');
      const uOutWidthLoc = gl.getUniformLocation(this.outlineProg, 'uOutlineWidth');

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (item.outlineWidth === 0) continue;
        const mesh = this.meshes[item.mesh];
        if (!mesh) continue;

        window.Mat4.fromTRS(this.modelMat, item.x, item.y, item.z, item.rx || 0, item.ry || 0, item.rz || 0, item.sx, item.sy, item.sz);
        gl.uniformMatrix4fv(uOutModelLoc, false, this.modelMat);
        gl.uniform1f(uOutWidthLoc, item.outlineWidth || (item.isCharacter ? 0.022 : 0.026));

        this.bindMesh(this.outlineProg, mesh);
        gl.drawElements(gl.TRIANGLES, mesh.indexCount, gl.UNSIGNED_SHORT, 0);
        dc++;
      }
      gl.cullFace(gl.BACK);
    }

    onStats(dc, tris);
  }
};
