// 3D Indexed Triangle Mesh Builder v2.0 (TEMP_Procedural blockout & look-dev geometry)

const GeometryBuffer = window.GeometryBuffer = class GeometryBuffer {
  constructor() {
    this.positions = [];
    this.normals = [];
    this.uvs = [];
    this.indices = [];
  }

  addVertex(x, y, z, nx, ny, nz, u, v) {
    const idx = this.positions.length / 3;
    this.positions.push(x, y, z);
    this.normals.push(nx, ny, nz);
    this.uvs.push(u, v);
    return idx;
  }

  addQuad(p0, p1, p2, p3, uScale = 1, vScale = 1) {
    const ux = p1[0] - p0[0], uy = p1[1] - p0[1], uz = p1[2] - p0[2];
    const vx = p3[0] - p0[0], vy = p3[1] - p0[1], vz = p3[2] - p0[2];
    let nx = uy * vz - uz * vy;
    let ny = uz * vx - ux * vz;
    let nz = ux * vy - uy * vx;
    const len = Math.hypot(nx, ny, nz) || 1;
    nx /= len; ny /= len; nz /= len;

    const i0 = this.addVertex(p0[0], p0[1], p0[2], nx, ny, nz, 0, 0);
    const i1 = this.addVertex(p1[0], p1[1], p1[2], nx, ny, nz, uScale, 0);
    const i2 = this.addVertex(p2[0], p2[1], p2[2], nx, ny, nz, uScale, vScale);
    const i3 = this.addVertex(p3[0], p3[1], p3[2], nx, ny, nz, 0, vScale);
    this.indices.push(i0, i1, i2, i0, i2, i3);
  }

  addBox(cx, cy, cz, w, h, d, uTile = 1, vTile = 1) {
    const hx = w * 0.5, hy = h * 0.5, hz = d * 0.5;
    const x0 = cx - hx, x1 = cx + hx;
    const y0 = cy - hy, y1 = cy + hy;
    const z0 = cz - hz, z1 = cz + hz;
    this.addQuad([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1], uTile, vTile);
    this.addQuad([x1, y0, z0], [x0, y0, z0], [x0, y1, z0], [x1, y1, z0], uTile, vTile);
    this.addQuad([x1, y0, z1], [x1, y0, z0], [x1, y1, z0], [x1, y1, z1], uTile, vTile);
    this.addQuad([x0, y0, z0], [x0, y0, z1], [x0, y1, z1], [x0, y1, z0], uTile, vTile);
    this.addQuad([x0, y1, z1], [x1, y1, z1], [x1, y1, z0], [x0, y1, z0], uTile, vTile);
    this.addQuad([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1], uTile, vTile);
  }

  addTaperedLimb(x0, y0, z0, r0, x1, y1, z1, r1, sides = 10) {
    const baseIdx = this.positions.length / 3;
    for (let s = 0; s <= sides; s++) {
      const a = (s / sides) * Math.PI * 2;
      const ca = Math.cos(a), sa = Math.sin(a);
      this.addVertex(x0 + ca * r0, y0, z0 + sa * r0, ca, 0.15, sa, s / sides, 0);
      this.addVertex(x1 + ca * r1, y1, z1 + sa * r1, ca, 0.15, sa, s / sides, 1);
    }
    for (let s = 0; s < sides; s++) {
      const i = baseIdx + s * 2;
      this.indices.push(i, i + 2, i + 3, i, i + 3, i + 1);
    }
  }

  addFlatRing(innerR, outerR, segs = 20) {
    const baseIdx = this.positions.length / 3;
    for (let s = 0; s <= segs; s++) {
      const a = (s / segs) * Math.PI * 2;
      const ca = Math.cos(a), sa = Math.sin(a);
      this.addVertex(ca * innerR, 0.02, sa * innerR, 0, 1, 0, s / segs, 0);
      this.addVertex(ca * outerR, 0.02, sa * outerR, 0, 1, 0, s / segs, 1);
    }
    for (let s = 0; s < segs; s++) {
      const i = baseIdx + s * 2;
      this.indices.push(i, i + 2, i + 3, i, i + 3, i + 1);
    }
  }

  addCurvedIrimoyaRoof(cx, baseY, cz, w, h, d) {
    const steps = 6;
    const halfW = w * 0.5;
    const halfD = d * 0.5;
    for (let i = 0; i < steps; i++) {
      const t0 = i / steps;
      const t1 = (i + 1) / steps;
      const y0 = baseY + h * Math.pow(1 - t0, 1.45);
      const y1 = baseY + h * Math.pow(1 - t1, 1.45);
      const xOff0 = halfW * t0;
      const xOff1 = halfW * t1;
      const zSpan0 = halfD * (0.62 + 0.38 * t0);
      const zSpan1 = halfD * (0.62 + 0.38 * t1);
      const cornerLift1 = (t1 > 0.7) ? (t1 - 0.7) * 0.38 : 0;

      this.addQuad([cx + xOff0, y0, cz + zSpan0], [cx + xOff1, y1 + cornerLift1, cz + zSpan1], [cx + xOff1, y1 + cornerLift1, cz - zSpan1], [cx + xOff0, y0, cz - zSpan0], 3, 1);
      this.addQuad([cx - xOff0, y0, cz - zSpan0], [cx - xOff1, y1 + cornerLift1, cz - zSpan1], [cx - xOff1, y1 + cornerLift1, cz + zSpan1], [cx - xOff0, y0, cz + zSpan0], 3, 1);
      this.addQuad([cx - xOff0, y0, cz + zSpan0], [cx - xOff1, y1 + cornerLift1, cz + zSpan1], [cx + xOff1, y1 + cornerLift1, cz + zSpan1], [cx + xOff0, y0, cz + zSpan0], 3, 1);
      this.addQuad([cx + xOff0, y0, cz - zSpan0], [cx + xOff1, y1 + cornerLift1, cz - zSpan1], [cx - xOff1, y1 + cornerLift1, cz - zSpan1], [cx - xOff0, y0, cz - zSpan0], 3, 1);
    }
    this.addBox(cx, baseY + h + 0.14, cz, 0.36, 0.28, d * 0.66, 1, 2);
  }

  upload(gl) {
    const vao = {
      posBuf: gl.createBuffer(),
      normBuf: gl.createBuffer(),
      uvBuf: gl.createBuffer(),
      idxBuf: gl.createBuffer(),
      indexCount: this.indices.length
    };
    gl.bindBuffer(gl.ARRAY_BUFFER, vao.posBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.positions), gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER, vao.normBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.normals), gl.STATIC_DRAW);
    gl.bindBuffer(gl.ARRAY_BUFFER, vao.uvBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.uvs), gl.STATIC_DRAW);
    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, vao.idxBuf);
    gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(this.indices), gl.STATIC_DRAW);
    return vao;
  }
};

window.createStandardMeshes = function createStandardMeshes(gl) {
  const boxGeo = new GeometryBuffer();
  boxGeo.addBox(0, 0, 0, 1, 1, 1, 1, 1);

  const roofGeo = new GeometryBuffer();
  roofGeo.addCurvedIrimoyaRoof(0, 0, 0, 1, 1, 1);

  const cylGeo = new GeometryBuffer();
  cylGeo.addTaperedLimb(0, -0.5, 0, 0.5, 0, 0.5, 0, 0.5, 10);

  const hatGeo = new GeometryBuffer();
  hatGeo.addTaperedLimb(0, 0, 0, 0.55, 0, 0.26, 0, 0.04, 12);

  // Hollow Ring for Sumi-e Sound Ripples (Pillar 2 / G2) & Shadow-Meld Pools (Pillar 1 / G1)
  const ringGeo = new GeometryBuffer();
  ringGeo.addFlatRing(0.82, 1.0, 24);

  //Katana Complete 3D Mesh
  const katanaGeo = new GeometryBuffer();
  katanaGeo.addBox(0, 0, -0.10, 0.032, 0.042, 0.26, 1, 1);
  katanaGeo.addBox(0, 0, 0.04, 0.092, 0.092, 0.018, 1, 1);
  katanaGeo.addBox(0, 0.008, 0.44, 0.014, 0.036, 0.78, 1, 1);
  katanaGeo.addBox(0, 0.022, 0.88, 0.010, 0.026, 0.16, 1, 1);

  const guardTorsoGeo = new GeometryBuffer();
  guardTorsoGeo.addTaperedLimb(0, 0, 0, 0.22, 0, 0.56, 0, 0.27, 8);
  guardTorsoGeo.addBox(-0.31, 0.46, 0, 0.14, 0.24, 0.30, 1, 1);
  guardTorsoGeo.addBox( 0.31, 0.46, 0, 0.14, 0.24, 0.30, 1, 1);
  guardTorsoGeo.addTaperedLimb(0, -0.22, 0, 0.28, 0, 0.02, 0, 0.22, 8);

  const peasantTorsoGeo = new GeometryBuffer();
  peasantTorsoGeo.addTaperedLimb(0, 0, 0, 0.17, 0, 0.52, 0, 0.19, 8);
  peasantTorsoGeo.addTaperedLimb(0, 0.12, -0.22, 0.14, 0, 0.48, -0.24, 0.18, 8);

  const monkTorsoGeo = new GeometryBuffer();
  monkTorsoGeo.addTaperedLimb(0, -0.28, 0, 0.28, 0, 0.54, 0, 0.23, 10);

  const headGeo = new GeometryBuffer();
  headGeo.addTaperedLimb(0, -0.13, 0, 0.10, 0, 0.13, 0, 0.11, 10);

  const kabutoGeo = new GeometryBuffer();
  kabutoGeo.addTaperedLimb(0, 0, 0, 0.17, 0, 0.16, 0, 0.11, 10);
  kabutoGeo.addBox(0, 0.02, -0.13, 0.34, 0.14, 0.12);
  kabutoGeo.addBox(-0.14, 0.18, 0.12, 0.04, 0.24, 0.03);
  kabutoGeo.addBox( 0.14, 0.18, 0.12, 0.04, 0.24, 0.03);

  return {
    box: boxGeo.upload(gl),
    roof: roofGeo.upload(gl),
    cylinder: cylGeo.upload(gl),
    hat: hatGeo.upload(gl),
    ring: ringGeo.upload(gl),
    katana: katanaGeo.upload(gl),
    guardTorso: guardTorsoGeo.upload(gl),
    peasantTorso: peasantTorsoGeo.upload(gl),
    monkTorso: monkTorsoGeo.upload(gl),
    head: headGeo.upload(gl),
    kabuto: kabutoGeo.upload(gl)
  };
};
