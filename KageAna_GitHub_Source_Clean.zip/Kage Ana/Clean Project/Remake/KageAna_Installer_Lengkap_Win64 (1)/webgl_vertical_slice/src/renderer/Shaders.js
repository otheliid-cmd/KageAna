// GLSL Shaders v2.0 for KAGE-ANA (Art Bible v2: Bokashi Sky, Halftone Shadows, Listen Mode, Variable Ink Outlines)

const Mat4 = window.Mat4 = {
  create() {
    const out = new Float32Array(16);
    out[0] = 1; out[5] = 1; out[10] = 1; out[15] = 1;
    return out;
  },
  identity(out) {
    out.fill(0);
    out[0] = 1; out[5] = 1; out[10] = 1; out[15] = 1;
    return out;
  },
  multiply(out, a, b) {
    const a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3];
    const a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7];
    const a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11];
    const a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
    let b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3];
    out[0] = b0*a00 + b1*a10 + b2*a20 + b3*a30;
    out[1] = b0*a01 + b1*a11 + b2*a21 + b3*a31;
    out[2] = b0*a02 + b1*a12 + b2*a22 + b3*a32;
    out[3] = b0*a03 + b1*a13 + b2*a23 + b3*a33;
    b0 = b[4]; b1 = b[5]; b2 = b[6]; b3 = b[7];
    out[4] = b0*a00 + b1*a10 + b2*a20 + b3*a30;
    out[5] = b0*a01 + b1*a11 + b2*a21 + b3*a31;
    out[6] = b0*a02 + b1*a12 + b2*a22 + b3*a32;
    out[7] = b0*a03 + b1*a13 + b2*a23 + b3*a33;
    b0 = b[8]; b1 = b[9]; b2 = b[10]; b3 = b[11];
    out[8] = b0*a00 + b1*a10 + b2*a20 + b3*a30;
    out[9] = b0*a01 + b1*a11 + b2*a21 + b3*a31;
    out[10] = b0*a02 + b1*a12 + b2*a22 + b3*a32;
    out[11] = b0*a03 + b1*a13 + b2*a23 + b3*a33;
    b0 = b[12]; b1 = b[13]; b2 = b[14]; b3 = b[15];
    out[12] = b0*a00 + b1*a10 + b2*a20 + b3*a30;
    out[13] = b0*a01 + b1*a11 + b2*a21 + b3*a31;
    out[14] = b0*a02 + b1*a12 + b2*a22 + b3*a32;
    out[15] = b0*a03 + b1*a13 + b2*a23 + b3*a33;
    return out;
  },
  perspective(out, fovy, aspect, near, far) {
    const f = 1.0 / Math.tan(fovy / 2);
    out.fill(0);
    out[0] = f / aspect;
    out[5] = f;
    out[10] = (far + near) / (near - far);
    out[11] = -1;
    out[14] = (2 * far * near) / (near - far);
    return out;
  },
  ortho(out, left, right, bottom, top, near, far) {
    const lr = 1 / (left - right);
    const bt = 1 / (bottom - top);
    const nf = 1 / (near - far);
    out.fill(0);
    out[0] = -2 * lr;
    out[5] = -2 * bt;
    out[10] = 2 * nf;
    out[12] = (left + right) * lr;
    out[13] = (top + bottom) * bt;
    out[14] = (far + near) * nf;
    out[15] = 1;
    return out;
  },
  lookAt(out, eye, center, up) {
    let z0 = eye[0] - center[0], z1 = eye[1] - center[1], z2 = eye[2] - center[2];
    let len = Math.hypot(z0, z1, z2);
    if (len === 0) { z2 = 1; } else { z0 /= len; z1 /= len; z2 /= len; }
    let x0 = up[1] * z2 - up[2] * z1;
    let x1 = up[2] * z0 - up[0] * z2;
    let x2 = up[0] * z1 - up[1] * z0;
    len = Math.hypot(x0, x1, x2);
    if (len === 0) { x0 = 0; x1 = 0; x2 = 0; } else { x0 /= len; x1 /= len; x2 /= len; }
    const y0 = z1 * x2 - z2 * x1, y1 = z2 * x0 - z0 * x2, y2 = z0 * x1 - z1 * x0;
    out[0] = x0; out[1] = y0; out[2] = z0; out[3] = 0;
    out[4] = x1; out[5] = y1; out[6] = z1; out[7] = 0;
    out[8] = x2; out[9] = y2; out[10] = z2; out[11] = 0;
    out[12] = -(x0 * eye[0] + x1 * eye[1] + x2 * eye[2]);
    out[13] = -(y0 * eye[0] + y1 * eye[1] + y2 * eye[2]);
    out[14] = -(z0 * eye[0] + z1 * eye[1] + z2 * eye[2]);
    out[15] = 1;
    return out;
  },
  fromTRS(out, tx, ty, tz, rx, ry, rz, sx, sy, sz) {
    const cx = Math.cos(rx), sxr = Math.sin(rx);
    const cy = Math.cos(ry), syr = Math.sin(ry);
    const cz = Math.cos(rz), szr = Math.sin(rz);
    out[0] = (cy * cz + syr * sxr * szr) * sx;
    out[1] = (cx * szr) * sx;
    out[2] = (-syr * cz + cy * sxr * szr) * sx;
    out[3] = 0;
    out[4] = (syr * sxr * cz - cy * szr) * sy;
    out[5] = (cx * cz) * sy;
    out[6] = (cy * sxr * cz + syr * szr) * sy;
    out[7] = 0;
    out[8] = (syr * cx) * sz;
    out[9] = (-sxr) * sz;
    out[10] = (cy * cx) * sz;
    out[11] = 0;
    out[12] = tx;
    out[13] = ty;
    out[14] = tz;
    out[15] = 1;
    return out;
  }
};

// Pass 0: Ukiyo-e Bokashi Woodblock Sky, Layered Mountains, Flat Moon/Sun & Woodblock Clouds (Fixes Critique A.1 & A.7)
const SKY_VS = window.SKY_VS = `
  attribute vec2 aQuadPos;
  varying vec2 vScreenUV;
  void main() {
    vScreenUV = aQuadPos * 0.5 + 0.5;
    gl_Position = vec4(aQuadPos, 0.999, 1.0);
  }
`;

const SKY_FS = window.SKY_FS = `
  precision highp float;
  varying vec2 vScreenUV;
  uniform float uCameraYaw;
  uniform float uCameraPitch;
  uniform int uIsNight;
  uniform int uListenMode;
  uniform int uDebugMode;

  void main() {
    if (uDebugMode == 1) {
      gl_FragColor = vec4(0.88, 0.88, 0.88, 1.0);
      return;
    }
    if (uListenMode == 1) {
      // Mata Telinga (G2): World fades into textured Washi parchment paper
      float fiber = fract(sin(dot(vScreenUV * 420.0, vec2(12.9898, 78.233))) * 43758.5453);
      vec3 washi = vec3(0.91, 0.87, 0.78) - vec3(fiber * 0.04);
      gl_FragColor = vec4(washi, 1.0);
      return;
    }

    float horizon = 0.48 - uCameraPitch * 0.42;
    float yRel = vScreenUV.y - horizon;

    // Bokashi Woodblock Sky Gradient (Indigo Zenith -> Slate Mid -> Warm Washi Horizon Band)
    vec3 zenithCol  = uIsNight == 1 ? vec3(0.05, 0.08, 0.14) : vec3(0.11, 0.17, 0.27);
    vec3 midSkyCol  = uIsNight == 1 ? vec3(0.14, 0.21, 0.34) : vec3(0.28, 0.37, 0.48);
    vec3 horizonCol = uIsNight == 1 ? vec3(0.52, 0.56, 0.64) : vec3(0.87, 0.81, 0.69);

    float t = clamp(yRel * 2.4, 0.0, 1.0);
    // Stepped woodblock bokashi bands
    vec3 sky = mix(horizonCol, midSkyCol, smoothstep(0.0, 0.42, t));
    sky = mix(sky, zenithCol, smoothstep(0.42, 0.92, t));

    // Flat Ukiyo-e Moon / Cinnabar Sun Disk
    float angleX = fract((vScreenUV.x - 0.5) * 0.35 + uCameraYaw / 6.28318);
    vec2 moonCenter = vec2(0.56, horizon + 0.28);
    float aspect = 1.777;
    float moonDist = length(vec2((vScreenUV.x - moonCenter.x) * aspect, vScreenUV.y - moonCenter.y));
    if (moonDist < 0.068) {
      vec3 diskCol = uIsNight == 1 ? vec3(0.96, 0.93, 0.84) : vec3(0.82, 0.18, 0.20);
      sky = diskCol;
    } else if (moonDist < 0.072) {
      sky = vec3(0.08, 0.10, 0.15); // Crisp ink outline around moon/sun
    }

    // Stylized Woodblock Cloud Bands
    float cloudWave = sin((vScreenUV.x + uCameraYaw * 0.15) * 14.0) * 0.012;
    float cBand = abs(vScreenUV.y - (horizon + 0.22 + cloudWave));
    if (cBand < 0.018 && abs(sin((vScreenUV.x + uCameraYaw * 0.1) * 6.0)) > 0.35) {
      sky = mix(sky, vec3(0.92, 0.88, 0.79), 0.72);
    }

    // 3 Layered Distant Mountain Silhouettes (Bokashi Mist Planes)
    float wx = vScreenUV.x * 6.0 + uCameraYaw * 1.5;
    float mFar  = horizon + 0.035 + sin(wx * 1.4) * 0.035 + cos(wx * 3.1) * 0.018;
    float mMid  = horizon + 0.012 + sin(wx * 2.1 + 1.2) * 0.028 + cos(wx * 4.5) * 0.012;
    if (vScreenUV.y < mFar && vScreenUV.y > horizon - 0.05) {
      sky = uIsNight == 1 ? vec3(0.18, 0.23, 0.32) : vec3(0.42, 0.47, 0.54);
    }
    if (vScreenUV.y < mMid && vScreenUV.y > horizon - 0.05) {
      sky = uIsNight == 1 ? vec3(0.10, 0.14, 0.21) : vec3(0.22, 0.27, 0.35);
    }

    if (uDebugMode == 2) {
      float luma = dot(sky, vec3(0.299, 0.587, 0.114));
      gl_FragColor = vec4(vec3(luma), 1.0);
      return;
    }
    gl_FragColor = vec4(sky, 1.0);
  }
`;

// Pass 1: Directional Shadow Map Depth Pass
const SHADOW_VS = window.SHADOW_VS = `
  attribute vec3 aPosition;
  uniform mat4 uLightMVP;
  uniform mat4 uModel;
  varying float vDepth;
  void main() {
    vec4 pos = uLightMVP * uModel * vec4(aPosition, 1.0);
    gl_Position = pos;
    vDepth = pos.z * 0.5 + 0.5;
  }
`;

const SHADOW_FS = window.SHADOW_FS = `
  precision highp float;
  varying float vDepth;
  vec4 packDepth(const in float depth) {
    const vec4 bitShift = vec4(256.0*256.0*256.0, 256.0*256.0, 256.0, 1.0);
    const vec4 bitMask  = vec4(0.0, 1.0/256.0, 1.0/256.0, 1.0/256.0);
    vec4 res = fract(depth * bitShift);
    res -= res.xxyz * bitMask;
    return res;
  }
  void main() {
    gl_FragColor = packDepth(clamp(vDepth, 0.0, 1.0));
  }
`;

// Pass 2: Art Bible v2 Cel-Shading + Halftone Shadow Hatching + Listen Mode ("Mata Telinga") + Photo Mode
const CEL_VS = window.CEL_VS = `
  attribute vec3 aPosition;
  attribute vec3 aNormal;
  attribute vec2 aUV;

  uniform mat4 uViewProj;
  uniform mat4 uModel;
  uniform mat4 uLightVP;

  varying vec3 vWorldPos;
  varying vec3 vNormal;
  varying vec2 vUV;
  varying vec4 vShadowCoord;

  void main() {
    vec4 worldPos = uModel * vec4(aPosition, 1.0);
    vWorldPos = worldPos.xyz;
    vNormal = normalize(mat3(uModel[0].xyz, uModel[1].xyz, uModel[2].xyz) * aNormal);
    vUV = aUV;
    vShadowCoord = uLightVP * worldPos;
    gl_Position = uViewProj * worldPos;
  }
`;

const CEL_FS = window.CEL_FS = `
  precision highp float;

  varying vec3 vWorldPos;
  varying vec3 vNormal;
  varying vec2 vUV;
  varying vec4 vShadowCoord;

  uniform sampler2D uAlbedoMap;
  uniform sampler2D uShadowMap;
  uniform vec3 uBaseColor;
  uniform vec3 uLightDir;
  uniform vec3 uLightColor;
  uniform vec3 uAmbientColor;
  uniform vec3 uRimColor;
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform vec3 uCameraPos;
  uniform float uEmissive;
  uniform int uDebugMode;   // 0 = Normal, 1 = Silhouette Test, 2 = Grayscale Value Test
  uniform int uListenMode;  // 1 = "Mata Telinga" Washi Paper + Cinnabar Brush Mode (G2)
  uniform int uPhotoMode;   // 1 = Ukiyo-e Woodblock Print Posterize Mode (G10)
  uniform int uIsCharacter;

  uniform vec3 uLanternPos[6];
  uniform float uLanternIntensity[6];

  float unpackDepth(const in vec4 rgbaDepth) {
    const vec4 bitShift = vec4(1.0/(256.0*256.0*256.0), 1.0/(256.0*256.0), 1.0/256.0, 1.0);
    return dot(rgbaDepth, bitShift);
  }

  float sampleShadowPCF(vec4 sc) {
    vec3 proj = sc.xyz / sc.w;
    proj = proj * 0.5 + 0.5;
    if (proj.x < 0.01 || proj.x > 0.99 || proj.y < 0.01 || proj.y > 0.99 || proj.z > 0.995) {
      return 1.0;
    }
    float currentDepth = proj.z - 0.0045;
    float shadow = 0.0;
    float texel = 1.0 / 1024.0;
    for (int x = -1; x <= 1; x++) {
      for (int y = -1; y <= 1; y++) {
        float closest = unpackDepth(texture2D(uShadowMap, proj.xy + vec2(float(x), float(y)) * texel));
        shadow += currentDepth > closest ? 0.22 : 1.0;
      }
    }
    return shadow / 9.0;
  }

  void main() {
    float dist = length(vWorldPos - uCameraPos);

    // Mode 1: Pure Black Silhouette Test
    if (uDebugMode == 1) {
      if (uIsCharacter == 1) {
        gl_FragColor = vec4(0.02, 0.02, 0.03, 1.0);
      } else {
        float bgVal = clamp(0.75 + vWorldPos.y * 0.025 - dist * 0.005, 0.38, 0.92);
        gl_FragColor = vec4(vec3(bgVal), 1.0);
      }
      return;
    }

    // Pillar 2 ("Mata Telinga" Listen Mode — G2): World becomes Washi Paper; Characters & Sound Ripples become Cinnabar/Sumi Ink!
    if (uListenMode == 1) {
      if (uIsCharacter == 1 || uEmissive > 0.8) {
        // Guards, Kage-Echo, and Sound Ink Ripples pop in vivid Cinnabar Red & Sumi Ink!
        gl_FragColor = vec4(uBaseColor, 1.0);
      } else {
        float hatch = step(0.82, fract((gl_FragCoord.x + gl_FragCoord.y) * 0.14));
        vec3 paper = mix(vec3(0.89, 0.85, 0.75), vec3(0.78, 0.73, 0.63), hatch * 0.35);
        gl_FragColor = vec4(paper, 1.0);
      }
      return;
    }

    vec4 texSample = texture2D(uAlbedoMap, vUV);
    vec3 albedo = texSample.rgb * uBaseColor;

    // Emissive surfaces (Lantern flames, Volumetric Light Shafts, Sound Ink Ripples, Shoji Interior Glow)
    if (uEmissive > 0.4) {
      vec3 glow = albedo * (1.15 + uEmissive * 0.45);
      if (uDebugMode == 2) {
        float luma = dot(glow, vec3(0.299, 0.587, 0.114));
        gl_FragColor = vec4(vec3(luma), 1.0);
        return;
      }
      gl_FragColor = vec4(clamp(glow, 0.0, 1.0), 1.0);
      return;
    }

    vec3 N = normalize(vNormal);
    vec3 L = normalize(uLightDir);
    vec3 V = normalize(uCameraPos - vWorldPos);

    float shadowAtten = sampleShadowPCF(vShadowCoord);
    float ndotl = max(0.0, dot(N, L)) * shadowAtten;

    // 3-Band Crisp Ukiyo-e Stepped Cel Ramp + Stylized Sumi-e Diagonal Hatching in Deep Shadows
    float celBand = 0.14;
    if (ndotl > 0.50) celBand = 1.05;
    else if (ndotl > 0.16) celBand = 0.66;
    else {
      // Stylized woodblock diagonal hatching inside shadow pools (supports G1 Living Shadow readability)
      float hatchLine = step(0.65, fract((vWorldPos.x + vWorldPos.z) * 4.5));
      celBand = 0.14 + hatchLine * 0.06;
    }

    vec3 directLight = uLightColor * celBand;

    // Dynamic Point Lights from 6 Toro Stone Lanterns (Warm Golden Pools)
    vec3 pointLightSum = vec3(0.0);
    for (int i = 0; i < 6; i++) {
      if (uLanternIntensity[i] > 0.01) {
        vec3 toLight = uLanternPos[i] - vWorldPos;
        float d = length(toLight);
        if (d < 12.5) {
          float atten = clamp(1.0 - (d / 12.5), 0.0, 1.0);
          atten = atten * atten;
          float pNdotL = max(0.25, dot(N, normalize(toLight)));
          float pStepped = pNdotL > 0.42 ? 1.0 : 0.55;
          pointLightSum += vec3(0.98, 0.72, 0.28) * (atten * pStepped * uLanternIntensity[i] * 1.35);
        }
      }
    }

    // Crisp Rim Light on Characters & Weapons so they never blend into dark walls (Fixes Critique A.2 & A.4)
    float rim = pow(1.0 - max(0.0, dot(N, V)), 3.0);
    vec3 rimContrib = uRimColor * rim * (uIsCharacter == 1 ? 0.75 : 0.22);

    vec3 litColor = albedo * (uAmbientColor + directLight + pointLightSum) + rimContrib;

    // 3-Plane Value Hierarchy Fog: Background softens toward misty Bokashi horizon (Fixes Critique A.1)
    float fogFactor = exp(-pow(dist * uFogDensity, 1.55));
    fogFactor = clamp(fogFactor, 0.0, 1.0);
    vec3 finalColor = mix(uFogColor, litColor, fogFactor);

    // Ukiyo-e Woodblock Photo Mode Posterization (G10)
    if (uPhotoMode == 1) {
      finalColor = floor(finalColor * 5.0 + 0.5) / 5.0;
    }

    // Washi Paper Fiber Grain (Horizontal/Vertical Weave instead of pure random noise — Critique B.4.5)
    float fiberX = sin(gl_FragCoord.x * 1.7 + sin(gl_FragCoord.y * 0.5)) * 0.012;
    float fiberY = cos(gl_FragCoord.y * 1.3) * 0.010;
    finalColor += vec3(fiberX + fiberY);

    // Soft Vignette framing
    vec2 screenPos = (gl_FragCoord.xy / vec2(1280.0, 720.0)) - 0.5;
    float vig = 1.0 - dot(screenPos, screenPos) * 0.38;
    finalColor *= clamp(vig, 0.65, 1.0);

    // Mode 2: Grayscale Value Structure Test
    if (uDebugMode == 2) {
      float luma = dot(finalColor, vec3(0.299, 0.587, 0.114));
      gl_FragColor = vec4(vec3(luma), 1.0);
      return;
    }

    gl_FragColor = vec4(clamp(finalColor, 0.0, 1.0), 1.0);
  }
`;

// Pass 3: Variable-Weight Sumi-e Brush Ink Outline Pass (Fixes Critique A.12)
const OUTLINE_VS = window.OUTLINE_VS = `
  attribute vec3 aPosition;
  attribute vec3 aNormal;
  uniform mat4 uViewProj;
  uniform mat4 uModel;
  uniform float uOutlineWidth;
  uniform vec3 uCameraPos;
  void main() {
    vec4 worldPos = uModel * vec4(aPosition, 1.0);
    vec3 worldNormal = normalize(mat3(uModel[0].xyz, uModel[1].xyz, uModel[2].xyz) * aNormal);
    float dist = length(worldPos.xyz - uCameraPos);
    // Variable ink weight: thicker on outer silhouettes, tapering smoothly with distance
    float strokeMod = 0.75 + 0.45 * abs(sin(worldPos.x * 3.5 + worldPos.y * 5.0));
    float attenWidth = (uOutlineWidth * strokeMod) / (1.0 + dist * 0.045);
    worldPos.xyz += worldNormal * attenWidth;
    gl_Position = uViewProj * worldPos;
  }
`;

const OUTLINE_FS = window.OUTLINE_FS = `
  precision mediump float;
  uniform vec3 uOutlineColor;
  void main() {
    gl_FragColor = vec4(uOutlineColor, 1.0);
  }
`;
