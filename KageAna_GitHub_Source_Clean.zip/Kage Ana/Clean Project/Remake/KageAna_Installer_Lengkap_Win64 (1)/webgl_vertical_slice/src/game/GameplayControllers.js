// Gameplay Systems v2.0:
// - Pillar 1: Living Shadow (Shadow-Meld [Z/Alt], Kaginawa [L], Two-Way Lanterns [E/R])
// - Pillar 2: Sound as Ink (Sumi-e Ink Ripples & "Mata Telinga" Listen Mode [V/Tab])
// - Pillar 3: One-Slash Iai Standoff ([B] + LMB) & Kage-Echo 10s Death Replay Decoy
// - Adaptive Multi-Layer Sengoku BGM with Pre-Execution Dramatic Silence ("Ma")

const LayeredAudio = window.LayeredAudio = {
  ctx: null,
  muted: false,
  bgmTimer: null,
  bgmStep: 0,
  bgmState: 'CALM', // 'CALM' | 'SUSPICIOUS' | 'COMBAT'
  dramaticSilenceTimer: 0,
  inSenScale: [146.83, 155.56, 196.00, 220.00, 261.63, 293.66, 311.13, 392.00, 440.00],

  init() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (AC) this.ctx = new AC();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      try { this.ctx.resume(); } catch (e) {}
    }
    if (!this.bgmTimer) this.startAdaptiveBGM();
  },

  triggerDramaticSilence(seconds = 0.85) {
    this.dramaticSilenceTimer = Math.max(this.dramaticSilenceTimer, seconds);
  },

  startAdaptiveBGM() {
    if (this.bgmTimer) return;
    const tick = () => {
      if (!this.muted && this.ctx && this.dramaticSilenceTimer <= 0) {
        const s = this.bgmStep++;
        const scale = this.inSenScale;
        if (this.bgmState === 'COMBAT') {
          // Intense O-Daiko + Shamisen Ostinato
          this.playLayeredSound([{ type: 'triangle', f0: s % 2 === 0 ? 68 : 112, f1: 34, dur: 0.22, vol: 0.11 }]);
          const n = scale[(s * 2 + (s % 3)) % scale.length];
          this.playLayeredSound([{ type: 'sawtooth', f0: n * 1.5, f1: n * 1.48, dur: 0.14, vol: 0.04 }]);
        } else if (this.bgmState === 'SUSPICIOUS') {
          // Tense Tsuzumi pulse + low Biwa pluck
          if (s % 2 === 0) {
            this.playLayeredSound([{ type: 'sine', f0: 185, f1: 95, dur: 0.16, vol: 0.06 }]);
          }
          const n = scale[s % 5];
          this.playLayeredSound([{ type: 'triangle', f0: n, f1: n * 0.98, dur: 0.32, vol: 0.035 }]);
        } else {
          // Calm Shakuhachi solo breath + sparse Koto harmonic
          if (s % 4 === 0) {
            const n = scale[(s % 5) + 3];
            this.playLayeredSound([{ type: 'sine', f0: n * 0.96, f1: n, dur: 0.95, vol: 0.032 }]);
          }
        }
      }
      const interval = this.bgmState === 'COMBAT' ? 210 : (this.bgmState === 'SUSPICIOUS' ? 320 : 450);
      this.bgmTimer = setTimeout(tick, interval);
    };
    tick();
  },

  playLayeredSound(layers) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    layers.forEach(l => {
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = l.type || 'triangle';
        osc.frequency.setValueAtTime(l.f0, now + (l.delay || 0));
        osc.frequency.exponentialRampToValueAtTime(Math.max(20, l.f1), now + (l.delay || 0) + l.dur);
        gain.gain.setValueAtTime(l.vol, now + (l.delay || 0));
        gain.gain.exponentialRampToValueAtTime(0.001, now + (l.delay || 0) + l.dur);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now + (l.delay || 0));
        osc.stop(now + (l.delay || 0) + l.dur);
      } catch (e) {}
    });
  },

  playStep(surface, isSprinting, isCrouching) {
    const vol = isCrouching ? 0.025 : (isSprinting ? 0.11 : 0.06);
    const baseF = surface === 'ClayTile' ? 920 : (surface === 'Wood' ? 680 : 810);
    this.playLayeredSound([
      { type: 'triangle', f0: baseF, f1: 160, dur: 0.045, vol },
      { type: 'sine', f0: 190, f1: 58, dur: 0.055, vol: vol * 0.8, delay: 0.012 }
    ]);
  },

  playShadowMeld() {
    this.playLayeredSound([
      { type: 'sine', f0: 320, f1: 75, dur: 0.28, vol: 0.14 },
      { type: 'triangle', f0: 640, f1: 180, dur: 0.22, vol: 0.08, delay: 0.04 }
    ]);
  },

  playIaiDrawSlash() {
    this.triggerDramaticSilence(0.85);
    this.playLayeredSound([
      { type: 'sine', f0: 1850, f1: 3200, dur: 0.09, vol: 0.14 }, // Metallic Saya draw ring
      { type: 'sawtooth', f0: 780, f1: 85, dur: 0.18, vol: 0.20, delay: 0.05 },
      { type: 'triangle', f0: 150, f1: 38, dur: 0.26, vol: 0.24, delay: 0.06 }
    ]);
  },

  playSlashImpact(hitFlesh) {
    if (hitFlesh) {
      this.triggerDramaticSilence(0.65);
      this.playLayeredSound([
        { type: 'sawtooth', f0: 620, f1: 95, dur: 0.14, vol: 0.16 },
        { type: 'triangle', f0: 140, f1: 42, dur: 0.22, vol: 0.22 },
        { type: 'sine', f0: 1420, f1: 380, dur: 0.09, vol: 0.08 }
      ]);
    } else {
      this.playLayeredSound([{ type: 'triangle', f0: 480, f1: 120, dur: 0.11, vol: 0.10 }]);
    }
  },

  playParryClash() {
    this.playLayeredSound([
      { type: 'square', f0: 1680, f1: 720, dur: 0.18, vol: 0.16 },
      { type: 'sine', f0: 2640, f1: 1120, dur: 0.28, vol: 0.12 }
    ]);
  }
};

const PlayerController = window.PlayerController = class PlayerController {
  constructor(cfg, spawn) {
    this.cfg = cfg.locomotion;
    this.acoustics = cfg.acoustics;
    this.spawn = { ...spawn };
    this.reset();
  }

  reset() {
    this.x = this.spawn.x;
    this.y = 1.68;
    this.z = this.spawn.z;
    this.vx = 0;
    this.vy = 0;
    this.vz = 0;
    this.yaw = this.spawn.yaw || 0;
    this.pitch = 0;
    this.roll = 0;

    this.vitality = 100;
    this.stamina = this.cfg.maxStamina;
    this.isGrounded = true;
    this.isCrouching = false;
    this.isSprinting = false;
    this.currentSurface = 'Stone';
    this.currentNoiseDb = 3;
    this.lightExposure = 0.35;
    this.shadowStrength = 0.65; // Pillar 1 (G1): 1.0 - lightExposure
    this.bobPhase = 0;
    this.lastStepCycle = 0;
    this.shakeTimer = 0;
    this.shakeIntensity = 0;
  }

  addCameraShake(duration, intensity) {
    this.shakeTimer = Math.max(this.shakeTimer, duration);
    this.shakeIntensity = Math.max(this.shakeIntensity, intensity);
  }

  getCamera(dt) {
    let shakeX = 0, shakeY = 0, shakeRoll = 0;
    if (this.shakeTimer > 0) {
      this.shakeTimer = Math.max(0, this.shakeTimer - dt);
      shakeX = (Math.random() - 0.5) * this.shakeIntensity;
      shakeY = (Math.random() - 0.5) * this.shakeIntensity;
      shakeRoll = (Math.random() - 0.5) * this.shakeIntensity * 0.5;
    }
    const eyeOffset = this.isCrouching ? -0.58 : 0.0;
    const headBobY = Math.sin(this.bobPhase * 2.0) * 0.011;
    return {
      x: this.x + shakeX,
      y: this.y + eyeOffset + headBobY + shakeY,
      z: this.z,
      yaw: this.yaw,
      pitch: this.pitch,
      roll: this.roll + shakeRoll
    };
  }

  /**
   * Pillar 1 (G1): Shadow-Meld ("Menyelam antar Lubang Bayangan / Kage-Ana")
   */
  tryShadowMeld(shadowPools, onInkRipple, onStatusMsg) {
    if (this.shadowStrength < 0.45) {
      onStatusMsg('Bayangan terlalu tipis! Masuklah ke area gelap atau padamkan lentera untuk Shadow-Meld [Z].');
      return false;
    }
    if (this.stamina < (this.cfg.shadowMeldCost || 24)) {
      onStatusMsg('Stamina belum cukup untuk Shadow-Meld.');
      return false;
    }

    const fwdX = Math.sin(this.yaw), fwdZ = Math.cos(this.yaw);
    let bestPool = null;
    let bestScore = Infinity;

    for (let i = 0; i < shadowPools.length; i++) {
      const sp = shadowPools[i];
      const dx = sp.x - this.x, dz = sp.z - this.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 2.2 && dist <= (this.cfg.shadowMeldRange || 12.5)) {
        const dot = (dx / dist) * fwdX + (dz / dist) * fwdZ;
        if (dot > 0.45) {
          const score = dist * (1.25 - dot * 0.5);
          if (score < bestScore) {
            bestScore = score;
            bestPool = sp;
          }
        }
      }
    }

    if (bestPool) {
      this.stamina -= (this.cfg.shadowMeldCost || 24);
      this.x = bestPool.x;
      this.z = bestPool.z;
      this.y = 1.68;
      this.isCrouching = true;
      window.LayeredAudio.playShadowMeld();
      if (onInkRipple) onInkRipple(this.x, this.z, 2.2, false);
      onStatusMsg('🌑 SHADOW-MELD (Kage-Ana): Menyelam menembus bayangan tanpa terlihat!');
      return true;
    }

    onStatusMsg('Arahkan pandangan ke Kolam Bayangan (lingkaran gelap di lantai < 12m) lalu tekan [Z / Alt]!');
    return false;
  }

  /**
   * Pillar 1 / G12: Kaginawa Grappling Hook onto Sarashi white-cloth ledges & overhead beams [L]
   */
  tryKaginawaGrapple(climbZones, onStatusMsg) {
    const fwdX = Math.sin(this.yaw), fwdZ = Math.cos(this.yaw);
    let best = null;
    let bestDist = this.cfg.kaginawaRange || 22.0;

    for (let i = 0; i < climbZones.length; i++) {
      const cz = climbZones[i];
      const dx = cz.x - this.x, dz = cz.z - this.z;
      const d = Math.hypot(dx, dz);
      if (d > 1.5 && d <= bestDist) {
        const dot = (dx / d) * fwdX + (dz / d) * fwdZ;
        if (dot > 0.40) {
          bestDist = d;
          best = cz;
        }
      }
    }

    if (best) {
      this.x = best.x;
      this.z = best.z;
      this.y = best.topY + 1.68;
      this.vy = 1.2;
      window.LayeredAudio.playShadowMeld();
      onStatusMsg(`🪝 KAGINAWA [L]: Melesat ke atas [${best.label || 'Atap'}]!`);
      return true;
    }
    onStatusMsg('Kaginawa [L]: Arahkan pandangan ke atap berkain putih atau balok atas (< 22m)!');
    return false;
  }

  update(dt, keys, colliders, climbZones, lanterns, shadowPools, timePreset, onFootstepEvent) {
    const moveS = !!keys['KeyS'] || !!keys['ArrowDown'];
    const moveW = (!!keys['KeyW'] || !!keys['ArrowUp']) && !moveS;
    const moveA = !!keys['KeyA'];
    const moveD = !!keys['KeyD'];
    const crouchHeld = !!keys['ControlLeft'] || !!keys['ControlRight'] || !!keys['KeyC'];
    const sprintHeld = !!keys['ShiftLeft'] || !!keys['ShiftRight'];
    const jumpHeld = !!keys['Space'];

    if (keys['ArrowLeft']) this.yaw -= 1.8 * dt;
    if (keys['ArrowRight']) this.yaw += 1.8 * dt;

    this.isCrouching = crouchHeld;
    const hasInput = moveW || moveS || moveA || moveD;
    this.isSprinting = sprintHeld && !this.isCrouching && hasInput && this.stamina > 8;

    // Pillar 1 (G1): Moving inside deep shadow grants +25% speed bonus!
    const shadowSpeedMult = this.shadowStrength >= 0.60 ? (this.cfg.shadowBonusMultiplier || 1.25) : 1.0;
    const baseSpeed = this.isCrouching
      ? this.cfg.crouchSpeed
      : (this.isSprinting ? this.cfg.sprintSpeed : this.cfg.walkSpeed);
    const targetSpeed = baseSpeed * shadowSpeedMult;

    const fwdX = Math.sin(this.yaw), fwdZ = Math.cos(this.yaw);
    const rightX = Math.cos(this.yaw), rightZ = -Math.sin(this.yaw);
    const inF = (moveW ? 1 : 0) - (moveS ? 1 : 0);
    const inS = (moveD ? 1 : 0) - (moveA ? 1 : 0);

    let wishX = fwdX * inF + rightX * inS;
    let wishZ = fwdZ * inF + rightZ * inS;
    const len = Math.hypot(wishX, wishZ);
    if (len > 0.001) { wishX /= len; wishZ /= len; }

    const accel = this.isGrounded ? 15.0 : 7.0;
    this.vx += (wishX * targetSpeed - this.vx) * Math.min(1, accel * dt);
    this.vz += (wishZ * targetSpeed - this.vz) * Math.min(1, accel * dt);

    const nx = this.x + this.vx * dt;
    if (!this.checkWall(nx, this.y, this.z, colliders)) {
      this.x = Math.max(-25, Math.min(25, nx));
    } else {
      this.vx = 0;
    }

    const nz = this.z + this.vz * dt;
    if (!this.checkWall(this.x, this.y, nz, colliders)) {
      this.z = Math.max(-28, Math.min(27, nz));
    } else {
      this.vz = 0;
    }

    if (this.isSprinting) {
      this.stamina = Math.max(0, this.stamina - this.cfg.sprintStaminaDrain * dt);
    } else if (this.isGrounded) {
      this.stamina = Math.min(this.cfg.maxStamina, this.stamina + this.cfg.staminaRegen * dt);
    }

    if (jumpHeld) {
      const climbTarget = this.findNearbyClimbZone(climbZones);
      if (climbTarget && this.y < climbTarget.topY + 1.2) {
        this.y = climbTarget.topY + 1.68;
        this.vy = 1.5;
        this.isGrounded = false;
        window.LayeredAudio.playStep('Wood', true, false);
      } else if (this.isGrounded && this.stamina >= 10) {
        this.vy = this.cfg.jumpVelocity;
        this.isGrounded = false;
        this.stamina -= 10;
        window.LayeredAudio.playStep(this.currentSurface, true, false);
      }
    }

    this.vy += this.cfg.gravity * dt;
    this.y += this.vy * dt;

    const floor = this.findFloorBelow(colliders);
    this.currentSurface = floor.surface;
    if (this.y <= floor.height + 1.68) {
      this.y = floor.height + 1.68;
      this.vy = 0;
      this.isGrounded = true;
    } else {
      this.isGrounded = false;
    }

    // Acoustic Footstep & Sumi-e Ink Ripple Generation (Pillar 2 / G2)
    const planarSpeed = Math.hypot(this.vx, this.vz);
    if (this.isGrounded && planarSpeed > 0.35) {
      const freq = this.isSprinting ? 5.4 : (this.isCrouching ? 2.4 : 3.6);
      this.bobPhase += dt * freq * Math.PI;
      const cycle = Math.floor(this.bobPhase / Math.PI);
      const surfTbl = this.acoustics[this.currentSurface] || this.acoustics.Stone;
      let rawDb = this.isCrouching ? surfTbl.crouchDb : (this.isSprinting ? surfTbl.sprintDb : surfTbl.walkDb);
      if (this.shadowStrength >= 0.65) rawDb *= 0.65; // Deep shadow dampens footsteps
      this.currentNoiseDb = rawDb;

      if (cycle > this.lastStepCycle) {
        this.lastStepCycle = cycle;
        window.LayeredAudio.playStep(this.currentSurface, this.isSprinting, this.isCrouching);
        if (onFootstepEvent) {
          const rippleRad = (surfTbl.rippleRadius || 4.0) * (this.isCrouching ? 0.35 : (this.isSprinting ? 1.45 : 0.85));
          onFootstepEvent(this.x, this.y - 1.62, this.z, rippleRad);
        }
      }
    } else {
      this.currentNoiseDb = Math.max(1, this.currentNoiseDb - 28 * dt);
    }

    // Calculate Light Exposure & Shadow Strength (Pillar 1 / G1)
    let exposure = timePreset === 'MALAM' ? 0.12 : 0.36;
    if (this.isCrouching) exposure -= 0.14;
    if (this.y > 3.5) exposure -= 0.12;

    // Check if inside a Shadow Pool ("Kage-Ana")
    for (let i = 0; i < (shadowPools || []).length; i++) {
      const sp = shadowPools[i];
      if (Math.hypot(this.x - sp.x, this.z - sp.z) <= sp.r) {
        exposure -= 0.28;
        break;
      }
    }

    // Check active lanterns
    lanterns.forEach(l => {
      if (l.lit) {
        const lx = l.x + (l.shiftOffset || 0);
        const d = Math.hypot(this.x - lx, this.z - l.z);
        if (d < 9.5) {
          exposure += (1.0 - d / 9.5) * 0.68;
        }
      }
    });
    this.lightExposure = Math.max(0.04, Math.min(1.0, exposure));
    this.shadowStrength = Number((1.0 - this.lightExposure).toFixed(2));
  }

  findNearbyClimbZone(climbZones) {
    for (let i = 0; i < climbZones.length; i++) {
      const cz = climbZones[i];
      if (Math.hypot(this.x - cz.x, this.z - cz.z) <= cz.radius) {
        return cz;
      }
    }
    return null;
  }

  findFloorBelow(colliders) {
    let bestH = 0.0;
    let bestSurf = Math.abs(this.x) < 2.6 ? 'Stone' : 'Gravel';
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (!c.walkable) continue;
      if (Math.abs(this.x - c.x) <= c.w * 0.5 && Math.abs(this.z - c.z) <= c.d * 0.5) {
        const topY = c.y + c.h * 0.5;
        if (this.y - 1.25 >= topY - 0.95 && topY >= bestH) {
          bestH = topY;
          bestSurf = c.surface || 'Wood';
        }
      }
    }
    return { height: bestH, surface: bestSurf };
  }

  checkWall(nx, ny, nz, colliders) {
    const footY = ny - 1.45;
    for (let i = 0; i < colliders.length; i++) {
      const c = colliders[i];
      if (!c.solid) continue;
      const topY = c.y + c.h * 0.5;
      const botY = c.y - c.h * 0.5;
      if (footY < topY - 0.25 && ny > botY) {
        if (Math.abs(nx - c.x) <= c.w * 0.5 + 0.32 && Math.abs(nz - c.z) <= c.d * 0.5 + 0.32) {
          return true;
        }
      }
    }
    return false;
  }
};

const BladeCombatSystem = window.BladeCombatSystem = class BladeCombatSystem {
  constructor(cfg) {
    this.cfg = cfg.combat;
    this.phase = 'IDLE';
    this.timer = 0;
    this.phaseProgress = 0;
    this.hitStopTimer = 0;
    this.kunaiCount = this.cfg.kunaiCount;
    this.strikeResolved = false;
    this.isSheathed = true; // Pillar 3 (G3): Starts sheathed in Saya for Lethal Iai Draw Slash or Silent Tanto!
    this.isIaiStrike = false;
  }

  toggleSheathe(onStatusMsg) {
    this.isSheathed = !this.isSheathed;
    window.LayeredAudio.playSlashImpact(false);
    onStatusMsg(this.isSheathed
      ? '🗡️ Katana Disarungkan [B]: Siap mengeksekusi Tebasan Kilat IAI (1 Tebasan Mematikan) atau Bunuh Senyap [F]!'
      : '⚔️ Katana Dihunus [B]: Siap menangkis [Q] dan bertarung jarak dekat.');
    return this.isSheathed;
  }

  startHeavySlash(player, npcs, onVfx, onInkRipple, onStatusMsg) {
    if (this.phase !== 'IDLE') return false;
    if (player.stamina < this.cfg.slashStaminaCost) {
      onStatusMsg('Stamina belum cukup untuk menebas.');
      return false;
    }
    player.stamina -= this.cfg.slashStaminaCost;
    this.isIaiStrike = this.isSheathed;
    this.isSheathed = false; // Drawing the blade unsheathes it
    this.phase = 'WINDUP';
    this.timer = this.isIaiStrike ? (this.cfg.iaiDrawSlashWindup || 0.06) : (this.cfg.normalWindupSeconds || 0.14);
    this.phaseProgress = 0;
    this.strikeResolved = false;

    if (this.isIaiStrike) {
      window.LayeredAudio.playIaiDrawSlash();
      if (onInkRipple) onInkRipple(player.x, player.z, 9.5, true);
      player.currentNoiseDb = Math.max(player.currentNoiseDb, this.cfg.iaiNoiseDb || 42);
    }
    return true;
  }

  startParry(player) {
    if (this.phase !== 'IDLE' && this.phase !== 'RECOVERY') return false;
    this.isSheathed = false;
    this.phase = 'PARRY';
    this.timer = this.cfg.parryWindowSeconds;
    this.phaseProgress = 0;
    window.LayeredAudio.playSlashImpact(false);
    return true;
  }

  throwKunaiAtTarget(player, lanterns, npcs, onVfx, onInkRipple, onStatusMsg) {
    if (this.kunaiCount <= 0) {
      onStatusMsg('Kunai habis.');
      return false;
    }
    this.kunaiCount--;
    const fwdX = Math.sin(player.yaw) * Math.cos(player.pitch);
    const fwdZ = Math.cos(player.yaw) * Math.cos(player.pitch);

    for (let i = 0; i < lanterns.length; i++) {
      const l = lanterns[i];
      if (!l.lit) continue;
      const lx = l.x + (l.shiftOffset || 0);
      const dx = lx - player.x, dz = l.z - player.z;
      const d = Math.hypot(dx, dz);
      if (d < 20.0 && ((dx / d) * fwdX + (dz / d) * fwdZ) > 0.88) {
        l.lit = false;
        window.LayeredAudio.playParryClash();
        onVfx({ type: 'SPARK', x: lx, y: 1.45, z: l.z, size: 0.25, color: '#f5b041', life: 0.35 });
        if (onInkRipple) onInkRipple(lx, l.z, 5.5, false);
        onStatusMsg(`Kunai memadamkan Lentera Batu #${l.id} — jalur bayangan terbuka!`);
        return true;
      }
    }

    for (let i = 0; i < npcs.length; i++) {
      const npc = npcs[i];
      if (npc.isDead) continue;
      const dx = npc.x - player.x, dz = npc.z - player.z;
      const d = Math.hypot(dx, dz);
      if (d < 18.0 && ((dx / d) * fwdX + (dz / d) * fwdZ) > 0.88) {
        npc.isDead = true;
        this.hitStopTimer = 0.055;
        window.LayeredAudio.playSlashImpact(true);
        onVfx({ type: 'BLOOD_DECAL', x: npc.x, z: npc.z, size: 0.95, life: 35 });
        onStatusMsg(`Eliminasi Kunai jarak jauh: ${npc.name}.`);
        return true;
      }
    }

    window.LayeredAudio.playSlashImpact(false);
    return true;
  }

  update(dt, player, npcs, onVfx, onStatusMsg, onEnemyKilled) {
    if (this.phase === 'IDLE') return;

    this.timer -= dt;
    const windupDur = this.isIaiStrike ? (this.cfg.iaiDrawSlashWindup || 0.06) : (this.cfg.normalWindupSeconds || 0.14);
    const strikeDur = this.isIaiStrike ? (this.cfg.iaiDrawSlashActive || 0.10) : (this.cfg.normalStrikeSeconds || 0.12);
    const recovDur  = this.isIaiStrike ? (this.cfg.iaiDrawSlashRecovery || 0.28) : (this.cfg.normalRecoverySeconds || 0.32);

    if (this.phase === 'WINDUP') {
      this.phaseProgress = 1.0 - Math.max(0, this.timer / windupDur);
      if (this.timer <= 0) {
        this.phase = 'STRIKE';
        this.timer = strikeDur;
        this.phaseProgress = 0;
      }
    } else if (this.phase === 'STRIKE') {
      this.phaseProgress = 1.0 - Math.max(0, this.timer / strikeDur);
      if (!this.strikeResolved) {
        this.strikeResolved = true;
        this.resolveBladeHit(player, npcs, onVfx, onStatusMsg, onEnemyKilled);
      }
      if (this.timer <= 0) {
        this.phase = 'RECOVERY';
        this.timer = recovDur;
        this.phaseProgress = 0;
      }
    } else if (this.phase === 'RECOVERY' || this.phase === 'PARRY') {
      const dur = this.phase === 'PARRY' ? this.cfg.parryWindowSeconds : recovDur;
      this.phaseProgress = 1.0 - Math.max(0, this.timer / dur);
      if (this.timer <= 0) {
        this.phase = 'IDLE';
        this.phaseProgress = 0;
        this.isIaiStrike = false;
      }
    }
  }

  resolveBladeHit(player, npcs, onVfx, onStatusMsg, onEnemyKilled) {
    const fwdX = Math.sin(player.yaw), fwdZ = Math.cos(player.yaw);
    const reach = this.isIaiStrike ? 3.25 : 2.65;
    let hitAny = false;

    for (let i = 0; i < npcs.length; i++) {
      const npc = npcs[i];
      if (npc.isDead) continue;
      const dx = npc.x - player.x, dz = npc.z - player.z;
      const dist = Math.hypot(dx, dz);
      const heightDiff = Math.abs((player.y - 1.68) - (npc.y || 0));
      if (dist <= reach && heightDiff <= 2.2) {
        const dot = (dx / (dist || 1)) * fwdX + (dz / (dist || 1)) * fwdZ;
        if (dot > 0.30) {
          hitAny = true;
          this.hitStopTimer = this.cfg.hitStopSeconds || 0.075;
          player.addCameraShake(0.20, 0.07);

          // Pillar 3 (G3): Iai Strike or Posture-Broken Guard = Instant One-Slash Kill!
          if (!this.isIaiStrike && (npc.archetype === 'GUARD' || npc.archetype === 'COMMANDER') && npc.state === 'COMBAT' && !npc.postureBroken) {
            npc.postureBroken = true;
            window.LayeredAudio.playParryClash();
            onVfx({ type: 'SPARK', x: npc.x, y: 1.28, z: npc.z, size: 0.30, color: '#f5b041', life: 0.28 });
            onStatusMsg(`⚡ Kuda-kuda ${npc.name} goyah! Tebas sekali lagi atau gunakan Iai [B]!`);
          } else {
            npc.isDead = true;
            window.LayeredAudio.playSlashImpact(true);
            onVfx({ type: 'BLOOD_DECAL', x: npc.x, z: npc.z, size: 1.15, life: 45 });
            onVfx({ type: 'SPARK', x: npc.x, y: 1.25, z: npc.z, size: 0.26, color: '#c8232c', life: 0.28 });
            onStatusMsg(this.isIaiStrike
              ? `🩸 SATU TEBASAN IAI: ${npc.name} tumbang seketika!`
              : `Target tumbang: ${npc.name}.`);
            if (onEnemyKilled) onEnemyKilled(npc);
          }
          break;
        }
      }
    }

    if (!hitAny && !this.isIaiStrike) {
      window.LayeredAudio.playSlashImpact(false);
    }
  }
};

const GuardAISystem = window.GuardAISystem = class GuardAISystem {
  constructor(aiCfg, rawNpcs) {
    this.cfg = aiCfg;
    this.npcs = rawNpcs.map(n => ({
      ...n,
      y: 0,
      isDead: false,
      isMoving: false,
      state: 'PATROL',
      suspicion: 0,
      patrolIdx: 0,
      animPhase: Math.random() * 6.28,
      windupTimer: 0,
      attackCooldown: 1.1,
      postureBroken: false,
      lastStimulusPos: { x: n.x, z: n.z },
      lastBarkState: 'PATROL',
      tunicColor: n.archetype === 'COMMANDER'
        ? '#c8232c'
        : (n.archetype === 'GUARD' ? '#2b5082' : (n.archetype === 'MONK' ? '#c87d28' : '#7a6852'))
    }));
  }

  reset(rawNpcs) {
    const fresh = new GuardAISystem(this.cfg, rawNpcs);
    this.npcs = fresh.npcs;
  }

  lureNearestGuardToPosition(tx, tz, onStatusMsg) {
    let best = null;
    let bestDist = 18.0;
    this.npcs.forEach(npc => {
      if (npc.isDead || (npc.archetype !== 'GUARD' && npc.archetype !== 'COMMANDER')) return;
      const d = Math.hypot(npc.x - tx, npc.z - tz);
      if (d < bestDist) {
        bestDist = d;
        best = npc;
      }
    });
    if (best && best.state !== 'COMBAT') {
      best.suspicion = Math.max(best.suspicion, 74);
      best.state = 'SEARCH';
      best.lastStimulusPos = { x: tx, z: tz };
      onStatusMsg(`🏮 Cahaya lentera memancing perhatian ${best.name} untuk mendekat!`);
    }
  }

  update(dt, player, combatSys, colliders, kageEchoGhost, onVfx, onStatusMsg, onPlayerSpotted, onPlayerKilled) {
    let highestSuspicion = 0;
    let highestState = 'PATROL';
    let lastDetectionReason = '';

    this.npcs.forEach(npc => {
      npc.isMoving = false;
      if (npc.isDead) return;

      const isArmedGuard = npc.archetype === 'GUARD' || npc.archetype === 'COMMANDER';

      // Pillar 3 (G4): Kage-Echo Ghost Decoy Attraction!
      if (isArmedGuard && kageEchoGhost && kageEchoGhost.active && npc.state !== 'COMBAT') {
        const edx = kageEchoGhost.x - npc.x, edz = kageEchoGhost.z - npc.z;
        const edist = Math.hypot(edx, edz);
        if (edist <= (this.cfg.kageEchoAttractRadius || 12.0)) {
          npc.suspicion = Math.max(npc.suspicion, 76);
          npc.state = 'SEARCH';
          npc.lastStimulusPos = { x: kageEchoGhost.x, z: kageEchoGhost.z };
        }
      }

      const dx = player.x - npc.x;
      const dz = player.z - npc.z;
      const dist = Math.hypot(dx, dz);
      const heightDiff = (player.y - 1.68) - (npc.y || 0);

      if (isArmedGuard) {
        const lookX = Math.sin(npc.yaw), lookZ = Math.cos(npc.yaw);
        const dot = (dx / (dist || 1)) * lookX + (dz / (dist || 1)) * lookZ;
        const angleDeg = Math.acos(Math.max(-1, Math.min(1, dot))) * (180 / Math.PI);

        // Personality trait modifier (G14: Paranoid looks wider, Veteran detects faster)
        const coneAngle = npc.personality === 'PARANOID' ? this.cfg.visionHalfAngleDeg * 1.18 : this.cfg.visionHalfAngleDeg;
        let maxSight = this.cfg.shadowSightRangeMeters +
          (this.cfg.litSightRangeMeters - this.cfg.shadowSightRangeMeters) * player.lightExposure;
        if (player.isCrouching) maxSight *= 0.72;
        if (heightDiff > 2.2) maxSight *= 0.52;

        if (dist <= maxSight && (dist < 2.2 || angleDeg <= coneAngle)) {
          const proximity = 1.0 - (dist / maxSight);
          const rate = (34 + proximity * 66) * (0.4 + player.lightExposure * 0.9);
          npc.suspicion = Math.min(100, npc.suspicion + rate * dt);
          npc.lastStimulusPos = { x: player.x, z: player.z };
          lastDetectionReason = player.lightExposure > 0.55
            ? `Terlihat berdiri di area terang lentera oleh ${npc.name}`
            : `Masuk ke jarak pandang dekat ${npc.name}`;
        } else {
          npc.suspicion = Math.max(0, npc.suspicion - 14 * dt);
        }

        // Acoustic Footstep / Iai Sound Ring Sensor
        if (player.currentNoiseDb >= 18 && dist <= player.currentNoiseDb * 0.48) {
          npc.suspicion = Math.min(100, npc.suspicion + 45 * dt);
          npc.lastStimulusPos = { x: player.x, z: player.z };
          lastDetectionReason = `Terdengar suara langkah/pedang (${Math.round(player.currentNoiseDb)} dB) oleh ${npc.name}`;
        }

        const prevState = npc.state;
        if (npc.suspicion >= this.cfg.combatThreshold) npc.state = 'COMBAT';
        else if (npc.suspicion >= this.cfg.searchThreshold) npc.state = 'SEARCH';
        else if (npc.suspicion >= this.cfg.suspicionThreshold) npc.state = 'SUSPICIOUS';
        else npc.state = 'PATROL';

        // Stealth Readability Barks (Rule 8 & G14)
        if (prevState !== npc.state) {
          if (npc.state === 'SUSPICIOUS') {
            onStatusMsg(`💬 ${npc.name}: "Nani...? Ada bayangan bergerak di sana?" (${lastDetectionReason})`);
          } else if (npc.state === 'SEARCH') {
            onStatusMsg(`💬 ${npc.name}: "Suara apa itu?! Periksa sudut halaman!" (${lastDetectionReason})`);
          } else if (npc.state === 'COMBAT') {
            if (onPlayerSpotted) onPlayerSpotted(lastDetectionReason || `Terdeteksi oleh ${npc.name}`);
            onStatusMsg(`⚔️ DUEL SATU TEBASAN! ${npc.name}: "Kusemono da! Kakugo!" (${lastDetectionReason})`);
            this.npcs.forEach(other => {
              if (other !== npc && !other.isDead && (other.archetype === 'GUARD' || other.archetype === 'COMMANDER')) {
                if (Math.hypot(other.x - npc.x, other.z - npc.z) < 15.0 && other.state !== 'COMBAT') {
                  other.suspicion = Math.max(other.suspicion, 78);
                  other.state = 'SEARCH';
                  other.lastStimulusPos = { x: player.x, z: player.z };
                }
              }
            });
          }
        }

        if (npc.suspicion > highestSuspicion) {
          highestSuspicion = npc.suspicion;
          highestState = npc.state;
        }
      }

      // Locomotion & Combat Duel Behavior
      if (npc.state === 'PATROL') {
        const wp = npc.patrol[npc.patrolIdx];
        const pdx = wp.x - npc.x, pdz = wp.z - npc.z;
        const pdist = Math.hypot(pdx, pdz);
        if (pdist < 0.45) {
          npc.patrolIdx = (npc.patrolIdx + 1) % npc.patrol.length;
        } else {
          npc.yaw = Math.atan2(pdx, pdz);
          npc.x += (pdx / pdist) * 1.45 * dt;
          npc.z += (pdz / pdist) * 1.45 * dt;
          npc.isMoving = true;
          npc.animPhase += dt * 4.5;
        }
      } else if (npc.state === 'SUSPICIOUS') {
        npc.yaw = Math.atan2(npc.lastStimulusPos.x - npc.x, npc.lastStimulusPos.z - npc.z);
      } else if (npc.state === 'SEARCH') {
        const sdx = npc.lastStimulusPos.x - npc.x, sdz = npc.lastStimulusPos.z - npc.z;
        const sdist = Math.hypot(sdx, sdz);
        npc.yaw = Math.atan2(sdx, sdz);
        if (sdist > 0.8) {
          npc.x += (sdx / sdist) * 2.3 * dt;
          npc.z += (sdz / sdist) * 2.3 * dt;
          npc.isMoving = true;
          npc.animPhase += dt * 5.8;
        }
      } else if (npc.state === 'COMBAT') {
        npc.yaw = Math.atan2(dx, dz);
        if (dist > 1.85 && Math.abs(heightDiff) < 1.8) {
          npc.x += (dx / dist) * 4.0 * dt;
          npc.z += (dz / dist) * 4.0 * dt;
          npc.isMoving = true;
          npc.animPhase += dt * 7.8;
        } else if (Math.abs(heightDiff) < 1.8) {
          if (npc.windupTimer > 0) {
            npc.windupTimer -= dt;
            if (npc.windupTimer <= 0 && dist <= 2.4) {
              if (combatSys.phase === 'PARRY') {
                combatSys.hitStopTimer = 0.08;
                npc.postureBroken = true;
                window.LayeredAudio.playParryClash();
                onVfx({ type: 'SPARK', x: npc.x, y: 1.32, z: npc.z, size: 0.34, color: '#f5b041', life: 0.32 });
                onStatusMsg(`⚡ TANGKISAN SEMPURNA! Kuda-kuda ${npc.name} hancur — balas tebas sekarang!`);
              } else {
                // Pillar 3 (G3): Lethal 1-2 Hit Duel!
                player.vitality = Math.max(0, player.vitality - 55);
                player.addCameraShake(0.26, 0.10);
                window.LayeredAudio.playSlashImpact(true);
                onVfx({ type: 'BLOOD_DECAL', x: player.x, z: player.z, size: 1.0, life: 35 });
                onStatusMsg(`🩸 Terkena tebasan mematikan ${npc.name}! Tangkis dengan [Q / Klik Kanan]!`);
                if (player.vitality <= 0 && onPlayerKilled) {
                  onPlayerKilled(`Tewas ditebas oleh ${npc.name} (${lastDetectionReason || 'Duel Jarak Dekat'})`);
                }
              }
            }
          } else {
            npc.attackCooldown -= dt;
            if (npc.attackCooldown <= 0) {
              npc.windupTimer = 0.40;
              npc.attackCooldown = 1.25;
            }
          }
        }
      }
    });

    // Update Adaptive BGM Layer
    window.LayeredAudio.bgmState = highestState === 'COMBAT' ? 'COMBAT' : (highestState !== 'PATROL' ? 'SUSPICIOUS' : 'CALM');

    return { highestState, highestSuspicion, lastDetectionReason };
  }
};
