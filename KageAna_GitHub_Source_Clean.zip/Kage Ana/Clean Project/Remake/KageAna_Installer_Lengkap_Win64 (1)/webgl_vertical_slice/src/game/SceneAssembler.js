// SceneAssembler v2.0: Populated Courtyard, Shoji Silhouettes, Role-Readable Characters, Sound Ink Ripples & Kuji-in Viewmodel

const SceneAssembler = window.SceneAssembler = class SceneAssembler {
  constructor(mapData) {
    this.mapData = mapData;
    this.staticWorldItems = [];
    this.colliders = [];
    this.climbableZones = [];
    this.shadowPools = mapData.shadowPools || [];
    this.particles = [];
    for (let i = 0; i < 36; i++) {
      this.particles.push({
        x: (Math.random() - 0.5) * 36,
        y: 0.6 + Math.random() * 5.5,
        z: -22 + Math.random() * 44,
        vy: (i % 3 === 0) ? 0.45 : -0.32, // Rising golden lantern embers vs falling sakura petals
        vx: (Math.random() - 0.5) * 0.4,
        isEmber: (i % 3 === 0)
      });
    }
    this.buildStaticEnvironment();
  }

  buildStaticEnvironment() {
    const items = [];
    const cols = [];
    const climbs = [];

    // 1. Courtyard Earth Ground & Main Flagstone Road
    items.push({
      mesh: 'box', tex: 'ground', color: '#454f46',
      x: 0, y: -0.1, z: 0, sx: 68, sy: 0.2, sz: 68,
      outlineWidth: 0, noShadow: true
    });
    items.push({
      mesh: 'box', tex: 'stone', color: '#7a8290',
      x: 0, y: 0.02, z: -2, sx: 5.0, sy: 0.06, sz: 54,
      outlineWidth: 0, noShadow: true
    });
    items.push({
      mesh: 'box', tex: 'stone', color: '#7a8290',
      x: 0, y: 0.02, z: 3.5, sx: 32, sy: 0.06, sz: 4.0,
      outlineWidth: 0, noShadow: true
    });

    // Understage Stealth Drainage Tunnels (Pillar 1 / G12 Three-Layer Map!)
    (this.mapData.understageTunnels || []).forEach(tun => {
      items.push({
        mesh: 'box', tex: 'stone', color: '#141923',
        x: tun.x, y: 0.03, z: tun.z, sx: tun.w, sy: 0.05, sz: tun.d,
        outlineWidth: 0, noShadow: true
      });
      // Wooden slats covering the stealth trench
      for (let sz = tun.z - tun.d * 0.4; sz <= tun.z + tun.d * 0.4; sz += 2.2) {
        items.push({
          mesh: 'box', tex: 'wood', color: '#3b281a',
          x: tun.x, y: 0.07, z: sz, sx: tun.w + 0.2, sy: 0.06, sz: 0.45,
          outlineWidth: 0, noShadow: true
        });
      }
    });

    // Shadow-Meld Pools ("Kage-Ana" Living Shadow Rings on Ground — Pillar 1 / G1!)
    this.shadowPools.forEach(sp => {
      items.push({
        mesh: 'cylinder', tex: 'ground', color: '#0d121c',
        x: sp.x, y: 0.025, z: sp.z, sx: sp.r * 1.6, sy: 0.02, sz: sp.r * 1.6,
        outlineWidth: 0, noShadow: true
      });
      items.push({
        mesh: 'ring', tex: 'shoji', color: '#1f3a60', emissive: 0.55,
        x: sp.x, y: 0.04, z: sp.z, sx: sp.r * 0.9, sy: 1, sz: sp.r * 0.9,
        outlineWidth: 0, noShadow: true
      });
    });

    // Courtyard Props: Stepping Stones, Stone Well, Wooden Cart, Bamboo Fences, Clan Banners, Reflective Puddles (Fixes Critique A.6)
    (this.mapData.props || []).forEach(pr => {
      if (pr.type === 'STEPPING_STONES') {
        [[-0.8, -0.6], [0.7, 0.0], [-0.5, 0.7]].forEach(([ox, oz]) => {
          items.push({ mesh: 'cylinder', tex: 'stone', color: '#8c94a4', x: pr.x + ox, y: 0.05, z: pr.z + oz, sx: 0.85, sy: 0.06, sz: 0.75, outlineWidth: 0.01 });
        });
      } else if (pr.type === 'STONE_WELL') {
        items.push({ mesh: 'cylinder', tex: 'stone', color: '#5c6472', x: pr.x, y: 0.45, z: pr.z, sx: 1.5, sy: 0.9, sz: 1.5 });
        items.push({ mesh: 'box', tex: 'wood', color: '#4a3322', x: pr.x - 0.65, y: 1.3, z: pr.z, sx: 0.14, sy: 1.8, sz: 0.14 });
        items.push({ mesh: 'box', tex: 'wood', color: '#4a3322', x: pr.x + 0.65, y: 1.3, z: pr.z, sx: 0.14, sy: 1.8, sz: 0.14 });
        items.push({ mesh: 'roof', tex: 'kawara', color: '#1b2230', x: pr.x, y: 2.1, z: pr.z, sx: 1.9, sy: 0.45, sz: 1.5 });
        cols.push({ x: pr.x, y: 0.45, z: pr.z, w: 1.6, h: 1.2, d: 1.6, solid: true });
      } else if (pr.type === 'WOOD_CART') {
        items.push({ mesh: 'box', tex: 'wood', color: '#6b4e35', x: pr.x, y: 0.55, z: pr.z, ry: pr.yaw || 0, sx: 1.5, sy: 0.35, sz: 2.2 });
        items.push({ mesh: 'cylinder', tex: 'wood', color: '#3b281a', x: pr.x - 0.8, y: 0.42, z: pr.z, rz: Math.PI * 0.5, sx: 0.85, sy: 0.12, sz: 0.85 });
        items.push({ mesh: 'cylinder', tex: 'wood', color: '#3b281a', x: pr.x + 0.8, y: 0.42, z: pr.z, rz: Math.PI * 0.5, sx: 0.85, sy: 0.12, sz: 0.85 });
        cols.push({ x: pr.x, y: 0.55, z: pr.z, w: 1.6, h: 1.0, d: 2.2, solid: true, walkable: true, surface: 'Wood' });
      } else if (pr.type === 'BAMBOO_FENCE') {
        items.push({ mesh: 'box', tex: 'wood', color: '#5c6b48', x: pr.x, y: 0.75, z: pr.z, sx: pr.w, sy: 1.5, sz: pr.d });
        cols.push({ x: pr.x, y: 0.75, z: pr.z, w: pr.w, h: 1.5, d: pr.d, solid: true });
      } else if (pr.type === 'CLAN_BANNER') {
        items.push({ mesh: 'cylinder', tex: 'wood', color: '#3b281a', x: pr.x, y: 1.8, z: pr.z, sx: 0.10, sy: 3.6, sz: 0.10 });
        items.push({ mesh: 'box', tex: 'cloth', color: '#c8232c', x: pr.x + 0.35, y: 2.3, z: pr.z, sx: 0.65, sy: 1.9, sz: 0.04 });
      } else if (pr.type === 'WATER_PUDDLE') {
        items.push({
          mesh: 'cylinder', tex: 'shoji', color: '#f5b041', emissive: 0.45,
          x: pr.x, y: 0.025, z: pr.z, sx: pr.r, sy: 0.015, sz: pr.r * 0.75,
          outlineWidth: 0, noShadow: true
        });
      }
    });

    // Perimeter Wall
    const wallSegments = [
      { x: 0, z: 29, sx: 54, sz: 1.2 },
      { x: -26, z: 0, sx: 1.2, sz: 58 },
      { x:  26, z: 0, sx: 1.2, sz: 58 },
      { x: -15, z: -26, sx: 22, sz: 1.2 },
      { x:  15, z: -26, sx: 22, sz: 1.2 }
    ];
    wallSegments.forEach(w => {
      items.push({ mesh: 'box', tex: 'stone', color: '#525866', x: w.x, y: 1.1, z: w.z, sx: w.sx, sy: 2.2, sz: w.sz });
      items.push({ mesh: 'roof', tex: 'kawara', color: '#1b2230', x: w.x, y: 2.2, z: w.z, sx: w.sx + 0.4, sy: 0.45, sz: w.sz + 0.4 });
      cols.push({ x: w.x, y: 1.1, z: w.z, w: w.sx, h: 2.4, d: w.sz, solid: true, walkable: true, surface: 'ClayTile' });
    });

    // 2. Modular Japanese Buildings with Curved Irimoya Roofs & Shoji Interior Silhouettes (Pillar 1 / G5!)
    this.mapData.buildings.forEach(b => {
      if (b.type === 'TORII_GATE') {
        // Wide-span Cinnabar Torii Gate framing the outer edges like a poster without blocking the vista (Fixes Critique A.10)
        const tx = 0.0;
        items.push({ mesh: 'cylinder', tex: 'wood', color: '#c8232c', x: tx - 3.6, y: 2.3, z: b.z, sx: 0.32, sy: 4.6, sz: 0.32 });
        items.push({ mesh: 'cylinder', tex: 'wood', color: '#c8232c', x: tx + 3.6, y: 2.3, z: b.z, sx: 0.32, sy: 4.6, sz: 0.32 });
        items.push({ mesh: 'box', tex: 'wood', color: '#c8232c', x: tx, y: 3.85, z: b.z, sx: 8.2, sy: 0.20, sz: 0.26 });
        items.push({ mesh: 'roof', tex: 'kawara', color: '#141923', x: tx, y: 4.45, z: b.z, sx: 9.0, sy: 0.38, sz: 0.80 });
        cols.push({ x: tx - 3.6, y: 2.3, z: b.z, w: 0.42, h: 4.6, d: 0.42, solid: true });
        cols.push({ x: tx + 3.6, y: 2.3, z: b.z, w: 0.42, h: 4.6, d: 0.42, solid: true });
        cols.push({ x: tx, y: 4.5, z: b.z, w: 8.8, h: 0.4, d: 0.85, solid: false, walkable: true, surface: 'ClayTile' });
        return;
      }

      items.push({ mesh: 'box', tex: 'stone', color: '#565e6c', x: b.x, y: 0.22, z: b.z, sx: b.w + 0.6, sy: 0.44, sz: b.d + 0.6 });
      items.push({ mesh: 'box', tex: 'wood', color: '#6b4e35', x: b.x, y: 0.48, z: b.z, sx: b.w + 1.1, sy: 0.12, sz: b.d + 1.1 });

      // Use shojiSilhouette texture on houses with indoor occupants so their silhouette is visible through the paper! (G5)
      const shojiTex = b.hasInteriorShojiSilhouette ? 'shojiSilhouette' : 'shoji';
      const wallCol = b.type === 'SHRINE_HALL' ? '#b8242a' : '#eae0c8';
      items.push({
        mesh: 'box', tex: shojiTex, color: wallCol,
        emissive: b.hasInteriorShojiSilhouette ? 0.35 : 0.0,
        x: b.x, y: 0.5 + b.h * 0.5, z: b.z, sx: b.w, sy: b.h, sz: b.d
      });

      const px = b.w * 0.5 + 0.04, pz = b.d * 0.5 + 0.04;
      [[-px, -pz], [px, -pz], [-px, pz], [px, pz]].forEach(([ox, oz]) => {
        items.push({ mesh: 'box', tex: 'wood', color: '#2b1d12', x: b.x + ox, y: 0.5 + b.h * 0.5, z: b.z + oz, sx: 0.22, sy: b.h + 0.08, sz: 0.22 });
      });

      const roofBaseY = 0.5 + b.h;
      const roofH = b.type === 'WATCHTOWER' ? 1.55 : 1.25;
      items.push({
        mesh: 'roof', tex: 'kawara', color: '#1b2230',
        x: b.x, y: roofBaseY, z: b.z,
        sx: b.w + 2.1, sy: roofH, sz: b.d + 2.1
      });

      if (b.type === 'WATCHTOWER') {
        items.push({ mesh: 'box', tex: 'shojiSilhouette', color: '#eae0c8', emissive: 0.45, x: b.x, y: roofBaseY + roofH + 0.9, z: b.z, sx: b.w * 0.62, sy: 1.8, sz: b.d * 0.62 });
        items.push({ mesh: 'roof', tex: 'kawara', color: '#1b2230', x: b.x, y: roofBaseY + roofH + 1.8, z: b.z, sx: b.w * 0.85, sy: 1.1, sz: b.d * 0.85 });
        // War Scroll Pedestal at Watchtower Climax
        items.push({ mesh: 'box', tex: 'wood', color: '#c8232c', emissive: 0.7, x: b.x, y: 0.85, z: b.z - b.d * 0.5 - 0.8, sx: 0.65, sy: 0.7, sz: 0.45 });
      }

      if (b.hasClimbCloth) {
        const clothZ = b.z - b.d * 0.5 - 0.56;
        items.push({
          mesh: 'box', tex: 'cloth', color: '#f4efe6',
          x: b.x, y: roofBaseY - 0.35, z: clothZ,
          sx: 1.25, sy: 0.85, sz: 0.12
        });
        climbs.push({ x: b.x, z: clothZ, topY: roofBaseY + 0.35, radius: 2.5, label: b.id });
      }

      cols.push({ x: b.x, y: 0.5 + b.h * 0.5, z: b.z, w: b.w, h: b.h, d: b.d, solid: true, walkable: true, surface: 'ClayTile' });
      cols.push({ x: b.x, y: roofBaseY + 0.25, z: b.z, w: b.w + 1.8, h: 0.5, d: b.d + 1.8, solid: false, walkable: true, surface: 'ClayTile' });
    });

    this.mapData.overheadBeams.forEach(bm => {
      items.push({ mesh: 'box', tex: 'wood', color: '#6b4e35', x: bm.x, y: bm.y, z: bm.z, sx: bm.w, sy: bm.h, sz: bm.d });
      cols.push({ x: bm.x, y: bm.y, z: bm.z, w: bm.w, h: bm.h, d: bm.d, solid: false, walkable: true, surface: 'Wood' });
      climbs.push({ x: bm.x, z: bm.z, topY: bm.y + 0.15, radius: 2.2, label: 'Balok Atas Ninja' });
    });

    this.mapData.climbingCrates.forEach(c => {
      items.push({ mesh: 'box', tex: 'wood', color: '#6b4e35', x: c.x, y: 0.55, z: c.z, sx: 1.3, sy: 1.1, sz: 1.3 });
      items.push({ mesh: 'box', tex: 'wood', color: '#5a3f28', x: c.x, y: 1.55, z: c.z + 0.85, sx: 1.2, sy: 0.9, sz: 1.2 });
      items.push({ mesh: 'box', tex: 'cloth', color: '#f4efe6', x: c.x, y: 1.98, z: c.z + 0.85, sx: 0.85, sy: 0.08, sz: 1.24 });
      cols.push({ x: c.x, y: 0.55, z: c.z, w: 1.4, h: 1.1, d: 1.4, solid: true, walkable: true, surface: 'Wood' });
      cols.push({ x: c.x, y: 1.55, z: c.z + 0.85, w: 1.3, h: 0.9, d: 1.3, solid: true, walkable: true, surface: 'Wood' });
      climbs.push({ x: c.x, z: c.z + 0.85, topY: 3.35, radius: 2.5, label: 'Peti Panjat' });
    });

    this.staticWorldItems = items;
    this.colliders = cols;
    this.climbableZones = climbs;
  }

  buildDynamicFrameItems(lanterns, npcs, vfxDecals, inkRipples, kageEchoGhost, goreMode, dt = 0.016) {
    const dyn = [];

    // 1. Interactive Toro Stone Lanterns + Volumetric Light Shafts (Fixes Critique A.8)
    lanterns.forEach(l => {
      const lx = l.x + (l.shiftOffset || 0);
      dyn.push({ mesh: 'cylinder', tex: 'stone', color: '#687080', x: lx, y: 0.65, z: l.z, sx: 0.36, sy: 1.3, sz: 0.36 });
      dyn.push({
        mesh: 'box', tex: 'shoji',
        color: l.lit ? '#f5b041' : '#2a2e38',
        emissive: l.lit ? 1.5 : 0.0,
        x: lx, y: 1.42, z: l.z, sx: 0.46, sy: 0.38, sz: 0.46
      });
      dyn.push({ mesh: 'hat', tex: 'stone', color: '#2b3240', x: lx, y: 1.62, z: l.z, sx: 0.85, sy: 0.85, sz: 0.85 });

      if (l.lit) {
        // Warm Golden Light Pool Ring on Ground (Visualizing Light vs Shadow Boundary for Pillar 1)
        dyn.push({
          mesh: 'ring', tex: 'shoji', color: '#f5b041', emissive: 0.85,
          x: lx, y: 0.03, z: l.z, sx: 3.8, sy: 1, sz: 3.8,
          outlineWidth: 0, noShadow: true
        });
      }
    });

    // 2. Living Atmospheric Particles: Sakura Petals & Rising Lantern Embers (Fixes Critique A.9)
    this.particles.forEach(pt => {
      pt.y += pt.vy * dt;
      pt.x += pt.vx * dt;
      if (pt.isEmber && pt.y > 4.8) pt.y = 1.2;
      if (!pt.isEmber && pt.y < 0.1) pt.y = 5.5;
      dyn.push({
        mesh: 'box', tex: 'shoji',
        color: pt.isEmber ? '#f5b041' : '#f4d5dc',
        emissive: pt.isEmber ? 1.4 : 0.5,
        x: pt.x, y: pt.y, z: pt.z,
        rx: pt.y * 2.0, ry: pt.x * 2.0,
        sx: pt.isEmber ? 0.05 : 0.07, sy: 0.02, sz: pt.isEmber ? 0.05 : 0.07,
        outlineWidth: 0, noShadow: true
      });
    });

    // 3. Pillar 2 (G2): Sumi-e Sound Ink Ripples Expanding on Ground!
    (inkRipples || []).forEach(rp => {
      dyn.push({
        mesh: 'ring', tex: 'shoji',
        color: rp.isLethal ? '#c8232c' : '#eae0c8',
        emissive: 1.2,
        x: rp.x, y: 0.045, z: rp.z,
        sx: rp.r, sy: 1, sz: rp.r,
        outlineWidth: 0, noShadow: true
      });
    });

    // 4. Pillar 3 (G4): Kage-Echo Shadow Decoy Ghost (Replays last 10s of player's previous life!)
    if (kageEchoGhost && kageEchoGhost.active) {
      dyn.push({
        mesh: 'guardTorso', tex: 'cloth', color: '#c8232c', emissive: 0.95,
        x: kageEchoGhost.x, y: 0.88, z: kageEchoGhost.z, ry: kageEchoGhost.yaw,
        sx: 0.92, sy: 0.95, sz: 0.92, isCharacter: true, noShadow: true
      });
      dyn.push({
        mesh: 'ring', tex: 'shoji', color: '#c8232c', emissive: 1.3,
        x: kageEchoGhost.x, y: 0.05, z: kageEchoGhost.z,
        sx: 1.4, sy: 1, sz: 1.4, outlineWidth: 0, noShadow: true
      });
    }

    // 5. Role-Readable Characters with Distinct Armor Colors, Masked Faces (Menpo), & Clan Banners (Fixes Critique A.2 & G18)
    npcs.forEach(npc => {
      if (npc.isDead) {
        dyn.push({
          mesh: (npc.archetype === 'GUARD' || npc.archetype === 'COMMANDER') ? 'guardTorso' : 'peasantTorso',
          tex: 'cloth', color: npc.tunicColor,
          x: npc.x, y: 0.22, z: npc.z, rx: Math.PI * 0.5, ry: npc.yaw, rz: 0,
          sx: 1, sy: 1, sz: 1, isCharacter: true
        });
        return;
      }

      const cosY = Math.cos(npc.yaw), sinY = Math.sin(npc.yaw);
      const toW = (lx, ly, lz) => ({
        x: npc.x + (lx * cosY + lz * sinY),
        y: (npc.y || 0) + ly,
        z: npc.z + (-lx * sinY + lz * cosY)
      });

      const swing = Math.sin(npc.animPhase) * (npc.isMoving ? 0.44 : 0.05);
      const isGuardOrCmd = npc.archetype === 'GUARD' || npc.archetype === 'COMMANDER';

      // Legs
      const lLeg = toW(-0.13, 0.42, Math.sin(swing) * 0.16);
      const rLeg = toW( 0.13, 0.42, Math.sin(-swing) * 0.16);
      const legWidth = isGuardOrCmd ? 0.18 : 0.13;
      dyn.push({ mesh: 'cylinder', tex: 'cloth', color: isGuardOrCmd ? '#243b5e' : '#3a342c', x: lLeg.x, y: lLeg.y, z: lLeg.z, rx: swing * 0.5, ry: npc.yaw, sx: legWidth, sy: 0.78, sz: legWidth, isCharacter: true });
      dyn.push({ mesh: 'cylinder', tex: 'cloth', color: isGuardOrCmd ? '#243b5e' : '#3a342c', x: rLeg.x, y: rLeg.y, z: rLeg.z, rx: -swing * 0.5, ry: npc.yaw, sx: legWidth, sy: 0.78, sz: legWidth, isCharacter: true });

      // Torso with High-Contrast Role Colors
      const torsoMesh = isGuardOrCmd ? 'guardTorso' : (npc.archetype === 'MONK' ? 'monkTorso' : 'peasantTorso');
      const tPos = toW(0, 0.84, 0);
      dyn.push({
        mesh: torsoMesh, tex: 'cloth', color: npc.tunicColor,
        x: tPos.x, y: tPos.y, z: tPos.z, ry: npc.yaw,
        sx: 1, sy: 1, sz: 1, isCharacter: true
      });

      // Clan Sashimono Back Banner + Glowing Hip Lantern for Guards/Commander so they are 100% readable at mid-range! (Fixes Critique A.2)
      if (isGuardOrCmd) {
        const bannerPos = toW(0, 1.52, -0.24);
        dyn.push({
          mesh: 'box', tex: 'cloth',
          color: npc.archetype === 'COMMANDER' ? '#f5b041' : '#eae0c8',
          x: bannerPos.x, y: bannerPos.y, z: bannerPos.z, ry: npc.yaw,
          sx: 0.28, sy: 0.55, sz: 0.04, isCharacter: true
        });
        // Cinnabar Clan Crest Stripe on Sashimono
        const crestPos = toW(0, 1.52, -0.26);
        dyn.push({
          mesh: 'box', tex: 'cloth', color: '#c8232c', emissive: 0.5,
          x: crestPos.x, y: crestPos.y, z: crestPos.z, ry: npc.yaw,
          sx: 0.14, sy: 0.18, sz: 0.05, isCharacter: true
        });
        // Warm Hip Lantern (Koshi-Andon) showing guard position & facing
        const hipLantern = toW(-0.26, 0.86, 0.10);
        dyn.push({
          mesh: 'box', tex: 'shoji', color: '#f5b041', emissive: 1.2,
          x: hipLantern.x, y: hipLantern.y, z: hipLantern.z, ry: npc.yaw,
          sx: 0.11, sy: 0.16, sz: 0.11, isCharacter: true
        });
      }

      // Head + Menpo Face Mask + Role Headgear (G18)
      const hPos = toW(0, 1.54, 0);
      dyn.push({
        mesh: 'head', tex: 'cloth', color: '#e2c4a6',
        x: hPos.x, y: hPos.y, z: hPos.z, ry: npc.yaw,
        sx: 1, sy: 1, sz: 1, isCharacter: true
      });

      if (isGuardOrCmd) {
        // Cinnabar Red Menpo War Mask on Face!
        const maskPos = toW(0, 1.49, 0.10);
        dyn.push({
          mesh: 'box', tex: 'cloth', color: '#c8232c', emissive: 0.4,
          x: maskPos.x, y: maskPos.y, z: maskPos.z, ry: npc.yaw,
          sx: 0.17, sy: 0.12, sz: 0.08, isCharacter: true
        });
        dyn.push({
          mesh: 'kabuto', tex: 'kawara',
          color: npc.archetype === 'COMMANDER' ? '#f5b041' : '#243b5e',
          x: hPos.x, y: hPos.y + 0.04, z: hPos.z, ry: npc.yaw,
          sx: 1.08, sy: 1.08, sz: 1.08, isCharacter: true
        });
      } else if (npc.archetype === 'PEASANT') {
        dyn.push({
          mesh: 'hat', tex: 'wood', color: '#d4b475',
          x: hPos.x, y: hPos.y + 0.06, z: hPos.z, ry: npc.yaw,
          sx: 1.28, sy: 1.0, sz: 1.28, isCharacter: true
        });
      } else if (npc.archetype === 'MONK') {
        dyn.push({
          mesh: 'cylinder', tex: 'wood', color: '#c89e58',
          x: hPos.x, y: hPos.y + 0.05, z: hPos.z, ry: npc.yaw,
          sx: 0.34, sy: 0.32, sz: 0.34, isCharacter: true
        });
      }

      // Arms & Socketed Weapon
      const lArmPos = toW(-0.28, 1.12, -Math.sin(swing) * 0.14);
      dyn.push({ mesh: 'cylinder', tex: 'cloth', color: npc.tunicColor, x: lArmPos.x, y: lArmPos.y, z: lArmPos.z, rx: -swing * 0.5, ry: npc.yaw, sx: 0.11, sy: 0.52, sz: 0.11, isCharacter: true });

      const armPitch = npc.state === 'COMBAT' ? (npc.windupTimer > 0 ? -1.45 : -0.55) : (swing * 0.45);
      const rShoulder = toW(0.28, 1.30, 0);
      const handSocket = toW(0.28, 1.02 - Math.sin(armPitch) * 0.26, 0.22 + Math.cos(armPitch) * 0.18);

      dyn.push({
        mesh: 'cylinder', tex: 'cloth', color: npc.tunicColor,
        x: (rShoulder.x + handSocket.x) * 0.5,
        y: (rShoulder.y + handSocket.y) * 0.5,
        z: (rShoulder.z + handSocket.z) * 0.5,
        rx: armPitch, ry: npc.yaw,
        sx: 0.12, sy: 0.50, sz: 0.12, isCharacter: true
      });
      dyn.push({
        mesh: 'box', tex: 'cloth', color: '#e2c4a6',
        x: handSocket.x, y: handSocket.y, z: handSocket.z,
        rx: armPitch, ry: npc.yaw,
        sx: 0.08, sy: 0.08, sz: 0.09, isCharacter: true
      });

      if (isGuardOrCmd) {
        dyn.push({
          mesh: 'katana', tex: 'stone', color: '#e8f0f8',
          emissive: npc.windupTimer > 0 ? 1.2 : 0.0,
          x: handSocket.x, y: handSocket.y, z: handSocket.z,
          rx: armPitch + 0.25, ry: npc.yaw, rz: 0,
          sx: 1, sy: 1, sz: 1, isCharacter: true
        });
      } else if (npc.archetype === 'MONK') {
        dyn.push({
          mesh: 'cylinder', tex: 'wood', color: '#6b4e35',
          x: handSocket.x, y: 0.85, z: handSocket.z,
          rx: 0, ry: npc.yaw, rz: 0,
          sx: 0.05, sy: 1.65, sz: 0.05, isCharacter: true
        });
      }
    });

    // 6. Cinnabar Ink-Splatter Gore Decals (G16) & Parry Sparks
    vfxDecals.forEach(d => {
      if (d.type === 'BLOOD_DECAL') {
        if (goreMode === 'OFF') return;
        const scale = goreMode === 'LOW' ? 0.55 : 1.0;
        // Woodblock Cinnabar Ink Splatter (Cluster of artistic ink drops)
        dyn.push({
          mesh: 'cylinder', tex: 'cloth', color: '#c8232c', emissive: 0.35,
          x: d.x, y: 0.03, z: d.z,
          sx: d.size * scale, sy: 0.02, sz: d.size * scale,
          outlineWidth: 0.012, noShadow: true
        });
        dyn.push({
          mesh: 'cylinder', tex: 'cloth', color: '#9e141c',
          x: d.x + 0.38 * scale, y: 0.032, z: d.z - 0.28 * scale,
          sx: d.size * 0.42 * scale, sy: 0.02, sz: d.size * 0.42 * scale,
          outlineWidth: 0, noShadow: true
        });
      } else if (d.type === 'SPARK') {
        dyn.push({
          mesh: 'box', tex: 'shoji', color: '#f5b041', emissive: 2.0,
          x: d.x, y: d.y, z: d.z, rx: 0.4, ry: 0.6, rz: 0.78,
          sx: d.size * 1.5, sy: 0.025, sz: 0.025,
          outlineWidth: 0, noShadow: true
        });
        dyn.push({
          mesh: 'box', tex: 'shoji', color: '#ffffff', emissive: 2.0,
          x: d.x, y: d.y, z: d.z, rx: -0.4, ry: 0.6, rz: -0.78,
          sx: d.size * 1.25, sy: 0.02, sz: 0.02,
          outlineWidth: 0, noShadow: true
        });
      } else if (d.type === 'DUST') {
        dyn.push({
          mesh: 'cylinder', tex: 'cloth', color: d.color, emissive: 0.0,
          x: d.x, y: d.y, z: d.z,
          sx: d.size, sy: 0.035, sz: d.size,
          outlineWidth: 0, noShadow: true
        });
      }
    });

    return dyn;
  }

  /**
   * Redesigned First-Person Viewmodel (Fixes Critique A.4 & Implements G11 "Living Hands"):
   * Cloth-wrapped gauntlets, Cinnabar Tekko-koko hand armor, articulated fingers, Kuji-in hand seal gesture,
   * Saya scabbard on left hip, and Iaijutsu draw/strike animation!
   */
  buildFirstPersonViewmodel(camera, combatState, bobPhase, isListenOrMeldActive = false) {
    const vm = [];
    const cosY = Math.cos(camera.yaw), sinY = Math.sin(camera.yaw);
    const cosP = Math.cos(camera.pitch), sinP = Math.sin(camera.pitch);

    const camToWorld = (lx, ly, lz) => {
      const py = ly * cosP - lz * sinP;
      const pz = ly * sinP + lz * cosP;
      return {
        x: camera.x + (lx * cosY + pz * sinY),
        y: camera.y + py,
        z: camera.z + (-lx * sinY + pz * cosY)
      };
    };

    const bobX = Math.sin(bobPhase) * 0.012;
    const bobY = Math.abs(Math.cos(bobPhase)) * 0.010;

    // 1. Left Hand: Either holding the Saya scabbard at hip OR forming Kuji-in Ninja Hand Seal in front of chest! (G11)
    if (isListenOrMeldActive) {
      // Kuji-in Hand Seal Gesture (Rin-Pyo-To-Sha...)
      const sealCenter = camToWorld(-0.08, -0.16, 0.38);
      const lForearm = camToWorld(-0.20, -0.28, 0.28);
      vm.push({
        mesh: 'cylinder', tex: 'cloth', color: '#1b283d',
        x: lForearm.x, y: lForearm.y, z: lForearm.z,
        rx: camera.pitch + 0.4, ry: camera.yaw - 0.35, rz: -0.4,
        sx: 0.062, sy: 0.26, sz: 0.062, isCharacter: true, noShadow: true
      });
      // Tekko-koko Backhand Plate (Cinnabar Accent)
      vm.push({
        mesh: 'box', tex: 'cloth', color: '#c8232c', emissive: 0.5,
        x: sealCenter.x, y: sealCenter.y, z: sealCenter.z,
        rx: camera.pitch, ry: camera.yaw, rz: 0,
        sx: 0.055, sy: 0.055, sz: 0.03, isCharacter: true, noShadow: true
      });
      // Two upright index/middle fingers forming Kuji-in Sword Seal!
      const fingerTip = camToWorld(-0.075, -0.10, 0.38);
      vm.push({
        mesh: 'cylinder', tex: 'cloth', color: '#e2c4a6',
        x: fingerTip.x, y: fingerTip.y, z: fingerTip.z,
        rx: camera.pitch, ry: camera.yaw, rz: 0,
        sx: 0.022, sy: 0.085, sz: 0.018, isCharacter: true, noShadow: true
      });
    } else {
      // Left Hand resting on the Black Lacquer Saya Scabbard at left hip (Supports G3 Iai Standoff!)
      const lSh = camToWorld(-0.32 - bobX, -0.34 - bobY, 0.26);
      const lWr = camToWorld(-0.24 - bobX, -0.26 - bobY, 0.40);
      vm.push({
        mesh: 'cylinder', tex: 'cloth', color: '#1b283d',
        x: (lSh.x + lWr.x) * 0.5, y: (lSh.y + lWr.y) * 0.5, z: (lSh.z + lWr.z) * 0.5,
        rx: camera.pitch - 0.45, ry: camera.yaw + 0.22, rz: 0,
        sx: 0.060, sy: 0.24, sz: 0.060, isCharacter: true, noShadow: true
      });
      vm.push({
        mesh: 'box', tex: 'cloth', color: '#c8232c',
        x: lWr.x, y: lWr.y, z: lWr.z,
        rx: camera.pitch, ry: camera.yaw, rz: 0,
        sx: 0.048, sy: 0.032, sz: 0.058, isCharacter: true, noShadow: true
      });
      // Lacquered Saya Scabbard gripped by Left Hand
      const sayaPos = camToWorld(-0.26 - bobX, -0.28 - bobY, 0.46);
      vm.push({
        mesh: 'box', tex: 'kawara', color: '#141923',
        x: sayaPos.x, y: sayaPos.y, z: sayaPos.z,
        rx: camera.pitch - 0.18, ry: camera.yaw + 0.12, rz: 0,
        sx: 0.028, sy: 0.036, sz: 0.52, isCharacter: true, noShadow: true
      });
    }

    // 2. Right Hand & Katana (Either Sheathed in Iai Kamae Stance OR Drawn in Chudan Stance!)
    let handX = combatState.isSheathed ? -0.14 : (0.34 + bobX);
    let handY = combatState.isSheathed ? (-0.24 - bobY) : (-0.26 - bobY);
    let handZ = combatState.isSheathed ? 0.42 : 0.48;
    let bladePitch = camera.pitch + (combatState.isSheathed ? -0.15 : 0.48);
    let bladeYaw = camera.yaw + (combatState.isSheathed ? 0.45 : 0.18);
    let bladeRoll = combatState.isSheathed ? 1.25 : -0.16;

    if (combatState.phase === 'WINDUP') {
      const t = combatState.phaseProgress;
      handX += 0.10 * t;
      handY += 0.12 * t;
      bladePitch += 0.45 * t;
    } else if (combatState.phase === 'STRIKE') {
      const t = combatState.phaseProgress;
      handX = 0.34 - 0.62 * t;
      handY = -0.10 - 0.18 * t;
      bladeYaw = camera.yaw - 0.70 + 1.45 * t;
      bladePitch = camera.pitch + 0.12;
      bladeRoll = 0.92;
    } else if (combatState.phase === 'RECOVERY') {
      const t = combatState.phaseProgress;
      handX = -0.26 + 0.58 * t;
      handY = -0.28 + 0.04 * t;
      bladeYaw = camera.yaw + 0.72 - 0.54 * t;
    } else if (combatState.phase === 'PARRY') {
      handX = 0.04;
      handY = -0.10;
      handZ = 0.46;
      bladeYaw = camera.yaw + 0.68;
      bladeRoll = 1.18;
    }

    const rElbow = camToWorld(0.38, -0.38, 0.24);
    const rWrist = camToWorld(handX, handY, handZ);
    // Cloth-wrapped forearm (Tekko)
    vm.push({
      mesh: 'cylinder', tex: 'cloth', color: '#1b283d',
      x: (rElbow.x + rWrist.x) * 0.5,
      y: (rElbow.y + rWrist.y) * 0.5,
      z: (rElbow.z + rWrist.z) * 0.5,
      rx: camera.pitch - 0.5, ry: camera.yaw, rz: -0.2,
      sx: 0.062, sy: 0.28, sz: 0.062, isCharacter: true, noShadow: true
    });
    // Cinnabar Tekko-koko Backhand Plate + Fingers
    vm.push({
      mesh: 'box', tex: 'cloth', color: '#c8232c',
      x: rWrist.x, y: rWrist.y + 0.01, z: rWrist.z,
      rx: bladePitch, ry: bladeYaw, rz: bladeRoll,
      sx: 0.048, sy: 0.025, sz: 0.062, isCharacter: true, noShadow: true
    });
    vm.push({
      mesh: 'cylinder', tex: 'cloth', color: '#e2c4a6',
      x: rWrist.x, y: rWrist.y - 0.01, z: rWrist.z,
      rx: bladePitch, ry: bladeYaw, rz: bladeRoll,
      sx: 0.044, sy: 0.055, sz: 0.048, isCharacter: true, noShadow: true
    });

    // Socketed 3D Katana
    vm.push({
      mesh: 'katana', tex: 'stone', color: '#eef4fa',
      emissive: combatState.isIaiStrike ? 1.2 : 0.15,
      x: rWrist.x, y: rWrist.y, z: rWrist.z,
      rx: bladePitch, ry: bladeYaw, rz: bladeRoll,
      sx: 0.72, sy: 0.72, sz: 0.72, isCharacter: true, noShadow: true
    });

    // 3D Blade Slash Trail Arc during Active Strike
    if (combatState.phase === 'STRIKE') {
      const trailPos = camToWorld(0.0, -0.05, 0.76);
      vm.push({
        mesh: 'box', tex: 'shoji',
        color: combatState.isIaiStrike ? '#c8232c' : '#f4efe6',
        emissive: 1.8,
        x: trailPos.x, y: trailPos.y, z: trailPos.z,
        rx: camera.pitch, ry: camera.yaw, rz: 0.32,
        sx: 0.88, sy: 0.022, sz: 0.22, outlineWidth: 0, noShadow: true
      });
    }

    return vm;
  }
};
