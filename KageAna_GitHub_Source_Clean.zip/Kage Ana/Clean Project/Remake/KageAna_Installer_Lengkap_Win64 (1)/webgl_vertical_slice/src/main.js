// Main Entry Point for KAGE-ANA v2.0 ("Wow Slice" — 3 Competitive Pillars)

const cfg = window.KAGE_DATA.gameplayConfig;
const mapData = window.KAGE_DATA.verticalSliceMap;

const canvas = document.getElementById('webglCanvas');
const renderer = new window.WebGLRenderer(canvas);
const assembler = new window.SceneAssembler(mapData);

const lanterns = mapData.lanterns.map(l => ({ ...l }));
const player = new window.PlayerController(cfg, mapData.playerSpawn);
const combat = new window.BladeCombatSystem(cfg);
const guardAI = new window.GuardAISystem(cfg.ai, mapData.npcs);

const state = {
  goreMode: 'HIGH',
  vfxDecals: [],
  inkRipples: [],
  recordedPath: [],
  kageEchoPlayback: [],
  kageEchoCursor: 0,
  kageEchoGhost: { active: false, x: 0, z: 0, yaw: 0 },
  missionTimeSeconds: 0,
  timesSpotted: 0,
  regularGuardsKilled: 0,
  missionWon: false,
  missionFailed: false,
  lastFailReason: '',
  showDebugTelemetry: false, // Critique A.11: Hidden by default, toggle with [F1]
  cinematicHideHud: false,   // Toggle with [F5]
  paused: false,
  statusMsg: 'Pilar 1 [Z] Shadow-Meld antar bayangan • Pilar 2 [V] Mata Telinga • Pilar 3 [B]+Klik Kiri Satu Tebasan Iai',
  frameTimes: [],
  avgFps: 60,
  low1Fps: 55
};

function spawnInkRipple(x, z, maxR, isLethal = false) {
  state.inkRipples.push({ x, z, r: 0.35, maxR, isLethal });
}

function triggerInkFlash() {
  const el = document.getElementById('inkFlashOverlay');
  if (!el) return;
  el.style.opacity = '1';
  setTimeout(() => { el.style.opacity = '0'; }, 240);
}

const keys = {};
window.addEventListener('keydown', e => {
  const code = e.code || '';
  if (code === 'Escape') {
    window.toggleSettingsMenu();
    return;
  }

  // Fast Reload from Fail Screen (< 1s) with Kage-Echo Ghost Spawn! (Pillar 3 / G4 & Rule 9)
  if (state.missionFailed && (code === 'Space' || code === 'KeyR')) {
    window.fastReloadWithKageEcho();
    return;
  }
  if (state.missionWon && code === 'KeyR') {
    window.restartFullMission();
    return;
  }
  if (state.paused || state.missionFailed || state.missionWon) return;

  keys[code] = true;
  if (code === 'KeyS' || code === 'ArrowDown') {
    keys['KeyW'] = false; keys['ArrowUp'] = false;
  }

  // Pillar 1 (G1): Shadow-Meld [Z] or [AltLeft]
  if (code === 'KeyZ' || code === 'AltLeft') {
    e.preventDefault();
    if (player.tryShadowMeld(assembler.shadowPools, spawnInkRipple, msg => { state.statusMsg = msg; })) {
      triggerInkFlash();
    }
  }
  // Pillar 1 (G12): Kaginawa Grapple [L]
  if (code === 'KeyL') {
    if (player.tryKaginawaGrapple(assembler.climbableZones, msg => { state.statusMsg = msg; })) {
      triggerInkFlash();
    }
  }
  // Pillar 2 (G2): "Mata Telinga" Listen Mode [V] or [Tab]
  if (code === 'KeyV' || code === 'Tab') {
    e.preventDefault();
    renderer.listenMode = renderer.listenMode === 1 ? 0 : 1;
    state.statusMsg = renderer.listenMode === 1
      ? '👁️ MATA TELINGA AKTIF [V]: Dunia menjadi kertas Washi — penjaga & riak suara tampak sebagai sapuan kuas merah!'
      : 'Mata Telinga dinonaktifkan.';
  }
  // Pillar 2 (G10): Ukiyo-e Woodblock Photo Mode [P]
  if (code === 'KeyP') {
    renderer.photoMode = renderer.photoMode === 1 ? 0 : 1;
    const hanko = document.getElementById('photoModeHanko');
    if (hanko) hanko.style.display = renderer.photoMode === 1 ? 'flex' : 'none';
    state.statusMsg = renderer.photoMode === 1
      ? '🖼️ MODE FOTO CETAK KAYU UKIYO-E AKTIF [P]'
      : 'Mode Foto Ukiyo-e dinonaktifkan.';
  }
  // Pillar 3 (G3): Sheathe / Iai Stance Toggle [B]
  if (code === 'KeyB') {
    combat.toggleSheathe(msg => { state.statusMsg = msg; });
  }
  // Contextual Action [E]: Two-Way Lantern (Extinguish/Relight to lure guard) or Seize War Scroll at Watchtower
  if (code === 'KeyE') {
    handleContextualAction();
  }
  // Shift Movable Lantern [R] to move shadow pool! (Pillar 1 / G1)
  if (code === 'KeyR') {
    handleShiftLantern();
  }
  // Silent Takedown [F]
  if (code === 'KeyF') {
    trySilentElimination();
  }
  // Parry [Q]
  if (code === 'KeyQ') {
    combat.startParry(player);
  }
  // Kunai [K]
  if (code === 'KeyK') {
    combat.throwKunaiAtTarget(player, lanterns, guardAI.npcs, v => state.vfxDecals.push(v), spawnInkRipple, msg => { state.statusMsg = msg; });
  }
  // [F1] Toggle Debug Telemetry (Critique A.11: Hidden by default!)
  if (code === 'F1') {
    e.preventDefault();
    state.showDebugTelemetry = !state.showDebugTelemetry;
    const tel = document.getElementById('perfTelemetry');
    if (tel) tel.style.display = state.showDebugTelemetry ? 'block' : 'none';
  }
  // [F2] Normal Ukiyo-e, [F3] Silhouette Test, [F4] Grayscale Value Test, [F5] Cinematic HUD Hide
  if (code === 'F2') window.setVisualMode(0);
  if (code === 'F3') window.setVisualMode(1);
  if (code === 'F4') window.setVisualMode(2);
  if (code === 'F5') {
    state.cinematicHideHud = !state.cinematicHideHud;
    document.getElementById('hudRoot').style.display = state.cinematicHideHud ? 'none' : 'block';
  }
  if (code === 'KeyT') {
    window.setTimePreset(renderer.timePreset === 'SORE' ? 'MALAM' : 'SORE');
  }
});

window.addEventListener('keyup', e => {
  const code = e.code || '';
  keys[code] = false;
  if (code === 'KeyW' || code === 'ArrowUp') { keys['KeyW'] = false; keys['ArrowUp'] = false; }
  if (code === 'KeyS' || code === 'ArrowDown') { keys['KeyS'] = false; keys['ArrowUp'] = false; }
});

window.addEventListener('blur', () => {
  Object.keys(keys).forEach(k => { keys[k] = false; });
});

// ---------------------------------------------------------------------------
// Mouse look (v2.0.1): Pointer Lock first-person look (no button held).
//   mouse right -> turn right, mouse left -> turn left, mouse up -> look up.
// Falls back to drag-to-look when Pointer Lock is unavailable.
// ---------------------------------------------------------------------------
const MOUSE_SENS_YAW = 0.0022;    // radians per pixel
const MOUSE_SENS_PITCH = 0.0020;  // radians per pixel
const MOUSE_INVERT_Y = false;     // true = push mouse forward to look down
const PITCH_LIMIT = 1.15;

let isDragging = false;
let lastX = 0, lastY = 0;

function isPointerLocked() {
  return document.pointerLockElement === canvas;
}
function tryLockPointer() {
  try {
    if (canvas.requestPointerLock && !isPointerLocked()) {
      const r = canvas.requestPointerLock();
      if (r && r.catch) r.catch(() => {});
    }
  } catch (err) { /* fall back to drag-to-look */ }
}
function applyLook(dx, dy) {
  player.yaw += dx * MOUSE_SENS_YAW;
  const sign = MOUSE_INVERT_Y ? 1 : -1;
  player.pitch = Math.max(-PITCH_LIMIT, Math.min(PITCH_LIMIT, player.pitch + sign * dy * MOUSE_SENS_PITCH));
}

canvas.addEventListener('mousedown', e => {
  if (state.paused || state.missionFailed || state.missionWon) return;
  window.LayeredAudio.init();
  // First click only captures the mouse (no accidental slash).
  if (canvas.requestPointerLock && !isPointerLocked()) {
    tryLockPointer();
    if (!isPointerLocked()) { isDragging = true; lastX = e.clientX; lastY = e.clientY; }
    return;
  }
  isDragging = true;
  lastX = e.clientX;
  lastY = e.clientY;
  if (e.button === 0) {
    combat.startHeavySlash(player, guardAI.npcs, v => state.vfxDecals.push(v), spawnInkRipple, msg => { state.statusMsg = msg; });
  } else if (e.button === 2) {
    combat.startParry(player);
  }
});
window.addEventListener('mouseup', () => { isDragging = false; });
window.addEventListener('contextmenu', e => e.preventDefault());
window.addEventListener('mousemove', e => {
  if (state.paused || state.missionFailed || state.missionWon) return;
  if (isPointerLocked()) {
    // Ignore the occasional huge spike some browsers emit when the lock starts.
    if (Math.abs(e.movementX) > 300 || Math.abs(e.movementY) > 300) return;
    applyLook(e.movementX, e.movementY);
    return;
  }
  if (!isDragging) return;
  const dx = e.clientX - lastX;
  const dy = e.clientY - lastY;
  lastX = e.clientX;
  lastY = e.clientY;
  applyLook(dx, dy);
});
document.addEventListener('pointerlockchange', () => {
  // Esc releases the mouse in the browser: show the pause menu instead of leaving a free cursor.
  if (!isPointerLocked() && !state.paused && !state.missionFailed && !state.missionWon && window.__kageHadLock) {
    window.toggleSettingsMenu();
  }
  window.__kageHadLock = isPointerLocked();
});

function handleContextualAction() {
  // 1. Check Watchtower War Scroll Climax Objective!
  const obj = mapData.objective;
  if (Math.hypot(player.x - obj.x, player.z - obj.z) <= 4.2) {
    triggerMissionVictory('Gulungan Perang Kuzuryu berhasil direbut di puncak Menara Utara!');
    return;
  }

  // 2. Two-Way Lantern Manipulation (Pillar 1 / G1): Extinguish for shadow OR Relight to lure guard!
  for (let i = 0; i < lanterns.length; i++) {
    const l = lanterns[i];
    const lx = l.x + (l.shiftOffset || 0);
    if (Math.hypot(player.x - lx, player.z - l.z) < 3.4) {
      l.lit = !l.lit;
      window.LayeredAudio.playStep('Stone', false, true);
      spawnInkRipple(lx, l.z, 3.5, false);
      if (l.lit) {
        guardAI.lureNearestGuardToPosition(lx, l.z, msg => { state.statusMsg = msg; });
      } else {
        state.statusMsg = `🌑 Lentera Batu #${l.id} dipadamkan — jembatan bayangan terhubung untuk Shadow-Meld [Z]!`;
      }
      return;
    }
  }
  trySilentElimination();
}

function handleShiftLantern() {
  for (let i = 0; i < lanterns.length; i++) {
    const l = lanterns[i];
    const lx = l.x + (l.shiftOffset || 0);
    if (Math.hypot(player.x - lx, player.z - l.z) < 3.6) {
      l.shiftOffset = (l.shiftOffset || 0) === 0 ? (l.x < 0 ? -1.8 : 1.8) : 0;
      window.LayeredAudio.playStep('Stone', true, false);
      spawnInkRipple(l.x + l.shiftOffset, l.z, 4.0, false);
      state.statusMsg = `🏮 Lentera #${l.id} digeser [R] — posisi bayangan berubah!`;
      return;
    }
  }
}

function trySilentElimination() {
  for (let i = 0; i < guardAI.npcs.length; i++) {
    const npc = guardAI.npcs[i];
    if (npc.isDead || (npc.archetype !== 'GUARD' && npc.archetype !== 'COMMANDER')) continue;
    const d = Math.hypot(player.x - npc.x, player.z - npc.z);
    if (d <= 2.8 && npc.state !== 'COMBAT') {
      npc.isDead = true;
      combat.hitStopTimer = 0.075;
      player.addCameraShake(0.14, 0.04);
      window.LayeredAudio.playSlashImpact(true);
      state.vfxDecals.push({ type: 'BLOOD_DECAL', x: npc.x, z: npc.z, size: 1.0, life: 45 });
      state.statusMsg = `🤫 Eliminasi Senyap Tanpa Suara: ${npc.name} dilumpuhkan.`;
      handleEnemyKilled(npc);
      return true;
    }
  }
  return false;
}

function handleEnemyKilled(npc) {
  if (npc.isPrimaryTarget || npc.archetype === 'COMMANDER') {
    triggerMissionVictory(`Komandan Menara Kuzuryu tumbang oleh tebasanmu!`);
  } else if (npc.archetype === 'GUARD') {
    state.regularGuardsKilled++;
  }
}

function triggerMissionVictory(summaryText) {
  if (state.missionWon) return;
  state.missionWon = true;
  window.LayeredAudio.triggerDramaticSilence(1.2);

  const unseen = state.timesSpotted === 0;
  const noCollateral = state.regularGuardsKilled === 0;
  const fastClear = state.missionTimeSeconds <= 180;
  const score = (unseen ? 1 : 0) + (noCollateral ? 1 : 0) + (fastClear ? 1 : 0);
  const rank = score === 3 ? 'S' : (score === 2 ? 'A' : 'B');

  document.getElementById('winSummaryText').textContent = summaryText;
  document.getElementById('winRankSeal').textContent = rank;
  document.getElementById('obj1Status').textContent = unseen ? '✅ LULUS (0x Terlihat)' : `❌ GAGAL (${state.timesSpotted}x Terdeteksi)`;
  document.getElementById('obj2Status').textContent = noCollateral ? '✅ LULUS (Hanya Target Utama)' : `❌ GAGAL (${state.regularGuardsKilled} Penjaga Biasa Terbunuh)`;
  document.getElementById('obj3Status').textContent = `${fastClear ? '✅ LULUS' : '❌ LAMBAT'} (${state.missionTimeSeconds.toFixed(1)} dtk)`;
  document.getElementById('victoryModal').style.display = 'flex';
}

function triggerMissionFailure(reason) {
  if (state.missionFailed || state.missionWon) return;
  state.missionFailed = true;
  state.lastFailReason = reason;
  document.getElementById('failReasonText').textContent = reason;
  document.getElementById('failModal').style.display = 'flex';
}

window.fastReloadWithKageEcho = function() {
  document.getElementById('failModal').style.display = 'none';
  triggerInkFlash();
  // Convert last 10s recording into an active Kage-Echo Ghost decoy! (Pillar 3 / G4)
  if (state.recordedPath.length > 5) {
    state.kageEchoPlayback = [...state.recordedPath];
    state.kageEchoCursor = 0;
    state.kageEchoGhost.active = true;
  }
  state.recordedPath = [];
  state.missionFailed = false;
  player.reset();
  combat.isSheathed = true;
  combat.phase = 'IDLE';
  guardAI.npcs.forEach(n => {
    if (!n.isDead) {
      n.state = 'PATROL';
      n.suspicion = 0;
    }
  });
  state.statusMsg = '👻 KAGE-ECHO AKTIF: Gema bayangan 10 detik terakhir sebelum kematianmu kini memancing penjaga!';
};

window.restartFullMission = function() {
  document.getElementById('victoryModal').style.display = 'none';
  document.getElementById('failModal').style.display = 'none';
  triggerInkFlash();
  lanterns.forEach(l => { l.lit = true; l.shiftOffset = 0; });
  guardAI.reset(mapData.npcs);
  player.reset();
  combat.isSheathed = true;
  combat.phase = 'IDLE';
  state.vfxDecals = [];
  state.inkRipples = [];
  state.recordedPath = [];
  state.kageEchoPlayback = [];
  state.kageEchoGhost.active = false;
  state.missionTimeSeconds = 0;
  state.timesSpotted = 0;
  state.regularGuardsKilled = 0;
  state.missionWon = false;
  state.missionFailed = false;
  state.statusMsg = 'Misi diulang dari awal. Gunakan Bayangan [Z], Mata Telinga [V], dan Satu Tebasan Iai [B].';
};

function computeContextualPrompt() {
  const obj = mapData.objective;
  if (Math.hypot(player.x - obj.x, player.z - obj.z) <= 4.2) {
    return '📜 [Tekan E] Rebut Gulungan Perang di Menara Utara (Selesaikan Misi)!';
  }
  for (let i = 0; i < lanterns.length; i++) {
    const l = lanterns[i];
    const lx = l.x + (l.shiftOffset || 0);
    if (Math.hypot(player.x - lx, player.z - l.z) < 3.4) {
      return l.lit
        ? `[E] Padamkan Lentera #${l.id} (Buka Bayangan) • [R] Geser Lentera`
        : `[E] Nyalakan Lentera #${l.id} (Pancing Penjaga) • [R] Geser Lentera`;
    }
  }
  for (let i = 0; i < guardAI.npcs.length; i++) {
    const npc = guardAI.npcs[i];
    if (!npc.isDead && (npc.archetype === 'GUARD' || npc.archetype === 'COMMANDER') && Math.hypot(player.x - npc.x, player.z - npc.z) <= 2.8 && npc.state !== 'COMBAT') {
      return `🤫 [F / E] Eliminasi Senyap (${npc.name})`;
    }
  }
  return state.statusMsg;
}

function updateMinimalHUD(aiSummary) {
  document.getElementById('fillVitality').style.width = `${Math.round(player.vitality)}%`;
  document.getElementById('fillStamina').style.width = `${Math.round(player.stamina)}%`;
  document.getElementById('fillShadowStrength').style.width = `${Math.round(player.shadowStrength * 100)}%`;
  document.getElementById('txtVitality').textContent = `${Math.round(player.vitality)}%`;
  document.getElementById('txtStamina').textContent = `${Math.round(player.stamina)}%`;
  document.getElementById('txtShadowStrength').textContent = `${Math.round(player.shadowStrength * 100)}%`;

  const obj = mapData.objective;
  const distObj = Math.hypot(obj.x - player.x, obj.z - player.z).toFixed(1);
  const stanceLabel = combat.isSheathed ? '🗡️ Iai Tersarung [B]' : '⚔️ Katana Terhunus [B]';
  document.getElementById('compassObjective').textContent =
    `⛩️ Menara Utara (${distObj} m) • ${stanceLabel} • Kunai [K]: ${combat.kunaiCount}`;

  if (state.showDebugTelemetry) {
    document.getElementById('perfTelemetry').textContent =
      `[DEV F1] WebGL GPU • ${state.avgFps} FPS (1% Low: ${state.low1Fps}) • Draw Calls: ${renderer.lastDrawCalls} • Tris: ${renderer.lastTriangles}`;
  }

  const visLabel = player.shadowStrength >= 0.60 ? '🌑 Pekat (Siap Shadow-Meld [Z])' : (player.shadowStrength >= 0.35 ? '🌘 Samar' : '🌕 Terang (Rentan)');
  document.getElementById('txtStealthLight').textContent = `Bayangan: ${visLabel}`;
  document.getElementById('txtAcousticDb').textContent = ` Riak Tinta: ${Math.round(player.currentNoiseDb)} dB • [V] Mata Telinga`;
  document.getElementById('badgeAlertState').textContent = `${aiSummary.highestState} (${Math.round(aiSummary.highestSuspicion)}%)`;

  document.getElementById('hudBottomCenter').textContent = computeContextualPrompt();
}

window.toggleSettingsMenu = function() {
  state.paused = !state.paused;
  const modal = document.getElementById('settingsModal');
  if (modal) modal.style.display = state.paused ? 'flex' : 'none';
  try {
    if (state.paused) { if (document.exitPointerLock) document.exitPointerLock(); }
    else { tryLockPointer(); }
  } catch (err) { /* pointer lock is optional */ }
};

window.setTimePreset = function(preset) {
  renderer.timePreset = preset;
  document.getElementById('btnTimeSore').classList.toggle('active', preset === 'SORE');
  document.getElementById('btnTimeMalam').classList.toggle('active', preset === 'MALAM');
};

window.setGoreMode = function(mode) {
  state.goreMode = mode;
  ['OFF', 'LOW', 'HIGH'].forEach(m => {
    const btn = document.getElementById('btnGore_' + m);
    if (btn) btn.classList.toggle('active', m === mode);
  });
};

window.setVisualMode = function(mode) {
  renderer.debugMode = mode;
  [0, 1, 2].forEach(m => {
    const btn = document.getElementById('btnVis_' + m);
    if (btn) btn.classList.toggle('active', m === mode);
  });
};

window.setRenderScale = function(scale) {
  renderer.renderScale = scale;
  renderer.resize();
};

// Expose API for Automated Verification & Screenshot Capture
window.KAGE_VERTICAL_SLICE = {
  renderer,
  assembler,
  player,
  combat,
  guardAI,
  lanterns,
  state,
  spawnInkRipple,
  setCameraPose(x, y, z, yaw, pitch, timePreset = 'SORE', debugMode = 0, keepVfx = false) {
    if (!keepVfx) {
      state.vfxDecals = [];
      state.inkRipples = [];
    }
    player.x = x;
    player.y = y;
    player.z = z;
    player.yaw = yaw;
    player.pitch = pitch;
    renderer.timePreset = timePreset;
    renderer.debugMode = debugMode;
    this.renderSingleFrame(0.016);
  },
  renderSingleFrame(dt = 0.016) {
    const aiSummary = guardAI.update(
      dt, player, combat, assembler.colliders, state.kageEchoGhost,
      v => state.vfxDecals.push(v), m => { state.statusMsg = m; },
      () => { state.timesSpotted++; },
      reason => triggerMissionFailure(reason)
    );
    const dynItems = assembler.buildDynamicFrameItems(
      lanterns, guardAI.npcs, state.vfxDecals, state.inkRipples, state.kageEchoGhost, state.goreMode, dt
    );
    const allWorld = assembler.staticWorldItems.concat(dynItems);
    const cam = player.getCamera(dt);
    const vmItems = assembler.buildFirstPersonViewmodel(cam, combat, player.bobPhase, renderer.listenMode === 1);
    renderer.renderScene(cam, allWorld, vmItems, lanterns);
    updateMinimalHUD(aiSummary);
  },
  runAutomatedStealthScenarios() {
    const results = [];

    // 1. Pass Undetected in Shadow & Rooftop
    guardAI.reset(mapData.npcs);
    player.reset();
    player.x = -11.8; player.y = 3.25 + 1.68; player.z = -6.0; player.isCrouching = true;
    player.lightExposure = 0.12; player.shadowStrength = 0.88;
    for (let i = 0; i < 30; i++) guardAI.update(0.05, player, combat, assembler.colliders, null, () => {}, () => {}, null, null);
    const s1MaxSusp = Math.max(...guardAI.npcs.map(n => n.suspicion));
    results.push({ scenario: '1. Lewat Tak Terdeteksi (Atap & Bayangan)', passed: s1MaxSusp < 25, maxSuspicion: Math.round(s1MaxSusp) });

    // 2. Detected in Bright Lantern Light
    guardAI.reset(mapData.npcs);
    player.x = -2.3; player.y = 1.68; player.z = -11.5;
    player.isCrouching = false; player.lightExposure = 0.98; player.shadowStrength = 0.02;
    for (let i = 0; i < 55; i++) guardAI.update(0.05, player, combat, assembler.colliders, null, () => {}, () => {}, null, null);
    results.push({ scenario: '2. Terdeteksi di Area Terang Lentera', passed: guardAI.npcs[0].state === 'COMBAT', finalState: guardAI.npcs[0].state });

    // 3. Acoustic Ink Ripple Search
    guardAI.reset(mapData.npcs);
    const g1 = guardAI.npcs[1];
    player.x = g1.x + 6.0; player.z = g1.z; player.currentNoiseDb = 44; player.lightExposure = 0.1;
    for (let i = 0; i < 55; i++) guardAI.update(0.05, player, combat, assembler.colliders, null, () => {}, () => {}, null, null);
    results.push({ scenario: '3. Investigasi Suara Tinta (Search)', passed: g1.suspicion >= 70, suspicion: Math.round(g1.suspicion) });

    // 4. Shadow-Meld Teleport Between Shadow Pools (Pillar 1 / G1)
    player.reset();
    player.x = -6.2; player.z = -17.5; player.yaw = 0; player.shadowStrength = 0.85; player.stamina = 100;
    const melded = player.tryShadowMeld(assembler.shadowPools, () => {}, () => {});
    results.push({ scenario: '4. Shadow-Meld Antar Kolam Bayangan (Pilar 1)', passed: melded && player.z > -12.0, newZ: player.z });

    // 5. Kage-Echo Ghost Decoy Lures Guard (Pillar 3 / G4)
    guardAI.reset(mapData.npcs);
    const gTest = guardAI.npcs[0];
    const echoGhost = { active: true, x: gTest.x + 5.0, z: gTest.z, yaw: 0 };
    guardAI.update(0.1, player, combat, assembler.colliders, echoGhost, () => {}, () => {}, null, null);
    results.push({ scenario: '5. Gema Bayangan (Kage-Echo) Memancing Penjaga (Pilar 3)', passed: gTest.state === 'SEARCH', guardState: gTest.state });

    lanterns.forEach(l => { l.lit = true; l.shiftOffset = 0; });
    guardAI.reset(mapData.npcs);
    player.reset();
    return results;
  }
};

let lastNow = performance.now();
let recordAccum = 0;

function loop(now) {
  const rawDt = (now - lastNow) / 1000;
  lastNow = now;
  const dt = Math.min(0.05, Math.max(0.001, rawDt));

  if (window.LayeredAudio.dramaticSilenceTimer > 0) {
    window.LayeredAudio.dramaticSilenceTimer = Math.max(0, window.LayeredAudio.dramaticSilenceTimer - dt);
  }

  const instFps = 1.0 / Math.max(0.001, rawDt);
  state.frameTimes.push(instFps);
  if (state.frameTimes.length > 90) state.frameTimes.shift();
  const sum = state.frameTimes.reduce((a, b) => a + b, 0);
  state.avgFps = Math.round(sum / state.frameTimes.length);
  const sorted = [...state.frameTimes].sort((a, b) => a - b);
  state.low1Fps = Math.round(sorted[0] || state.avgFps);

  if (!state.paused && !state.missionFailed && !state.missionWon) {
    state.missionTimeSeconds += dt;

    // Record player movement every 0.1s for Kage-Echo 10-second replay (Pillar 3 / G4)
    recordAccum += dt;
    if (recordAccum >= 0.10) {
      recordAccum = 0;
      state.recordedPath.push({ x: player.x, z: player.z, yaw: player.yaw });
      if (state.recordedPath.length > 100) state.recordedPath.shift();

      if (state.kageEchoGhost.active && state.kageEchoPlayback.length > 0) {
        const frame = state.kageEchoPlayback[state.kageEchoCursor];
        if (frame) {
          state.kageEchoGhost.x = frame.x;
          state.kageEchoGhost.z = frame.z;
          state.kageEchoGhost.yaw = frame.yaw;
          state.kageEchoCursor++;
        } else {
          state.kageEchoGhost.active = false;
        }
      }
    }

    if (combat.hitStopTimer > 0) {
      combat.hitStopTimer = Math.max(0, combat.hitStopTimer - dt);
    } else {
      player.update(dt, keys, assembler.colliders, assembler.climbableZones, lanterns, assembler.shadowPools, renderer.timePreset, (fx, fy, fz, rippleRad) => {
        state.vfxDecals.push({ type: 'DUST', x: fx, y: fy, z: fz, size: 0.14, color: '#9e9585', life: 0.28 });
        spawnInkRipple(fx, fz, rippleRad, false);
      });

      combat.update(dt, player, guardAI.npcs, v => state.vfxDecals.push(v), m => { state.statusMsg = m; }, killedNpc => handleEnemyKilled(killedNpc));

      const aiSummary = guardAI.update(
        dt, player, combat, assembler.colliders, state.kageEchoGhost,
        v => state.vfxDecals.push(v), m => { state.statusMsg = m; },
        () => { state.timesSpotted++; },
        reason => triggerMissionFailure(reason)
      );

      // Update expanding Sumi-e Sound Ink Ripples (Pillar 2 / G2)
      for (let i = state.inkRipples.length - 1; i >= 0; i--) {
        const rp = state.inkRipples[i];
        rp.r += dt * (rp.maxR * 1.85);
        if (rp.r >= rp.maxR) state.inkRipples.splice(i, 1);
      }

      for (let i = state.vfxDecals.length - 1; i >= 0; i--) {
        state.vfxDecals[i].life -= dt;
        if (state.vfxDecals[i].life <= 0) state.vfxDecals.splice(i, 1);
      }

      const dynItems = assembler.buildDynamicFrameItems(
        lanterns, guardAI.npcs, state.vfxDecals, state.inkRipples, state.kageEchoGhost, state.goreMode, dt
      );
      const allWorld = assembler.staticWorldItems.concat(dynItems);
      const cam = player.getCamera(dt);
      const vmItems = assembler.buildFirstPersonViewmodel(cam, combat, player.bobPhase, renderer.listenMode === 1);

      renderer.renderScene(cam, allWorld, vmItems, lanterns);
      updateMinimalHUD(aiSummary);
    }
  }

  requestAnimationFrame(loop);
}

requestAnimationFrame(loop);
