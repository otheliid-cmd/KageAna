# IDEAS.md — Parked Mechanics & Post-Gate Ideas

> Per Section 1.3 #15 of the World Book (*Kitab Dunia*) and Gelombang D instructions, features and ideas outside the active task (`Butir 1–9`) are recorded here rather than built prematurely.

---

## 1. Retired / Re-scoped Mechanics from v0.7–v2.0

1. **`Kage-Echo` (10-Second Death Replay Shadow Decoy) & Instant `< 1s` Fast Reload:**
   - *Origin:* v2.0 Pillar 3 (`G4`).
   - *Decision (L0):* Removed from core canon because KAGE-ANA v3.0 treats failure and violence as continuous systemic consequences (wounds, debt, social suspicion, or awakening at Kurama Shrine `D4`) rather than arcade stage restarts.
   - *Possible Future Use:* Could be re-imagined post-release as a physical distraction tool (e.g., an *Utsusemi* straw dummy / lantern shadow puppet that projects a moving silhouette on walls without requiring player death) or a dedicated arcade challenge mode.
2. **8-Zone Anatomical Dismemberment & Active Weapon Clash Disarm (`v0.7`):**
   - *Origin:* `legacy/KageAna_v0.7_Legacy_Mechanics_Archive.zip`.
   - *Status:* Archived. Core canon v3.0 uses `Light / Medium / Heavy` wounds (Section 8.6) that leave visible bandages, bloodstains, and medicinal/blood scents detectable by Physician Sōan and guard dogs.

---

## 2. Candidate Ideas for Future Phases (Do Not Build Before Assigned Phase)

- **Seasonal Sake Brewing & Fermentation Odor (Phase F2/F3):** Hiding inside the Kura (`D5`) sake vats masks blood scent from guard dogs but gives the player a strong alcohol smell (`+6` social suspicion if visiting Kurama Shrine or working at Fumie's medicine stall the next morning).
- **Children's Chalk / Ink Drawings on Nagaya Walls (Phase F3/F4):** When rumors about `"Nopperabō"` or `"the rooftop cat"` spread above `strength > 0.6`, Mio and village children draw chalk/charcoal sketches on Nagaya walls, giving the player a diegetic visual readout of local rumor themes before checking the *Papan Tinta*.
- **Interactive Negotiation Mini-Dialogues for Debt Forgiveness or Counter-Accusation (Post-Gerbang 1):** Allowing Sōma to present a verified *Kabar* directly to Ryōta or Jūbei to clear a falsely accused villager (`WrongPerson` misunderstanding chain) or negotiate rent deferral with O-Hana in exchange for specific errands. Parked until Gerbang 1 Pilot playtest confirms baseline story readability.
- **Automated Replay Visualizer for `sesi_*.jsonl` Logs (Post-Gerbang 1):** A developer overlay inside `KageAna.Sandbox` that plays back a tester's `sesi_*.jsonl` path step-by-step on the 2D map to speed up blind scoring after the 5-person anecdote test.


## Ide yang Diparkir pada Gelombang E (Di Luar Cakupan Irisan Vertikal Pertama)
1. **25 Distrik/Tempat di Luar Pasar Kaki Kastil & Nagaya untuk Visual 3D:** Sim tetap menjalankan 12 tempat dan 26 NPC di balik layar, namun pemodelan lingkungan 3D tahap pertama dibatasi pada 1 distrik (*Satu Malam di Kaki Kastil*, 8–10 NPC terlihat) agar kualitas visual E4 tercapai.
2. **Sinkronisasi Bibir Berbasis Fonem Penuh (Non-Amplop) di Android:** Ditunda; pada Android kelas menengah digunakan mode amplop 5 visem (`aa, ih, ou, ee, oh`) demi menjaga anggaran < 2 ms dan 30 fps.
3. **Sulih Suara Penuh untuk Seluruh Percakapan Panjang:** Ditunda demi penghematan biaya produksi; rilis awal memprioritaskan *bark* pendek berbahasa Jepang asli (40–60 baris karakter utama, 10–15 baris NPC) dengan teks Bahasa Indonesia.
