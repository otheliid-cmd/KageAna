; =============================================================================
; KAGE-ANA v0.4.0 [d4f039b3] — Skrip Pemasang Inno Setup (Butir 9.2)
; Judul: Kage-Ana: Sandbox Uji Sistem
; Deskripsi Jujur: Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)
; =============================================================================

#define MyAppName "Kage-Ana: Sandbox Uji Sistem"
#define MyAppHonestSubtitle "Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)"
#define MyAppVersion "0.4.0"
#define MyAppPublisher "Pengembang Kage-Ana (Perorangan)"
#define MyAppExeName "KageAna.Sandbox.exe"
#define MyAppId "{{8F4E2A91-5C3B-4D18-9A72-1E6C8B04F3D2}"

[Setup]
AppId={#MyAppId}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} v{#MyAppVersion} [d4f039b3]
AppPublisher={#MyAppPublisher}
AppComments={#MyAppHonestSubtitle}
DefaultDirName={localappdata}\Programs\KageAna
DefaultGroupName={#MyAppName}
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
UsePreviousAppDir=yes
OutputDir=..\Keluaran
OutputBaseFilename=KageAna_Sandbox_Uji_Setup
SetupIconFile=..\staging\kageana_icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
DisableWelcomePage=no
DisableDirPage=no
DisableProgramGroupPage=yes

[Messages]
WelcomeLabel1=Selamat Datang di Pemasang {#MyAppName}
WelcomeLabel2=Program ini akan memasang {#MyAppHonestSubtitle} (versi {#MyAppVersion}) ke komputer Anda tanpa memerlukan hak Administrator maupun perangkat lunak tambahan.%n%nKlik Berikutnya untuk melanjutkan.
ClickNext=Klik Berikutnya untuk melanjutkan, atau Batal untuk keluar dari pemasang.
ButtonNext=&Berikutnya >
ButtonBack=< &Kembali
ButtonInstall=&Pasang Sekarang
ButtonFinish=&Selesai
ButtonCancel=Batal
FinishedHeadingLabel=Pemasangan {#MyAppName} Selesai
FinishedLabelNoIcons=Aplikasi {#MyAppHonestSubtitle} telah terpasang di komputer Anda.
FinishedLabel=Aplikasi {#MyAppHonestSubtitle} telah siap digunakan. Biarkan kotak centang di bawah tetap terpilih lalu klik Selesai agar aplikasi langsung terbuka.

[Tasks]
Name: "desktopicon"; Description: "Buat pintasan di &Desktop"; GroupDescription: "Pintasan Tambahan:"

[Files]
Source: "..\staging\KageAna.Sandbox.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\staging\CARA_UJI_COBA.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\staging\kageana_icon.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\staging\Jalankan_Sandbox.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\staging\Data\*"; DestDir: "{app}\Data"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{userprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\kageana_icon.ico"; Comment: "{#MyAppHonestSubtitle}"
Name: "{userprograms}\Petunjuk Uji Coba Kage-Ana (1 Halaman)"; Filename: "{app}\CARA_UJI_COBA.md"
Name: "{userdesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; IconFilename: "{app}\kageana_icon.ico"; Tasks: desktopicon; Comment: "{#MyAppHonestSubtitle}"

[Run]
; Halaman terakhir: dicentang secara bawaan untuk mode interaktif
Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; Description: "Jalankan Sandbox Uji Sistem sekarang"; Flags: postinstall nowait skipifsilent
Filename: "{app}\CARA_UJI_COBA.md"; WorkingDir: "{app}"; Description: "Buka petunjuk uji coba (1 halaman)"; Flags: postinstall shellexec skipifsilent
; Mode senyap (/SILENT) langsung menjalankan aplikasi juga
Filename: "{app}\{#MyAppExeName}"; WorkingDir: "{app}"; Flags: nowait; Check: WizardSilent

[UninstallDelete]
Type: filesandordirs; Name: "{app}\Data"

[Code]
procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  SesiDir: String;
begin
  if CurUninstallStep = usPostUninstall then
  begin
    SesiDir := ExpandConstant('{localappdata}\KageAna\Sesi');
    if DirExists(SesiDir) then
    begin
      if MsgBox('Apakah Anda juga ingin menghapus rekaman sesi uji coba Anda di ' + SesiDir + '?' + #13#10 + 'Pilih "Tidak (No)" jika Anda masih ingin menyimpan atau mengirim laporan uji kepada pembuatnya.', mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
      begin
        DelTree(ExpandConstant('{localappdata}\KageAna'), True, True, True);
      end;
    end;
  end;
end;
