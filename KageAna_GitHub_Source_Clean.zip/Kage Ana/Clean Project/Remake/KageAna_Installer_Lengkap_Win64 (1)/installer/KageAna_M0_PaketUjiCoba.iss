; =============================================================================
; KAGE-ANA (影穴) — Skrip Installer Inno Setup 6 (Gelombang C - Kandidat Gerbang 1)
; Penamaan Jujur: "Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)"
; =============================================================================

#define MyAppName "KAGE-ANA — Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)"
#define MyAppVersion "0.3.0-GelombangC-Gerbang1"
#define MyAppPublisher "Proyek KAGE-ANA (Shinonome Souma)"
#define MyStagingDir "..\dist\Paket_Gelombang_C"
#define MyOutputDir "..\dist\Installer"

[Setup]
AppId={{8F4C2B91-3D7A-4E6B-9A15-7C2E5D8104B2}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\KageAna_Sandbox_Uji_Sistem
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir={#MyOutputDir}
OutputBaseFilename=KageAna_Sandbox_Uji_Sistem_GelombangC_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Buat pintasan di Desktop untuk Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)"; GroupDescription: "Pintasan Tambahan:"

[Files]
Source: "{#MyStagingDir}\sim_cli\*"; DestDir: "{app}\sim_cli"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#MyStagingDir}\sandbox\*"; DestDir: "{app}\sandbox"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#MyStagingDir}\Data\*"; DestDir: "{app}\Data"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#MyStagingDir}\docs\*"; DestDir: "{app}\docs"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#MyStagingDir}\Jalankan_Sandbox.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#MyStagingDir}\sim_report_Gelombang_C.json"; DestDir: "{app}"; Flags: ignoreversion skipifsourcedoesntexist
Source: "{#MyStagingDir}\sim_log.jsonl"; DestDir: "{app}"; Flags: ignoreversion skipifsourcedoesntexist

[Icons]
Name: "{group}\1. Jalankan Sandbox 2D Mode TAHUN"; Filename: "{app}\Jalankan_Sandbox.bat"; WorkingDir: "{app}"
Name: "{group}\2. Baca Panduan Uji Coba (CARA_UJI_COBA.md)"; Filename: "{app}\docs\CARA_UJI_COBA.md"
Name: "{group}\3. Lembar Penilaian Uji Anekdot Gerbang 1 (UJI_ANEKDOT.md)"; Filename: "{app}\docs\UJI_ANEKDOT.md"
Name: "{autodesktop}\KAGE-ANA Sandbox Uji Sistem (2D)"; Filename: "{app}\Jalankan_Sandbox.bat"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\Jalankan_Sandbox.bat"; Description: "Buka Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)"; Flags: nowait postinstall skipifsilent
