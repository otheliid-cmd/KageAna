[Version]
Class=IEXPRESS
SEDVersion=3

[Options]
PackagePurpose=InstallApp
ShowInstallProgramWindow=1
HideExtractAnimation=0
UseLongFileName=1
InsideCompressed=0
CAB_FixedSize=0
CAB_ResvCodeSigning=0
RebootMode=N
InstallPrompt=%InstallPrompt%
DisplayLicense=%DisplayLicense%
FinishMessage=%FinishMessage%
TargetName=%TargetName%
FriendlyName=%FriendlyName%
AppLaunched=%AppLaunched%
PostInstallCmd=%PostInstallCmd%
AdminQuietInstCmd=%AdminQuietInstCmd%
UserQuietInstCmd=%UserQuietInstCmd%
SourceFiles=SourceFiles

[Strings]
InstallPrompt=Apakah Anda ingin memasang dan menjalankan Kage-Ana: Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final) sekarang?
DisplayLicense=
FinishMessage=
TargetName=..\Keluaran\KageAna_Pasang.exe
FriendlyName=Kage-Ana: Sandbox Uji Sistem (v0.4.0)
AppLaunched=cmd.exe /c pasang.cmd
PostInstallCmd=<None>
AdminQuietInstCmd=cmd.exe /c pasang.cmd /SILENT
UserQuietInstCmd=cmd.exe /c pasang.cmd /SILENT
FILE0="KageAna.Sandbox.exe"
FILE1="CARA_UJI_COBA.md"
FILE2="kageana_icon.ico"
FILE3="pasang.cmd"
FILE4="Jalankan_Sandbox.bat"

[SourceFiles]
SourceFiles0=..\staging\

[SourceFiles0]
%FILE0%=
%FILE1%=
%FILE2%=
%FILE3%=
%FILE4%=
