1. Unduh berkas `KageAna_Repo_L1.9.zip` dari lampiran pesan ini ke komputer Windows Anda.
2. Klik kanan `KageAna_Repo_L1.9.zip` lalu pilih **Extract All** (Ekstrak Semua) ke folder mana pun yang mudah ditemukan.
3. Buka folder hasil ekstrak tersebut, lalu klik dua kali **`PASANG_DOTNET.bat`** untuk memeriksa atau memasang .NET 8.
4. Jika .NET 8 baru saja dipasang, **tutup jendela hitam yang terbuka** dan buka kembali folder hasil ekstrak tadi.
5. Klik dua kali **`VERIFIKASI_DOTNET.bat`** dan tunggu hingga proses selesai serta muncul tulisan **COCOK** atau **BERBEDA**.
6. Kirimkan isi berkas **`hasil_verifikasi.txt`** yang otomatis muncul di folder tersebut kembali kepada pembuat.
