#!/usr/bin/env python3
"""
KAGE-ANA v3.0 — Canonical Data, Cross-Reference, Lampiran A (L1.5), Paket M0 (L1.9), Gelombang A (L1.95/L2/L3/Sandbox), & Unity-Safety Validator
Validates:
  1. JSON schemas in docs/schemas/.
  2. All JSON files under unity_project/Assets/_Project/Data/:
     - Places (>= 11 places, 2D map coordinates, connected Place Graph neighbors & travelMinutes > 0).
     - NPCs (>= 12 initial NPCs from Kitab Section 7, non-overlapping 24h schedules, valid place references).
     - Rumor chains (`rumor_chains.json`: >= 3 chains, >= 2 distortions per chain, valid place/NPC/Kabar cross-refs).
     - Gigs (>= 3 distinct approaches, NPC/place references).
     - Weather tuning & 49 LightingPresets.
     - L1.5 Player profile `souma.json` ([ISI-PENGGUNA] fields must use `TEMP_` prefix, starterWaresPool -> wares).
     - L1.5 Rotating Wares `wares.json` (8 categories A.4.1, cross-ref `dagangan -> tempat akses`).
     - L1.5 Kabar `kabar_catalog.json` (A.4.2 schema, cross-ref `kabar -> NPC` & `kabar -> tempat`).
     - L1.5 Group Orders `group_orders.json` & `group_trust.json` (A.3, cross-ref `pesanan -> kabar`, `pesanan -> dagangan/tempat/NPC`).
     - L1.5 True Face `true_face.json` (3 stages `Retak`, `Terbuka`, `Menghilang` & witness costs A.4.3).
  3. L1.9 & Gelombang A Sandbox Architecture:
     - `unity_project/Directory.Build.props` (`<Deterministic>true</Deterministic>`).
     - `unity_project/KageAna.SimCli.csproj` & `unity_project/KageAna.Sandbox.csproj` (`net8.0-windows`, `UseWindowsForms=true`, `SelfContained=true`, linked `Runtime/Sim`).
     - `BANGUN_PAKET.bat`, `Jalankan_Sandbox.bat`, `docs/sim_watch_viewer.html`, `docs/CARA_UJI_COBA.md`.
     - Honest naming guard: must contain `"Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)"` and never use `"game"`, `"playable"`, or `"build final"`.
  4. Unity-Safety (L0.1d):
     - Every non-hidden file and folder in unity_project/Assets/ has a matching .meta file with a unique 32-hex GUID.
     - Zero orphan .meta files without a corresponding asset/folder.
     - All .asmdef files have unique "name" fields and all "references" resolve to an existing .asmdef name.
"""

import argparse
import json
import os
import re
import sys

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

REQUIRED_SCHEMAS = [
    "npc.schema.json",
    "place.schema.json",
    "gig.schema.json",
    "story.schema.json",
    "rumor.schema.json",
    "tuning.schema.json",
    "lighting.schema.json",
    "player_profile.schema.json",
    "wares.schema.json",
    "kabar.schema.json",
    "group_orders.schema.json",
    "true_face.schema.json",
    "clothing.schema.json",
    "salience.schema.json",
]

REQUIRED_12_NPCS = {
    "ohana",
    "okiku",
    "ryota",
    "jubei",
    "jikai",
    "kurobe",
    "tsuru",
    "mio",
    "soan",
    "haruki",
    "sabu",
    "hisame",
    "gensai",
    "kaede",
    "tome",
    "gorou",
    "rin",
    "kojiro",
    "yasu",
    "hanae",
    "daigo",
    "suzu",
    "matsubei",
    "chiyo",
    "kanta",
    "shino",
}

CANONICAL_KITAB_7_1_ROLES = {
    "ohana": ("place_nagaya", "Landlady", "Nagaya", "Kedai Teh"),
    "okiku": ("place_kedai_teh", "Merchant", "Kedai Teh", "Nagaya"),
    "ryota": ("place_barak_gerbang", "Guard", "Penjaga", ""),
    "jubei": ("place_rumah_samurai", "Guard", "Kepala", ""),
    "jikai": ("place_kuil_kecil", "Monk", "Biksu", ""),
    "kurobe": ("place_bengkel_kayu", "Craftsman", "Pandai Besi", ""),
    "soan": ("place_apotek_soan", "Scholar", "Tabib", ""),
    "haruki": ("place_pasar", "Merchant", "Serikat", ""),
    "gensai": ("place_benteng_juru_tulis", "Scholar", "Juru Tulis", ""),
}

VALID_APPROACH_TAGS = {"Quiet", "Social", "Loud", "Clever", "Merciful", "Cruel"}
VALID_SEGMENTS = {"Dawn", "Morning", "Noon", "Afternoon", "Dusk", "Night", "LateNight"}
VALID_WEATHERS = {"Clear", "Cloudy", "Fog", "Rain", "Storm", "Snow", "Windy"}
VALID_SEASONS = {"Spring", "Summer", "Autumn", "Winter"}
VALID_KABAR_SOURCES = {"Saw", "Heard", "Told", "Read", "Inferred"}
TIME_RE = re.compile(r"^([01][0-9]|2[0-3]):([0-5][0-9])$")
GUID_RE = re.compile(r"guid:\s*([0-9a-f]{32})\b")
HEX_COLOR_RE = re.compile(r"^#[0-9A-Fa-f]{6}$")

M0_HONEST_TITLE = "Paket Uji Coba M0 (simulasi + lab)"
SANDBOX_HONEST_TITLE = "Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)"
M0_FORBIDDEN_PATTERNS = [
    (re.compile(r"\bgame\b", re.IGNORECASE), "game"),
    (re.compile(r"\bplayable\b", re.IGNORECASE), "playable"),
    (re.compile(r"\bbuild\s+final\b", re.IGNORECASE), "build final"),
]


def parse_minutes(hhmm: str) -> int:
    m = TIME_RE.match(hhmm)
    if not m:
        raise ValueError(f"Invalid 24h time string: {hhmm}")
    return int(m.group(1)) * 60 + int(m.group(2))


def validate_place_entries(places_list: list, known_places: set, errors: list, source_file: str):
    if len(places_list) < 11:
        errors.append(f"{source_file}: must define >= 11 places in Lembah Kurokawa (found {len(places_list)})")
    for idx, p in enumerate(places_list):
        pid = p.get("id", f"<place_{idx}>")
        for req in ("id", "name", "district", "type", "mapX", "mapY", "neighbors"):
            if req not in p:
                errors.append(f"{source_file} [Place:{pid}]: missing required field '{req}'")
        neighbors = p.get("neighbors", [])
        if not isinstance(neighbors, list) or len(neighbors) == 0:
            errors.append(f"{source_file} [Place:{pid}]: neighbors must be a non-empty list")
            continue
        for nb in neighbors:
            to_id = nb.get("to", "")
            mins = nb.get("travelMinutes", 0)
            if to_id not in known_places:
                errors.append(f"{source_file} [Place:{pid}]: neighbor references unknown place ID '{to_id}'")
            if not isinstance(mins, int) or mins <= 0:
                errors.append(f"{source_file} [Place:{pid}]: neighbor '{to_id}' travelMinutes must be positive integer (found {mins})")


def validate_npc_entry(npc: dict, known_places: set, errors: list, source_file: str):
    npc_id = npc.get("id", "<missing_id>")
    for req in ("id", "displayName", "role", "home", "traits", "speechHabit", "schedule", "secrets"):
        if req not in npc:
            errors.append(f"{source_file} [NPC:{npc_id}]: missing required field '{req}'")
    if npc.get("home") and npc["home"] not in known_places:
        errors.append(f"{source_file} [NPC:{npc_id}]: unknown home place ID '{npc['home']}'")

    if npc_id in CANONICAL_KITAB_7_1_ROLES:
        exp_home, exp_cat, req_kw, forbid_kw = CANONICAL_KITAB_7_1_ROLES[npc_id]
        role_str = str(npc.get("role", ""))
        if npc.get("home") != exp_home:
            errors.append(f"{source_file} [NPC:{npc_id}]: Kitab 7.1 canon violation — home must be '{exp_home}' (found '{npc.get('home')}')")
        if npc.get("roleCategory") != exp_cat:
            errors.append(f"{source_file} [NPC:{npc_id}]: Kitab 7.1 canon violation — roleCategory must be '{exp_cat}' (found '{npc.get('roleCategory')}')")
        if req_kw and req_kw.lower() not in role_str.lower():
            errors.append(f"{source_file} [NPC:{npc_id}]: Kitab 7.1 canon violation — role '{role_str}' must include '{req_kw}'")
        if forbid_kw and forbid_kw.lower() in role_str.lower():
            errors.append(f"{source_file} [NPC:{npc_id}]: Kitab 7.1 canon violation — role '{role_str}' must not include '{forbid_kw}'")

    schedule = npc.get("schedule", [])
    if not isinstance(schedule, list) or len(schedule) == 0:
        errors.append(f"{source_file} [NPC:{npc_id}]: schedule must be a non-empty list")
        return

    intervals = []
    for idx, blk in enumerate(schedule):
        for req in ("from", "to", "activity", "place", "interruptible"):
            if req not in blk:
                errors.append(f"{source_file} [NPC:{npc_id}] block #{idx}: missing '{req}'")
        try:
            t0 = parse_minutes(blk.get("from", ""))
            t1 = parse_minutes(blk.get("to", ""))
            if "condition" not in blk and t1 > t0:
                intervals.append((t0, t1, blk.get("activity", "")))
        except ValueError as exc:
            errors.append(f"{source_file} [NPC:{npc_id}] block #{idx}: {exc}")

        if blk.get("place") and blk["place"] not in known_places:
            errors.append(f"{source_file} [NPC:{npc_id}] block #{idx}: unknown place ID '{blk['place']}'")

    intervals.sort()
    for i in range(len(intervals) - 1):
        if intervals[i][1] > intervals[i + 1][0]:
            errors.append(
                f"{source_file} [NPC:{npc_id}]: overlapping unconditional schedule blocks "
                f"({intervals[i][2]} vs {intervals[i+1][2]})"
            )


def validate_claim_templates(data: dict, errors: list, rel: str):
    tpls = data.get("templates", []) if isinstance(data, dict) else []
    motives = data.get("motives", []) if isinstance(data, dict) else []
    if not isinstance(tpls, list) or len(tpls) < 6:
        errors.append(f"{rel}: must define >= 6 claim templates for A2-1 (found {len(tpls)})")
    for idx, t in enumerate(tpls):
        for req in ("action", "templateId", "templateEn"):
            if req not in t:
                errors.append(f"{rel} [Template:{idx}]: missing '{req}'")
        for slot in ("{subject}", "{place}", "{time}", "{motive}"):
            if slot not in str(t.get("templateId", "")) or slot not in str(t.get("templateEn", "")):
                errors.append(f"{rel} [Template:{t.get('action')}]: templateId and templateEn must contain slot '{slot}'")
    if not isinstance(motives, list) or len(motives) < 5:
        errors.append(f"{rel}: must define >= 5 motives in motive table for A2-1 (found {len(motives)})")


def validate_micro_stories(data: list, known_places: set, known_npcs: set, errors: list, rel: str):
    if not isinstance(data, list) or len(data) < 24:
        errors.append(f"{rel}: must define all 24 conditional Micro-Stories for L7+L8 (found {len(data) if isinstance(data, list) else 0})")
        return
    for idx, st in enumerate(data):
        sid = st.get("id", f"<story_{idx}>")
        tr = st.get("trigger", {})
        cond = str(tr.get("conditionType", ""))
        if not cond or cond in ("fixed_hour", "jam_tetap", "none"):
            errors.append(f"{rel} [Story:{sid}]: trigger.conditionType must be a world-state condition, never empty or fixed_hour (found '{cond}')")
        plc = tr.get("requiredPlaceId", "")
        if plc not in known_places:
            errors.append(f"{rel} [Story:{sid}]: unknown requiredPlaceId '{plc}'")
        for nk in ("primaryNpcId", "secondaryNpcId"):
            nid = tr.get(nk, "")
            if nid not in known_npcs:
                errors.append(f"{rel} [Story:{sid}]: unknown {nk} '{nid}'")
        if not st.get("beats") or not st.get("ripples"):
            errors.append(f"{rel} [Story:{sid}]: must define non-empty beats and ripples")


def validate_festivals_catalog(data: dict, known_places: set, errors: list, rel: str):
    fests = data.get("festivals", []) if isinstance(data, dict) else []
    if not isinstance(fests, list) or len(fests) != 4:
        errors.append(f"{rel}: must define all 4 systemic Festivals for L8 (found {len(fests)})")
        return
    by_id = {f.get("id"): f for f in fests}
    if by_id.get("Obon", {}).get("violenceTabooMultiplier") != 3:
        errors.append(f"{rel}: Obon festival must enforce systemic violenceTabooMultiplier == 3 per Kitab 9.4")
    if not by_id.get("Setsubun", {}).get("masksAndNightGarbLegal"):
        errors.append(f"{rel}: Setsubun festival must enforce masksAndNightGarbLegal == true per Kitab 9.4")
    for f in fests:
        gp = f.get("gatheringPlaceId", "")
        if gp not in known_places:
            errors.append(f"{rel} [Festival:{f.get('id')}]: unknown gatheringPlaceId '{gp}'")


def validate_garments_catalog(data: dict, errors: list, rel: str):
    garments = data.get("garments", []) if isinstance(data, dict) else []
    if not isinstance(garments, list) or len(garments) < 4:
        errors.append(f"{rel}: must define >= 4 garments for L4 (found {len(garments)})")
    for idx, g in enumerate(garments):
        gid = g.get("id", f"<garment_{idx}>")
        phex = str(g.get("primaryHex", "")).upper()
        shex = str(g.get("secondaryHex", "")).upper()
        gname = str(g.get("name", "")).lower()
        if phex == "#000000" or shex == "#000000" or "shozoku hitam" in gname or "hitam total" in gname:
            errors.append(f"{rel} [Garment:{gid}]: pure black shozoku (#000000) is strictly prohibited by Lampiran A.4.4")


def validate_rumor_chains(
    data: dict,
    known_places: set,
    known_npcs: set,
    known_kabars: set,
    errors: list,
    rel: str,
):
    chains = data.get("rumorChains", []) if isinstance(data, dict) else []
    if not isinstance(chains, list) or len(chains) < 3:
        errors.append(f"{rel}: must define >= 3 rumor chains for L3 (found {len(chains)})")
        return
    for idx, c in enumerate(chains):
        cid = c.get("id", f"<chain_{idx}>")
        for req in ("id", "linkedKabarId", "subjectNpcId", "originPlaceId", "originHour", "firstWitnessNpcIds", "claim", "distortions"):
            if req not in c:
                errors.append(f"{rel} [RumorChain:{cid}]: missing required field '{req}'")
        if c.get("linkedKabarId") and c["linkedKabarId"] not in known_kabars:
            errors.append(f"{rel} [RumorChain:{cid}]: linkedKabarId references unknown kabar '{c['linkedKabarId']}'")
        if c.get("subjectNpcId") and c["subjectNpcId"] not in known_npcs:
            errors.append(f"{rel} [RumorChain:{cid}]: subjectNpcId references unknown NPC '{c['subjectNpcId']}'")
        if c.get("originPlaceId") and c["originPlaceId"] not in known_places:
            errors.append(f"{rel} [RumorChain:{cid}]: originPlaceId references unknown place '{c['originPlaceId']}'")
        witnesses = c.get("firstWitnessNpcIds", [])
        if not isinstance(witnesses, list) or len(witnesses) < 2:
            errors.append(f"{rel} [RumorChain:{cid}]: firstWitnessNpcIds must contain >= 2 independent witnesses")
        else:
            for w in witnesses:
                if w not in known_npcs:
                    errors.append(f"{rel} [RumorChain:{cid}]: witness references unknown NPC '{w}'")
        distortions = c.get("distortions", [])
        if not isinstance(distortions, list) or len(distortions) < 2:
            errors.append(f"{rel} [RumorChain:{cid}]: distortions must contain >= 2 progressive distortion strings")


def validate_gig_entry(gig: dict, known_places: set, known_npcs: set, errors: list, source_file: str):
    gid = gig.get("id", "<missing_id>")
    approaches = gig.get("approaches", [])
    if not isinstance(approaches, list) or len(set(approaches)) < 3:
        errors.append(f"{source_file} [Gig:{gid}]: must define >= 3 distinct approaches (found {len(approaches)})")
    for tag in approaches:
        if tag not in VALID_APPROACH_TAGS:
            errors.append(f"{source_file} [Gig:{gid}]: invalid approach tag '{tag}'")
    if not gig.get("rippleTemplates"):
        errors.append(f"{source_file} [Gig:{gid}]: rippleTemplates must not be empty")
    if gig.get("giver") and gig["giver"] not in known_npcs:
        errors.append(f"{source_file} [Gig:{gid}]: unknown giver NPC ID '{gig['giver']}'")
    for loc in gig.get("locations", []):
        if loc not in known_places:
            errors.append(f"{source_file} [Gig:{gid}]: unknown location ID '{loc}'")


def validate_player_profile(data: dict, known_wares: set, errors: list, rel: str):
    if data.get("id") != "souma":
        errors.append(f"{rel}: player profile 'id' must be 'souma'")
    if data.get("familyName") != "Shinonome" or data.get("familyNameKanji") != "東雲":
        errors.append(f"{rel}: protagonist familyName must be 'Shinonome' (東雲)")

    for top_temp in ("givenNameKanji_ISI_PENGGUNA", "affiliatedGroupPublicName_ISI_PENGGUNA"):
        val = data.get(top_temp, "")
        if not isinstance(val, str) or not val.startswith("TEMP_"):
            errors.append(f"{rel}: [ISI-PENGGUNA] field '{top_temp}' must start with 'TEMP_' (found '{val}')")

    backstory = data.get("personalBackstory_ISI_PENGGUNA", {})
    if not isinstance(backstory, dict):
        errors.append(f"{rel}: missing object 'personalBackstory_ISI_PENGGUNA'")
    else:
        for bkey in ("originRegion", "mentor", "motive", "secretFromGroup", "greatestFear", "relationToMuraku"):
            bval = backstory.get(bkey, "")
            if not isinstance(bval, str) or not bval.startswith("TEMP_"):
                errors.append(
                    f"{rel}: [ISI-PENGGUNA] field 'personalBackstory_ISI_PENGGUNA.{bkey}' "
                    f"must start with 'TEMP_' (found '{bval}')"
                )

    palette = data.get("nightGarbPalette", {})
    if not palette.get("prohibitsPureBlackShozoku") or str(palette.get("primaryHex", "")).upper() == "#000000":
        errors.append(f"{rel}: nightGarbPalette must prohibit pure black shozoku (#000000) per Lampiran A.1 #4")

    starter_wares = data.get("starterWaresPool", [])
    if not isinstance(starter_wares, list) or len(starter_wares) < 4:
        errors.append(f"{rel}: starterWaresPool must contain >= 4 ware IDs")
    for wid in starter_wares:
        if wid not in known_wares:
            errors.append(f"{rel}: starterWaresPool references unknown ware ID '{wid}'")


def validate_wares_catalog(data: dict, known_places: set, errors: list, rel: str):
    wares = data.get("wares", []) if isinstance(data, dict) else []
    if not isinstance(wares, list) or len(wares) < 8:
        errors.append(f"{rel}: must define all 8 rotating ware categories from Lampiran A.4.1 (found {len(wares)})")
        return

    for idx, w in enumerate(wares):
        wid = w.get("id", f"<ware_{idx}>")
        for req in (
            "id",
            "categoryName",
            "accessPlaces",
            "sourcePlaces",
            "bonusProfile",
            "characteristicRisk",
            "baseCapitalMon",
            "maxCarryUnits",
            "speedMultiplier",
            "noiseMultiplier",
            "canConcealWeapon",
            "requiresZaLicense",
            "seasonalOnly",
        ):
            if req not in w:
                errors.append(f"{rel} [Ware:{wid}]: missing required field '{req}'")

        access_places = w.get("accessPlaces", [])
        if not isinstance(access_places, list) or len(access_places) == 0:
            errors.append(f"{rel} [Ware:{wid}]: accessPlaces must be a non-empty list")
        for pid in access_places:
            if pid not in known_places:
                errors.append(f"{rel} [Ware:{wid}]: accessPlaces references unknown place ID '{pid}'")

        source_places = w.get("sourcePlaces", [])
        if not isinstance(source_places, list) or len(source_places) == 0:
            errors.append(f"{rel} [Ware:{wid}]: sourcePlaces must be a non-empty list")
        for pid in source_places:
            if pid not in known_places:
                errors.append(f"{rel} [Ware:{wid}]: sourcePlaces references unknown place ID '{pid}'")


def validate_kabar_catalog(data: dict, known_npcs: set, known_places: set, errors: list, rel: str):
    kabars = data.get("kabars", []) if isinstance(data, dict) else []
    if not isinstance(kabars, list) or len(kabars) == 0:
        errors.append(f"{rel}: kabars must be a non-empty list")
        return

    for idx, k in enumerate(kabars):
        kid = k.get("id", f"<kabar_{idx}>")
        for req in (
            "id",
            "subjectType",
            "subjectNpcId",
            "subjectPlaceId",
            "claim",
            "source",
            "reliability",
            "freshnessDays",
            "sensitivity",
            "verifiedBy",
        ):
            if req not in k:
                errors.append(f"{rel} [Kabar:{kid}]: missing required field '{req}'")

        src = k.get("source")
        if src not in VALID_KABAR_SOURCES:
            errors.append(f"{rel} [Kabar:{kid}]: invalid source '{src}' (must be one of {sorted(VALID_KABAR_SOURCES)})")

        rel_val = k.get("reliability", -1)
        if not isinstance(rel_val, (int, float)) or not (0.0 <= rel_val <= 1.0):
            errors.append(f"{rel} [Kabar:{kid}]: reliability out of range [0,1]: {rel_val}")

        sens_val = k.get("sensitivity", -1)
        if not isinstance(sens_val, (int, float)) or not (0.0 <= sens_val <= 1.0):
            errors.append(f"{rel} [Kabar:{kid}]: sensitivity out of range [0,1]: {sens_val}")

        subj_npc = k.get("subjectNpcId")
        if subj_npc and subj_npc not in known_npcs:
            errors.append(f"{rel} [Kabar:{kid}]: subjectNpcId references unknown NPC ID '{subj_npc}'")

        subj_place = k.get("subjectPlaceId")
        if subj_place and subj_place not in known_places:
            errors.append(f"{rel} [Kabar:{kid}]: subjectPlaceId references unknown place ID '{subj_place}'")

        verified_by = k.get("verifiedBy", [])
        if not isinstance(verified_by, list):
            errors.append(f"{rel} [Kabar:{kid}]: verifiedBy must be a list of NPC IDs")
        else:
            for vnpc in verified_by:
                if vnpc not in known_npcs:
                    errors.append(f"{rel} [Kabar:{kid}]: verifiedBy references unknown NPC ID '{vnpc}'")


def validate_group_orders(
    data: dict,
    known_kabars: set,
    known_wares: set,
    known_places: set,
    known_npcs: set,
    errors: list,
    rel: str,
):
    front_name = data.get("groupPublicFrontName_ISI_PENGGUNA", "")
    if not isinstance(front_name, str) or not front_name.startswith("TEMP_"):
        errors.append(f"{rel}: groupPublicFrontName_ISI_PENGGUNA must start with 'TEMP_' (found '{front_name}')")

    orders = data.get("orders", [])
    if not isinstance(orders, list) or len(orders) < 2:
        errors.append(f"{rel}: orders must contain >= 2 weekly group orders per Lampiran A.3")
        return

    for idx, o in enumerate(orders):
        oid = o.get("id", f"<order_{idx}>")
        for req in (
            "id",
            "weekNumber",
            "title",
            "requiredKabarIds",
            "recommendedWareId",
            "deadlineDay",
            "deadDropPlaceId",
            "contactNpcId",
            "rewardCapitalMon",
            "trustGainOnSuccess",
            "trustPenaltyOnFailure",
        ):
            if req not in o:
                errors.append(f"{rel} [GroupOrder:{oid}]: missing required field '{req}'")

        req_kabars = o.get("requiredKabarIds", [])
        if not isinstance(req_kabars, list) or len(req_kabars) == 0:
            errors.append(f"{rel} [GroupOrder:{oid}]: requiredKabarIds must be a non-empty list")
        for kid in req_kabars:
            if kid not in known_kabars:
                errors.append(f"{rel} [GroupOrder:{oid}]: requiredKabarIds references unknown kabar ID '{kid}'")

        rec_ware = o.get("recommendedWareId")
        if rec_ware and rec_ware not in known_wares:
            errors.append(f"{rel} [GroupOrder:{oid}]: recommendedWareId references unknown ware ID '{rec_ware}'")

        dd_place = o.get("deadDropPlaceId")
        if dd_place and dd_place not in known_places:
            errors.append(f"{rel} [GroupOrder:{oid}]: deadDropPlaceId references unknown place ID '{dd_place}'")

        c_npc = o.get("contactNpcId")
        if c_npc and c_npc not in known_npcs:
            errors.append(f"{rel} [GroupOrder:{oid}]: contactNpcId references unknown NPC ID '{c_npc}'")


def validate_group_trust_tuning(data: dict, errors: list, rel: str):
    front = data.get("groupPublicFrontName_ISI_PENGGUNA", "")
    if not isinstance(front, str) or not front.startswith("TEMP_"):
        errors.append(f"{rel}: groupPublicFrontName_ISI_PENGGUNA must start with 'TEMP_'")
    if data.get("minTrust") != 0 or data.get("maxTrust") != 100:
        errors.append(f"{rel}: group trust bounds must be 0..100")


def validate_true_face_tuning(data: dict, errors: list, rel: str):
    stages = data.get("stages", [])
    if not isinstance(stages, list) or len(stages) != 3:
        errors.append(f"{rel}: True Face (Wajah Asli) must define exactly 3 stages (Retak, Terbuka, Menghilang)")
        return
    expected_ids = ["Retak", "Terbuka", "Menghilang"]
    for i, exp_id in enumerate(expected_ids):
        if stages[i].get("id") != exp_id:
            errors.append(f"{rel}: stage #{i+1} id must be '{exp_id}' (found '{stages[i].get('id')}')")
    if stages[0].get("nearbySuspicionDelta") != 8:
        errors.append(f"{rel}: Stage 1 (Retak) nearbySuspicionDelta must be +8 per Lampiran A.4.3")
    wcosts = data.get("witnessCosts", {})
    if wcosts.get("witnessSuspicionSpike") != 35:
        errors.append(f"{rel}: witnessSuspicionSpike must be +35 per Lampiran A.4.3")
    if wcosts.get("spawnedRumorInitialStrength") != 0.7:
        errors.append(f"{rel}: spawnedRumorInitialStrength must be 0.7 per Lampiran A.4.3")
    if wcosts.get("groupTrustDelta") != -10:
        errors.append(f"{rel}: groupTrustDelta must be -10 per Lampiran A.4.3")



def validate_salience_tuning(data: dict, errors: list, rel: str):
    if not isinstance(data, dict):
        errors.append(f"{rel}: salience.json root must be an object")
        return
    for sec in ("weights", "thresholds", "decayPerDay", "actionProfiles"):
        if sec not in data:
            errors.append(f"{rel}: missing required section '{sec}'")
    th = data.get("thresholds", {})
    if float(th.get("routineMaxSalience", 1.0)) >= float(th.get("salientMinSalience", 0.0)):
        errors.append(f"{rel}: routineMaxSalience must be strictly less than salientMinSalience")
    profs = data.get("actionProfiles", [])
    if not isinstance(profs, list) or len(profs) < 15:
        errors.append(f"{rel}: actionProfiles must define >= 15 action salience profiles (found {len(profs) if isinstance(profs, list) else 0})")
    else:
        for idx, pr in enumerate(profs):
            bs = pr.get("baseSalience", -1)
            if not isinstance(bs, (int, float)) or not (0.0 <= bs <= 1.0):
                errors.append(f"{rel} [Profile:{idx}]: baseSalience out of range [0,1]: {bs}")


def validate_uji_anekdot_v2(repo_root: str, errors: list):
    ua_path = os.path.join(repo_root, "docs", "UJI_ANEKDOT.md")
    if os.path.exists(ua_path):
        utxt = open(ua_path, "r", encoding="utf-8").read()
        for req_phrase in (
            "Ceritakan satu kejadian yang kamu ingat",
            "PILOT",
            "Lembar Catatan Kebingungan",
            "Penilaian Buta",
        ):
            if req_phrase not in utxt:
                errors.append(f"Butir 7 Uji Anekdot v2: docs/UJI_ANEKDOT.md missing required section/phrase '{req_phrase}'")


def validate_weather_tuning(data: dict, errors: list, rel: str):
    if "seasons" not in data or not isinstance(data["seasons"], dict):
        errors.append(f"{rel}: missing 'seasons' dictionary")
        return
    for season in VALID_SEASONS:
        if season not in data["seasons"]:
            errors.append(f"{rel}: missing season '{season}' in weather weights")
            continue
        weights = data["seasons"][season]
        if not isinstance(weights, dict) or len(weights) == 0:
            errors.append(f"{rel}: season '{season}' weights must be a non-empty object")
            continue
        total_w = 0.0
        for wtype, wval in weights.items():
            if wtype not in VALID_WEATHERS:
                errors.append(f"{rel}: unknown weather type '{wtype}' in season '{season}'")
            if not isinstance(wval, (int, float)) or wval < 0:
                errors.append(f"{rel}: invalid weight '{wval}' for '{wtype}' in season '{season}'")
            else:
                total_w += wval
        if total_w <= 0:
            errors.append(f"{rel}: total weather weight for '{season}' must be > 0")


def validate_lighting_presets(data, errors: list, rel: str):
    presets = data.get("presets", data) if isinstance(data, dict) else data
    if not isinstance(presets, list) or len(presets) == 0:
        errors.append(f"{rel}: lighting presets must be a non-empty list")
        return
    seen_pairs = set()
    for idx, p in enumerate(presets):
        for req in ("id", "segment", "weather", "sunColor", "ambientColor", "fogColor", "fogDensity", "lanternIntensity"):
            if req not in p:
                errors.append(f"{rel} preset #{idx}: missing '{req}'")
        seg = p.get("segment")
        wea = p.get("weather")
        if seg not in VALID_SEGMENTS:
            errors.append(f"{rel} preset #{idx}: invalid segment '{seg}'")
        if wea not in VALID_WEATHERS:
            errors.append(f"{rel} preset #{idx}: invalid weather '{wea}'")
        for col_field in ("sunColor", "ambientColor", "fogColor"):
            val = p.get(col_field, "")
            if not isinstance(val, str) or not HEX_COLOR_RE.match(val):
                errors.append(f"{rel} preset #{idx}: invalid hex color '{val}' in '{col_field}'")
        fog_d = p.get("fogDensity", -1)
        if not isinstance(fog_d, (int, float)) or not (0.0 <= fog_d <= 1.0):
            errors.append(f"{rel} preset #{idx}: fogDensity out of range [0,1]: {fog_d}")
        lant = p.get("lanternIntensity", -1)
        if not isinstance(lant, (int, float)) or not (0.0 <= lant <= 5.0):
            errors.append(f"{rel} preset #{idx}: lanternIntensity out of range [0,5]: {lant}")
        seen_pairs.add((seg, wea))

    for seg in VALID_SEGMENTS:
        for wea in VALID_WEATHERS:
            if (seg, wea) not in seen_pairs:
                errors.append(f"{rel}: missing LightingPreset for ({seg}, {wea})")


def validate_m0_and_sandbox_packages(repo_root: str, errors: list):
    props_path = os.path.join(repo_root, "unity_project", "Directory.Build.props")
    if not os.path.exists(props_path):
        errors.append("L1.95 Package: missing unity_project/Directory.Build.props")
    else:
        ptxt = open(props_path, "r", encoding="utf-8").read()
        for req_prop in (
            "<Deterministic>true</Deterministic>",
            "<BaseIntermediateOutputPath>obj/$(MSBuildProjectName)/</BaseIntermediateOutputPath>",
            "<BaseOutputPath>bin/$(MSBuildProjectName)/</BaseOutputPath>",
        ):
            if req_prop not in ptxt:
                errors.append(f"A2-3 Build: unity_project/Directory.Build.props missing '{req_prop}'")

    simcli_csproj = os.path.join(repo_root, "unity_project", "KageAna.SimCli.csproj")
    if not os.path.exists(simcli_csproj):
        errors.append("L1.9 M0 Package: missing unity_project/KageAna.SimCli.csproj")
    else:
        txt = open(simcli_csproj, "r", encoding="utf-8").read()
        for req_tag in (
            "<AssemblyName>KageAna.SimCli</AssemblyName>",
            "<RuntimeIdentifier>win-x64</RuntimeIdentifier>",
            "<SelfContained>true</SelfContained>",
            'Include="Assets/_Project/Runtime/Sim/**/*.cs"',
        ):
            if req_tag not in txt:
                errors.append(f"L1.9 M0 Package: unity_project/KageAna.SimCli.csproj missing '{req_tag}'")

    sandbox_csproj = os.path.join(repo_root, "unity_project", "KageAna.Sandbox.csproj")
    if not os.path.exists(sandbox_csproj):
        errors.append("Gelombang A Sandbox: missing unity_project/KageAna.Sandbox.csproj")
    else:
        stxt = open(sandbox_csproj, "r", encoding="utf-8").read()
        for req_tag in (
            "<AssemblyName>KageAna.Sandbox</AssemblyName>",
            "<TargetFramework>net8.0-windows</TargetFramework>",
            "<UseWindowsForms>true</UseWindowsForms>",
            "<SelfContained>true</SelfContained>",
            'Include="Assets/_Project/Runtime/Sim/**/*.cs"',
        ):
            if req_tag not in stxt:
                errors.append(f"Gelombang A Sandbox: unity_project/KageAna.Sandbox.csproj missing '{req_tag}'")

    # Check M0 honest naming files
    m0_files = [
        ".github/workflows/build_m0_trial_package.yml",
    ]
    for rel in m0_files:
        fpath = os.path.join(repo_root, rel)
        if not os.path.exists(fpath):
            errors.append(f"L1.9 M0 Package: missing required file '{rel}'")
            continue
        content = open(fpath, "r", encoding="utf-8").read()
        if M0_HONEST_TITLE not in content:
            errors.append(f"L1.9 M0 Package: '{rel}' must contain honest title '{M0_HONEST_TITLE}'")
        for pat, label in M0_FORBIDDEN_PATTERNS:
            if pat.search(content):
                errors.append(f"L1.9 M0 Package: '{rel}' contains prohibited term '{label}' (must not call M0/Sandbox a game, playable, or build final)")

    # Check Gelombang A Sandbox honest naming files
    sandbox_files = [
        "unity_project/Sandbox/SandboxProgram.cs",
        "BANGUN_PAKET.bat",
        "Jalankan_Sandbox.bat",
        "installer/KageAna_M0_PaketUjiCoba.iss",
        "docs/sim_watch_viewer.html",
        "docs/CARA_UJI_COBA.md",
        "docs/UJI_ANEKDOT.md",
    ]
    for rel in sandbox_files:
        fpath = os.path.join(repo_root, rel)
        if not os.path.exists(fpath):
            errors.append(f"Gelombang A Sandbox: missing required file '{rel}'")
            continue
        content = open(fpath, "r", encoding="utf-8").read()
        if SANDBOX_HONEST_TITLE not in content:
            errors.append(f"Gelombang A Sandbox: '{rel}' must contain honest title '{SANDBOX_HONEST_TITLE}'")
        if rel in ("BANGUN_PAKET.bat", "Jalankan_Sandbox.bat", "docs/CARA_UJI_COBA.md", "docs/UJI_ANEKDOT.md", "unity_project/Sandbox/SandboxProgram.cs"):
            for pat, label in M0_FORBIDDEN_PATTERNS:
                if pat.search(content):
                    errors.append(f"Gelombang A Sandbox: '{rel}' contains prohibited term '{label}'")

    bangun_path = os.path.join(repo_root, "BANGUN_PAKET.bat")
    if os.path.exists(bangun_path):
        btxt = open(bangun_path, "r", encoding="utf-8").read()
        for req_b in ("STATUS AKHIR: BERHASIL", "STATUS AKHIR: SEBAGIAN", "KageAna.SimCli.exe", "KageAna.Sandbox.exe"):
            if req_b not in btxt:
                errors.append(f"A2-3 Build: BANGUN_PAKET.bat missing required token '{req_b}'")

    adapter_path = os.path.join(repo_root, "unity_project", "Adapter", "SimJsonDataLoader.cs")
    if not os.path.exists(adapter_path):
        errors.append("A2-2 Adapter: missing unity_project/Adapter/SimJsonDataLoader.cs")
    else:
        atxt = open(adapter_path, "r", encoding="utf-8").read()
        if "System.Text.Json" not in atxt:
            errors.append("A2-2 Adapter: SimJsonDataLoader.cs must use System.Text.Json")



def validate_e1_sim_portability_and_e2_no_hardcoded_npcs(repo_root: str, canonical_npc_ids: set, errors: list):
    sim_csproj = os.path.join(repo_root, "unity_project", "KageAna.Sim.csproj")
    if not os.path.exists(sim_csproj):
        errors.append("E1.2 Sim Portability: missing unity_project/KageAna.Sim.csproj")
    else:
        ctxt = open(sim_csproj, "r", encoding="utf-8").read()
        if "netstandard2.1" not in ctxt:
            errors.append("E1.2 Sim Portability: KageAna.Sim.csproj must target netstandard2.1")
        if "<LangVersion>9" not in ctxt:
            errors.append("E1.2 Sim Portability: KageAna.Sim.csproj must specify LangVersion 9")

    isim_file = os.path.join(repo_root, "unity_project", "Assets", "_Project", "Runtime", "Sim", "ISimDataSource.cs")
    if not os.path.exists(isim_file):
        errors.append("E1.2 Sim Portability: missing Runtime/Sim/ISimDataSource.cs")

    unity_loader = os.path.join(repo_root, "unity_project", "Adapter", "UnitySimDataLoader.cs")
    if not os.path.exists(unity_loader):
        errors.append("E1.2 Sim Portability: missing unity_project/Adapter/UnitySimDataLoader.cs")
    else:
        utxt = re.sub(r"//.*", "", open(unity_loader, "r", encoding="utf-8").read())
        if "System.Text.Json" in utxt:
            errors.append("E1.2 Sim Portability: UnitySimDataLoader.cs must NOT use System.Text.Json")

    forbidden_sim_tokens = [
        "System.Text.Json",
        "UnityEngine",
        "System.Drawing",
        "System.Windows.Forms",
        "record struct",
    ]
    all_npc_ids = sorted(set(canonical_npc_ids) | REQUIRED_12_NPCS)
    npc_literal_re = re.compile(r'"(?:npc_)?(' + "|".join(re.escape(x) for x in all_npc_ids) + r')"', re.IGNORECASE)

    sim_dir = os.path.join(repo_root, "unity_project", "Assets", "_Project", "Runtime", "Sim")
    for r, _dirs, files in os.walk(sim_dir):
        for fname in sorted(files):
            if not fname.endswith(".cs"):
                continue
            fpath = os.path.join(r, fname)
            rel = os.path.relpath(fpath, repo_root)
            raw_code = open(fpath, "r", encoding="utf-8").read()
            code = re.sub(r"/\*.*?\*/", "", raw_code, flags=re.DOTALL)
            code = re.sub(r"//.*", "", code)
            for ftok in forbidden_sim_tokens:
                if ftok in code:
                    errors.append(f"E1.2 Sim Portability Violation: {rel} contains forbidden token '{ftok}'")
            m = npc_literal_re.search(code)
            if m:
                errors.append(f"E2.2 Hardcoded NPC ID Violation: {rel} contains literal NPC ID {m.group(0)}")


def validate_unity_safety(repo_root: str, errors: list) -> tuple:
    assets_dir = os.path.join(repo_root, "unity_project", "Assets")
    guids = {}
    meta_count = 0
    asmdef_names = {}
    asmdef_refs = []

    for root, dirs, files in os.walk(assets_dir):
        for d in sorted(dirs):
            if d.startswith("."):
                continue
            dpath = os.path.join(root, d)
            mpath = dpath + ".meta"
            rel = os.path.relpath(dpath, repo_root)
            if not os.path.exists(mpath):
                errors.append(f"Unity-Safety: folder missing .meta file: {rel}")
        for fname in sorted(files):
            if fname.startswith("."):
                continue
            fpath = os.path.join(root, fname)
            rel = os.path.relpath(fpath, repo_root)
            if fname.endswith(".meta"):
                meta_count += 1
                target = fpath[:-5]
                if not os.path.exists(target):
                    errors.append(f"Unity-Safety: orphan .meta file without target asset: {rel}")
                txt = open(fpath, "r", encoding="utf-8", errors="ignore").read()
                m = GUID_RE.search(txt)
                if not m:
                    errors.append(f"Unity-Safety: .meta file missing 32-hex guid: {rel}")
                else:
                    g = m.group(1)
                    if g in guids:
                        errors.append(f"Unity-Safety: duplicate GUID {g} in {rel} and {guids[g]}")
                    guids[g] = rel
            else:
                if not os.path.exists(fpath + ".meta"):
                    errors.append(f"Unity-Safety: asset missing .meta file: {rel}")
                if fname.endswith(".asmdef"):
                    try:
                        acfg = json.load(open(fpath, "r", encoding="utf-8"))
                        aname = acfg.get("name")
                        if not aname:
                            errors.append(f"Unity-Safety: .asmdef missing 'name': {rel}")
                        elif aname in asmdef_names:
                            errors.append(f"Unity-Safety: duplicate .asmdef name '{aname}' in {rel} and {asmdef_names[aname]}")
                        else:
                            asmdef_names[aname] = rel
                        for ref in acfg.get("references", []):
                            asmdef_refs.append((rel, aname, ref))
                    except Exception as exc:
                        errors.append(f"Unity-Safety: invalid JSON in .asmdef {rel}: {exc}")

    for rel, aname, ref in asmdef_refs:
        if ref not in asmdef_names:
            errors.append(f"Unity-Safety: .asmdef '{aname}' ({rel}) references unknown assembly '{ref}'")

    return meta_count, len(asmdef_names)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=REPO_ROOT)
    args = parser.parse_args()

    repo_root = os.path.abspath(args.repo_root)
    schemas_dir = os.path.join(repo_root, "docs", "schemas")
    data_dir = os.path.join(repo_root, "unity_project", "Assets", "_Project", "Data")

    errors = []
    checked_files = 0

    for sname in REQUIRED_SCHEMAS:
        spath = os.path.join(schemas_dir, sname)
        if not os.path.exists(spath):
            errors.append(f"Missing required schema file: docs/schemas/{sname}")
            continue
        try:
            with open(spath, "r", encoding="utf-8") as f:
                sdoc = json.load(f)
            if "$schema" not in sdoc or "properties" not in sdoc:
                errors.append(f"Schema docs/schemas/{sname} missing $schema or properties")
            checked_files += 1
        except Exception as exc:
            errors.append(f"Invalid JSON in schema docs/schemas/{sname}: {exc}")

    known_places = set()
    known_npcs = set()
    canonical_npc_ids = set()
    known_wares = set()
    known_kabars = set()

    domain_places_docs = []
    domain_npcs = []
    domain_rumor_chains_docs = []
    domain_gigs = []
    domain_player_profiles = []
    domain_wares_docs = []
    domain_kabar_docs = []
    domain_group_order_docs = []
    domain_story_docs = []
    domain_festival_docs = []

    for root, _dirs, files in os.walk(data_dir):
        for fname in sorted(files):
            if not fname.endswith(".json"):
                continue
            fpath = os.path.join(root, fname)
            rel = os.path.relpath(fpath, repo_root)
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    data = json.load(f)
                checked_files += 1
            except Exception as exc:
                errors.append(f"Invalid JSON syntax in {rel}: {exc}")
                continue

            folder = os.path.basename(root)
            if folder == "places":
                entries = data if isinstance(data, list) else [data]
                domain_places_docs.append((entries, rel))
                for p in entries:
                    if "id" in p:
                        known_places.add(p["id"])
                    else:
                        errors.append(f"{rel}: place entry missing 'id'")
            elif folder == "npcs":
                entries = data if isinstance(data, list) else [data]
                for n in entries:
                    if "id" in n:
                        nid = n["id"]
                        known_npcs.add(nid)
                        canonical_npc_ids.add(nid)
                        known_npcs.add("npc_" + nid)
                    if "legacyAliasId" in n:
                        known_npcs.add(n["legacyAliasId"])
                    domain_npcs.append((n, rel))
            elif folder == "player":
                domain_player_profiles.append((data, rel))
            elif folder == "items" and fname == "wares.json":
                domain_wares_docs.append((data, rel))
                for w in data.get("wares", []):
                    if "id" in w:
                        known_wares.add(w["id"])
            elif folder == "rumors":
                if fname == "kabar_catalog.json":
                    domain_kabar_docs.append((data, rel))
                    for k in data.get("kabars", []):
                        if "id" in k:
                            known_kabars.add(k["id"])
                elif fname == "claim_templates.json":
                    validate_claim_templates(data, errors, rel)
                elif fname == "rumor_chains.json":
                    errors.append(f"A2-1 Violation: hand-authored {rel} must be deleted from Data/rumors/")
            elif folder == "clothing" and fname == "garments.json":
                validate_garments_catalog(data, errors, rel)
            elif folder == "stories" and fname == "micro_stories.json":
                domain_story_docs.append((data, rel))
            elif folder == "festivals" and fname == "kurokawa_festivals.json":
                domain_festival_docs.append((data, rel))
            elif folder == "gigs":
                if fname == "group_orders.json":
                    domain_group_order_docs.append((data, rel))
                else:
                    entries = data if isinstance(data, list) else [data]
                    for g in entries:
                        domain_gigs.append((g, rel))
            elif folder == "tuning":
                if fname == "weather.json":
                    validate_weather_tuning(data, errors, rel)
                elif fname == "group_trust.json":
                    validate_group_trust_tuning(data, errors, rel)
                elif fname == "true_face.json":
                    validate_true_face_tuning(data, errors, rel)
                elif fname == "salience.json":
                    validate_salience_tuning(data, errors, rel)
            elif folder == "lighting":
                validate_lighting_presets(data, errors, rel)
            elif fname == "GameplayConfig.json":
                for sec in ("locomotion", "acoustics", "combat", "ai"):
                    if sec not in data:
                        errors.append(f"{rel}: missing top-level section '{sec}'")
            elif fname == "VerticalSliceLevelData.json":
                for sec in ("bounds", "playerSpawn", "buildings", "lanterns", "npcs"):
                    if sec not in data:
                        errors.append(f"{rel}: missing top-level section '{sec}'")

    sal_explicit = os.path.join(data_dir, "tuning", "salience.json")
    if os.path.exists(sal_explicit):
        try:
            s_doc = json.load(open(sal_explicit, "r", encoding="utf-8"))
            validate_salience_tuning(s_doc, errors, os.path.relpath(sal_explicit, repo_root))
        except Exception as exc:
            errors.append(f"Invalid JSON in {sal_explicit}: {exc}")
    else:
        errors.append("Missing required tuning file: unity_project/Assets/_Project/Data/tuning/salience.json")

    missing_12 = REQUIRED_12_NPCS - canonical_npc_ids
    if missing_12:
        errors.append(f"L2 NPC Catalog: missing required initial NPCs from Kitab Section 7: {sorted(missing_12)}")

    for plist, rel in domain_places_docs:
        validate_place_entries(plist, known_places, errors, rel)
    for npc, rel in domain_npcs:
        validate_npc_entry(npc, known_places, errors, rel)
    for rdoc, rel in domain_rumor_chains_docs:
        validate_rumor_chains(rdoc, known_places, known_npcs, known_kabars, errors, rel)
    for gig, rel in domain_gigs:
        validate_gig_entry(gig, known_places, known_npcs, errors, rel)
    for pprof, rel in domain_player_profiles:
        validate_player_profile(pprof, known_wares, errors, rel)
    for wdoc, rel in domain_wares_docs:
        validate_wares_catalog(wdoc, known_places, errors, rel)
    for kdoc, rel in domain_kabar_docs:
        validate_kabar_catalog(kdoc, known_npcs, known_places, errors, rel)
    for godoc, rel in domain_group_order_docs:
        validate_group_orders(godoc, known_kabars, known_wares, known_places, known_npcs, errors, rel)
    for sdoc, rel in domain_story_docs:
        validate_micro_stories(sdoc, known_places, known_npcs, errors, rel)
    for fdoc, rel in domain_festival_docs:
        validate_festivals_catalog(fdoc, known_places, errors, rel)

    validate_m0_and_sandbox_packages(repo_root, errors)
    validate_e1_sim_portability_and_e2_no_hardcoded_npcs(repo_root, canonical_npc_ids, errors)
    validate_uji_anekdot_v2(repo_root, errors)
    meta_count, asmdef_count = validate_unity_safety(repo_root, errors)

    if errors:
        print(f"[validate_data] FAILED with {len(errors)} error(s):")
        for e in errors:
            print(f"  - {e}")
        return 1

    print(
        f"[validate_data] PASS: {checked_files} JSON files + Gelombang A Sandbox package validated "
        f"(schemas={len(REQUIRED_SCHEMAS)}, places={len(known_places)}, npcs={len(domain_npcs)}, "
        f"rumor_chains={len(domain_rumor_chains_docs)}, wares={len(known_wares)}, kabars={len(known_kabars)}, "
        f"group_orders={len(domain_group_order_docs)}, gigs={len(domain_gigs)}, unity_metas={meta_count}, "
        f"asmdefs={asmdef_count}, sandbox_package=OK, errors=0)."
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
