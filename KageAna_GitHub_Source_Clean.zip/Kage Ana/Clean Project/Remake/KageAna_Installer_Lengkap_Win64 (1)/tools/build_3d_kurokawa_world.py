#!/usr/bin/env python3
"""
Builds the Upgraded 3D WebGL 2.0 Open-World Merchant & Night-Shinobi Sandbox:
  KageAna_Dunia_Lembah_Kurokawa_3D.html
Implementing 100% of the user's new foundational directives:
  1. Sōma as a Normal Everyday Merchant in a Normal Neighborhood:
     - 4 Switchable Merchant Carrying Styles [R]:
       (a) Gerobak Dorong Kayu Beroda (Handcart with rotating wheels & goods)
       (b) Tentengan Keranjang & Bungkusan Kain Furoshiki (Hand-carried bundles)
       (c) Pikulan Bambu Tenbinbō (Shoulder pole with twin chests)
       (d) Ransel Kayu Punggung Seoi-Bako (Back-carried merchant rack)
     - Customers Slowly Approach Sōma on Their Own: Nearby citizens walk up slowly to buy goods,
       naturally opening conversation & intelligence gathering.
     - Smooth, Weighty Merchant Walking: Smooth velocity damping, clear articulated stepping legs/feet,
       and realistic merchant walking pace (cannot sprint like an arcade runner while hauling goods).
  2. Expanded, Livelier 16-Location Valley Map (-420m to +420m) + Camera & Audio:
     - 1.65x wider distance between major landmarks + dozens of intermediate houses, fences, gardens, bridges & trees.
     - 4 New Customer-Rich Places: Taman Bunga Sakura & Kolam Koi, Pemandian Air Panas (Onsen),
       Kompleks Kediaman Warga (Machiya-Dōri), and Anjungan Air Terjun & Kebun Teh Bukit.
     - Selectable 1st-Person & 3rd-Person Camera [C], smooth non-inverted Mouse Look (PointerLock or Drag),
       and smooth Zoom In / Zoom Out (Mouse Wheel & [+]/[-]).
     - Interactive WebAudio Soundtrack (Koto & Shakuhachi BGM + Nature Ambience + Footstep/Cart/Coin/Chime SFX).
     - Strictly NO robotic TTS voices (per user rule: "jangan seperti bot karena itu malah mengganggu").
  3. Colorful & Expressive Characters, Short Dialogues + "BERTANYA" (Ask Questions) System,
     Comrade Representative (Sabu), & Strict Night-Only Stealth Rules:
     - Colorful multi-layered kimono/haori + expressive portrait badges in a compact dialogue bar.
     - Short 1-2 sentence lines + interactive 4-option "BERTANYA" panel ([1] Layani Pembeli, [2] Tanya Kabar Sekitar,
       [3] Tanya Target Misi, [4] Tanya Kebutuhan Warga).
     - Comrade Sabu (Perwakilan Kelompok) gives clear mission briefings on what to investigate or do.
     - Suspicious actions (sneaking, copying secret ledgers, rooftop Kaginawa, Shadow-Meld) are strictly locked
       to Nighttime (18:00-05:00) in realistic non-black camouflage (Nila Malam #1F3A60 / Abu Arang #2A2E35 / Hijau Lumut #243628).
"""
import json
from pathlib import Path

BASE_DATA = Path("/tmp/kageana_work/unity_project/Assets/_Project/Data")
OUT_HTML = Path("/working_dir/c_66e5364d2f871b20/artifacts/file_generation/ttl=63d/output/KageAna_Dunia_Lembah_Kurokawa_3D.html")
COPY_HTML = Path("/tmp/kageana_work/KageAna_Langsung_Main_PC.html")


def load_canonical_bundle():
    raw_places = json.loads((BASE_DATA / "places/kurokawa_places.json").read_text(encoding="utf-8"))
    # Scale out the 12 canonical places by 1.65x so major landmarks are further apart and more interesting to traverse
    places = []
    for p in raw_places:
        p_copy = dict(p)
        p_copy["mapX"] = round(float(p["mapX"]) * 1.65)
        p_copy["mapY"] = round(float(p["mapY"]) * 1.65)
        places.append(p_copy)

    # Add 4 New Lively Customer-Gathering Places (Park, Tourist Onsen, Residential Neighborhood, Scenic Waterfall Tea Garden)
    extra_places = [
        {
            "id": "place_taman_sakura",
            "name": "Taman Bunga Sakura & Kolam Koi",
            "district": "D2B",
            "districtName": "TamanKota",
            "type": "outdoor",
            "mapX": -78,
            "mapY": -45,
            "witnessDensity": 0.86,
            "lightProfile": "DayBright_NightLantern",
            "isIndoorShelter": False,
            "anchors": ["koi_bridge", "sakura_gazebo", "park_bench"],
            "tags": ["park", "scenic", "customers"],
            "neighbors": [
                {"to": "place_pasar", "travelMinutes": 6, "routeType": "jalan_utama"},
                {"to": "place_kedai_teh", "travelMinutes": 5, "routeType": "jalan_utama"},
                {"to": "place_kediaman_warga", "travelMinutes": 7, "routeType": "jalan_utama"},
            ],
        },
        {
            "id": "place_kediaman_warga",
            "name": "Kompleks Kediaman Warga & Saudagar (Machiya-Dōri)",
            "district": "D3B",
            "districtName": "KediamanWarga",
            "type": "outdoor",
            "mapX": -195,
            "mapY": -135,
            "witnessDensity": 0.82,
            "lightProfile": "WarmInteriorShoji",
            "isIndoorShelter": True,
            "anchors": ["machiya_courtyard", "well_plaza", "laundry_lane"],
            "tags": ["residential", "families", "customers"],
            "neighbors": [
                {"to": "place_nagaya", "travelMinutes": 7, "routeType": "jalan_utama"},
                {"to": "place_taman_sakura", "travelMinutes": 7, "routeType": "jalan_utama"},
                {"to": "place_barak_gerbang", "travelMinutes": 10, "routeType": "jalan_utama"},
            ],
        },
        {
            "id": "place_pemandian_onsen",
            "name": "Pemandian Air Panas & Paviliun Wisata (Onsen)",
            "district": "D5B",
            "districtName": "WisataOnsen",
            "type": "outdoor",
            "mapX": 82,
            "mapY": -155,
            "witnessDensity": 0.78,
            "lightProfile": "WarmInteriorShoji",
            "isIndoorShelter": True,
            "anchors": ["onsen_bath", "relax_pavilion", "steam_garden"],
            "tags": ["tourist", "relaxation", "gossip_hub"],
            "neighbors": [
                {"to": "place_pasar", "travelMinutes": 8, "routeType": "jalan_utama"},
                {"to": "place_dermaga", "travelMinutes": 9, "routeType": "jalan_utama"},
                {"to": "place_barak_gerbang", "travelMinutes": 10, "routeType": "jalan_utama"},
            ],
        },
        {
            "id": "place_kebun_teh_air_terjun",
            "name": "Anjungan Wisata Air Terjun & Kebun Teh Bukit",
            "district": "D8B",
            "districtName": "WisataBukit",
            "type": "outdoor",
            "mapX": -45,
            "mapY": 215,
            "witnessDensity": 0.64,
            "lightProfile": "StoneLanternSparse",
            "isIndoorShelter": False,
            "anchors": ["waterfall_deck", "tea_terrace", "viewpoint_pavilion"],
            "tags": ["tourist", "scenic", "tea_garden"],
            "neighbors": [
                {"to": "place_kuil_kecil", "travelMinutes": 8, "routeType": "jalan_utama"},
                {"to": "place_apotek_soan", "travelMinutes": 9, "routeType": "jalan_utama"},
                {"to": "place_benteng_juru_tulis", "travelMinutes": 9, "routeType": "jalan_utama"},
            ],
        },
    ]
    places.extend(extra_places)

    npcs = json.loads((BASE_DATA / "npcs/kurokawa_npcs.json").read_text(encoding="utf-8"))
    wares = json.loads((BASE_DATA / "items/wares.json").read_text(encoding="utf-8"))["wares"]
    # Expand ware access places to include the 4 new customer locations
    for w in wares:
        acc = list(w.get("accessPlaces", []))
        for ep in ["place_taman_sakura", "place_kediaman_warga", "place_pemandian_onsen", "place_kebun_teh_air_terjun"]:
            if ep not in acc:
                acc.append(ep)
        w["accessPlaces"] = acc

    kabars = json.loads((BASE_DATA / "rumors/kabar_catalog.json").read_text(encoding="utf-8"))["kabars"]
    orders = json.loads((BASE_DATA / "gigs/group_orders.json").read_text(encoding="utf-8"))["orders"]
    gigs = json.loads((BASE_DATA / "gigs/kurokawa_gigs.json").read_text(encoding="utf-8"))
    festivals = json.loads((BASE_DATA / "festivals/kurokawa_festivals.json").read_text(encoding="utf-8"))["festivals"]
    stories = json.loads((BASE_DATA / "stories/micro_stories.json").read_text(encoding="utf-8"))
    char_bible = json.loads((BASE_DATA / "characters/kurokawa_character_bible.json").read_text(encoding="utf-8"))["characters"]
    souma = json.loads((BASE_DATA / "player/souma.json").read_text(encoding="utf-8"))
    return {
        "places": places,
        "npcs": npcs,
        "wares": wares,
        "kabars": kabars,
        "orders": orders,
        "gigs": gigs,
        "festivals": festivals,
        "stories": stories,
        "charBible": char_bible,
        "souma": souma,
    }


HTML_TEMPLATE = r"""<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>KAGE-ANA (影穴) — Dunia Terbuka 3D Lembah Kurokawa (Pedagang Normal di Siang Hari • Bayangan Realistis di Malam Hari)</title>
<style>
  :root {
    --washi: #F4EFE4;
    --washi-dim: #D8CEB8;
    --sumi: #141822;
    --ai-iro: #27406B;
    --kon: #101624;
    --tsuki: #B9C7D8;
    --andon: #F5B041;
    --kaki: #D2692E;
    --shu: #C8232C;
    --matcha: #7A8B5C;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; }
  html, body {
    width: 100%; height: 100%; overflow: hidden;
    background: var(--kon); color: var(--washi);
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    font-size: 16px;
  }
  #webglCanvas {
    position: fixed; inset: 0; width: 100vw; height: 100vh; display: block;
    cursor: grab;
  }
  #webglCanvas:active { cursor: grabbing; }
  #inkFlashOverlay {
    position: fixed; inset: 0; pointer-events: none; z-index: 6;
    background: radial-gradient(circle, transparent 35%, rgba(16, 22, 36, 0.92) 100%);
    opacity: 0; transition: opacity 0.22s ease-out;
  }

  /* =========================================================================
     PANEL DIALOG SINGKAT & INTERAKTIF "BERTANYA" (Poin 3: Berwarna, Berekspresi,
     Dialog Singkat 1-2 Kalimat, dan Opsi Bertanya Langsung [1-4])
     ========================================================================= */
  #dialogueAskPanel {
    position: fixed; top: 92px; left: 50%; transform: translateX(-50%);
    z-index: 15; pointer-events: auto; display: none;
    background: rgba(16, 22, 36, 0.94);
    border: 1.5px solid rgba(245, 176, 65, 0.75);
    border-left: 6px solid var(--andon);
    border-radius: 8px; padding: 12px 18px;
    width: min(720px, 92vw);
    box-shadow: 0 12px 32px rgba(0,0,0,0.82);
    backdrop-filter: blur(6px);
  }
  .dlg-top {
    display: flex; align-items: center; gap: 14px;
  }
  #dlgPortrait {
    width: 54px; height: 54px; border-radius: 50%;
    border: 2.5px solid var(--andon);
    display: flex; align-items: center; justify-content: center;
    font-size: 28px; flex-shrink: 0;
    background: #27406B;
    box-shadow: 0 4px 12px rgba(0,0,0,0.5);
  }
  .dlg-body { flex: 1; }
  .dlg-header-line {
    display: flex; justify-content: space-between; align-items: center; gap: 8px;
  }
  #dlgSpeakerName {
    font-family: 'Georgia', serif; font-size: 18px; font-weight: 700; color: var(--andon);
  }
  #dlgMoodBadge {
    padding: 2px 9px; border-radius: 4px; font-size: 12.5px; font-weight: 700;
    background: rgba(46, 134, 68, 0.35); border: 1px solid #78E08F; color: #E2F9E1;
  }
  #dlgSpeechText {
    margin-top: 4px; font-size: 15.5px; color: #FFF; line-height: 1.38;
  }
  .ask-btn-row {
    display: flex; gap: 8px; flex-wrap: wrap; margin-top: 10px;
    padding-top: 8px; border-top: 1px solid rgba(239, 230, 210, 0.18);
  }
  .ask-btn {
    background: #1B2C4B; border: 1px solid rgba(245, 176, 65, 0.55);
    color: var(--washi); padding: 6px 11px; border-radius: 5px;
    font-size: 13.5px; font-weight: 600; cursor: pointer;
    display: inline-flex; align-items: center; gap: 5px;
    transition: background 0.15s ease;
  }
  .ask-btn:hover { background: var(--shu); border-color: #FFF; color: #FFF; }
  .ask-btn.buy { background: #244B32; border-color: #78E08F; }
  .ask-btn.buy:hover { background: #2E6340; }

  /* =========================================================================
     4 CLEAN, SPACIOUS HUD ELEMENTS (Zero Overlap, Large Readable Typography)
     ========================================================================= */
  #hudRoot {
    position: fixed; inset: 0; pointer-events: none; z-index: 10;
  }
  .interactive { pointer-events: auto; }
  .washi-panel {
    background: rgba(16, 22, 36, 0.88);
    border: 1.5px solid rgba(239, 230, 210, 0.36);
    border-left: 4px solid var(--shu);
    border-radius: 6px;
    padding: 11px 16px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.68);
    backdrop-filter: blur(4px);
  }

  /* ELEMENT 1 (Top-Left): Hanko Crest + Identity Mode + Clock & Purse */
  #hudTopLeft {
    position: absolute; top: 16px; left: 18px;
    display: flex; align-items: center; gap: 12px;
  }
  .hanko-seal {
    width: 46px; height: 46px; border-radius: 50%;
    border: 2.5px solid var(--shu); background: #0C101A;
    color: var(--washi); display: flex; align-items: center; justify-content: center;
    font-family: 'Georgia', serif; font-weight: 900; font-size: 21px; flex-shrink: 0;
  }
  .tl-info { display: flex; flex-direction: column; gap: 3px; }
  .tl-row1 { display: flex; align-items: center; gap: 8px; }
  .tl-name { font-family: 'Georgia', serif; font-size: 17.5px; font-weight: 700; color: #FFF; }
  .mode-badge {
    padding: 2px 9px; border-radius: 4px; font-size: 12.5px; font-weight: 700;
    background: var(--ai-iro); border: 1px solid var(--andon); color: #FFF;
  }
  .mode-badge.ura { background: #1F3A60; border-color: #78E08F; }
  .tl-row2 {
    display: flex; gap: 14px; font-size: 14.5px; color: var(--washi-dim);
  }
  .tl-row2 strong { color: var(--andon); font-weight: 700; }

  /* ELEMENT 2 (Top-Right): Current Place + Carrier Style + Audio & Map Buttons */
  #hudTopRight {
    position: absolute; top: 16px; right: 18px;
    max-width: 600px;
    display: flex; align-items: center; gap: 10px;
    border-left: none; border-right: 4px solid var(--andon);
  }
  .tr-info { text-align: right; max-width: 370px; overflow: hidden; }
  #hudDistrictTitle {
    font-family: 'Georgia', serif; font-size: 16.5px; font-weight: 700; color: var(--andon);
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  #hudWareCover {
    font-size: 13.5px; color: #B8E994; margin-top: 2px;
  }
  #hudWareCover.warn { color: #FF9F43; }
  .big-hud-btn {
    background: #1F3356; border: 1.5px solid var(--andon);
    color: var(--washi); padding: 8px 12px; border-radius: 5px;
    font-size: 14px; font-weight: 700; cursor: pointer;
    display: inline-flex; align-items: center; gap: 5px;
  }
  .big-hud-btn:hover, .big-hud-btn.active {
    background: var(--shu); color: #FFF;
  }

  /* ELEMENT 3 (Bottom-Left): Positioned cleanly at bottom: 72px; left: 18px */
  #hudBottomLeft {
    position: absolute; bottom: 72px; left: 18px;
    width: 375px;
    display: flex; flex-direction: column; gap: 4px;
    padding: 9px 14px;
  }
  .sensor-line {
    display: flex; justify-content: space-between; align-items: center;
    font-size: 13.5px; gap: 8px; white-space: nowrap;
  }
  .alert-pill {
    padding: 2px 8px; border-radius: 4px; font-size: 12px; font-weight: 700;
    background: rgba(39, 64, 107, 0.55); border: 1px solid var(--tsuki); color: #FFF;
  }

  /* ELEMENT 4 (Bottom Full-Width Bar): Contextual Prompt + Action Pills */
  #hudBottomCenter {
    position: absolute; bottom: 12px; left: 18px; right: 18px;
    display: flex; flex-direction: column; align-items: flex-end; gap: 6px;
  }
  #actionPromptBar {
    background: rgba(16, 22, 36, 0.94);
    border: 1.5px solid var(--andon);
    border-radius: 6px; padding: 7px 16px;
    font-size: 14.5px; font-weight: 600; color: #FFF;
    max-width: 100%; overflow: hidden; text-overflow: ellipsis;
    white-space: nowrap; box-shadow: 0 6px 20px rgba(0,0,0,0.75);
  }
  .hud-pill-bar {
    display: flex; gap: 6px; flex-wrap: nowrap; justify-content: flex-end; width: 100%;
  }
  .pill-btn {
    background: rgba(20, 29, 51, 0.92);
    border: 1px solid rgba(239, 230, 210, 0.45);
    color: var(--washi); padding: 6px 10px; border-radius: 5px;
    font-size: 13px; font-weight: 600; cursor: pointer;
    display: inline-flex; align-items: center; gap: 4px; white-space: nowrap;
  }
  .pill-btn:hover, .pill-btn.primary {
    background: var(--shu); border-color: var(--andon); color: #FFF;
  }
  .k-tag {
    background: rgba(0,0,0,0.5); padding: 1px 5px; border-radius: 3px;
    font-family: monospace; font-size: 12.5px; color: var(--andon);
  }

  /* Toast Banner for Brief Notifications */
  #toastBanner {
    position: fixed; bottom: 148px; left: 50%; transform: translateX(-50%);
    z-index: 25; pointer-events: none; opacity: 0;
    transition: opacity 0.25s ease;
    background: rgba(20, 29, 51, 0.96); border: 2px solid var(--andon);
    color: #FFF; padding: 9px 22px; border-radius: 6px;
    font-size: 16px; font-weight: 700; text-align: center;
    box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  }

  /* Full-Screen Modal Drawers */
  .drawer-modal {
    position: fixed; inset: 0; background: rgba(10, 14, 24, 0.88);
    z-index: 50; display: none; align-items: center; justify-content: center;
    padding: 22px; pointer-events: auto;
  }
  .drawer-card {
    width: min(980px, 94vw); max-height: 86vh; overflow-y: auto;
    background: #141C30; border: 2px solid var(--andon);
    border-radius: 8px; padding: 22px 26px;
    box-shadow: 0 24px 64px rgba(0,0,0,0.92);
  }
  .drawer-header {
    display: flex; justify-content: space-between; align-items: center;
    border-bottom: 1.5px solid rgba(239, 230, 210, 0.25);
    padding-bottom: 12px; margin-bottom: 16px;
  }
  .drawer-header h2 {
    font-family: 'Georgia', serif; font-size: 22px; color: var(--andon);
  }
  .drawer-desc {
    font-size: 15.5px; color: var(--washi-dim); line-height: 1.45; margin-bottom: 16px;
  }
  .card-grid {
    display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 12px;
  }
  .item-card {
    background: rgba(10, 15, 28, 0.85);
    border: 1.5px solid rgba(239, 230, 210, 0.25);
    border-left: 5px solid var(--ai-iro);
    border-radius: 6px; padding: 14px 16px; margin-bottom: 10px;
  }
  .item-card.verified { border-left-color: #78E08F; }
  .item-card.urgent { border-left-color: var(--shu); }
  .item-card h3 { font-size: 17px; color: #FFF; margin-bottom: 5px; }
  .item-card p { font-size: 14.5px; color: var(--washi-dim); line-height: 1.42; }
  .badge {
    display: inline-block; padding: 3px 9px; border-radius: 4px;
    font-size: 12.5px; font-weight: 700; margin-right: 6px; margin-bottom: 5px;
    background: rgba(39, 64, 107, 0.65); color: var(--washi);
  }
  .badge.ok { background: rgba(46, 134, 68, 0.7); color: #E2F9E1; }
  .badge.alert { background: rgba(200, 35, 44, 0.7); color: #FFD6D0; }

  #mapCanvasLarge {
    width: 100%; height: 320px; background: #0B101D;
    border: 1.5px solid rgba(239, 230, 210, 0.35); border-radius: 6px;
    display: block; margin-bottom: 14px; cursor: pointer;
  }
</style>
</head>
<body>
  <canvas id="webglCanvas"></canvas>
  <div id="inkFlashOverlay"></div>

  <!-- PANEL INTERAKTIF "BERTANYA" & TRANSAKSI PEMBELI (Poin 1 & Poin 3) -->
  <div id="dialogueAskPanel">
    <div class="dlg-top">
      <div id="dlgPortrait">😊</div>
      <div class="dlg-body">
        <div class="dlg-header-line">
          <span id="dlgSpeakerName">O-Kiku — Pemilik Kedai Teh</span>
          <span id="dlgMoodBadge">😊 Pembeli Menghampiri</span>
        </div>
        <div id="dlgSpeechText">"Sōma-san, kebetulan lewat! Boleh saya beli daganganmu sekalian berbincang sebentar?"</div>
      </div>
    </div>
    <div class="ask-btn-row">
      <button class="ask-btn buy" onclick="window.KAGE_WORLD.askCustomerOption(1)">
        <span class="k-tag">1</span> 🧺 Layani Pembeli (+Mon)
      </button>
      <button class="ask-btn" onclick="window.KAGE_WORLD.askCustomerOption(2)">
        <span class="k-tag">2</span> 💬 Tanya Kabar Sekitar
      </button>
      <button class="ask-btn" onclick="window.KAGE_WORLD.askCustomerOption(3)">
        <span class="k-tag">3</span> 🔍 Tanya Petunjuk Misi Sabu
      </button>
      <button class="ask-btn" onclick="window.KAGE_WORLD.askCustomerOption(4)">
        <span class="k-tag">4</span> 🤝 Tanya Kebutuhan Warga
      </button>
    </div>
  </div>

  <div id="toastBanner"></div>

  <!-- 4 CLEAN HUD ELEMENTS -->
  <div id="hudRoot">
    <!-- 1. Top-Left: Hanko Seal + Sōma Identity, Time & Mon -->
    <div id="hudTopLeft" class="washi-panel interactive">
      <div id="hankoSeal" class="hanko-seal" title="Lambang Peran Sōma">商</div>
      <div class="tl-info">
        <div class="tl-row1">
          <span class="tl-name">Shinonome Sōma</span>
          <span id="badgeMode" class="mode-badge">SIANG • PEDAGANG NORMAL</span>
        </div>
        <div class="tl-row2">
          <span id="txtClock">Hari 1 • 09:00 (Siang)</span>
          <span>Kas: <strong id="txtMon">180 mon</strong></span>
          <span>Misi Sabu: <strong id="txtTrust">Aktif (65)</strong></span>
        </div>
      </div>
    </div>

    <!-- 2. Top-Right: Current Place + Carrier Style + Audio & Map Buttons -->
    <div id="hudTopRight" class="washi-panel interactive">
      <div class="tr-info">
        <div id="hudDistrictTitle">🌸 Taman Bunga Sakura &amp; Kolam Koi</div>
        <div id="hudWareCover">🛒 Bawaan: Gerobak Dorong Kayu • Obat &amp; ramuan (8)</div>
      </div>
      <button id="btnAudioToggle" class="big-hud-btn active" onclick="window.KAGE_WORLD.toggleAudio()" title="Nyalakan/Matikan Soundtrack, BGM & Sound Effect">
        🔊 BGM &amp; SFX
      </button>
      <button class="big-hud-btn" onclick="window.KAGE_WORLD.openDrawer('map')">
        <span class="k-tag">M</span> Peta 16 Lokasi
      </button>
    </div>

    <!-- 3. Bottom-Left: Camera & Zoom Controls + Stealth/Walk Status -->
    <div id="hudBottomLeft" class="washi-panel interactive">
      <div class="sensor-line">
        <span id="txtWalkState">🚶 Langkah Pedagang Normal (Bawa Gerobak)</span>
        <span id="badgeAlert" class="alert-pill">WARGA AKRAB</span>
      </div>
      <div class="sensor-line" style="color:var(--washi-dim);">
        <span id="txtCameraMode" style="color:var(--andon); cursor:pointer;" onclick="window.KAGE_WORLD.toggleViewMode()">🎥 [C] Kamera 3rd-Person</span>
        <span>🔍 Zoom: <strong style="color:#FFF; cursor:pointer;" onclick="window.KAGE_WORLD.zoomCamera(-2.2)">[+]</strong> / <strong style="color:#FFF; cursor:pointer;" onclick="window.KAGE_WORLD.zoomCamera(2.2)">[-]</strong> (Scroll)</span>
      </div>
    </div>

    <!-- 4. Bottom-Center: Single Contextual Action Bar + Clean Action Pills -->
    <div id="hudBottomCenter" class="interactive">
      <div id="actionPromptBar">
         Pembeli akan menghampiri perlahan • Tekan [1-4] untuk Melayani &amp; BERTANYA • [R] Ganti Gerobak/Tentengan • [C] 1st/3rd Person
      </div>
      <div class="hud-pill-bar">
        <button class="pill-btn primary" onclick="window.KAGE_WORLD.triggerPrimaryAction()">
          <span class="k-tag">E</span> <span id="lblPrimaryBtn">Layani Pembeli / Aksi</span>
        </button>
        <button class="pill-btn" onclick="window.KAGE_WORLD.triggerGatherRumor()">
          <span class="k-tag">F</span> Sapa &amp; Bertanya
        </button>
        <button class="pill-btn" onclick="window.KAGE_WORLD.cycleCarrierStyle()">
          <span class="k-tag">R</span> <span id="lblCarrierBtn">Bawaan: Gerobak</span>
        </button>
        <button class="pill-btn" onclick="window.KAGE_WORLD.openDrawer('wares')">
          <span class="k-tag">X</span> Isi Dagangan
        </button>
        <button class="pill-btn" onclick="window.KAGE_WORLD.openDrawer('inkboard')">
          <span class="k-tag">Tab</span> Catatan Info (<span id="lblKabarCount">0/4</span>)
        </button>
        <button class="pill-btn" onclick="window.KAGE_WORLD.openDrawer('orders')">
          <span class="k-tag">J</span> Misi Kawan (Sabu)
        </button>
        <button class="pill-btn" onclick="window.KAGE_WORLD.advanceTimeHours(6)">
          <span class="k-tag">T</span> Siang ↔ Malam
        </button>
      </div>
    </div>
  </div>

  <!-- DRAWER 1: PETA 16 LOKASI LEMBAH KUROKAWA (Taman, Wisata Onsen, Kediaman, Pasar, Benteng) [M] -->
  <div id="drawer_map" class="drawer-modal">
    <div class="drawer-card">
      <div class="drawer-header">
        <h2>🗺️ PETA 16 LOKASI LEMBAH KUROKAWA (Taman, Tempat Wisata, Kediaman &amp; Distrik)</h2>
        <button class="big-hud-btn" onclick="window.KAGE_WORLD.closeDrawers()">Tutup [Esc]</button>
      </div>
      <p class="drawer-desc">
        Jarak antar tempat penting dibuat lebih berjauhan dengan lingkungan perumahan, taman sakura, pemandian air panas (onsen), dan kebun teh air terjun agar Sōma dapat berkeliling menjumpai berbagai kalangan pembeli secara alami.
      </p>
      <canvas id="mapCanvasLarge" width="900" height="320"></canvas>
      <div id="mapDistrictGrid" class="card-grid"></div>
    </div>
  </div>

  <!-- DRAWER 2: CATATAN INFORMASI & PAPAN TINTA [Tab] -->
  <div id="drawer_inkboard" class="drawer-modal">
    <div class="drawer-card">
      <div class="drawer-header">
        <h2>🖋️ CATATAN INFORMASI SŌMA — Hasil Bertanya ke Pembeli &amp; Penyelidikan Malam</h2>
        <button class="big-hud-btn" onclick="window.KAGE_WORLD.closeDrawers()">Tutup [Esc]</button>
      </div>
      <p class="drawer-desc">
        Di siang hari, kumpulkan informasi dengan <strong>BERTANYA (`[F]` lalu pilih `[2]` atau `[3]`)</strong> saat melayani pembeli yang menghampiri. Di malam hari (`18:00–05:00`), gunakan pakaian samaran malam untuk memeriksa bukti fisik, lalu laporkan ke kawanmu <strong>Sabu</strong>.
      </p>
      <div id="inkboardList"></div>
    </div>
  </div>

  <!-- DRAWER 3: GAYA BAWAAN (GEROBAK / TENTENGAN / PIKULAN / RANSEL) & 8 BARANG DAGANGAN [X] -->
  <div id="drawer_wares" class="drawer-modal">
    <div class="drawer-card">
      <div class="drawer-header">
        <h2>🛒 GAYA BAWAAN PEDAGANG &amp; 8 BARANG DAGANGAN SŌMA</h2>
        <button class="big-hud-btn" onclick="window.KAGE_WORLD.closeDrawers()">Tutup [Esc]</button>
      </div>
      <div id="carrierStyleSection" style="margin-bottom: 18px;"></div>
      <div id="waresList" class="card-grid"></div>
    </div>
  </div>

  <!-- DRAWER 4: INTERVENSI SALAH PAHAM WARGA [G] -->
  <div id="drawer_intervene" class="drawer-modal">
    <div class="drawer-card">
      <div class="drawer-header">
        <h2>⚖️ BANTU LURUSKAN SALAH PAHAM WARGA</h2>
        <button class="big-hud-btn" onclick="window.KAGE_WORLD.closeDrawers()">Tutup [Esc]</button>
      </div>
      <div id="misunderstandingList"></div>
    </div>
  </div>

  <!-- DRAWER 5: MISI DARI KAWAN PERWAKILAN KELOMPOK (SABU) & PENYAMARAN MALAM [J] -->
  <div id="drawer_orders" class="drawer-modal">
    <div class="drawer-card">
      <div class="drawer-header">
        <h2>🕵️ ARAHAN MISI DARI KAWAN KELOMPOK (SABU) &amp; ATURAN MALAM HARI</h2>
        <button class="big-hud-btn" onclick="window.KAGE_WORLD.closeDrawers()">Tutup [Esc]</button>
      </div>
      <div id="ordersAndNisshiList"></div>
    </div>
  </div>

<script>
window.KUROKAWA_CANONICAL_DATA = __CANONICAL_JSON__;
</script>
<script>
(function() {
  const DATA = window.KUROKAWA_CANONICAL_DATA;
  const canvas = document.getElementById('webglCanvas');
  const gl = canvas.getContext('webgl2', { antialias: true, preserveDrawingBuffer: true }) ||
             canvas.getContext('webgl',  { antialias: true, preserveDrawingBuffer: true });

  // =========================================================================
  // 1. WEBAUDIO PROCEDURAL SOUNDTRACK, BGM & INTERACTIVE SFX ENGINE
  //    (Poin 2: Soundtrack, Music Background, Sound Effect — ZERO Bot TTS!)
  // =========================================================================
  const SoundEngine = {
    ctx: null,
    enabled: true,
    bgmTimer: null,
    stepIdx: 0,
    // Japanese Hirajōshi & Yo Pentatonic Scales (Warm & Authentic)
    dayScale: [261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33, 659.25],
    nightScale: [196.00, 220.00, 233.08, 293.66, 311.13, 392.00, 440.00],

    init() {
      if (!this.ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (AC) this.ctx = new AC();
      }
      if (this.ctx && this.ctx.state === 'suspended') {
        try { this.ctx.resume(); } catch (e) {}
      }
      if (!this.bgmTimer) this.startBgmLoop();
    },

    playTone(freq0, freq1, duration, vol, waveType = 'triangle', delay = 0) {
      if (!this.enabled) return;
      this.init();
      if (!this.ctx) return;
      const now = this.ctx.currentTime + delay;
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = waveType;
        osc.frequency.setValueAtTime(freq0, now);
        osc.frequency.exponentialRampToValueAtTime(Math.max(24, freq1), now + duration);
        gain.gain.setValueAtTime(0.0001, now);
        gain.gain.linearRampToValueAtTime(vol, now + Math.min(0.025, duration * 0.25));
        gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(now);
        osc.stop(now + duration + 0.02);
      } catch (e) {}
    },

    startBgmLoop() {
      if (this.bgmTimer) return;
      const loopTick = () => {
        if (this.enabled && this.ctx && !state.manualPoseMode) {
          const s = this.stepIdx++;
          const night = isNightTime();
          if (!night) {
            // Daytime Soundtrack: Warm Koto pluck + gentle Shakuhachi breeze + occasional birdsong
            const n = this.dayScale[(s * 3 + (s % 2)) % this.dayScale.length];
            this.playTone(n, n * 0.998, 0.65, 0.032, 'triangle');
            if (s % 3 === 0) {
              const harm = this.dayScale[(s + 2) % this.dayScale.length] * 0.5;
              this.playTone(harm, harm, 1.1, 0.022, 'sine', 0.12);
            }
            if (s % 7 === 0) {
              // Gentle morning birdsong in park/valley
              this.playTone(1320, 1680, 0.09, 0.015, 'sine', 0.05);
              this.playTone(1680, 1420, 0.11, 0.015, 'sine', 0.16);
            }
          } else {
            // Nighttime Soundtrack: Deep Shakuhachi breath + Suikinkutsu water drop
            if (s % 2 === 0) {
              const n = this.nightScale[s % this.nightScale.length];
              this.playTone(n * 0.98, n, 1.25, 0.028, 'sine');
            }
            if (s % 5 === 0) {
              this.playTone(880, 920, 0.18, 0.018, 'sine', 0.1);
            }
          }
        }
        this.bgmTimer = setTimeout(loopTick, 520);
      };
      loopTick();
    },

    playFootstepAndCart(carrierStyle, isNightUra) {
      if (!this.enabled) return;
      // Soft realistic waraji sandal step
      this.playTone(isNightUra ? 140 : 185, 58, 0.065, isNightUra ? 0.025 : 0.05, 'triangle');
      // If pushing wooden handcart, add subtle wooden axle/wheel creak
      if (!isNightUra && carrierStyle === 'CARRIER_CART') {
        this.playTone(310, 240, 0.08, 0.022, 'sine', 0.03);
      }
    },

    playCoinClink() {
      this.playTone(1560, 1580, 0.11, 0.065, 'sine', 0);
      this.playTone(2120, 2140, 0.16, 0.055, 'sine', 0.07);
    },

    playAskChime() {
      // Subtle traditional wooden hyōshigi / koto chime on dialogue interaction (Never robotic TTS!)
      this.playTone(523.25, 659.25, 0.14, 0.045, 'triangle', 0);
    },

    playNightStealthWhoosh() {
      this.playTone(280, 72, 0.24, 0.08, 'sine', 0);
    }
  };

  // =========================================================================
  // 2. WEBGL 2.0 3D SHADER ENGINE
  // =========================================================================
  const Mat4 = {
    create() { const o = new Float32Array(16); o[0]=1; o[5]=1; o[10]=1; o[15]=1; return o; },
    multiply(out, a, b) {
      const a00=a[0],a01=a[1],a02=a[2],a03=a[3], a10=a[4],a11=a[5],a12=a[6],a13=a[7],
            a20=a[8],a21=a[9],a22=a[10],a23=a[11], a30=a[12],a31=a[13],a32=a[14],a33=a[15];
      for (let i=0;i<4;i++) {
        const b0=b[i*4], b1=b[i*4+1], b2=b[i*4+2], b3=b[i*4+3];
        out[i*4]   = b0*a00 + b1*a10 + b2*a20 + b3*a30;
        out[i*4+1] = b0*a01 + b1*a11 + b2*a21 + b3*a31;
        out[i*4+2] = b0*a02 + b1*a12 + b2*a22 + b3*a32;
        out[i*4+3] = b0*a03 + b1*a13 + b2*a23 + b3*a33;
      }
      return out;
    },
    perspective(out, fovy, aspect, near, far) {
      const f = 1.0 / Math.tan(fovy / 2);
      out.fill(0);
      out[0] = f / aspect; out[5] = f;
      out[10] = (far + near) / (near - far); out[11] = -1;
      out[14] = (2 * far * near) / (near - far);
      return out;
    },
    lookAt(out, eye, center, up) {
      let z0=eye[0]-center[0], z1=eye[1]-center[1], z2=eye[2]-center[2];
      let len=Math.hypot(z0,z1,z2)||1; z0/=len; z1/=len; z2/=len;
      let x0=up[1]*z2-up[2]*z1, x1=up[2]*z0-up[0]*z2, x2=up[0]*z1-up[1]*z0;
      len=Math.hypot(x0,x1,x2)||1; x0/=len; x1/=len; x2/=len;
      const y0=z1*x2-z2*x1, y1=z2*x0-z0*x2, y2=z0*x1-z1*x0;
      out[0]=x0; out[1]=y0; out[2]=z0; out[3]=0;
      out[4]=x1; out[5]=y1; out[6]=z1; out[7]=0;
      out[8]=x2; out[9]=y2; out[10]=z2; out[11]=0;
      out[12]=-(x0*eye[0]+x1*eye[1]+x2*eye[2]);
      out[13]=-(y0*eye[0]+y1*eye[1]+y2*eye[2]);
      out[14]=-(z0*eye[0]+z1*eye[1]+z2*eye[2]);
      out[15]=1; return out;
    },
    fromTRS(out, tx, ty, tz, rx, ry, rz, sx, sy, sz) {
      const cx=Math.cos(rx||0), sxr=Math.sin(rx||0), cy=Math.cos(ry||0), syr=Math.sin(ry||0), cz=Math.cos(rz||0), szr=Math.sin(rz||0);
      out[0]=(cy*cz+syr*sxr*szr)*sx; out[1]=(cx*szr)*sx; out[2]=(-syr*cz+cy*sxr*szr)*sx; out[3]=0;
      out[4]=(syr*sxr*cz-cy*szr)*sy; out[5]=(cx*cz)*sy; out[6]=(cy*sxr*cz+syr*szr)*sy; out[7]=0;
      out[8]=(syr*cx)*sz; out[9]=(-sxr)*sz; out[10]=(cy*cx)*sz; out[11]=0;
      out[12]=tx; out[13]=ty; out[14]=tz; out[15]=1; return out;
    }
  };

  function hexRgb(hex) {
    const clean = (hex || '#EFE6D2').replace('#', '');
    const n = parseInt(clean, 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }

  function compileProgram(vsSrc, fsSrc) {
    const vs = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vs, vsSrc); gl.compileShader(vs);
    const fs = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fs, fsSrc); gl.compileShader(fs);
    const p = gl.createProgram();
    gl.attachShader(p, vs); gl.attachShader(p, fs); gl.linkProgram(p);
    return p;
  }

  const SKY_VS = `
    attribute vec2 aQuadPos;
    varying vec2 vScreenUV;
    void main() {
      vScreenUV = aQuadPos * 0.5 + 0.5;
      gl_Position = vec4(aQuadPos, 0.999, 1.0);
    }
  `;
  const SKY_FS = `
    precision highp float;
    varying vec2 vScreenUV;
    uniform float uCameraYaw;
    uniform float uCameraPitch;
    uniform float uDayFactor;
    uniform int uListenMode;
    void main() {
      if (uListenMode == 1) {
        float fiber = fract(sin(dot(vScreenUV * 420.0, vec2(12.9898, 78.233))) * 43758.5453);
        gl_FragColor = vec4(vec3(0.92, 0.88, 0.79) - vec3(fiber * 0.035), 1.0);
        return;
      }
      float horizon = 0.46 - uCameraPitch * 0.38;
      float yRel = vScreenUV.y - horizon;

      vec3 dayZenith = vec3(0.16, 0.30, 0.52);
      vec3 dayMid    = vec3(0.46, 0.62, 0.78);
      vec3 dayHoriz  = vec3(0.96, 0.90, 0.80);

      vec3 nightZenith = vec3(0.05, 0.08, 0.15);
      vec3 nightMid    = vec3(0.12, 0.19, 0.32);
      vec3 nightHoriz  = vec3(0.38, 0.44, 0.56);

      vec3 zCol = mix(nightZenith, dayZenith, uDayFactor);
      vec3 mCol = mix(nightMid, dayMid, uDayFactor);
      vec3 hCol = mix(nightHoriz, dayHoriz, uDayFactor);

      float t = clamp(yRel * 2.2, 0.0, 1.0);
      vec3 sky = mix(hCol, mCol, smoothstep(0.0, 0.42, t));
      sky = mix(sky, zCol, smoothstep(0.42, 0.95, t));

      vec2 diskPos = vec2(0.62, horizon + 0.27);
      float d = length(vec2((vScreenUV.x - diskPos.x) * 1.77, vScreenUV.y - diskPos.y));
      if (d < 0.062) {
        sky = uDayFactor > 0.5 ? vec3(0.92, 0.32, 0.24) : vec3(0.95, 0.92, 0.84);
      } else if (d < 0.066) {
        sky = vec3(0.08, 0.10, 0.15);
      }

      float wx = vScreenUV.x * 6.5 + uCameraYaw * 1.4;
      float mFar = horizon + 0.044 + sin(wx * 1.3) * 0.038 + cos(wx * 2.9) * 0.018;
      float mMid = horizon + 0.016 + sin(wx * 2.2 + 1.1) * 0.028;
      if (vScreenUV.y < mFar && vScreenUV.y > horizon - 0.06) {
        sky = mix(vec3(0.16, 0.22, 0.33), vec3(0.40, 0.50, 0.62), uDayFactor);
      }
      if (vScreenUV.y < mMid && vScreenUV.y > horizon - 0.06) {
        sky = mix(vec3(0.09, 0.13, 0.21), vec3(0.25, 0.35, 0.44), uDayFactor);
      }
      gl_FragColor = vec4(sky, 1.0);
    }
  `;

  const CEL_VS = `
    attribute vec3 aPosition;
    attribute vec3 aNormal;
    attribute vec2 aUV;
    uniform mat4 uViewProj;
    uniform mat4 uModel;
    varying vec3 vWorldPos;
    varying vec3 vNormal;
    varying vec2 vUV;
    void main() {
      vec4 wp = uModel * vec4(aPosition, 1.0);
      vWorldPos = wp.xyz;
      vNormal = normalize(mat3(uModel[0].xyz, uModel[1].xyz, uModel[2].xyz) * aNormal);
      vUV = aUV;
      gl_Position = uViewProj * wp;
    }
  `;
  const CEL_FS = `
    precision highp float;
    varying vec3 vWorldPos;
    varying vec3 vNormal;
    varying vec2 vUV;
    uniform sampler2D uAlbedoMap;
    uniform vec3 uBaseColor;
    uniform vec3 uLightDir;
    uniform vec3 uLightColor;
    uniform vec3 uAmbientColor;
    uniform vec3 uRimColor;
    uniform vec3 uFogColor;
    uniform float uFogDensity;
    uniform vec3 uCameraPos;
    uniform float uEmissive;
    uniform int uListenMode;
    uniform int uIsCharacter;
    uniform vec3 uLanternPos[8];
    uniform float uLanternIntensity[8];

    void main() {
      float dist = length(vWorldPos - uCameraPos);
      if (uListenMode == 1) {
        if (uIsCharacter == 1 || uEmissive > 0.6) {
          gl_FragColor = vec4(uBaseColor, 1.0);
        } else {
          float hatch = step(0.80, fract((gl_FragCoord.x + gl_FragCoord.y) * 0.14));
          vec3 paper = mix(vec3(0.90, 0.86, 0.76), vec3(0.78, 0.73, 0.63), hatch * 0.35);
          gl_FragColor = vec4(paper, 1.0);
        }
        return;
      }

      vec4 texSample = texture2D(uAlbedoMap, vUV);
      vec3 albedo = texSample.rgb * uBaseColor;

      if (uEmissive > 0.4) {
        gl_FragColor = vec4(clamp(albedo * (1.1 + uEmissive * 0.45), 0.0, 1.0), 1.0);
        return;
      }

      vec3 N = normalize(vNormal);
      vec3 L = normalize(uLightDir);
      vec3 V = normalize(uCameraPos - vWorldPos);
      float ndotl = max(0.0, dot(N, L));

      float celBand = 0.28;
      if (ndotl > 0.50) celBand = 1.08;
      else if (ndotl > 0.18) celBand = 0.76;
      else {
        float hLine = step(0.68, fract((vWorldPos.x + vWorldPos.z) * 3.5));
        celBand = 0.28 + hLine * 0.05;
      }
      if (uIsCharacter == 1) {
        celBand = max(celBand, 0.82);
      }

      vec3 pointLightSum = vec3(0.0);
      for (int i = 0; i < 8; i++) {
        if (uLanternIntensity[i] > 0.01) {
          vec3 toL = uLanternPos[i] - vWorldPos;
          float d = length(toL);
          if (d < 18.0) {
            float att = clamp(1.0 - (d / 18.0), 0.0, 1.0);
            pointLightSum += vec3(0.98, 0.74, 0.30) * (att * att * uLanternIntensity[i] * 1.25);
          }
        }
      }

      float rim = pow(1.0 - max(0.0, dot(N, V)), 3.0);
      vec3 rimContrib = uRimColor * rim * (uIsCharacter == 1 ? 0.72 : 0.18);
      vec3 litColor = albedo * (uAmbientColor + uLightColor * celBand + pointLightSum) + rimContrib;

      float fogFactor = clamp(exp(-pow(dist * uFogDensity, 1.5)), 0.0, 1.0);
      vec3 finalColor = mix(uFogColor, litColor, fogFactor);

      float fiber = sin(gl_FragCoord.x * 1.6) * 0.008 + cos(gl_FragCoord.y * 1.3) * 0.008;
      gl_FragColor = vec4(clamp(finalColor + vec3(fiber), 0.0, 1.0), 1.0);
    }
  `;

  const OUTLINE_VS = `
    attribute vec3 aPosition;
    attribute vec3 aNormal;
    uniform mat4 uViewProj;
    uniform mat4 uModel;
    uniform float uOutlineWidth;
    uniform vec3 uCameraPos;
    void main() {
      vec4 wp = uModel * vec4(aPosition, 1.0);
      vec3 wn = normalize(mat3(uModel[0].xyz, uModel[1].xyz, uModel[2].xyz) * aNormal);
      float dist = length(wp.xyz - uCameraPos);
      float w = uOutlineWidth / (1.0 + dist * 0.025);
      wp.xyz += wn * w;
      gl_Position = uViewProj * wp;
    }
  `;
  const OUTLINE_FS = `
    precision mediump float;
    uniform vec3 uOutlineColor;
    void main() { gl_FragColor = vec4(uOutlineColor, 1.0); }
  `;

  const skyProg = compileProgram(SKY_VS, SKY_FS);
  const celProg = compileProgram(CEL_VS, CEL_FS);
  const outlineProg = compileProgram(OUTLINE_VS, OUTLINE_FS);

  const skyQuadBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, skyQuadBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1,-1, 1,-1, -1,1, -1,1, 1,-1, 1,1]), gl.STATIC_DRAW);

  function createMipTex(size, drawFn) {
    const c = document.createElement('canvas');
    c.width = size; c.height = size;
    drawFn(c.getContext('2d'), size);
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
    gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
    return tex;
  }

  const TEXTURES = {
    wood: createMipTex(512, (ctx, s) => {
      ctx.fillStyle = '#704E34'; ctx.fillRect(0, 0, s, s);
      for (let y = 0; y < s; y += 64) {
        ctx.fillStyle = (y / 64) % 2 === 0 ? '#62422B' : '#7B573B';
        ctx.fillRect(0, y, s, 60);
        ctx.fillStyle = '#1C1B1A'; ctx.fillRect(0, y + 60, s, 4);
      }
    }),
    kawara: createMipTex(512, (ctx, s) => {
      ctx.fillStyle = '#1D2536'; ctx.fillRect(0, 0, s, s);
      for (let x = 0; x < s; x += 64) {
        const g = ctx.createLinearGradient(x, 0, x + 64, 0);
        g.addColorStop(0, '#0F141E'); g.addColorStop(0.5, '#34425C'); g.addColorStop(1, '#0F141E');
        ctx.fillStyle = g; ctx.fillRect(x, 0, 64, s);
      }
      ctx.strokeStyle = '#0B0E16'; ctx.lineWidth = 4;
      for (let y = 0; y < s; y += 64) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(s, y); ctx.stroke(); }
    }),
    shoji: createMipTex(512, (ctx, s) => {
      ctx.fillStyle = '#F3EAD6'; ctx.fillRect(0, 0, s, s);
      ctx.fillStyle = '#422C1D'; ctx.fillRect(0, s * 0.72, s, s * 0.28);
      ctx.fillStyle = '#1C1B1A';
      for (let x = 0; x < s; x += 64) ctx.fillRect(x, 0, 6, s);
      for (let y = 0; y < s * 0.72; y += 48) ctx.fillRect(0, y, s, 5);
    }),
    shojiSilhouette: createMipTex(512, (ctx, s) => {
      const g = ctx.createRadialGradient(s*0.5, s*0.4, 20, s*0.5, s*0.4, s*0.5);
      g.addColorStop(0, '#FFE8A6'); g.addColorStop(1, '#E2C98A');
      ctx.fillStyle = g; ctx.fillRect(0, 0, s, s * 0.72);
      ctx.fillStyle = 'rgba(20, 22, 30, 0.74)';
      ctx.beginPath(); ctx.arc(s * 0.5, s * 0.26, 34, 0, Math.PI * 2); ctx.fill();
      ctx.fillRect(s * 0.36, s * 0.33, s * 0.28, s * 0.38);
      ctx.fillStyle = '#422C1D'; ctx.fillRect(0, s * 0.72, s, s * 0.28);
      ctx.fillStyle = '#1C1B1A';
      for (let x = 0; x < s; x += 64) ctx.fillRect(x, 0, 6, s);
      for (let y = 0; y < s * 0.72; y += 48) ctx.fillRect(0, y, s, 5);
    }),
    stone: createMipTex(512, (ctx, s) => {
      ctx.fillStyle = '#6A7382'; ctx.fillRect(0, 0, s, s);
      for (let r = 0; r < 8; r++) {
        const y = r * 64, off = (r % 2) * 64;
        for (let x = -64; x < s; x += 128) {
          ctx.fillStyle = ((x + r * 31) % 3 === 0) ? '#7A8394' : '#58606E';
          ctx.fillRect(x + off + 3, y + 3, 122, 58);
          ctx.strokeStyle = '#1C2029'; ctx.lineWidth = 4; ctx.strokeRect(x + off + 3, y + 3, 122, 58);
        }
      }
    }),
    ground: createMipTex(512, (ctx, s) => {
      ctx.fillStyle = '#526348'; ctx.fillRect(0, 0, s, s);
      ctx.strokeStyle = 'rgba(28, 38, 24, 0.36)'; ctx.lineWidth = 5;
      for (let i = 0; i < 40; i++) {
        const y = (i * 27) % s;
        ctx.beginPath(); ctx.moveTo(0, y); ctx.bezierCurveTo(s*0.3, y+14, s*0.7, y-14, s, y); ctx.stroke();
      }
    }),
    cloth: createMipTex(512, (ctx, s) => {
      ctx.fillStyle = '#F5EFE0'; ctx.fillRect(0, 0, s, s);
      ctx.strokeStyle = 'rgba(20, 27, 45, 0.20)'; ctx.lineWidth = 3;
      for (let i = 0; i < s; i += 32) {
        ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(s, i); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, s); ctx.stroke();
      }
    })
  };

  class GeoBuf {
    constructor() { this.p=[]; this.n=[]; this.u=[]; this.idx=[]; }
    v(x,y,z,nx,ny,nz,u,v) {
      const i = this.p.length / 3;
      this.p.push(x,y,z); this.n.push(nx,ny,nz); this.u.push(u,v); return i;
    }
    quad(p0,p1,p2,p3,uS=1,vS=1) {
      const ux=p1[0]-p0[0], uy=p1[1]-p0[1], uz=p1[2]-p0[2];
      const vx=p3[0]-p0[0], vy=p3[1]-p0[1], vz=p3[2]-p0[2];
      let nx=uy*vz-uz*vy, ny=uz*vx-ux*vz, nz=ux*vy-uy*vx;
      const l=Math.hypot(nx,ny,nz)||1; nx/=l; ny/=l; nz/=l;
      const i0=this.v(p0[0],p0[1],p0[2],nx,ny,nz,0,0), i1=this.v(p1[0],p1[1],p1[2],nx,ny,nz,uS,0),
            i2=this.v(p2[0],p2[1],p2[2],nx,ny,nz,uS,vS), i3=this.v(p3[0],p3[1],p3[2],nx,ny,nz,0,vS);
      this.idx.push(i0,i1,i2, i0,i2,i3);
    }
    box(cx,cy,cz,w,h,d,uT=1,vT=1) {
      const hx=w*0.5, hy=h*0.5, hz=d*0.5;
      const x0=cx-hx,x1=cx+hx, y0=cy-hy,y1=cy+hy, z0=cz-hz,z1=cz+hz;
      this.quad([x0,y0,z1],[x1,y0,z1],[x1,y1,z1],[x0,y1,z1],uT,vT);
      this.quad([x1,y0,z0],[x0,y0,z0],[x0,y1,z0],[x1,y1,z0],uT,vT);
      this.quad([x1,y0,z1],[x1,y0,z0],[x1,y1,z0],[x1,y1,z1],uT,vT);
      this.quad([x0,y0,z0],[x0,y0,z1],[x0,y1,z1],[x0,y1,z0],uT,vT);
      this.quad([x0,y1,z1],[x1,y1,z1],[x1,y1,z0],[x0,y1,z0],uT,vT);
      this.quad([x0,y0,z0],[x1,y0,z0],[x1,y0,z1],[x0,y0,z1],uT,vT);
    }
    limb(x0,y0,z0,r0,x1,y1,z1,r1,sides=10) {
      const b = this.p.length / 3;
      for (let s=0;s<=sides;s++) {
        const a=(s/sides)*Math.PI*2, ca=Math.cos(a), sa=Math.sin(a);
        this.v(x0+ca*r0,y0,z0+sa*r0,ca,0.15,sa,s/sides,0);
        this.v(x1+ca*r1,y1,z1+sa*r1,ca,0.15,sa,s/sides,1);
      }
      for (let s=0;s<sides;s++) {
        const i=b+s*2; this.idx.push(i,i+2,i+3, i,i+3,i+1);
      }
    }
    ring(inR,outR,segs=24) {
      const b = this.p.length / 3;
      for (let s=0;s<=segs;s++) {
        const a=(s/segs)*Math.PI*2, ca=Math.cos(a), sa=Math.sin(a);
        this.v(ca*inR,0.03,sa*inR,0,1,0,s/segs,0);
        this.v(ca*outR,0.03,sa*outR,0,1,0,s/segs,1);
      }
      for (let s=0;s<segs;s++) {
        const i=b+s*2; this.idx.push(i,i+2,i+3, i,i+3,i+1);
      }
    }
    irimoyaRoof(cx,baseY,cz,w,h,d) {
      const steps=5, hw=w*0.5, hd=d*0.5;
      for (let i=0;i<steps;i++) {
        const t0=i/steps, t1=(i+1)/steps;
        const y0=baseY+h*Math.pow(1-t0,1.4), y1=baseY+h*Math.pow(1-t1,1.4);
        const x0=hw*t0, x1=hw*t1, z0=hd*(0.62+0.38*t0), z1=hd*(0.62+0.38*t1);
        const lift=(t1>0.7)?(t1-0.7)*0.35:0;
        this.quad([cx+x0,y0,cz+z0],[cx+x1,y1+lift,cz+z1],[cx+x1,y1+lift,cz-z1],[cx+x0,y0,cz-z0],3,1);
        this.quad([cx-x0,y0,cz-z0],[cx-x1,y1+lift,cz-z1],[cx-x1,y1+lift,cz+z1],[cx-x0,y0,cz+z0],3,1);
        this.quad([cx-x0,y0,cz+z0],[cx-x1,y1+lift,cz+z1],[cx+x1,y1+lift,cz+z1],[cx+x0,y0,cz+z0],3,1);
        this.quad([cx+x0,y0,cz-z0],[cx+x1,y1+lift,cz-z1],[cx-x1,y1+lift,cz-z1],[cx-x0,y0,cz-z0],3,1);
      }
      this.box(cx,baseY+h+0.12,cz,0.34,0.24,d*0.64,1,2);
    }
    upload() {
      const o = { pBuf:gl.createBuffer(), nBuf:gl.createBuffer(), uBuf:gl.createBuffer(), iBuf:gl.createBuffer(), count:this.idx.length };
      gl.bindBuffer(gl.ARRAY_BUFFER,o.pBuf); gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(this.p),gl.STATIC_DRAW);
      gl.bindBuffer(gl.ARRAY_BUFFER,o.nBuf); gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(this.n),gl.STATIC_DRAW);
      gl.bindBuffer(gl.ARRAY_BUFFER,o.uBuf); gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(this.u),gl.STATIC_DRAW);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,o.iBuf); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(this.idx),gl.STATIC_DRAW);
      return o;
    }
  }

  const MESHES = (() => {
    const b = new GeoBuf(); b.box(0,0,0,1,1,1,1,1);
    const rf = new GeoBuf(); rf.irimoyaRoof(0,0,0,1,1,1);
    const cy = new GeoBuf(); cy.limb(0,-0.5,0,0.5,0,0.5,0,0.5,10);
    const ht = new GeoBuf(); ht.limb(0,0,0,0.58,0,0.28,0,0.04,12);
    const tr = new GeoBuf(); tr.limb(0,0,0,0.65,0,1.0,0,0.06,10);
    const rg = new GeoBuf(); rg.ring(0.82,1.0,24);
    const kt = new GeoBuf();
    kt.box(0,0,-0.10,0.035,0.045,0.26); kt.box(0,0,0.04,0.095,0.095,0.02); kt.box(0,0.01,0.46,0.016,0.04,0.82);
    const gt = new GeoBuf();
    gt.limb(0,0,0,0.23,0,0.58,0,0.28,8); gt.box(-0.32,0.46,0,0.15,0.24,0.32); gt.box(0.32,0.46,0,0.15,0.24,0.32);
    gt.limb(0,-0.24,0,0.29,0,0.02,0,0.23,8);
    const hd = new GeoBuf(); hd.limb(0,-0.14,0,0.11,0,0.14,0,0.12,10);
    // Wooden Wheel Mesh for Sōma's Handcart (Gerobak Dorong Kayu)
    const wh = new GeoBuf();
    wh.limb(-0.06,0,0,0.46, 0.06,0,0,0.46, 12);
    wh.box(0,0,0, 0.14,0.88,0.08);
    wh.box(0,0,0, 0.14,0.08,0.88);
    return {
      box: b.upload(), roof: rf.upload(), cylinder: cy.upload(), hat: ht.upload(),
      cone: tr.upload(), ring: rg.upload(), katana: kt.upload(), torso: gt.upload(),
      head: hd.upload(), wheel: wh.upload()
    };
  })();

  // =========================================================================
  // 3. ASSEMBLE THE EXPANDED 16-LOCATION LEMBAH KUROKAWA 3D WORLD (-480m..+480m)
  //    (Poin 2: Lebih banyak bangunan, taman, tempat wisata, kediaman, & jarak berjauhan)
  // =========================================================================
  const staticScene = [];
  const shadowPools = [];
  const climbZones = [];
  const worldLanterns = [];

  function addStatic(mesh, tex, color, x, y, z, sx, sy, sz, ry = 0, emissive = 0, outlineWidth = 0.022) {
    staticScene.push({ mesh, tex, rgb: hexRgb(color), x, y, z, sx, sy, sz, rx: 0, ry, rz: 0, emissive, outlineWidth, isCharacter: false });
  }

  // Expanded Valley Floor (1050m x 1050m) + Rice Paddies + Winding River
  addStatic('box', 'ground', '#4E5E43', 0, -0.15, 0, 1050, 0.3, 1050, 0, 0, 0);
  addStatic('box', 'ground', '#68824B', -340, 0.02, -160, 110, 0.06, 130, 0, 0, 0);
  addStatic('box', 'ground', '#5E7843', -340, 0.02,  65,  110, 0.06, 130, 0, 0, 0);

  const riverSegs = [
    { x: 190, z: 380, w: 34, d: 140, ry: -0.15 },
    { x: 168, z: 255, w: 34, d: 140, ry: 0.12 },
    { x: 156, z: 132, w: 36, d: 140, ry: 0.05 },
    { x: 156, z: 25,  w: 36, d: 110, ry: -0.22 },
    { x: 210, z: -66, w: 40, d: 140, ry: -0.48 },
    { x: 255, z: -190,w: 44, d: 155, ry: -0.18 },
    { x: 272, z: -330,w: 48, d: 170, ry: 0.0 }
  ];
  riverSegs.forEach(r => {
    addStatic('box', 'kawara', '#245282', r.x, 0.03, r.z, r.w, 0.08, r.d, r.ry, 0.25, 0);
    addStatic('box', 'stone',  '#6E7788', r.x - r.w*0.52, 0.16, r.z, 2.2, 0.32, r.d, r.ry, 0, 0.015);
    addStatic('box', 'stone',  '#6E7788', r.x + r.w*0.52, 0.16, r.z, 2.2, 0.32, r.d, r.ry, 0, 0.015);
  });

  function addMinka(x, z, w, h, d, wallCol, roofCol, hasSil = true, twoFloor = false, climbLabel = null, ry = 0) {
    addStatic('box', 'stone', '#5C6474', x, 0.22, z, w + 0.7, 0.44, d + 0.7, ry);
    addStatic('box', 'wood',  '#6A4B32', x, 0.48, z, w + 1.2, 0.14, d + 1.2, ry);
    addStatic('box', hasSil ? 'shojiSilhouette' : 'shoji', wallCol, x, 0.5 + h*0.5, z, w, h, d, ry, hasSil ? 0.32 : 0.0);
    const roofY = 0.5 + h;
    addStatic('roof', 'kawara', roofCol, x, roofY, z, w + 2.2, 1.45, d + 2.2, ry);
    if (twoFloor) {
      const h2 = h * 0.72;
      addStatic('box', 'shojiSilhouette', '#F3EAD6', x, roofY + 1.3 + h2*0.5, z, w*0.66, h2, d*0.66, ry, 0.38);
      addStatic('roof', 'kawara', roofCol, x, roofY + 1.3 + h2, z, w*0.86, 1.25, d*0.86, ry);
    }
    if (climbLabel) {
      const cz = z - d*0.5 - 0.55;
      addStatic('box', 'cloth', '#F4EFE6', x, roofY - 0.35, cz, 1.3, 0.9, 0.12, ry);
      climbZones.push({ x, z: cz, topY: roofY + 0.4, radius: 22.0, label: climbLabel });
    }
  }

  function addTorii(x, z, span = 8.4, h = 5.4, ry = 0) {
    const hw = span * 0.5;
    const cx = Math.cos(ry), sx = Math.sin(ry);
    addStatic('cylinder', 'wood', '#C8232C', x - hw*cx, h*0.5, z + hw*sx, 0.38, h, 0.38);
    addStatic('cylinder', 'wood', '#C8232C', x + hw*cx, h*0.5, z - hw*sx, 0.38, h, 0.38);
    addStatic('box', 'wood', '#C8232C', x, h - 0.65, z, span + 1.6, 0.26, 0.32, ry);
    addStatic('roof', 'kawara', '#181E2B', x, h, z, span + 2.4, 0.42, 0.85, ry);
  }

  function addTree(x, z, sc = 1.0, col = '#3F633E') {
    addStatic('cylinder', 'wood', '#4D3622', x, 1.8*sc, z, 0.48*sc, 3.6*sc, 0.48*sc);
    addStatic('cone', 'ground', col, x, 3.8*sc, z, 3.3*sc, 2.8*sc, 3.3*sc);
    addStatic('cone', 'ground', col, x, 5.4*sc, z, 2.5*sc, 2.3*sc, 2.5*sc);
  }

  function addLanternAndShadowPool(x, z, idLabel) {
    worldLanterns.push({ id: worldLanterns.length + 1, x, z, lit: true, shiftOffset: 0, label: idLabel });
    const spX = x + (x < 0 ? -4.5 : 4.5), spZ = z + 3.2;
    shadowPools.push({ x: spX, z: spZ, r: 3.4 });
    addStatic('cylinder', 'ground', '#0D121D', spX, 0.03, spZ, 5.0, 0.02, 5.0, 0, 0, 0);
    addStatic('ring', 'shoji', '#27406B', spX, 0.05, spZ, 2.9, 1.0, 2.9, 0, 0.55, 0);
  }

  // Connect all neighboring places with stone/wood roads AND populate roadsides with neighborhood houses & trees!
  const placeMap = {};
  DATA.places.forEach(p => { placeMap[p.id] = p; });
  const drawnRoads = new Set();
  DATA.places.forEach(p => {
    (p.neighbors || []).forEach(nb => {
      const q = placeMap[nb.to];
      if (!q) return;
      const k = [p.id, q.id].sort().join('--');
      if (drawnRoads.has(k)) return;
      drawnRoads.add(k);
      const mx = (p.mapX + q.mapX) * 0.5, mz = (p.mapY + q.mapY) * 0.5;
      const dx = q.mapX - p.mapX, dz = q.mapY - p.mapY;
      const len = Math.hypot(dx, dz), yaw = Math.atan2(dx, dz);
      const isMain = nb.routeType === 'jalan_utama';
      addStatic('box', isMain ? 'stone' : 'wood', isMain ? '#828A98' : '#705C48', mx, 0.04, mz, isMain ? 6.2 : 4.2, 0.08, len, yaw, 0, 0);

      // Populate roadside with intermediate neighborhood homes, trees & lanterns so the map feels alive!
      if (len > 90) {
        const nx = Math.cos(yaw), nz = -Math.sin(yaw);
        addMinka(mx + nx * 13, mz + nz * 13, 7.5, 3.1, 6.8, '#F3EAD6', '#232B3A', true, false, null, yaw);
        addTree(mx - nx * 12, mz - nz * 12, 1.15, '#466B44');
        addTree(mx + nx * 14 + dx * 0.22, mz + nz * 14 + dz * 0.22, 1.2, '#E58A98');
      }
    });
  });

  // Build All 16 Locations (12 Canonical Districts + 4 New Customer/Scenic/Residential Locations)
  DATA.places.forEach(p => {
    const px = p.mapX, pz = p.mapY;
    addStatic('box', 'stone', '#6E7786', px, 0.03, pz, 46, 0.06, 46, 0, 0, 0);
    addLanternAndShadowPool(px - 8.5, pz - 9.5, p.name);
    addLanternAndShadowPool(px + 8.5, pz - 9.5, p.name);

    if (p.id === 'place_taman_sakura') {
      // NEW LOCATION 1: Taman Bunga Sakura & Kolam Koi (Scenic Park with Koi Pond, Red Arched Bridge, Gazebo & Sakura Grove)
      addStatic('box', 'kawara', '#266094', px, 0.05, pz + 2, 22, 0.08, 16, 0, 0.35, 0); // Koi Pond
      addStatic('box', 'wood', '#C8232C', px, 0.85, pz + 2, 5.2, 0.45, 17.5); // Red Bridge over Pond
      addMinka(px - 15, pz + 10, 7.5, 3.0, 7.5, '#F5E4B3', '#5E1F18', true, false, 'Gazebo Taman Sakura');
      addStatic('box', 'cloth', '#C8232C', px + 13, 0.45, pz - 4, 4.2, 0.55, 2.0); // Red Tea Bench
      addStatic('box', 'cloth', '#C8232C', px - 13, 0.45, pz - 4, 4.2, 0.55, 2.0);
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        addTree(px + Math.cos(a) * 18, pz + Math.sin(a) * 16, 1.35, i % 2 === 0 ? '#F294A5' : '#E37B8E');
      }
    } else if (p.id === 'place_kediaman_warga') {
      // NEW LOCATION 2: Kompleks Kediaman Warga & Saudagar (Machiya-Dōri Normal Residential Neighborhood)
      addMinka(px - 14, pz + 11, 10.5, 3.3, 7.5, '#F3EAD6', '#253042', true, true, 'Atap Rumah Saudagar Barat');
      addMinka(px + 14, pz + 11, 10.5, 3.3, 7.5, '#EFE6D2', '#2B3648', true, true, 'Atap Rumah Saudagar Timur');
      addMinka(px - 14, pz - 9,  9.5,  3.1, 6.8, '#E8DEC8', '#382B22', true, false, 'Atap Kediaman Keluarga Barat');
      addMinka(px + 14, pz - 9,  9.5,  3.1, 6.8, '#E8DEC8', '#382B22', true, false, 'Atap Kediaman Keluarga Timur');
      addStatic('cylinder', 'stone', '#687080', px, 0.55, pz, 2.0, 1.1, 2.0); // Neighborhood Well
      addTree(px - 6, pz + 4, 1.2, '#F090A0');
      addTree(px + 6, pz - 4, 1.15, '#4A6E46');
    } else if (p.id === 'place_pemandian_onsen') {
      // NEW LOCATION 3: Pemandian Air Panas & Paviliun Wisata (Onsen)
      addMinka(px, pz + 13, 14.5, 3.8, 9.2, '#F5E4B3', '#5E1F18', true, true, 'Atap Paviliun Utama Onsen');
      addStatic('box', 'kawara', '#3882A8', px - 11, 0.25, pz - 2, 10.0, 0.45, 8.5, 0, 0.5, 0.015); // Outdoor Hot Spring Pool
      addStatic('box', 'stone',  '#727B8C', px + 11, 0.25, pz - 2, 10.0, 0.45, 8.5);
      addTorii(px, pz - 16, 7.8, 5.0);
      addTree(px - 16, pz + 5, 1.3, '#D96B38'); // Autumn Maple by Onsen
      addTree(px + 16, pz + 5, 1.3, '#E892A2');
    } else if (p.id === 'place_kebun_teh_air_terjun') {
      // NEW LOCATION 4: Anjungan Wisata Air Terjun & Kebun Teh Bukit
      addStatic('box', 'stone', '#566070', px, 4.5, pz + 16, 18.0, 9.0, 7.0); // Cliff Rock
      addStatic('box', 'kawara', '#58A8D8', px, 4.5, pz + 12.3, 6.5, 8.8, 0.5, 0, 0.75, 0); // Cascading Waterfall!
      addStatic('box', 'kawara', '#286898', px, 0.06, pz + 5, 16.0, 0.1, 10.0, 0, 0.4, 0); // Waterfall Basin
      addMinka(px - 13, pz - 3, 8.5, 3.2, 7.2, '#F3EAD6', '#3A5238', true, false, 'Gardu Pandang Kebun Teh');
      for (let r = -1; r <= 1; r++) {
        addStatic('box', 'ground', '#5C8244', px + 13, 0.45, pz + r * 4.5, 9.5, 0.85, 2.4); // Tea Hedge Rows
      }
    } else if (p.id === 'place_barak_gerbang') {
      addTorii(px, pz - 16, 9.6, 5.8);
      addMinka(px - 13, pz + 3, 9.5, 3.5, 8.0, '#EFE6D2', '#1B2230', true, false, 'Atap Barak Gerbang Barat');
      addMinka(px + 13, pz + 3, 9.5, 3.5, 8.0, '#EFE6D2', '#1B2230', true, false, 'Atap Barak Gerbang Timur');
      addMinka(px - 14, pz - 10, 7.0, 3.0, 6.5, '#E5DCC8', '#2C3444', true, false);
    } else if (p.id === 'place_pasar') {
      addMinka(px, pz + 14, 13.5, 3.8, 9.0, '#EFE6D2', '#27406B', true, true, 'Atap Balai Serikat Za');
      addMinka(px - 14, pz - 2, 8.2, 3.3, 7.6, '#EFE6D2', '#1B2230', true, false, 'Atap Lapak Barat Pasar');
      addMinka(px + 14, pz - 2, 8.2, 3.3, 7.6, '#EFE6D2', '#1B2230', true, false, 'Atap Lapak Timur Pasar');
      addStatic('box', 'wood', '#6A4B32', px, 3.6, pz - 2, 19.0, 0.24, 0.9);
      climbZones.push({ x: px, z: pz - 2, topY: 3.75, radius: 22.0, label: 'Balok Atas Pasar' });
    } else if (p.id === 'place_kedai_teh') {
      addMinka(px, pz + 10, 12.5, 3.6, 8.8, '#F5E4B3', '#5E1F18', true, true, 'Atap Kedai Teh O-Kiku');
      addMinka(px - 14, pz - 2, 7.8, 3.1, 6.8, '#EFE6D2', '#2A3344', true, false);
      addStatic('box', 'cloth', '#C8232C', px - 6, 0.45, pz - 4, 3.8, 0.55, 2.2);
      addStatic('box', 'cloth', '#C8232C', px + 6, 0.45, pz - 4, 3.8, 0.55, 2.2);
      addTree(px - 14, pz + 6, 1.35, '#F090A0');
    } else if (p.id === 'place_nagaya') {
      addMinka(px - 12, pz + 8, 14.5, 3.2, 7.2, '#D8CEB8', '#2C251E', true, false, 'Atap Nagaya O-Hana');
      addMinka(px + 12, pz - 7, 14.5, 3.2, 7.2, '#D8CEB8', '#2C251E', true, false, 'Atap Kamar Sōma');
      addMinka(px - 13, pz - 9, 8.5, 3.0, 6.5, '#E6DEC8', '#3B3026', true, false);
      addStatic('cylinder', 'stone', '#5C6472', px, 0.55, pz, 1.9, 1.1, 1.9);
    } else if (p.id === 'place_apotek_soan') {
      addMinka(px, pz + 10, 11.5, 3.5, 8.2, '#EFE6D2', '#3E543B', true, false, 'Atap Apotek Tabib Sōan');
      addMinka(px + 14, pz - 2, 7.8, 3.1, 6.8, '#EFE6D2', '#3E543B', true, false);
      addTree(px - 12, pz - 4, 1.15, '#587846');
      addTree(px + 12, pz + 6, 1.15, '#587846');
    } else if (p.id === 'place_bengkel_kayu') {
      addMinka(px - 10, pz + 8, 9.8, 3.5, 7.8, '#A37E56', '#1B2230', false, false, 'Atap Pandai Besi Kurobē');
      addMinka(px + 10, pz + 8, 9.8, 3.5, 7.8, '#8C6239', '#2B2118', false, false, 'Atap Bengkel Kayu Gorō');
      addStatic('box', 'shoji', '#C8232C', px - 10, 0.9, pz - 3, 2.4, 1.6, 2.4, 0, 1.2);
    } else if (p.id === 'place_dermaga') {
      addMinka(px + 12, pz + 9, 12.0, 3.9, 8.6, '#EFE6D2', '#141B33', false, false, 'Atap Gudang Garam Dermaga');
      addMinka(px + 12, pz - 9, 12.0, 3.9, 8.6, '#EFE6D2', '#141B33', false, false, 'Atap Gudang Beras Daigō');
      addStatic('box', 'wood', '#7A5938', px - 13, 0.45, pz, 15.0, 0.45, 7.5);
      addStatic('box', 'wood', '#4E3620', px - 21, 0.35, pz - 6, 4.0, 0.85, 10.5, 0.15);
    } else if (p.id === 'place_jembatan_batu') {
      addStatic('box', 'stone', '#8A92A0', px, 1.1, pz, 32.0, 1.1, 8.2);
      addStatic('box', 'wood',  '#C8232C', px, 1.9, pz - 3.8, 32.0, 0.65, 0.4);
      addStatic('box', 'wood',  '#C8232C', px, 1.9, pz + 3.8, 32.0, 0.65, 0.4);
      addMinka(px - 17, pz + 9, 8.2, 3.4, 7.6, '#EFE6D2', '#1B2230', true, false, 'Atap Pos Ronda Jembatan Rin');
    } else if (p.id === 'place_kuil_kecil') {
      addTorii(px, pz - 16, 8.2, 5.4);
      addTorii(px, pz - 8,  7.2, 4.9);
      addMinka(px, pz + 11, 13.0, 3.9, 9.2, '#C8232C', '#1B2230', true, true, 'Atap Kuil Kecil Jikai');
      addMinka(px + 13, pz + 1, 6.0, 4.6, 6.0, '#A37E56', '#1B2230', false, false, 'Menara Lonceng Jikai');
      addTree(px - 14, pz + 6, 1.4, '#F090A0');
    } else if (p.id === 'place_rumah_samurai') {
      addMinka(px, pz + 10, 14.5, 3.9, 10.0, '#EFE6D2', '#141B33', true, true, 'Atap Kediaman Samurai Jūbei');
      addMinka(px - 15, pz - 3, 8.5, 3.3, 7.5, '#EFE6D2', '#1B2538', true, false);
      addStatic('box', 'shoji', '#D8CEB8', px, 1.3, pz - 14, 32.0, 2.6, 0.9);
    } else if (p.id === 'place_benteng_juru_tulis') {
      addStatic('box', 'stone', '#525A68', px, 1.2, pz + 9, 22.0, 2.4, 15.0);
      addMinka(px, pz + 9, 15.0, 4.3, 11.0, '#EFE6D2', '#141B33', true, true, 'Atap Balai Juru Tulis Gensai');
    } else if (p.id === 'place_titik_serah_hutan') {
      addStatic('cylinder', 'wood', '#422C1B', px, 5.8, pz, 3.0, 11.6, 3.0);
      addStatic('cone', 'ground', '#234228', px, 10.8, pz, 11.5, 7.8, 11.5);
      addStatic('cone', 'ground', '#1B3420', px, 15.2, pz, 8.5, 6.2, 8.5);
      addStatic('box', 'cloth', '#F4EFE6', px, 2.5, pz, 3.4, 0.45, 3.4, 0, 0.6);
      for (let i = 0; i < 8; i++) {
        const a = (i / 8) * Math.PI * 2;
        addTree(px + Math.cos(a) * 16, pz + Math.sin(a) * 16, 1.35, '#29482E');
      }
    }
  });

  // Scatter scenic trees & sakura groves across the expanded valley
  for (let i = 0; i < 95; i++) {
    const tx = Math.sin(i * 19.3) * 390, tz = Math.cos(i * 31.7) * 370;
    let near = false;
    for (let j = 0; j < DATA.places.length; j++) {
      if (Math.hypot(tx - DATA.places[j].mapX, tz - DATA.places[j].mapY) < 34) { near = true; break; }
    }
    if (!near && Math.abs(tx - 165) > 24) {
      const col = (i % 4 === 0) ? '#E88E9E' : ((i % 5 === 0) ? '#D26E3A' : '#3F623E');
      addTree(tx, tz, 1.0 + (i % 3) * 0.25, col);
    }
  }

  // =========================================================================
  // 4. NIGHTTIME ESPIONAGE NODES (Scaled to Expanded Map Coordinates)
  // =========================================================================
  const INTEL_NODES = [
    { id: 'intel_gerbang_ryota', placeId: 'place_barak_gerbang', title: 'Buku Giliran Jaga Pos Gerbang Selatan', kabarId: 'kabar_jadwal_gerbang_ryota', x: placeMap['place_barak_gerbang'].mapX - 6, z: placeMap['place_barak_gerbang'].mapY + 6, collected: false },
    { id: 'intel_dermaga_haruki', placeId: 'place_dermaga', title: 'Buku Timbangan Garam & Pungutan Za', kabarId: 'kabar_pajak_gelap_haruki', gigId: 'gig_salin_buku_pajak_dermaga', x: placeMap['place_dermaga'].mapX + 8, z: placeMap['place_dermaga'].mapY + 6, collected: false },
    { id: 'intel_benteng_hisame', placeId: 'place_benteng_juru_tulis', title: 'Arsip Pemeriksaan Pendatang Baru (Gensai)', kabarId: 'kabar_ronda_malam_hisame', x: placeMap['place_benteng_juru_tulis'].mapX, z: placeMap['place_benteng_juru_tulis'].mapY + 4, collected: false },
    { id: 'intel_kuil_muraku', placeId: 'place_kuil_kecil', title: 'Bungkusan Kain di Bawah Lonceng Kuil Jikai', kabarId: 'kabar_jejak_terakhir_muraku', x: placeMap['place_kuil_kecil'].mapX + 12, z: placeMap['place_kuil_kecil'].mapY, collected: false },
    { id: 'intel_samurai_kojiro', placeId: 'place_rumah_samurai', title: 'Surat Utang Judi Samurai Patroli Kojirō', gigId: 'gig_bongkar_suap_kojiro', x: placeMap['place_rumah_samurai'].mapX + 6, z: placeMap['place_rumah_samurai'].mapY + 6, collected: false }
  ];

  // =========================================================================
  // 5. MERCHANT CARRIER STYLES & REALISTIC NON-BLACK NIGHT CAMOUFLAGE
  // =========================================================================
  const CARRIER_STYLES = [
    {
      id: 'CARRIER_CART',
      name: 'Gerobak Dorong Kayu (Daisen-Guruma)',
      shortLabel: 'Gerobak Dorong',
      walkSpeed: 7.4,
      desc: 'Gerobak kayu beroda dua yang didorong tenang di depan Sōma. Muatan banyak dan menarik warga di taman maupun kediaman untuk menghampiri.'
    },
    {
      id: 'CARRIER_TENTENGAN',
      name: 'Tentengan Keranjang & Bungkusan Furoshiki',
      shortLabel: 'Tentengan Tangan',
      walkSpeed: 8.6,
      desc: 'Tentengan keranjang bambu dan bungkusan kain Furoshiki warna-warni di kedua tangan. Ringkas untuk keluar-masuk halaman rumah dan onsen.'
    },
    {
      id: 'CARRIER_PIKULAN',
      name: 'Pikulan Bambu Dua Kotak (Tenbinbō)',
      shortLabel: 'Pikulan Bambu',
      walkSpeed: 7.9,
      desc: 'Batang pikulan bambu dengan dua peti barang di bahu. Langkah berirama mantap khas pedagang keliling antar kampung.'
    },
    {
      id: 'CARRIER_RANSEL',
      name: 'Ransel Rak Kayu Punggung (Seoi-Bako)',
      shortLabel: 'Ransel Kayu',
      walkSpeed: 8.2,
      desc: 'Kotak rak kayu bertingkat di punggung yang diikat tali rami, cocok saat mendaki ke Kuil Kecil atau Kebun Teh Air Terjun.'
    }
  ];

  const NIGHT_CAMO_STYLES = [
    { id: 'CAMO_AI_ZOME', name: 'Biru Nila Malam (Ai-Zome)', robeHex: '#1F3A60', hoodHex: '#2A4B78' },
    { id: 'CAMO_SUMI_NEZUMI', name: 'Abu Arang Lembah (Sumi-Nezumi)', robeHex: '#2A2E35', hoodHex: '#3A404A' },
    { id: 'CAMO_KOKE_IRO', name: 'Hijau Lumut Hutan (Koke-Iro)', robeHex: '#243628', hoodHex: '#334D38' }
  ];

  const bibleMap = {};
  DATA.charBible.forEach(c => { bibleMap[c.id] = c; });

  const startPlace = placeMap['place_taman_sakura'] || DATA.places[0];

  const state = {
    day: 1,
    hour: 9.5,
    mon: 180,
    rentPaidThisWeek: false,
    garbMode: 'OMOTE', // 'OMOTE' (Pedagang Normal Siang) | 'URA' (Samaran Malam Realistis)
    carrierIdx: 0,     // 0: Gerobak, 1: Tentengan, 2: Pikulan, 3: Ransel
    nightCamoIdx: 0,   // 0: Nila Malam, 1: Abu Arang, 2: Hijau Lumut (Tidak Hitam Pekat!)
    viewMode: 'THIRD_PERSON', // 'THIRD_PERSON' | 'FIRST_PERSON'
    invertMouseY: false,
    listenMode: 0,
    isSheathed: true,
    slashTimer: 0,
    activeWareIdx: 0,
    wareStock: DATA.wares.map((w, i) => i === 0 ? 10 : 6),
    suspicion: 5,
    groupTrust: 68,
    groupContactState: 'Aktif',
    shadowStrength: 0.68,
    noiseDb: 4,
    player: {
      x: startPlace.mapX, y: 0, z: startPlace.mapY - 12,
      vx: 0, vz: 0,
      yaw: 0,
      pitch: 0.22,
      walkCycle: 0,
      lastStepHalfCycle: 0,
      wheelAngle: 0,
      isMoving: false
    },
    camYawOffset: 0.0,
    camDist: 8.2,
    fovDeg: 60.0,
    inkRipples: [],
    witnessedByKabar: {
      kabar_jadwal_gerbang_ryota: new Set(['okiku']),
      kabar_pajak_gelap_haruki: new Set(),
      kabar_ronda_malam_hisame: new Set(),
      kabar_jejak_terakhir_muraku: new Set()
    },
    verifiedKabars: new Set(),
    completedOrders: new Set(),
    completedGigs: new Set(),
    activeDialogueNpc: null,
    misunderstandings: [
      {
        id: 'mis_01_okiku_cukai',
        accuserName: 'Penjaga Gerbang Ryōta',
        victimName: 'O-Kiku (Pemilik Kedai Teh)',
        trueCulpritName: 'Mio (Dermaga)',
        placeId: 'place_pasar',
        distortionOp: 'WrongPerson',
        summary: 'Ryōta salah menuduh O-Kiku menyembunyikan keranjang ikan tanpa cukai, padahal itu milik Mio.',
        resolved: false,
        outcomeText: ''
      },
      {
        id: 'mis_02_rin_pos_jembatan',
        accuserName: 'Makelar Daigō',
        victimName: 'Rin (Penjaga Jembatan)',
        trueCulpritName: 'Kojirō (Samurai Patroli)',
        placeId: 'place_jembatan_batu',
        distortionOp: 'AddMotive',
        summary: 'Kabar burung menuduh Rin menerima suap di Jembatan Batu, padahal Kojirō yang meninggalkan pos jaga.',
        resolved: false,
        outcomeText: ''
      }
    ],
    nisshiEntries: [
      'Hari 1: Berkeliling sebagai pedagang normal dengan gerobak & tentengan di Taman Sakura dan Kediaman Warga. Pembeli menghampiri dengan ramah.',
      'Pesan Kawan Kelompok (Sabu): Cari tahu jadwal jaga Gerbang Selatan dan buku garam Dermaga dengan BERTANYA ke pelanggan di siang hari, lalu salin buktinya saat malam tiba.'
    ]
  };

  let toastTimer = null;
  function showToast(msg) {
    const el = document.getElementById('toastBanner');
    if (!el) return;
    el.textContent = msg;
    el.style.opacity = '1';
    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { el.style.opacity = '0'; }, 3500);
  }

  function triggerInkFlash() {
    const el = document.getElementById('inkFlashOverlay');
    if (!el) return;
    el.style.opacity = '1';
    setTimeout(() => { el.style.opacity = '0'; }, 240);
  }

  // =========================================================================
  // 6. COLORFUL, EXPRESSIVE NPCS & AUTOMATIC APPROACHING CUSTOMER AI (Poin 1 & 3)
  // =========================================================================
  const EXTRA_CUSTOMER_PLACES = [
    'place_taman_sakura', 'place_kediaman_warga', 'place_pemandian_onsen', 'place_kebun_teh_air_terjun'
  ];
  const VIBRANT_PALETTES = [
    { robe: '#D25238', haori: '#27406B', obi: '#F5B041', emoji: '😊' },
    { robe: '#3A6B88', haori: '#EFE6D2', obi: '#C8232C', emoji: '😄' },
    { robe: '#68824B', haori: '#422C1D', obi: '#E8A33D', emoji: '😊' },
    { robe: '#8E4B72', haori: '#F3EAD6', obi: '#F5B041', emoji: '😊' },
    { robe: '#C87A2E', haori: '#1F3A60', obi: '#78E08F', emoji: '🤔' },
    { robe: '#27406B', haori: '#8C2D26', obi: '#EFE6D2', emoji: '😐' }
  ];

  const npcsRuntime = DATA.npcs.map((n, idx) => {
    const b = bibleMap[n.id] || {};
    const pal = VIBRANT_PALETTES[idx % VIBRANT_PALETTES.length];
    const isGuard = n.roleCategory === 'Guard';
    const isSabu = n.id === 'sabu';
    // Distribute several citizens across the 4 new lively places so parks/residences/onsen are full of customers!
    let assignedHomeId = n.home;
    if (!isGuard && !isSabu && idx % 3 === 1) {
      assignedHomeId = EXTRA_CUSTOMER_PLACES[(idx >> 1) % EXTRA_CUSTOMER_PLACES.length];
    }
    const homePlace = placeMap[assignedHomeId] || DATA.places[0];
    const ang = (idx / 26) * Math.PI * 2;

    return {
      ...n,
      name: (n.displayName && n.displayName.id) || n.id,
      primaryHex: isGuard ? '#27406B' : (b.primaryPaletteHex || pal.robe),
      haoriHex: isGuard ? '#182640' : pal.haori,
      obiHex: isGuard ? '#C8232C' : pal.obi,
      accentHex: b.accentPaletteHex || (isGuard ? '#C8232C' : '#E8B86D'),
      moodEmoji: isSabu ? '🕵️' : (isGuard ? '😐' : pal.emoji),
      moodLabel: isSabu ? 'Kawan Kelompok' : (isGuard ? 'Penjaga Lembah' : 'Warga & Pembeli'),
      isGuard,
      isSabu,
      assignedHomeId,
      currentPlaceId: homePlace.id,
      currentActivity: 'Berjalan Santai',
      x: homePlace.mapX + Math.cos(ang) * 7.5,
      z: homePlace.mapY + Math.sin(ang) * 7.5,
      yaw: ang + Math.PI,
      animPhase: idx * 0.8,
      speechText: '',
      speechTimer: 0,
      offsetRadius: 6.5 + (idx % 4) * 2.4,
      offsetAngle: ang,
      isApproachingCustomer: false,
      customerCooldown: 0,
      rightArmInjured: false
    };
  });

  function parseHm(str) {
    const pts = (str || '08:00').split(':');
    return parseInt(pts[0], 10) + parseInt(pts[1] || '0', 10) / 60;
  }

  function updateNpcsAndApproachingCustomers(dt) {
    const isDayMerchant = !isNightTime() && state.garbMode === 'OMOTE';
    let closestApproacher = null;
    let closestApproachDist = Infinity;

    npcsRuntime.forEach((npc, idx) => {
      if (npc.customerCooldown > 0) npc.customerCooldown = Math.max(0, npc.customerCooldown - dt);

      let targetPlaceId = npc.assignedHomeId || npc.home;
      let act = 'Beraktivitas';
      for (let i = 0; i < (npc.schedule || []).length; i++) {
        const slot = npc.schedule[i];
        const f = parseHm(slot.from), t = parseHm(slot.to);
        if (state.hour >= f && state.hour <= t) {
          targetPlaceId = (idx % 3 === 1 && !npc.isGuard && !npc.isSabu) ? npc.assignedHomeId : slot.place;
          act = slot.activity;
          break;
        }
      }
      npc.currentPlaceId = targetPlaceId;
      npc.currentActivity = act;

      const dToPlayer = Math.hypot(state.player.x - npc.x, state.player.z - npc.z);

      // Poin 1: Pembeli datang dan menghampiri secara perlahan untuk membeli sesuatu!
      if (isDayMerchant && !npc.isSabu && dToPlayer < 26.0 && npc.customerCooldown <= 0) {
        npc.isApproachingCustomer = true;
        if (dToPlayer < closestApproachDist) {
          closestApproachDist = dToPlayer;
          closestApproacher = npc;
        }
      } else if (dToPlayer > 30.0 || !isDayMerchant) {
        npc.isApproachingCustomer = false;
      }

      if (npc.isApproachingCustomer) {
        // Walk slowly and politely toward Sōma, stopping ~2.5m in front of him
        const dx = state.player.x - npc.x, dz = state.player.z - npc.z;
        const dist = Math.hypot(dx, dz) || 1;
        npc.yaw = Math.atan2(dx, dz);
        if (dist > 2.6) {
          const slowApproachSpeed = 2.8; // Slow, natural customer walk
          npc.x += (dx / dist) * slowApproachSpeed * dt;
          npc.z += (dz / dist) * slowApproachSpeed * dt;
          npc.animPhase += dt * 4.2;
        } else {
          // Arrived in front of Sōma! Greet briefly (1 short sentence)
          if (!npc.speechText) {
            const wName = DATA.wares[state.activeWareIdx].categoryName;
            npc.speechText = `"Sōma-san, kebetulan lewat! Boleh saya beli ${wName.toLowerCase()}?"`;
            npc.speechTimer = 8.0;
            npc.moodEmoji = '😊';
            npc.moodLabel = 'Pembeli Menghampiri';
          }
        }
      } else {
        // Normal neighborhood stroll
        const pl = placeMap[targetPlaceId] || DATA.places[0];
        npc.offsetAngle += dt * (0.16 + (idx % 3) * 0.05);
        const tx = pl.mapX + Math.cos(npc.offsetAngle) * npc.offsetRadius;
        const tz = pl.mapY + Math.sin(npc.offsetAngle) * npc.offsetRadius;
        const dx = tx - npc.x, dz = tz - npc.z;
        const dist = Math.hypot(dx, dz);
        if (dist > 0.15) {
          npc.yaw = Math.atan2(dx, dz);
          const step = Math.min(dist, 3.6 * dt);
          npc.x += (dx / dist) * step;
          npc.z += (dz / dist) * step;
          npc.animPhase += dt * 4.5;
        }
      }

      if (npc.speechTimer > 0) {
        npc.speechTimer -= dt;
        if (npc.speechTimer <= 0) npc.speechText = '';
      }
    });

    // Keep Sabu accessible at Pohon Aras Tua or nearby when needed
    const sabuNpc = npcsRuntime.find(n => n.isSabu);
    if (sabuNpc) {
      const deadDrop = placeMap['place_titik_serah_hutan'];
      if (deadDrop && Math.hypot(state.player.x - deadDrop.mapX, state.player.z - deadDrop.mapY) < 45) {
        sabuNpc.x = deadDrop.mapX - 3.5;
        sabuNpc.z = deadDrop.mapY - 4.5;
        sabuNpc.yaw = Math.atan2(state.player.x - sabuNpc.x, state.player.z - sabuNpc.z);
      }
    }
  }

  // =========================================================================
  // 7. INTERACTIVE "BERTANYA" (ASK QUESTIONS) & MERCHANT / NIGHT-STEALTH LOGIC
  // =========================================================================
  function getNearestPlace() {
    let best = DATA.places[0], bestD = Infinity;
    DATA.places.forEach(p => {
      const d = Math.hypot(state.player.x - p.mapX, state.player.z - p.mapY);
      if (d < bestD) { bestD = d; best = p; }
    });
    return { place: best, dist: bestD };
  }

  function getNearestNpc() {
    let best = null, bestD = Infinity;
    npcsRuntime.forEach(n => {
      const d = Math.hypot(state.player.x - n.x, state.player.z - n.z);
      if (d < bestD) { bestD = d; best = n; }
    });
    return { npc: best, dist: bestD };
  }

  function getNearestIntelNode() {
    let best = null, bestD = Infinity;
    INTEL_NODES.forEach(node => {
      if (node.collected) return;
      const d = Math.hypot(state.player.x - node.x, state.player.z - node.z);
      if (d < bestD) { bestD = d; best = node; }
    });
    return { node: best, dist: bestD };
  }

  function isNightTime() {
    return state.hour >= 18.0 || state.hour < 5.5;
  }

  // Poin 3: Interactive 4-Option "BERTANYA" (Ask Questions) System with Short, Crisp Answers!
  function askCustomerOption(optionNum) {
    const nearNpc = getNearestNpc();
    const npc = (nearNpc.npc && nearNpc.dist < 28) ? nearNpc.npc : npcsRuntime[0];
    state.activeDialogueNpc = npc;
    const w = DATA.wares[state.activeWareIdx];

    // If speaking to Comrade Sabu (Perwakilan Kelompok)
    if (npc.isSabu) {
      SoundEngine.playAskChime();
      const nextOrd = DATA.orders.find(o => !state.completedOrders.has(o.id)) || DATA.orders[0];
      if (optionNum === 1 || optionNum === 3) {
        npc.moodEmoji = '🕵️';
        npc.moodLabel = 'Arahan Misi Kelompok';
        npc.speechText = `"Misi kita saat ini: '${nextOrd.title}'. Di siang hari tanyai pelangganmu, lalu malam nanti salin buktinya."`;
        npc.speechTimer = 10.0;
        showToast(`🕵️ Sabu memberi arahan: ${nextOrd.title}`);
      } else {
        deliverKabarAtDeadDrop();
      }
      updateHUD();
      return;
    }

    if (optionNum === 1) {
      // [1] Layani Pembeli (+Mon & Akrabkan Diri)
      if (state.wareStock[state.activeWareIdx] <= 0) {
        const cost = Math.round(w.baseCapitalMon * 0.4);
        state.mon = Math.max(0, state.mon - cost);
        state.wareStock[state.activeWareIdx] += 6;
        SoundEngine.playCoinClink();
        showToast(`🧺 Mengisi ulang 6 unit [${w.categoryName}] (-${cost} mon).`);
        updateHUD();
        return;
      }
      state.wareStock[state.activeWareIdx]--;
      const profit = Math.round(w.baseCapitalMon * 0.28) + 15;
      state.mon += profit;
      state.suspicion = Math.max(0, state.suspicion - 3);
      npc.moodEmoji = '😄';
      npc.moodLabel = 'Senang Membeli';
      npc.speechText = `"Wah, ${w.categoryName} buatanmu bagus sekali! Ini ${profit} mon, Sōma-san. Mau tanya apa?"`;
      npc.speechTimer = 9.0;
      npc.customerCooldown = 18.0;
      npc.isApproachingCustomer = false;
      SoundEngine.playCoinClink();
      showToast(`💰 Pembeli ${npc.name} membeli ${w.categoryName} (+${profit} mon)!`);
    } else if (optionNum === 2) {
      // [2] Tanya Kabar Sekitar (Short, direct neighborhood intel)
      SoundEngine.playAskChime();
      const nearP = getNearestPlace().place;
      const shortRumors = [
        `"Di sekitar ${nearP.name.split('&')[0].trim()}, Ryōta sering mengeluh giliran jaganya selesai tepat pukul 18:00."`,
        `"Tadi pagi saya lihat Haruki buru-buru menyimpan buku catatan di gudang garam Dermaga."`,
        `"Warga kediaman bilang Juru Tulis Gensai sedang mendata setiap pendatang baru di benteng."`,
        `"Biksu Jikai sempat menyebut ada bungkusan kain lama di bawah lonceng kuil."`
      ];
      npc.moodEmoji = '🤫';
      npc.moodLabel = 'Berbisik Pelan';
      npc.speechText = shortRumors[(state.day + npc.name.length) % shortRumors.length];
      npc.speechTimer = 9.5;
      recordWitnessForKabar(npc);
    } else if (optionNum === 3) {
      // [3] Tanya Petunjuk Misi Sabu (Targeted question for active group mission)
      SoundEngine.playAskChime();
      const targetKabar = DATA.kabars.find(k => !state.verifiedKabars.has(k.id)) || DATA.kabars[0];
      npc.moodEmoji = '🤔';
      npc.moodLabel = 'Menjawab Pertanyaan';
      npc.speechText = `"Soal itu... ${targetKabar.claim}"`;
      npc.speechTimer = 10.0;
      recordWitnessForKabar(npc, targetKabar);
    } else if (optionNum === 4) {
      // [4] Tanya Kebutuhan Warga (Unlocks neighborhood goodwill / side gig)
      SoundEngine.playAskChime();
      const gig = DATA.gigs.find(g => !state.completedGigs.has(g.id)) || DATA.gigs[0];
      npc.moodEmoji = '😊';
      npc.moodLabel = 'Permintaan Warga';
      npc.speechText = `"Kalau sempat, tolong bantu urusan '${gig.title}' ya. Upahnya ${gig.rewardMon} mon!"`;
      npc.speechTimer = 9.5;
      showToast(`🤝 Permintaan Warga: ${gig.title} (+${gig.rewardMon} mon)`);
    }
    updateHUD();
  }

  function recordWitnessForKabar(speaker, specificKabar = null) {
    const chosenKabar = specificKabar || DATA.kabars.find(k => !state.verifiedKabars.has(k.id)) || DATA.kabars[0];
    const wSet = state.witnessedByKabar[chosenKabar.id];
    wSet.add(speaker.id);
    state.inkRipples.push({ x: speaker.x, z: speaker.z, r: 0.5, maxR: 6.5, isLethal: false });

    if (wSet.size >= 2 && !state.verifiedKabars.has(chosenKabar.id)) {
      state.verifiedKabars.add(chosenKabar.id);
      showToast(`🖋️ INFO TERKONFIRMASI (≥2 Warga): Siap dilaporkan ke kawanmu Sabu!`);
      state.nisshiEntries.unshift(`Hari ${state.day}: Mengonfirmasi info [${chosenKabar.id}] lewat bertanya ke warga.`);
    } else {
      showToast(`👂 Jawaban ${speaker.name} dicatat (${wSet.size}/2 saksi). Tanyai 1 pembeli lagi!`);
    }
  }

  function triggerPrimaryAction() {
    const nearPlace = getNearestPlace();
    const nearIntel = getNearestIntelNode();
    const nearNpc = getNearestNpc();

    // 1. Report to Comrade Sabu at Pohon Aras Tua
    if ((nearPlace.place.id === 'place_titik_serah_hutan' && nearPlace.dist < 30) || (nearNpc.npc && nearNpc.npc.isSabu && nearNpc.dist < 14)) {
      deliverKabarAtDeadDrop();
      return;
    }

    // 2. Suspicious Action: Copying Secret Ledger (STRICTLY NIGHT-ONLY + URA DISGUISE per Poin 3!)
    if (nearIntel.node && nearIntel.dist < 18) {
      if (!isNightTime() || state.garbMode !== 'URA') {
        SoundEngine.playAskChime();
        showToast('☀️ Tidak bisa di siang hari! Menyalin dokumen rahasia hanya bisa dilakukan Malam Hari [T] dengan Pakaian Samaran Malam [Z].');
        return;
      }
      const n = nearIntel.node;
      n.collected = true;
      SoundEngine.playNightStealthWhoosh();
      state.inkRipples.push({ x: n.x, z: n.z, r: 0.5, maxR: 8.5, isLethal: false });
      if (n.kabarId) {
        state.witnessedByKabar[n.kabarId].add('bukti_malam');
        state.witnessedByKabar[n.kabarId].add('sadap_souma');
        state.verifiedKabars.add(n.kabarId);
      }
      if (n.gigId && !state.completedGigs.has(n.gigId)) {
        state.completedGigs.add(n.gigId);
        state.mon += 95;
        showToast(`✅ MISI MALAM BERHASIL: "${n.title}" disalin senyap (+95 mon)!`);
      } else {
        showToast(`🌙 BUKTI MALAM DISALIN: "${n.title}" → Siap lapor ke Sabu!`);
      }
      state.nisshiEntries.unshift(`Malam Hari ${state.day}: Menyalin [${n.title}] dengan pakaian samaran malam.`);
      updateHUD();
      return;
    }

    // 3. Daytime: Serve approaching customer directly
    askCustomerOption(1);
  }

  function triggerGatherRumor() {
    // Pressing [F] greets the nearest citizen and asks a question
    askCustomerOption(2);
  }

  function deliverKabarAtDeadDrop() {
    SoundEngine.playCoinClink();
    let anyCompleted = false;
    DATA.orders.forEach(ord => {
      if (state.completedOrders.has(ord.id)) return;
      const ready = ord.requiredKabarIds.every(kid => state.verifiedKabars.has(kid));
      if (ready) {
        state.completedOrders.add(ord.id);
        state.mon += ord.rewardCapitalMon;
        state.groupTrust = Math.min(100, state.groupTrust + ord.trustGainOnSuccess);
        anyCompleted = true;
        showToast(`🌲 SABU MENERIMA LAPORAN MISI: "${ord.title}" Tuntas (+${ord.rewardCapitalMon} mon)!`);
        state.nisshiEntries.unshift(`Hari ${state.day}: Melaporkan hasil misi [${ord.title}] kepada Sabu.`);
      }
    });
    if (!anyCompleted) {
      const nextOrd = DATA.orders.find(o => !state.completedOrders.has(o.id)) || DATA.orders[0];
      showToast(`🕵️ Sabu: "Tugasmu saat ini: '${nextOrd.title}'. Tanyai pembeli di siang hari atau salin bukti saat malam!"`);
    }
    updateHUD();
  }

  // Cycle 4 Merchant Carrier Styles [R] (Gerobak, Tentengan, Pikulan, Ransel)
  function cycleCarrierStyle(setIdx = null) {
    if (typeof setIdx === 'number') {
      state.carrierIdx = setIdx % CARRIER_STYLES.length;
    } else {
      state.carrierIdx = (state.carrierIdx + 1) % CARRIER_STYLES.length;
    }
    const c = CARRIER_STYLES[state.carrierIdx];
    SoundEngine.playAskChime();
    showToast(`🛒 Gaya Bawaan Sōma: ${c.name}`);
    renderDrawers();
    updateHUD();
  }

  function selectNightCamo(idx) {
    state.nightCamoIdx = idx % NIGHT_CAMO_STYLES.length;
    const cm = NIGHT_CAMO_STYLES[state.nightCamoIdx];
    showToast(`🌙 Warna Samaran Malam dipilih: ${cm.name} (Realistis & Tidak Hitam Pekat)`);
    renderDrawers();
    updateHUD();
  }

  // Poin 3: Strict Night-Only Rule for Suspicious Garb & Shadow-Meld [Z]
  function triggerShadowMeldOrGarb() {
    if (!isNightTime()) {
      SoundEngine.playAskChime();
      showToast('☀️ Masih siang hari! Berpakaian mencurigakan hanya bisa dilakukan di Malam Hari (Tekan [T] untuk menuju Malam).');
      return;
    }

    const fwdX = Math.sin(state.player.yaw), fwdZ = Math.cos(state.player.yaw);
    let bestPool = null, bestD = 18.0;
    shadowPools.forEach(sp => {
      const dx = sp.x - state.player.x, dz = sp.z - state.player.z;
      const d = Math.hypot(dx, dz);
      if (d > 2.5 && d < bestD && ((dx / d) * fwdX + (dz / d) * fwdZ) > 0.35) {
        bestD = d; bestPool = sp;
      }
    });

    if (state.garbMode === 'URA' && bestPool) {
      state.player.x = bestPool.x;
      state.player.z = bestPool.z;
      triggerInkFlash();
      SoundEngine.playNightStealthWhoosh();
      state.inkRipples.push({ x: bestPool.x, z: bestPool.z, r: 0.4, maxR: 4.5, isLethal: false });
      showToast('🌑 SHADOW-MELD: Menyelinap di antara bayangan malam tanpa suara!');
    } else {
      state.garbMode = state.garbMode === 'OMOTE' ? 'URA' : 'OMOTE';
      triggerInkFlash();
      SoundEngine.playNightStealthWhoosh();
      const cm = NIGHT_CAMO_STYLES[state.nightCamoIdx];
      showToast(state.garbMode === 'URA'
        ? `🌙 Mode Samaran Malam Aktif: Mengenakan pakaian ${cm.name} tanpa gerobak untuk misi malam.`
        : '☀️ Kembali ke penampilan Pedagang Normal.');
    }
    updateHUD();
  }

  // Rooftop Kaginawa [L] — Strictly Night-Only!
  function triggerKaginawa() {
    if (!isNightTime() || state.garbMode !== 'URA') {
      SoundEngine.playAskChime();
      showToast('☀️ Memanjat atap sangat mencurigakan di siang hari! Lakukan hanya saat Malam Hari dengan Pakaian Samaran Malam [Z].');
      return;
    }
    let best = null, bestD = 26.0;
    climbZones.forEach(cz => {
      const d = Math.hypot(cz.x - state.player.x, cz.z - state.player.z);
      if (d < bestD) { bestD = d; best = cz; }
    });
    if (best) {
      state.player.x = best.x;
      state.player.z = best.z;
      state.player.y = best.topY;
      triggerInkFlash();
      SoundEngine.playNightStealthWhoosh();
      showToast(`🪝 KAGINAWA MALAM [L]: Naik ke atas [${best.label}]!`);
      updateHUD();
    }
  }

  function resolveMisunderstanding(misId, actionType) {
    const m = state.misunderstandings.find(x => x.id === misId);
    if (!m || m.resolved) return;
    m.resolved = true;
    SoundEngine.playAskChime();
    if (actionType === 'MenyerahkanBukti') {
      state.mon += 45;
      m.outcomeText = `BERHASIL: ${m.victimName} bebas dari tuduhan berkat bukti silangmu (+45 mon)!`;
    } else if (actionType === 'Bersaksi') {
      m.outcomeText = `BERHASIL: Kesaksianmu meredakan salah paham terhadap ${m.victimName}.`;
    } else {
      m.outcomeText = `SELESAI: Masalah ${m.victimName} telah ditangani.`;
    }
    showToast(`⚖️ ${m.outcomeText}`);
    renderDrawers();
    updateHUD();
  }

  // =========================================================================
  // 8. CLEAN HUD & INTERACTIVE "BERTANYA" DIALOGUE BAR UPDATER
  // =========================================================================
  function updateHUD() {
    const h = Math.floor(state.hour), m = Math.floor((state.hour - h) * 60);
    const night = isNightTime();
    document.getElementById('txtClock').textContent = `Hari ${state.day} • ${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')} (${night ? 'Malam' : 'Siang'})`;
    document.getElementById('txtMon').textContent = `${state.mon} mon`;
    document.getElementById('txtTrust').textContent = `${state.groupContactState} (${state.groupTrust})`;

    const seal = document.getElementById('hankoSeal');
    const bMode = document.getElementById('badgeMode');
    const cm = NIGHT_CAMO_STYLES[state.nightCamoIdx];
    const carrier = CARRIER_STYLES[state.carrierIdx];

    if (state.garbMode === 'URA') {
      seal.textContent = '影';
      bMode.textContent = `MALAM • SAMARAN (${cm.name.split('(')[0].trim()})`;
      bMode.className = 'mode-badge ura';
    } else {
      seal.textContent = '商';
      bMode.textContent = 'SIANG • PEDAGANG NORMAL';
      bMode.className = 'mode-badge';
    }

    const nearP = getNearestPlace();
    const p = nearP.place;
    const w = DATA.wares[state.activeWareIdx];
    document.getElementById('hudDistrictTitle').textContent = `📍 ${p.name}`;
    const coverEl = document.getElementById('hudWareCover');
    if (state.garbMode === 'URA') {
      coverEl.className = '';
      coverEl.textContent = `🌙 Pakaian Samaran ${cm.name} • [Z] Selam Bayangan • [L] Panjat Atap`;
    } else {
      coverEl.className = '';
      coverEl.textContent = `🛒 ${carrier.shortLabel}: ${w.categoryName} (${state.wareStock[state.activeWareIdx]}) • [R] Ganti Bawaan`;
    }

    document.getElementById('lblCarrierBtn').textContent = `Bawaan: ${carrier.shortLabel}`;
    document.getElementById('txtWalkState').textContent = state.garbMode === 'URA'
      ? `🌙 Langkah Senyap Malam (${cm.name.split('(')[0].trim()})`
      : `🚶 Langkah Pedagang Normal (${carrier.shortLabel})`;
    document.getElementById('badgeAlert').textContent = night ? 'MODE MALAM' : 'WARGA RAMAH';
    document.getElementById('txtCameraMode').textContent = state.viewMode === 'THIRD_PERSON'
      ? '🎥 [C] Kamera 3rd-Person'
      : '👁️ [C] Kamera 1st-Person';

    document.getElementById('lblKabarCount').textContent = `${state.verifiedKabars.size}/${DATA.kabars.length}`;

    // Update Interactive "BERTANYA" Dialogue Panel when an approaching customer or Sabu is nearby!
    const nearIntel = getNearestIntelNode();
    const nearNpc = getNearestNpc();
    const dlgPanel = document.getElementById('dialogueAskPanel');
    const promptBar = document.getElementById('actionPromptBar');
    const lblBtn = document.getElementById('lblPrimaryBtn');

    if (nearNpc.npc && nearNpc.dist < 14.0) {
      const npc = nearNpc.npc;
      dlgPanel.style.display = 'block';
      document.getElementById('dlgPortrait').textContent = npc.moodEmoji || '😊';
      document.getElementById('dlgPortrait').style.background = npc.primaryHex || '#27406B';
      document.getElementById('dlgSpeakerName').textContent = `${npc.name} — ${npc.role.split('&')[0].trim()}`;
      document.getElementById('dlgMoodBadge').textContent = `${npc.moodEmoji || '😊'} ${npc.moodLabel || 'Warga'}`;
      document.getElementById('dlgSpeechText').textContent = npc.speechText || (npc.isSabu
        ? `"Sōma, ada kabar baru dari pelangganmu? Tekan [3] untuk cek target misi kita."`
        : `"Halo Sōma-san! Kebetulan saya sedang mencari ${w.categoryName.toLowerCase()}."`);
      lblBtn.textContent = npc.isSabu ? 'Lapor ke Sabu' : `Layani ${npc.name}`;
      promptBar.textContent = `💬 Dekat ${npc.name}: Klik/Tekan [1] Layani Pembeli • [2] Tanya Kabar • [3] Tanya Target Misi • [4] Tanya Kebutuhan`;
    } else if (nearIntel.node && nearIntel.dist < 18.0) {
      dlgPanel.style.display = 'none';
      lblBtn.textContent = isNightTime() ? 'Salin Bukti Malam' : 'Tunggu Malam [T]';
      promptBar.textContent = isNightTime()
        ? `🌙 Tekan [E] untuk Menyalin Bukti Rahasia: [${nearIntel.node.title}]`
        : `☀️ Ada [${nearIntel.node.title}], namun aksi mencurigakan hanya bisa dilakukan Malam Hari [T] dengan Pakaian Samaran [Z]!`;
    } else {
      dlgPanel.style.display = 'none';
      lblBtn.textContent = `Jual ${w.categoryName}`;
      promptBar.textContent = `WASD: Jalan Mulus Berbobot • Mouse/Scroll: Kamera & Zoom • [R] Ganti Gerobak/Tentengan • [C] 1st/3rd Person • [M] Peta 16 Lokasi`;
    }
  }

  function renderDrawers() {
    // 1. Peta 16 Lokasi Lembah Kurokawa
    const mapCanvas = document.getElementById('mapCanvasLarge');
    if (mapCanvas) {
      const mctx = mapCanvas.getContext('2d');
      const w = mapCanvas.width, h = mapCanvas.height;
      mctx.fillStyle = '#0B101D'; mctx.fillRect(0, 0, w, h);
      const toX = x => w * 0.5 + (x / 840) * w;
      const toY = z => h * 0.5 + (z / 800) * h;

      mctx.strokeStyle = '#245282'; mctx.lineWidth = 10;
      mctx.beginPath(); mctx.moveTo(toX(190), toY(380)); mctx.lineTo(toX(156), toY(25)); mctx.lineTo(toX(272), toY(-330)); mctx.stroke();

      mctx.strokeStyle = 'rgba(239, 230, 210, 0.35)'; mctx.lineWidth = 2.0;
      DATA.places.forEach(p => {
        (p.neighbors || []).forEach(nb => {
          const q = placeMap[nb.to];
          if (!q) return;
          mctx.beginPath(); mctx.moveTo(toX(p.mapX), toY(p.mapY)); mctx.lineTo(toX(q.mapX), toY(q.mapY)); mctx.stroke();
        });
      });

      const curP = getNearestPlace().place;
      DATA.places.forEach(p => {
        const x = toX(p.mapX), y = toY(p.mapY);
        const isNew = p.id.includes('taman') || p.id.includes('onsen') || p.id.includes('kediaman') || p.id.includes('air_terjun');
        mctx.fillStyle = p.id === curP.id ? '#F5B041' : (isNew ? '#78E08F' : '#EFE6D2');
        mctx.beginPath(); mctx.arc(x, y, p.id === curP.id ? 8 : 6, 0, Math.PI * 2); mctx.fill();
        mctx.fillStyle = '#EFE6D2'; mctx.font = 'bold 12px Segoe UI';
        mctx.fillText(p.name.split('(')[0].split('&')[0].trim(), x + 9, y + 4);
      });

      mctx.fillStyle = '#FF5252';
      mctx.beginPath(); mctx.arc(toX(state.player.x), toY(state.player.z), 7, 0, Math.PI * 2); mctx.fill();
    }

    const mGrid = document.getElementById('mapDistrictGrid');
    if (mGrid) {
      mGrid.innerHTML = DATA.places.map((p, idx) => {
        const isScenic = p.id.includes('taman') || p.id.includes('onsen') || p.id.includes('kediaman') || p.id.includes('air_terjun');
        return `
          <div class="item-card ${isScenic ? 'verified' : ''}">
            <span class="badge ${isScenic ? 'ok' : ''}">${isScenic ? '🌸 Ramai Pelanggan / Wisata & Kediaman' : `Distrik ${p.districtName}`}</span>
            <h3>${idx + 1}. ${p.name}</h3>
            <p>Keramaian Warga: ${Math.round(p.witnessDensity * 100)}%</p>
            <div style="margin-top:8px;">
              <button class="big-hud-btn" onclick="window.KAGE_WORLD.teleportTo('${p.id}'); window.KAGE_WORLD.closeDrawers();">
                📍 Berkeliling ke Sini
              </button>
            </div>
          </div>
        `;
      }).join('');
    }

    // 2. Catatan Informasi (Papan Tinta)
    const inkEl = document.getElementById('inkboardList');
    if (inkEl) {
      inkEl.innerHTML = DATA.kabars.map(k => {
        const wSet = state.witnessedByKabar[k.id] || new Set();
        const verified = state.verifiedKabars.has(k.id);
        const pl = placeMap[k.subjectPlaceId];
        return `
          <div class="item-card ${verified ? 'verified' : ''}">
            <span class="badge ${verified ? 'ok' : 'alert'}">${verified ? '✅ INFO LENGKAP (Siap Lapor ke Sabu)' : `⏳ Jawaban Warga: ${wSet.size}/2`}</span>
            <span class="badge">Lokasi Terkait: ${pl ? pl.name : k.subjectPlaceId}</span>
            <h3>${k.claim}</h3>
            <p>Sumber: <strong>${wSet.size > 0 ? Array.from(wSet).join(', ') : 'Tanyai pembeli dengan tombol [2] atau [3] saat mereka menghampiri'}</strong></p>
          </div>
        `;
      }).join('');
    }

    // 3. Gaya Bawaan (Gerobak / Tentengan / Pikulan / Ransel) & 8 Barang Dagangan
    const cSec = document.getElementById('carrierStyleSection');
    if (cSec) {
      cSec.innerHTML = `
        <h3 style="color:var(--andon); margin-bottom:10px;">A. Pilih Cara Sōma Membawa Dagangan (Tekan [R] Kapan Saja)</h3>
        <div class="card-grid">
          ${CARRIER_STYLES.map((c, i) => `
            <div class="item-card ${i === state.carrierIdx ? 'verified' : ''}">
              <h3>${c.name}</h3>
              <p>${c.desc}</p>
              <div style="margin-top:8px;">
                <button class="big-hud-btn ${i === state.carrierIdx ? 'active' : ''}" onclick="window.KAGE_WORLD.cycleCarrierStyle(${i})">
                  ${i === state.carrierIdx ? '✅ Sedang Dipakai' : 'Gunakan Bawaan Ini'}
                </button>
              </div>
            </div>
          `).join('')}
        </div>
        <h3 style="color:var(--andon); margin:16px 0 8px;">B. Pilih Barang Dagangan Sōma</h3>
      `;
    }

    const wEl = document.getElementById('waresList');
    if (wEl) {
      wEl.innerHTML = DATA.wares.map((w, idx) => {
        const active = idx === state.activeWareIdx;
        return `
          <div class="item-card ${active ? 'verified' : ''}">
            <h3>[${idx + 1}] ${w.categoryName} (Stok: ${state.wareStock[idx]})</h3>
            <p>${w.bonusProfile}</p>
            <div style="margin-top:8px;">
              <button class="big-hud-btn ${active ? 'active' : ''}" onclick="window.KAGE_WORLD.selectWare(${idx})">
                ${active ? '✅ Sedang Dijual' : 'Jual Barang Ini'}
              </button>
            </div>
          </div>
        `;
      }).join('');
    }

    // 4. Intervensi Salah Paham
    const misEl = document.getElementById('misunderstandingList');
    if (misEl) {
      misEl.innerHTML = state.misunderstandings.map(m => `
        <div class="item-card ${m.resolved ? 'verified' : 'urgent'}">
          <span class="badge ${m.resolved ? 'ok' : 'alert'}">${m.resolved ? '✅ SELESAI' : '⚠️ SALAH PAHAM WARGA'}</span>
          <h3>${m.accuserName} menuduh ${m.victimName}</h3>
          <p>${m.summary}</p>
          ${m.resolved
            ? `<p style="color:#78E08F; margin-top:6px;"><strong>Hasil:</strong> ${m.outcomeText}</p>`
            : `<div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
                <button class="big-hud-btn" onclick="window.KAGE_WORLD.resolveMis('${m.id}','MenyerahkanBukti')">1. Tunjukkan Bukti</button>
                <button class="big-hud-btn" onclick="window.KAGE_WORLD.resolveMis('${m.id}','Bersaksi')">2. Bantu Jelaskan</button>
              </div>`
          }
        </div>
      `).join('');
    }

    // 5. Misi dari Kawan Kelompok (Sabu) & Pilihan Warna Pakaian Samaran Malam Realistis
    const ordEl = document.getElementById('ordersAndNisshiList');
    if (ordEl) {
      const camoHtml = `
        <div class="item-card verified">
          <span class="badge ok">🌙 Pakaian Samaran Malam Realistis (Tidak Harus Hitam)</span>
          <h3>Pilih Warna Pakaian Menyamar Malam Hari (Hanya Bisa Dipakai Pukul 18:00–05:00)</h3>
          <p>Sesuai tradisi shinobi realistis, pakaian menyamar malam menggunakan warna biru nila gelap, abu arang, atau hijau lumut agar menyatu dengan bayangan malam.</p>
          <div style="display:flex; gap:8px; flex-wrap:wrap; margin-top:10px;">
            ${NIGHT_CAMO_STYLES.map((cm, idx) => `
              <button class="big-hud-btn ${idx === state.nightCamoIdx ? 'active' : ''}" onclick="window.KAGE_WORLD.selectNightCamo(${idx})">
                ${idx === state.nightCamoIdx ? '✅ ' : ''}${cm.name}
              </button>
            `).join('')}
          </div>
        </div>
      `;

      const sabuOrders = DATA.orders.map(o => {
        const done = state.completedOrders.has(o.id);
        return `
          <div class="item-card ${done ? 'verified' : 'urgent'}">
            <span class="badge ${done ? 'ok' : 'alert'}">${done ? '✅ MISI SELESAI DILAPORKAN KE SABU' : `🕵️ Arahan Kawan Kelompok (Sabu) • Minggu ${o.weekNumber}`}</span>
            <h3>${o.title}</h3>
            <p>Cara Menyelesaikan: Tanyai pembeli di siang hari (<code>[F]</code> → <code>[3] Tanya Petunjuk Misi</code>), atau salin bukti fisik saat malam hari, lalu temui <strong>Sabu di Pohon Aras Tua</strong>. Imbalan: <strong>+${o.rewardCapitalMon} mon</strong>.</p>
            <div style="margin-top:8px;">
              <button class="big-hud-btn" onclick="window.KAGE_WORLD.teleportTo('place_titik_serah_hutan'); window.KAGE_WORLD.closeDrawers();">
                🌲 Temui Kawanmu Sabu di Pohon Aras Tua
              </button>
            </div>
          </div>
        `;
      }).join('');

      ordEl.innerHTML = camoHtml + sabuOrders;
    }
  }

  // =========================================================================
  // 9. INPUT HANDLERS: SMOOTH NON-INVERTED MOUSE LOOK, POINTERLOCK, ZOOM & KEYS
  // =========================================================================
  const keys = {};
  window.addEventListener('keydown', e => {
    keys[e.code] = true;
    SoundEngine.init();
    if (e.code === 'Escape') closeDrawers();
    else if (e.code === 'KeyE') triggerPrimaryAction();
    else if (e.code === 'KeyF') triggerGatherRumor();
    else if (e.code === 'KeyR') cycleCarrierStyle();
    else if (e.code === 'KeyM') openDrawer('map');
    else if (e.code === 'Tab') { e.preventDefault(); openDrawer('inkboard'); }
    else if (e.code === 'KeyX') openDrawer('wares');
    else if (e.code === 'KeyG') openDrawer('intervene');
    else if (e.code === 'KeyJ' || e.code === 'KeyN') openDrawer('orders');
    else if (e.code === 'KeyZ' || e.code === 'AltLeft') { e.preventDefault(); triggerShadowMeldOrGarb(); }
    else if (e.code === 'KeyV') {
      state.listenMode = state.listenMode === 1 ? 0 : 1;
      showToast(state.listenMode === 1 ? '👁️ MATA TELINGA AKTIF: Memfokuskan pendengaran pada langkah & bisikan sekitar!' : 'Mata Telinga dinonaktifkan.');
    }
    else if (e.code === 'KeyL') triggerKaginawa();
    else if (e.code === 'KeyC') toggleViewMode();
    else if (e.code === 'KeyT') advanceTimeHours(6);
    else if (e.code === 'Equal' || e.code === 'NumpadAdd') zoomCamera(-2.0);
    else if (e.code === 'Minus' || e.code === 'NumpadSubtract') zoomCamera(2.0);
    else if (e.code === 'Digit1') askCustomerOption(1);
    else if (e.code === 'Digit2') askCustomerOption(2);
    else if (e.code === 'Digit3') askCustomerOption(3);
    else if (e.code === 'Digit4') askCustomerOption(4);
  });
  window.addEventListener('keyup', e => { keys[e.code] = false; });

  // Smooth, Natural Non-Inverted Mouse Look (Supports both Dragging and Click-to-PointerLock!)
  let dragging = false, lastMX = 0, lastMY = 0;
  canvas.addEventListener('mousedown', e => {
    SoundEngine.init();
    dragging = true;
    lastMX = e.clientX;
    lastMY = e.clientY;
  });
  canvas.addEventListener('dblclick', () => {
    if (canvas.requestPointerLock) canvas.requestPointerLock();
  });
  window.addEventListener('mouseup', () => { dragging = false; });
  window.addEventListener('contextmenu', e => e.preventDefault());
  window.addEventListener('mousemove', e => {
    const locked = (document.pointerLockElement === canvas);
    if (!dragging && !locked) return;
    const dx = locked ? (e.movementX || 0) : (e.clientX - lastMX);
    const dy = locked ? (e.movementY || 0) : (e.clientY - lastMY);
    lastMX = e.clientX;
    lastMY = e.clientY;
    // Natural, non-inverted mouse rotation: moving mouse right turns right; moving mouse up looks up
    state.player.yaw += dx * 0.0042;
    const ySign = state.invertMouseY ? -1 : 1;
    state.player.pitch = Math.max(-0.55, Math.min(0.82, state.player.pitch + dy * 0.0032 * ySign));
  });

  function zoomCamera(delta) {
    if (state.viewMode === 'FIRST_PERSON') {
      state.fovDeg = Math.max(35.0, Math.min(78.0, state.fovDeg + delta * 2.2));
      showToast(`🔍 Zoom Pandangan 1st-Person: FOV ${Math.round(state.fovDeg)}°`);
    } else {
      state.camDist = Math.max(3.2, Math.min(38.0, state.camDist + delta));
    }
  }

  canvas.addEventListener('wheel', e => {
    e.preventDefault();
    zoomCamera(e.deltaY * 0.014);
  }, { passive: false });

  function toggleAudio() {
    SoundEngine.enabled = !SoundEngine.enabled;
    if (SoundEngine.enabled) SoundEngine.init();
    const btn = document.getElementById('btnAudioToggle');
    if (btn) {
      btn.classList.toggle('active', SoundEngine.enabled);
      btn.textContent = SoundEngine.enabled ? '🔊 BGM & SFX' : '🔇 BGM Mati';
    }
    showToast(SoundEngine.enabled ? '🔊 Soundtrack, BGM & Sound Effect Aktif!' : '🔇 Suara Dimatikan.');
  }

  function openDrawer(name) {
    closeDrawers();
    renderDrawers();
    const el = document.getElementById('drawer_' + name);
    if (el) el.style.display = 'flex';
  }
  function closeDrawers() {
    document.querySelectorAll('.drawer-modal').forEach(el => { el.style.display = 'none'; });
  }
  function selectWare(idx) {
    state.activeWareIdx = idx;
    SoundEngine.playAskChime();
    showToast(`🧺 Barang dagangan diganti ke: ${DATA.wares[idx].categoryName}`);
    renderDrawers();
    updateHUD();
  }
  function teleportTo(placeId) {
    const p = placeMap[placeId];
    if (!p) return;
    state.player.x = p.mapX;
    state.player.z = p.mapY - 12;
    state.player.y = 0;
    SoundEngine.playFootstepAndCart(CARRIER_STYLES[state.carrierIdx].id, false);
    showToast(`🚶 Tiba di ${p.name}`);
    updateHUD();
  }
  function toggleViewMode() {
    state.viewMode = state.viewMode === 'THIRD_PERSON' ? 'FIRST_PERSON' : 'THIRD_PERSON';
    SoundEngine.playAskChime();
    showToast(state.viewMode === 'FIRST_PERSON'
      ? '👁️ Kamera Orang Pertama (1st-Person) Aktif! Gunakan Scroll / [+][-] untuk Zoom.'
      : '🎥 Kamera Orang Ketiga (3rd-Person) Aktif! Gunakan Scroll / [+][-] untuk Zoom.');
    updateHUD();
  }
  function advanceTimeHours(hrs) {
    state.hour += hrs;
    while (state.hour >= 24.0) {
      state.hour -= 24.0;
      state.day += 1;
      state.mon = Math.max(0, state.mon - 15);
    }
    if (!isNightTime() && state.garbMode === 'URA') {
      state.garbMode = 'OMOTE';
    }
    SoundEngine.playAskChime();
    showToast(isNightTime()
      ? '🌙 Malam Tiba di Lembah Kurokawa! Tekan [Z] untuk memakai Pakaian Samaran Malam & menjalankan misi.'
      : '☀️ Siang Tiba! Sōma kembali berkeliling sebagai pedagang normal.');
    updateNpcsAndApproachingCustomers(0.4);
    updateHUD();
  }

  // =========================================================================
  // 10. ARTICULATED 3D CHARACTERS WITH STEPPING FEET & 4 CARRIER MODELS
  // =========================================================================
  function appendArticulatedCharacter(list, x, y, z, yaw, walkCycle, robeHex, haoriHex, obiHex, accentHex, modeType, carrierStyleId, wheelAngle, hasGuardGear) {
    const cosY = Math.cos(yaw), sinY = Math.sin(yaw);
    const toW = (lx, ly, lz) => ({
      x: x + (lx * cosY + lz * sinY),
      y: y + ly,
      z: z + (-lx * sinY + lz * cosY)
    });

    // Clear, smooth left/right leg & foot stepping animation (Poin 1: "ada langkah kakinya yang bergerak")
    const stride = Math.sin(walkCycle) * 0.36;
    const liftL = Math.max(0, Math.cos(walkCycle)) * 0.12;
    const liftR = Math.max(0, -Math.cos(walkCycle)) * 0.12;
    const bodyBob = Math.abs(Math.sin(walkCycle)) * 0.045;

    const legCol = hexRgb(modeType === 'URA' ? '#1E242E' : '#2C3A4E');
    const sandalCol = hexRgb('#C8A870');
    const robeRgb = hexRgb(robeHex);
    const haoriRgb = hexRgb(haoriHex || robeHex);
    const obiRgb = hexRgb(obiHex || accentHex);
    const accRgb = hexRgb(accentHex);
    const skinRgb = hexRgb('#E6C7A8');

    // Left & Right Legs + Distinct Stepping Feet (Waraji Sandals)
    const lLeg = toW(-0.14, 0.40 + liftL * 0.5, stride * 0.48);
    const rLeg = toW( 0.14, 0.40 + liftR * 0.5, -stride * 0.48);
    list.push({ mesh:'cylinder', tex:'cloth', rgb:legCol, x:lLeg.x, y:lLeg.y, z:lLeg.z, rx:stride*0.55, ry:yaw, sx:0.15, sy:0.74, sz:0.15, isCharacter:true });
    list.push({ mesh:'cylinder', tex:'cloth', rgb:legCol, x:rLeg.x, y:rLeg.y, z:rLeg.z, rx:-stride*0.55, ry:yaw, sx:0.15, sy:0.74, sz:0.15, isCharacter:true });

    const lFoot = toW(-0.14, 0.06 + liftL, stride * 0.68 + 0.06);
    const rFoot = toW( 0.14, 0.06 + liftR, -stride * 0.68 + 0.06);
    list.push({ mesh:'box', tex:'wood', rgb:sandalCol, x:lFoot.x, y:lFoot.y, z:lFoot.z, rx:stride*0.25, ry:yaw, sx:0.16, sy:0.09, sz:0.28, isCharacter:true });
    list.push({ mesh:'box', tex:'wood', rgb:sandalCol, x:rFoot.x, y:rFoot.y, z:rFoot.z, rx:-stride*0.25, ry:yaw, sx:0.16, sy:0.09, sz:0.28, isCharacter:true });

    // Layered Kimono Torso + Haori + Contrasting Obi Sash (Colorful Character Design per Poin 3)
    const tPos = toW(0, 0.88 + bodyBob, 0);
    list.push({ mesh:'torso', tex:'cloth', rgb:robeRgb, x:tPos.x, y:tPos.y, z:tPos.z, ry:yaw, sx:1, sy:1, sz:1, isCharacter:true });
    const obiPos = toW(0, 0.82 + bodyBob, 0);
    list.push({ mesh:'cylinder', tex:'cloth', rgb:obiRgb, x:obiPos.x, y:obiPos.y, z:obiPos.z, ry:yaw, sx:0.54, sy:0.16, sz:0.50, isCharacter:true });

    // Head + Expressive Face Band / Hair + Role Hat
    const hPos = toW(0, 1.58 + bodyBob, 0);
    list.push({ mesh:'head', tex:'cloth', rgb:skinRgb, x:hPos.x, y:hPos.y, z:hPos.z, ry:yaw, sx:1, sy:1, sz:1, isCharacter:true });
    if (modeType === 'URA') {
      // Realistic Non-Black Shinobi Night Hood & Half-Wrap
      list.push({ mesh:'cylinder', tex:'cloth', rgb:haoriRgb, x:hPos.x, y:hPos.y+0.04, z:hPos.z, ry:yaw, sx:0.26, sy:0.28, sz:0.26, isCharacter:true });
    } else {
      list.push({ mesh:'hat', tex:'wood', rgb:accRgb, x:hPos.x, y:hPos.y+0.08, z:hPos.z, ry:yaw, sx:1.25, sy:0.95, sz:1.25, isCharacter:true });
    }

    // Arms (Positioned naturally for Cart pushing, Tentengan carrying, or walking)
    const pushingCart = (modeType === 'OMOTE' && carrierStyleId === 'CARRIER_CART');
    const lArm = toW(-0.30, 1.15 + bodyBob, pushingCart ? 0.26 : -stride * 0.25);
    const rArm = toW( 0.30, 1.15 + bodyBob, pushingCart ? 0.26 : stride * 0.25);
    list.push({ mesh:'cylinder', tex:'cloth', rgb:haoriRgb, x:lArm.x, y:lArm.y, z:lArm.z, rx:pushingCart ? -0.65 : -stride*0.45, ry:yaw, sx:0.13, sy:0.52, sz:0.13, isCharacter:true });
    list.push({ mesh:'cylinder', tex:'cloth', rgb:haoriRgb, x:rArm.x, y:rArm.y, z:rArm.z, rx:pushingCart ? -0.65 : stride*0.45, ry:yaw, sx:0.13, sy:0.52, sz:0.13, isCharacter:true });

    // =========================================================================
    // 4 SWITCHABLE MERCHANT CARRIER 3D MODELS FOR SŌMA (Poin 1)
    // =========================================================================
    if (modeType === 'OMOTE' && carrierStyleId) {
      if (carrierStyleId === 'CARRIER_CART') {
        // 1. Gerobak Dorong Kayu Beroda (Daisen-Guruma Handcart in front of Sōma)
        const cartPos = toW(0, 0.58, 1.38);
        list.push({ mesh:'box', tex:'wood', rgb:hexRgb('#7A5434'), x:cartPos.x, y:cartPos.y, z:cartPos.z, ry:yaw, sx:1.28, sy:0.22, sz:1.65, isCharacter:true });
        // Side rails & handle shafts
        const hL = toW(-0.46, 0.82, 0.65), hR = toW(0.46, 0.82, 0.65);
        list.push({ mesh:'box', tex:'wood', rgb:hexRgb('#5C3D24'), x:hL.x, y:hL.y, z:hL.z, rx:0.18, ry:yaw, sx:0.08, sy:0.08, sz:1.55, isCharacter:true });
        list.push({ mesh:'box', tex:'wood', rgb:hexRgb('#5C3D24'), x:hR.x, y:hR.y, z:hR.z, rx:0.18, ry:yaw, sx:0.08, sy:0.08, sz:1.55, isCharacter:true });
        // Colorful Merchant Goods stacked on Cart (Cloth bolts, Herb Chest, Ceramic Jar)
        const g1 = toW(-0.26, 0.92, 1.35), g2 = toW(0.28, 0.90, 1.45), g3 = toW(0, 0.95, 1.82);
        list.push({ mesh:'box', tex:'wood', rgb:hexRgb('#8C6239'), x:g1.x, y:g1.y, z:g1.z, ry:yaw, sx:0.52, sy:0.48, sz:0.58, isCharacter:true });
        list.push({ mesh:'box', tex:'cloth', rgb:hexRgb('#C8232C'), x:g2.x, y:g2.y, z:g2.z, ry:yaw, sx:0.48, sy:0.42, sz:0.52, isCharacter:true });
        list.push({ mesh:'cylinder', tex:'cloth', rgb:hexRgb('#F5B041'), x:g3.x, y:g3.y, z:g3.z, ry:yaw, sx:0.38, sy:0.52, sz:0.38, isCharacter:true });
        // Rotating Left & Right Wooden Cart Wheels!
        const wL = toW(-0.70, 0.45, 1.42), wR = toW(0.70, 0.45, 1.42);
        list.push({ mesh:'wheel', tex:'wood', rgb:hexRgb('#4A321E'), x:wL.x, y:wL.y, z:wL.z, rx:wheelAngle||0, ry:yaw, sx:1, sy:1, sz:1, isCharacter:true });
        list.push({ mesh:'wheel', tex:'wood', rgb:hexRgb('#4A321E'), x:wR.x, y:wR.y, z:wR.z, rx:wheelAngle||0, ry:yaw, sx:1, sy:1, sz:1, isCharacter:true });
      } else if (carrierStyleId === 'CARRIER_TENTENGAN') {
        // 2. Tentengan Keranjang Bambu & Bungkusan Kain Furoshiki di Kedua Tangan
        const tL = toW(-0.44, 0.72 + bodyBob, 0.12 - stride * 0.25);
        const tR = toW( 0.44, 0.72 + bodyBob, 0.12 + stride * 0.25);
        list.push({ mesh:'box', tex:'cloth', rgb:hexRgb('#D25238'), x:tL.x, y:tL.y, z:tL.z, ry:yaw, sx:0.38, sy:0.38, sz:0.38, isCharacter:true });
        list.push({ mesh:'cylinder', tex:'wood', rgb:hexRgb('#C89E58'), x:tR.x, y:tR.y, z:tR.z, ry:yaw, sx:0.40, sy:0.42, sz:0.40, isCharacter:true });
      } else if (carrierStyleId === 'CARRIER_PIKULAN') {
        // 3. Pikulan Bambu Tenbinbō
        const pCenter = toW(0, 1.42 + bodyBob, 0);
        list.push({ mesh:'box', tex:'wood', rgb:hexRgb('#A37E56'), x:pCenter.x, y:pCenter.y, z:pCenter.z, ry:yaw, sx:2.25, sy:0.08, sz:0.10, isCharacter:true });
        const bL = toW(-0.96, 0.88 + bodyBob, 0), bR = toW(0.96, 0.88 + bodyBob, 0);
        list.push({ mesh:'box', tex:'wood', rgb:hexRgb('#8C6239'), x:bL.x, y:bL.y, z:bL.z, ry:yaw, sx:0.54, sy:0.60, sz:0.54, isCharacter:true });
        list.push({ mesh:'box', tex:'wood', rgb:hexRgb('#8C6239'), x:bR.x, y:bR.y, z:bR.z, ry:yaw, sx:0.54, sy:0.60, sz:0.54, isCharacter:true });
      } else if (carrierStyleId === 'CARRIER_RANSEL') {
        // 4. Ransel Rak Kayu Punggung (Seoi-Bako)
        const bk = toW(0, 1.16 + bodyBob, -0.34);
        list.push({ mesh:'box', tex:'wood', rgb:hexRgb('#7A5434'), x:bk.x, y:bk.y, z:bk.z, ry:yaw, sx:0.58, sy:0.92, sz:0.42, isCharacter:true });
        const topRoll = toW(0, 1.70 + bodyBob, -0.34);
        list.push({ mesh:'cylinder', tex:'cloth', rgb:hexRgb('#C8232C'), x:topRoll.x, y:topRoll.y, z:topRoll.z, rz:Math.PI*0.5, ry:yaw, sx:0.26, sy:0.62, sz:0.26, isCharacter:true });
      }
    }

    if (hasGuardGear) {
      const ban = toW(0, 1.55 + bodyBob, -0.24);
      list.push({ mesh:'box', tex:'cloth', rgb:hexRgb('#EFE6D2'), x:ban.x, y:ban.y, z:ban.z, ry:yaw, sx:0.28, sy:0.56, sz:0.04, isCharacter:true });
      const hip = toW(-0.26, 0.88 + bodyBob, 0.12);
      list.push({ mesh:'box', tex:'shoji', rgb:hexRgb('#F5B041'), emissive:1.2, x:hip.x, y:hip.y, z:hip.z, ry:yaw, sx:0.12, sy:0.16, sz:0.12, isCharacter:true });
    }
  }

  // First-Person Viewmodel (Shows Sōma's hands holding the Cart/Bundle in daytime, or Night Camo sleeves at night!)
  function buildFirstPersonViewmodel(cam) {
    const vm = [];
    const cosY = Math.cos(cam.yaw), sinY = Math.sin(cam.yaw);
    const cosP = Math.cos(cam.pitch), sinP = Math.sin(cam.pitch);
    const toW = (lx, ly, lz) => {
      const py = ly * cosP - lz * sinP, pz = ly * sinP + lz * cosP;
      return { x: cam.x + (lx * cosY + pz * sinY), y: cam.y + py, z: cam.z + (-lx * sinY + pz * cosY) };
    };
    const bob = Math.sin(state.player.walkCycle) * 0.015;
    const isOmote = state.garbMode === 'OMOTE';
    const sleeveHex = isOmote ? '#27406B' : NIGHT_CAMO_STYLES[state.nightCamoIdx].robeHex;

    const lWr = toW(-0.24, -0.24 + bob, 0.44);
    const rWr = toW( 0.24, -0.24 - bob, 0.44);
    vm.push({ mesh:'cylinder', tex:'cloth', rgb:hexRgb(sleeveHex), x:lWr.x, y:lWr.y, z:lWr.z, rx:cam.pitch, ry:cam.yaw, sx:0.065, sy:0.24, sz:0.065, isCharacter:true });
    vm.push({ mesh:'cylinder', tex:'cloth', rgb:hexRgb(sleeveHex), x:rWr.x, y:rWr.y, z:rWr.z, rx:cam.pitch, ry:cam.yaw, sx:0.065, sy:0.24, sz:0.065, isCharacter:true });

    if (isOmote && CARRIER_STYLES[state.carrierIdx].id === 'CARRIER_CART') {
      const bar = toW(0, -0.26 + bob * 0.5, 0.58);
      vm.push({ mesh:'box', tex:'wood', rgb:hexRgb('#7A5434'), x:bar.x, y:bar.y, z:bar.z, rx:cam.pitch, ry:cam.yaw, sx:0.65, sy:0.05, sz:0.06, isCharacter:true });
    } else if (isOmote && CARRIER_STYLES[state.carrierIdx].id === 'CARRIER_TENTENGAN') {
      const bundle = toW(0.26, -0.28 - bob, 0.52);
      vm.push({ mesh:'box', tex:'cloth', rgb:hexRgb('#D25238'), x:bundle.x, y:bundle.y, z:bundle.z, rx:cam.pitch, ry:cam.yaw, sx:0.18, sy:0.18, sz:0.18, isCharacter:true });
    }
    return vm;
  }

  const projMat = Mat4.create();
  const viewMat = Mat4.create();
  const vpMat   = Mat4.create();
  const modelMat= Mat4.create();

  function resize() {
    const dpr = Math.min(2.0, window.devicePixelRatio || 1.0);
    canvas.width = Math.max(640, Math.floor(window.innerWidth * dpr));
    canvas.height = Math.max(360, Math.floor(window.innerHeight * dpr));
  }
  resize();
  window.addEventListener('resize', resize);

  function renderWebGLScene(dt) {
    const dayFactor = (state.hour >= 6.0 && state.hour <= 17.5)
      ? 1.0
      : ((state.hour > 17.5 && state.hour < 19.0) ? (1.0 - (state.hour - 17.5) / 1.5) : 0.08);

    const totalYaw = state.player.yaw + state.camYawOffset;
    let cam = {};
    if (state.viewMode === 'FIRST_PERSON') {
      const headBob = Math.abs(Math.sin(state.player.walkCycle)) * 0.035;
      cam = {
        x: state.player.x,
        y: state.player.y + 1.66 + headBob,
        z: state.player.z,
        yaw: totalYaw,
        pitch: state.player.pitch * 0.65
      };
    } else {
      const backAngle = totalYaw + Math.PI;
      const shoulderRight = totalYaw + Math.PI * 0.5;
      cam = {
        x: state.player.x + Math.sin(backAngle) * Math.cos(state.player.pitch) * state.camDist + Math.sin(shoulderRight) * 0.45,
        y: state.player.y + 2.0 + Math.sin(state.player.pitch) * state.camDist,
        z: state.player.z + Math.cos(backAngle) * Math.cos(state.player.pitch) * state.camDist + Math.cos(shoulderRight) * 0.45,
        yaw: totalYaw,
        pitch: -state.player.pitch * 0.55
      };
    }

    gl.viewport(0, 0, canvas.width, canvas.height);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // 1. Pass 0: Bokashi Sky
    gl.disable(gl.DEPTH_TEST);
    gl.depthMask(false);
    gl.useProgram(skyProg);
    const sPos = gl.getAttribLocation(skyProg, 'aQuadPos');
    gl.bindBuffer(gl.ARRAY_BUFFER, skyQuadBuf);
    gl.enableVertexAttribArray(sPos);
    gl.vertexAttribPointer(sPos, 2, gl.FLOAT, false, 0, 0);
    gl.uniform1f(gl.getUniformLocation(skyProg, 'uCameraYaw'), cam.yaw);
    gl.uniform1f(gl.getUniformLocation(skyProg, 'uCameraPitch'), cam.pitch);
    gl.uniform1f(gl.getUniformLocation(skyProg, 'uDayFactor'), dayFactor);
    gl.uniform1i(gl.getUniformLocation(skyProg, 'uListenMode'), state.listenMode);
    gl.drawArrays(gl.TRIANGLES, 0, 6);
    gl.depthMask(true);
    gl.enable(gl.DEPTH_TEST);
    gl.enable(gl.CULL_FACE);

    const frameItems = [];
    for (let i = 0; i < staticScene.length; i++) {
      const it = staticScene[i];
      if (Math.hypot(it.x - state.player.x, it.z - state.player.z) < 340) {
        frameItems.push(it);
      }
    }

    const nearLanterns = [];
    worldLanterns.forEach(l => {
      const lx = l.x + (l.shiftOffset || 0);
      const d = Math.hypot(lx - state.player.x, l.z - state.player.z);
      if (d < 180) {
        frameItems.push({ mesh:'cylinder', tex:'stone', rgb:hexRgb('#687080'), x:lx, y:0.65, z:l.z, sx:0.36, sy:1.3, sz:0.36 });
        frameItems.push({ mesh:'box', tex:'shoji', rgb:hexRgb(l.lit ? '#F5B041' : '#2A2E38'), emissive:l.lit ? 1.5 : 0.0, x:lx, y:1.42, z:l.z, sx:0.46, sy:0.38, sz:0.46 });
        frameItems.push({ mesh:'hat', tex:'stone', rgb:hexRgb('#2B3240'), x:lx, y:1.62, z:l.z, sx:0.85, sy:0.85, sz:0.85 });
        if (l.lit) {
          frameItems.push({ mesh:'ring', tex:'shoji', rgb:hexRgb('#F5B041'), emissive:0.85, x:lx, y:0.04, z:l.z, sx:3.4, sy:1, sz:3.4, outlineWidth:0 });
          nearLanterns.push({ x:lx, z:l.z, d });
        }
      }
    });
    nearLanterns.sort((a, b) => a.d - b.d);

    INTEL_NODES.forEach(node => {
      if (node.collected) return;
      frameItems.push({ mesh:'box', tex:'cloth', rgb:hexRgb('#C8232C'), emissive:1.1, x:node.x, y:0.95, z:node.z, ry:state.hour*3.0, sx:0.75, sy:0.75, sz:0.75 });
      frameItems.push({ mesh:'ring', tex:'shoji', rgb:hexRgb('#F5B041'), emissive:1.2, x:node.x, y:0.05, z:node.z, sx:2.2, sy:1, sz:2.2, outlineWidth:0 });
    });

    for (let i = state.inkRipples.length - 1; i >= 0; i--) {
      const rp = state.inkRipples[i];
      rp.r += dt * 6.5;
      frameItems.push({ mesh:'ring', tex:'shoji', rgb:hexRgb(rp.isLethal ? '#C8232C' : '#EFE6D2'), emissive:1.2, x:rp.x, y:0.06, z:rp.z, sx:rp.r, sy:1, sz:rp.r, outlineWidth:0 });
      if (rp.r >= rp.maxR) state.inkRipples.splice(i, 1);
    }

    // 26 Colorful, Expressive NPCs in 3D
    npcsRuntime.forEach(npc => {
      if (Math.hypot(npc.x - state.player.x, npc.z - state.player.z) < 180) {
        appendArticulatedCharacter(
          frameItems,
          npc.x, 0, npc.z,
          npc.yaw, npc.animPhase,
          npc.primaryHex, npc.haoriHex, npc.obiHex, npc.accentHex,
          'OMOTE', null, 0, npc.isGuard
        );
      }
    });

    // Player Sōma (3rd-Person Articulated Model with Stepping Feet & Selected Carrier Model!)
    if (state.viewMode === 'THIRD_PERSON') {
      const isOmote = state.garbMode === 'OMOTE';
      const cm = NIGHT_CAMO_STYLES[state.nightCamoIdx];
      appendArticulatedCharacter(
        frameItems,
        state.player.x, state.player.y, state.player.z,
        state.player.yaw, state.player.walkCycle,
        isOmote ? '#27406B' : cm.robeHex,
        isOmote ? '#3B5C85' : cm.hoodHex,
        isOmote ? '#D8A448' : '#3A4048',
        isOmote ? '#D8B878' : cm.hoodHex,
        state.garbMode,
        isOmote ? CARRIER_STYLES[state.carrierIdx].id : null,
        state.player.wheelAngle,
        false
      );
    }

    const activeFov = state.viewMode === 'FIRST_PERSON' ? state.fovDeg : 58.0;
    Mat4.perspective(projMat, activeFov * Math.PI / 180, canvas.width / canvas.height, 0.15, 480.0);
    if (state.viewMode === 'FIRST_PERSON') {
      const cosP = Math.cos(cam.pitch), sinP = Math.sin(cam.pitch);
      Mat4.lookAt(viewMat, [cam.x, cam.y, cam.z], [cam.x + Math.sin(cam.yaw)*cosP, cam.y + sinP, cam.z + Math.cos(cam.yaw)*cosP], [0, 1, 0]);
    } else {
      Mat4.lookAt(viewMat, [cam.x, cam.y, cam.z], [state.player.x, state.player.y + 1.45, state.player.z], [0, 1, 0]);
    }
    Mat4.multiply(vpMat, projMat, viewMat);

    drawCelAndOutlines(frameItems, cam, dayFactor, nearLanterns);

    if (state.viewMode === 'FIRST_PERSON') {
      gl.clear(gl.DEPTH_BUFFER_BIT);
      const vmItems = buildFirstPersonViewmodel(cam);
      drawCelAndOutlines(vmItems, cam, dayFactor, nearLanterns);
    }
  }

  function drawCelAndOutlines(items, cam, dayFactor, nearLanterns) {
    gl.useProgram(celProg);
    gl.cullFace(gl.BACK);
    gl.uniformMatrix4fv(gl.getUniformLocation(celProg, 'uViewProj'), false, vpMat);
    gl.uniform3f(gl.getUniformLocation(celProg, 'uLightDir'), -0.58, 0.68, -0.45);
    gl.uniform3f(gl.getUniformLocation(celProg, 'uLightColor'), 0.64 + dayFactor*0.44, 0.70 + dayFactor*0.28, 0.86 - dayFactor*0.04);
    gl.uniform3f(gl.getUniformLocation(celProg, 'uAmbientColor'), 0.25 + dayFactor*0.18, 0.28 + dayFactor*0.16, 0.38 + dayFactor*0.08);
    gl.uniform3f(gl.getUniformLocation(celProg, 'uRimColor'), 0.95, 0.74, 0.32);
    gl.uniform3f(gl.getUniformLocation(celProg, 'uFogColor'), 0.24 + dayFactor*0.58, 0.30 + dayFactor*0.48, 0.42 + dayFactor*0.24);
    gl.uniform1f(gl.getUniformLocation(celProg, 'uFogDensity'), 0.0042);
    gl.uniform3f(gl.getUniformLocation(celProg, 'uCameraPos'), cam.x, cam.y, cam.z);
    gl.uniform1i(gl.getUniformLocation(celProg, 'uListenMode'), state.listenMode);

    for (let i = 0; i < 8; i++) {
      const nl = nearLanterns[i];
      gl.uniform3f(gl.getUniformLocation(celProg, `uLanternPos[${i}]`), nl ? nl.x : 0, nl ? 1.5 : -99, nl ? nl.z : 0);
      gl.uniform1f(gl.getUniformLocation(celProg, `uLanternIntensity[${i}]`), nl ? 1.0 : 0.0);
    }

    const uModel = gl.getUniformLocation(celProg, 'uModel');
    const uBaseCol = gl.getUniformLocation(celProg, 'uBaseColor');
    const uEmissive = gl.getUniformLocation(celProg, 'uEmissive');
    const uIsChar = gl.getUniformLocation(celProg, 'uIsCharacter');
    const aPos = gl.getAttribLocation(celProg, 'aPosition');
    const aNorm = gl.getAttribLocation(celProg, 'aNormal');
    const aUV = gl.getAttribLocation(celProg, 'aUV');

    gl.activeTexture(gl.TEXTURE0);
    gl.uniform1i(gl.getUniformLocation(celProg, 'uAlbedoMap'), 0);

    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const m = MESHES[it.mesh];
      if (!m) continue;
      Mat4.fromTRS(modelMat, it.x, it.y, it.z, it.rx||0, it.ry||0, it.rz||0, it.sx, it.sy, it.sz);
      gl.uniformMatrix4fv(uModel, false, modelMat);
      gl.uniform3f(uBaseCol, it.rgb[0], it.rgb[1], it.rgb[2]);
      gl.uniform1f(uEmissive, it.emissive || 0.0);
      gl.uniform1i(uIsChar, it.isCharacter ? 1 : 0);
      gl.bindTexture(gl.TEXTURE_2D, TEXTURES[it.tex || 'wood'] || TEXTURES.wood);

      gl.bindBuffer(gl.ARRAY_BUFFER, m.pBuf); gl.enableVertexAttribArray(aPos); gl.vertexAttribPointer(aPos, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, m.nBuf); gl.enableVertexAttribArray(aNorm); gl.vertexAttribPointer(aNorm, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, m.uBuf); gl.enableVertexAttribArray(aUV); gl.vertexAttribPointer(aUV, 2, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.iBuf);
      gl.drawElements(gl.TRIANGLES, m.count, gl.UNSIGNED_SHORT, 0);
    }

    gl.useProgram(outlineProg);
    gl.cullFace(gl.FRONT);
    gl.uniformMatrix4fv(gl.getUniformLocation(outlineProg, 'uViewProj'), false, vpMat);
    gl.uniform3f(gl.getUniformLocation(outlineProg, 'uOutlineColor'), 0.06, 0.08, 0.12);
    gl.uniform3f(gl.getUniformLocation(outlineProg, 'uCameraPos'), cam.x, cam.y, cam.z);
    const uOutModel = gl.getUniformLocation(outlineProg, 'uModel');
    const uOutW = gl.getUniformLocation(outlineProg, 'uOutlineWidth');
    const oPos = gl.getAttribLocation(outlineProg, 'aPosition');
    const oNorm = gl.getAttribLocation(outlineProg, 'aPosition');
    const oNormReal = gl.getAttribLocation(outlineProg, 'aNormal');

    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (it.outlineWidth === 0) continue;
      const m = MESHES[it.mesh];
      if (!m) continue;
      Mat4.fromTRS(modelMat, it.x, it.y, it.z, it.rx||0, it.ry||0, it.rz||0, it.sx, it.sy, it.sz);
      gl.uniformMatrix4fv(uOutModel, false, modelMat);
      gl.uniform1f(uOutW, it.isCharacter ? 0.008 : (it.outlineWidth || 0.020));
      gl.bindBuffer(gl.ARRAY_BUFFER, m.pBuf); gl.enableVertexAttribArray(oPos); gl.vertexAttribPointer(oPos, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ARRAY_BUFFER, m.nBuf); gl.enableVertexAttribArray(oNormReal); gl.vertexAttribPointer(oNormReal, 3, gl.FLOAT, false, 0, 0);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, m.iBuf);
      gl.drawElements(gl.TRIANGLES, m.count, gl.UNSIGNED_SHORT, 0);
    }
    gl.cullFace(gl.BACK);
  }

  // =========================================================================
  // 11. SMOOTH WEIGHTY MERCHANT WALKING LOOP & PUBLIC API
  // =========================================================================
  let lastNow = performance.now();
  function tick(now) {
    if (state.manualPoseMode) return;
    const dt = Math.min(0.05, Math.max(0.001, (now - lastNow) / 1000));
    lastNow = now;

    state.hour += dt * 0.03;
    if (state.hour >= 24.0) { state.hour -= 24.0; state.day += 1; }

    let moveF = (keys['KeyW'] || keys['ArrowUp'] ? 1 : 0) - (keys['KeyS'] || keys['ArrowDown'] ? 1 : 0);
    let moveS = (keys['KeyD'] ? 1 : 0) - (keys['KeyA'] ? 1 : 0);
    if (keys['ArrowLeft']) state.player.yaw -= 1.8 * dt;
    if (keys['ArrowRight']) state.player.yaw += 1.8 * dt;

    // Poin 1: Realistic measured merchant walking pace (cannot run super fast while carrying merchant loads!)
    const carrier = CARRIER_STYLES[state.carrierIdx];
    const baseSpeed = state.garbMode === 'URA' ? 11.5 : carrier.walkSpeed;
    const maxSpeed = (state.garbMode === 'URA' && (keys['ShiftLeft'] || keys['ShiftRight']))
      ? baseSpeed * 1.35
      : ((keys['ShiftLeft'] || keys['ShiftRight']) ? baseSpeed * 1.12 : baseSpeed);

    const fwdX = Math.sin(state.player.yaw), fwdZ = Math.cos(state.player.yaw);
    const rightX = Math.cos(state.player.yaw), rightZ = -Math.sin(state.player.yaw);
    let wishX = fwdX * moveF + rightX * moveS;
    let wishZ = fwdZ * moveF + rightZ * moveS;
    const wishLen = Math.hypot(wishX, wishZ);
    if (wishLen > 0.001) { wishX /= wishLen; wishZ /= wishLen; }

    // Smooth acceleration & deceleration damping
    const accel = 7.5;
    state.player.vx += (wishX * maxSpeed - state.player.vx) * Math.min(1.0, accel * dt);
    state.player.vz += (wishZ * maxSpeed - state.player.vz) * Math.min(1.0, accel * dt);

    const actualSpeed = Math.hypot(state.player.vx, state.player.vz);
    if (actualSpeed > 0.15) {
      state.player.x = Math.max(-440, Math.min(440, state.player.x + state.player.vx * dt));
      state.player.z = Math.max(-440, Math.min(440, state.player.z + state.player.vz * dt));
      state.player.walkCycle += dt * (actualSpeed * 0.92);
      state.player.wheelAngle += dt * (actualSpeed * 1.3);

      const halfCycle = Math.floor(state.player.walkCycle / Math.PI);
      if (halfCycle > state.player.lastStepHalfCycle) {
        state.player.lastStepHalfCycle = halfCycle;
        SoundEngine.playFootstepAndCart(carrier.id, state.garbMode === 'URA');
      }
    }

    if (state.player.y > 0 && !keys['Space']) {
      state.player.y = Math.max(0, state.player.y - 9.5 * dt);
    }

    updateNpcsAndApproachingCustomers(dt);
    renderWebGLScene(dt);
    updateHUD();

    requestAnimationFrame(tick);
  }

  updateNpcsAndApproachingCustomers(1.0);
  updateHUD();
  requestAnimationFrame(tick);

  window.KAGE_WORLD = {
    DATA,
    state,
    npcsRuntime,
    INTEL_NODES,
    CARRIER_STYLES,
    NIGHT_CAMO_STYLES,
    teleportTo,
    triggerPrimaryAction,
    triggerGatherRumor,
    askCustomerOption,
    cycleCarrierStyle,
    selectNightCamo,
    triggerShadowMeldOrGarb,
    triggerKaginawa,
    openDrawer,
    closeDrawers,
    selectWare,
    toggleViewMode,
    toggleAudio,
    zoomCamera,
    advanceTimeHours,
    resolveMis: resolveMisunderstanding,
    setScenePose(opts) {
      state.manualPoseMode = true;
      closeDrawers();
      if (typeof opts.day === 'number') state.day = opts.day;
      if (typeof opts.hour === 'number') state.hour = opts.hour;
      if (opts.garbMode) state.garbMode = opts.garbMode;
      if (typeof opts.carrierIdx === 'number') state.carrierIdx = opts.carrierIdx;
      if (typeof opts.nightCamoIdx === 'number') state.nightCamoIdx = opts.nightCamoIdx;
      if (opts.viewMode) state.viewMode = opts.viewMode;
      if (typeof opts.listenMode === 'number') state.listenMode = opts.listenMode;
      if (typeof opts.wareIdx === 'number') state.activeWareIdx = opts.wareIdx;
      if (opts.placeId && placeMap[opts.placeId]) {
        const pl = placeMap[opts.placeId];
        state.player.x = pl.mapX + (opts.offsetX || 0);
        state.player.z = pl.mapY + (opts.offsetZ || -12);
        state.player.y = opts.y || 0;
      }
      if (typeof opts.x === 'number') state.player.x = opts.x;
      if (typeof opts.y === 'number') state.player.y = opts.y;
      if (typeof opts.z === 'number') state.player.z = opts.z;
      if (typeof opts.yaw === 'number') state.player.yaw = opts.yaw;
      if (typeof opts.pitch === 'number') state.player.pitch = opts.pitch;
      if (typeof opts.camYawOffset === 'number') state.camYawOffset = opts.camYawOffset;
      if (typeof opts.camDist === 'number') state.camDist = opts.camDist;
      if (typeof opts.walkCycle === 'number') state.player.walkCycle = opts.walkCycle;
      updateNpcsAndApproachingCustomers(0.35);
      // If customerNearby is requested for screenshot, place a friendly customer right in front of Sōma
      if (opts.bringCustomerFront) {
        const cust = npcsRuntime.find(n => !n.isGuard && !n.isSabu) || npcsRuntime[0];
        cust.x = state.player.x + Math.sin(state.player.yaw) * 2.8;
        cust.z = state.player.z + Math.cos(state.player.yaw) * 2.8;
        cust.yaw = state.player.yaw + Math.PI;
        cust.isApproachingCustomer = true;
        cust.moodEmoji = '😊';
        cust.moodLabel = 'Pembeli Menghampiri';
        cust.speechText = opts.customerLine || `"Sōma-san, kebetulan lewat! Boleh saya beli daganganmu sekalian berbincang?"`;
      }
      if (opts.bringSabuFront) {
        const sb = npcsRuntime.find(n => n.isSabu) || npcsRuntime[0];
        sb.x = state.player.x + Math.sin(state.player.yaw) * 2.8;
        sb.z = state.player.z + Math.cos(state.player.yaw) * 2.8;
        sb.yaw = state.player.yaw + Math.PI;
        sb.moodEmoji = '🕵️';
        sb.moodLabel = 'Kawan Kelompok (Sabu)';
        sb.speechText = `"Misi kita: cari tahu jadwal jaga Gerbang Selatan & gudang Dermaga lewat bertanya ke pelangganmu."`;
      }
      if (opts.drawer) openDrawer(opts.drawer);
      renderWebGLScene(0.016);
      updateHUD();
    }
  };
})();
</script>
</body>
</html>
"""


def main():
    OUT_HTML.parent.mkdir(parents=True, exist_ok=True)
    bundle = load_canonical_bundle()
    json_str = json.dumps(bundle, ensure_ascii=False)
    final_html = HTML_TEMPLATE.replace("__CANONICAL_JSON__", json_str)
    OUT_HTML.write_text(final_html, encoding="utf-8")
    COPY_HTML.write_text(final_html, encoding="utf-8")
    print(f"Built {OUT_HTML} ({OUT_HTML.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
