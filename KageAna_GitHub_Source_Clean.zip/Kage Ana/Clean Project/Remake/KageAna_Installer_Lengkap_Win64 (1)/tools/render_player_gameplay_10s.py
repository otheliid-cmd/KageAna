#!/usr/bin/env python3
"""
tools/render_player_gameplay_10s.py
Renders 10 seconds (240 frames @ 24 fps, 1280x720) of real 3D player-perspective gameplay
(Third-Person Over-the-Shoulder, Two-Shot Dialog, Mata Telinga Sound-Ink Mode, Night Stealth,
Rooftop Kaginawa & Iaijutsu, and Diegetic Nisshi Scroll) using headless Chromium WebGL + Canvas,
extracts 10 distinct 1280x720 player-POV gameplay PNG screenshots, and encodes a 10-second MP4
video with synchronized Sengoku koto/shakuhachi/taiko/footstep audio.
"""
import base64
import math
import os
import pathlib
import shutil
import subprocess
import tempfile
import wave
import numpy as np
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT_DIR = pathlib.Path("/working_dir/c_66e5364d2f871b20/artifacts/file_generation/ttl=63d/output")


def synthesize_10s_gameplay_audio(wav_path: pathlib.Path):
    sr = 22050
    dur = 10.0
    n = int(sr * dur)
    t = np.linspace(0, dur, n, endpoint=False)
    rng = np.random.default_rng(42)

    # Subtle wind/courtyard ambience
    white = rng.normal(0, 0.04, n)
    amb = np.convolve(white, np.ones(24) / 24.0, mode="same")

    # Pentatonic In-sen Koto plucks (Karplus-Strong) at key transitions
    notes = [
        (0.2, 196.00, 1.2),
        (0.9, 220.00, 1.1),
        (1.6, 261.63, 1.3),
        (2.5, 196.00, 1.4),
        (3.4, 155.56, 1.5),
        (4.5, 220.00, 1.2),
        (5.5, 146.83, 1.8),
        (6.8, 155.56, 1.4),
        (8.1, 293.66, 1.2),
        (9.0, 196.00, 1.0),
    ]
    music = np.zeros(n, dtype=np.float64)
    for start_s, freq, note_dur in notes:
        i0 = int(start_s * sr)
        length = min(int(note_dur * sr), n - i0)
        if length <= 0:
            continue
        delay = max(2, int(sr / freq))
        buf = rng.uniform(-1.0, 1.0, delay).astype(np.float64)
        for k in range(length):
            music[i0 + k] += 0.28 * buf[k % delay]
            buf[k % delay] = 0.5 * (buf[k % delay] + buf[(k + 1) % delay]) * 0.994

    # Shakuhachi breath swell during Night/Mata Telinga (6.0s - 8.5s)
    shaku_mask = (t >= 5.8) & (t <= 8.8)
    ts = t[shaku_mask] - 5.8
    env = np.sin(np.pi * ts / 3.0)
    music[shaku_mask] += 0.22 * env * (np.sin(2 * np.pi * 293.66 * ts) + 0.35 * np.sin(2 * np.pi * 587.33 * ts))

    # Taiko pulse at Guard confrontation (3.2s) & Iai strike (8.2s)
    for pulse_s in (3.1, 4.2, 8.15):
        i0 = int(pulse_s * sr)
        plen = min(int(0.65 * sr), n - i0)
        tp = np.linspace(0, 0.65, plen, endpoint=False)
        f_sweep = 95.0 * np.exp(-tp * 6.0) + 44.0
        music[i0 : i0 + plen] += 0.48 * np.sin(2 * np.pi * f_sweep * tp) * np.exp(-tp * 5.5)

    # Iai sword metallic ring at 8.2s
    i_iai = int(8.20 * sr)
    ilen = min(int(0.35 * sr), n - i_iai)
    ti = np.linspace(0, 0.35, ilen, endpoint=False)
    music[i_iai : i_iai + ilen] += 0.32 * np.sin(2 * np.pi * 2150.0 * ti) * np.exp(-ti * 14.0)

    # Footsteps throughout walking segments
    for step_s in np.arange(0.3, 9.6, 0.42):
        i0 = int(step_s * sr)
        slen = min(int(0.12 * sr), n - i0)
        tsf = np.linspace(0, 0.12, slen, endpoint=False)
        music[i0 : i0 + slen] += 0.16 * np.sin(2 * np.pi * 240.0 * np.exp(-tsf * 15.0) * tsf) * np.exp(-tsf * 28.0)

    mix = amb + music
    peak = np.max(np.abs(mix))
    if peak > 1e-6:
        mix = mix / peak * 0.85
    pcm16 = np.clip(mix * 32767.0, -32768, 32767).astype(np.int16)
    with wave.open(str(wav_path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sr)
        wf.writeframes(pcm16.tobytes())


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    tmp_dir = pathlib.Path(tempfile.mkdtemp(prefix="kageana_vid_"))

    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=1280,720")
    opts.add_argument("--use-gl=angle")
    opts.add_argument("--use-angle=swiftshader")
    opts.add_argument("--enable-webgl")
    opts.add_argument("--ignore-gpu-blocklist")

    driver = webdriver.Chrome(options=opts)
    try:
        import re
        webgl_dir = ROOT / "webgl_vertical_slice"
        driver.get("about:blank")
        css_content = (webgl_dir / "css" / "sengoku_ui.css").read_text(encoding="utf-8")
        index_html = (webgl_dir / "index.html").read_text(encoding="utf-8")
        body_match = re.search(r"<body[^>]*>(.*?)<script", index_html, re.DOTALL)
        body_html = body_match.group(1) if body_match else index_html
        driver.execute_script(
            """
            const style = document.createElement('style');
            style.textContent = arguments[0];
            document.head.appendChild(style);
            document.body.innerHTML = arguments[1];
            """,
            css_content,
            body_html,
        )
        for jf in [
            "src/data_bundle.js",
            "src/renderer/Shaders.js",
            "src/renderer/ProceduralTextures.js",
            "src/renderer/MeshBuilder.js",
            "src/renderer/WebGLRenderer.js",
            "src/game/SceneAssembler.js",
            "src/game/GameplayControllers.js",
            "src/main.js",
        ]:
            driver.execute_script((webgl_dir / jf).read_text(encoding="utf-8"))

        # Configure the 3D engine for pure player-POV gameplay (with 3D third-person Soma avatar + diegetic overlay canvas)
        driver.execute_script(
            r"""
            const s = window.KAGE_VERTICAL_SLICE;
            s.state.paused = true;
            s.state.showDebugTelemetry = false;
            document.getElementById('hudRoot').style.display = 'none'; // Replaced by clean diegetic 2D overlay canvas burned directly into each frame

            const hudCanvas = document.createElement('canvas');
            hudCanvas.id = 'diegeticPlayerCanvas';
            hudCanvas.width = 1280;
            hudCanvas.height = 720;
            hudCanvas.style.position = 'fixed';
            hudCanvas.style.inset = '0';
            hudCanvas.style.zIndex = '30';
            hudCanvas.style.pointerEvents = 'none';
            document.body.appendChild(hudCanvas);

            const outCanvas = document.createElement('canvas');
            outCanvas.id = 'compositeCanvas';
            outCanvas.width = 1280;
            outCanvas.height = 720;

            window.renderPlayerGameplayFrame = function(cfg) {
                const glCanvas = document.getElementById('webglCanvas');
                s.renderer.width = 1280;
                s.renderer.height = 720;
                glCanvas.width = 1280;
                glCanvas.height = 720;

                s.renderer.timePreset = cfg.timePreset || 'SORE';
                s.renderer.listenMode = cfg.listenMode ? 1 : 0;
                s.renderer.photoMode = cfg.photoMode ? 1 : 0;
                s.renderer.debugMode = 0;

                // Position NPCs for the current gameplay scene
                const npcs = s.guardAI.npcs;
                if (cfg.npcOverrides) {
                    for (let i = 0; i < cfg.npcOverrides.length && i < npcs.length; i++) {
                        const ov = cfg.npcOverrides[i];
                        if (!ov) continue;
                        if (ov.x !== undefined) npcs[i].x = ov.x;
                        if (ov.y !== undefined) npcs[i].y = ov.y;
                        if (ov.z !== undefined) npcs[i].z = ov.z;
                        if (ov.yaw !== undefined) npcs[i].yaw = ov.yaw;
                        if (ov.tunicColor) npcs[i].tunicColor = ov.tunicColor;
                        if (ov.archetype) npcs[i].archetype = ov.archetype;
                        npcs[i].isDead = !!ov.isDead;
                        npcs[i].isMoving = !!ov.isMoving;
                        npcs[i].animPhase = ov.animPhase || 0.0;
                        npcs[i].windupTimer = ov.windupTimer || 0.0;
                    }
                }

                s.state.vfxDecals = cfg.vfxDecals || [];
                s.state.inkRipples = cfg.inkRipples || [];
                s.state.kageEchoGhost = cfg.kageEchoGhost || { active: false, x: 0, z: 0, yaw: 0 };

                const dynItems = s.assembler.buildDynamicFrameItems(
                    s.lanterns, npcs, s.state.vfxDecals, s.state.inkRipples, s.state.kageEchoGhost, 'HIGH', 0.016
                );

                // Build Third-Person Player Avatar (Shinonome Soma) in front of the over-the-shoulder camera!
                if (cfg.showThirdPersonSoma) {
                    const sx = cfg.somaX;
                    const sy = cfg.somaY || 0.0;
                    const sz = cfg.somaZ;
                    const syaw = cfg.somaYaw || 0.0;
                    const cosY = Math.cos(syaw), sinY = Math.sin(syaw);
                    const toW = (lx, ly, lz) => ({
                        x: sx + (lx * cosY + lz * sinY),
                        y: sy + ly,
                        z: sz + (-lx * sinY + lz * cosY)
                    });
                    const walkSwing = Math.sin(cfg.animPhase || 0.0) * (cfg.somaMoving ? 0.45 : 0.06);
                    const isUra = !!cfg.isUraGarb;
                    const kimonoCol = isUra ? '#141B33' : '#27406B'; // Kon night vs Ai-iro day
                    const haoriCol  = isUra ? '#1C1B1A' : '#6B5A44'; // Sumi charcoal vs Kuri wood

                    // Legs
                    const lLeg = toW(-0.12, 0.38, Math.sin(walkSwing) * 0.16);
                    const rLeg = toW( 0.12, 0.38, Math.sin(-walkSwing) * 0.16);
                    dynItems.push({ mesh: 'cylinder', tex: 'cloth', color: '#1C1B1A', x: lLeg.x, y: lLeg.y, z: lLeg.z, rx: walkSwing * 0.5, ry: syaw, sx: 0.14, sy: 0.72, sz: 0.14, isCharacter: true });
                    dynItems.push({ mesh: 'cylinder', tex: 'cloth', color: '#1C1B1A', x: rLeg.x, y: rLeg.y, z: rLeg.z, rx: -walkSwing * 0.5, ry: syaw, sx: 0.14, sy: 0.72, sz: 0.14, isCharacter: true });

                    // Torso & Haori
                    const crouchDrop = cfg.somaCrouching ? -0.26 : 0.0;
                    const tPos = toW(0, 0.84 + crouchDrop, 0);
                    dynItems.push({ mesh: 'guardTorso', tex: 'cloth', color: kimonoCol, x: tPos.x, y: tPos.y, z: tPos.z, ry: syaw, sx: 0.92, sy: 0.96, sz: 0.88, isCharacter: true });

                    // Omote Merchant Carrying Pole & Wares Boxes OR Ura Night Katana on Back
                    if (!isUra) {
                        const polePos = toW(0, 1.34 + crouchDrop, -0.14);
                        dynItems.push({ mesh: 'box', tex: 'wood', color: '#A37E56', x: polePos.x, y: polePos.y, z: polePos.z, ry: syaw, sx: 1.35, sy: 0.07, sz: 0.07, isCharacter: true });
                        const boxL = toW(-0.56, 1.02 + crouchDrop, -0.14);
                        const boxR = toW( 0.56, 1.02 + crouchDrop, -0.14);
                        dynItems.push({ mesh: 'box', tex: 'wood', color: '#6B5A44', x: boxL.x, y: boxL.y, z: boxL.z, ry: syaw, sx: 0.34, sy: 0.42, sz: 0.34, isCharacter: true });
                        dynItems.push({ mesh: 'box', tex: 'wood', color: '#D2692E', x: boxR.x, y: boxR.y, z: boxR.z, ry: syaw, sx: 0.34, sy: 0.42, sz: 0.34, isCharacter: true });
                    } else {
                        const scabbardPos = toW(-0.18, 1.06 + crouchDrop, -0.18);
                        dynItems.push({ mesh: 'katana', tex: 'stone', color: '#B9C7D8', emissive: cfg.iaiGlow ? 1.4 : 0.2, x: scabbardPos.x, y: scabbardPos.y, z: scabbardPos.z, rx: 0.65, ry: syaw, rz: 0.45, sx: 0.95, sy: 0.95, sz: 0.95, isCharacter: true });
                        if (cfg.iaiSlashArc) {
                            const arcPos = toW(0.0, 1.15 + crouchDrop, 0.95);
                            dynItems.push({ mesh: 'ring', tex: 'shoji', color: '#B8321F', emissive: 1.9, x: arcPos.x, y: arcPos.y, z: arcPos.z, rx: 0.35, ry: syaw, rz: -0.25, sx: 1.85, sy: 1, sz: 1.85, outlineWidth: 0, noShadow: true });
                        }
                    }

                    // Head & Sugegasa Hat (Omote) / Dark Hair Topknot (Ura)
                    const hPos = toW(0, 1.50 + crouchDrop, 0);
                    dynItems.push({ mesh: 'head', tex: 'cloth', color: '#e2c4a6', x: hPos.x, y: hPos.y, z: hPos.z, ry: syaw, sx: 0.96, sy: 0.96, sz: 0.96, isCharacter: true });
                    if (!isUra) {
                        dynItems.push({ mesh: 'hat', tex: 'wood', color: '#A37E56', x: hPos.x, y: hPos.y + 0.08, z: hPos.z, ry: syaw, sx: 1.24, sy: 0.92, sz: 1.24, isCharacter: true });
                    } else {
                        dynItems.push({ mesh: 'cylinder', tex: 'cloth', color: '#1C1B1A', x: hPos.x, y: hPos.y + 0.14, z: hPos.z - 0.04, rx: -0.4, ry: syaw, sx: 0.16, sy: 0.22, sz: 0.16, isCharacter: true });
                        // Cinnabar Collar / Scarf Accent
                        const scarfPos = toW(0, 1.36 + crouchDrop, 0.02);
                        dynItems.push({ mesh: 'box', tex: 'cloth', color: '#B8321F', x: scarfPos.x, y: scarfPos.y, z: scarfPos.z, ry: syaw, sx: 0.32, sy: 0.10, sz: 0.30, isCharacter: true });
                    }
                }

                const cam = {
                    x: cfg.camX,
                    y: cfg.camY,
                    z: cfg.camZ,
                    yaw: cfg.camYaw,
                    pitch: cfg.camPitch,
                    roll: cfg.camRoll || 0.0
                };

                const allWorld = s.assembler.staticWorldItems.concat(dynItems);
                s.renderer.renderScene(cam, allWorld, [], s.lanterns);

                // Draw Diegetic Player HUD onto hudCanvas (E4.5: Hanko seal, Kamon, Washi/Kon theme, Dialog/Kosatsu/Nisshi overlays)
                const ctx = hudCanvas.getContext('2d');
                ctx.clearRect(0, 0, 1280, 720);

                const isNight = (cfg.timePreset === 'MALAM');
                const panelBg = isNight ? 'rgba(20, 27, 51, 0.88)' : 'rgba(239, 230, 210, 0.92)';
                const textPrimary = isNight ? '#EFE6D2' : '#1C1B1A';
                const textAccent = '#B8321F'; // Shu Vermilion
                const goldAccent = '#E8A33D'; // Andon Warm Gold

                // 1. Top-Left Diegetic Status Card (Kamon + Identity + Time/Weather + Mon & Suspicion Hanko)
                ctx.save();
                ctx.fillStyle = panelBg;
                ctx.strokeStyle = isNight ? '#E8A33D' : '#1C1B1A';
                ctx.lineWidth = 2.2;
                ctx.fillRect(24, 22, 475, 86);
                ctx.strokeRect(24, 22, 475, 86);
                ctx.fillStyle = textAccent;
                ctx.fillRect(24, 22, 6, 86);

                // Hanko Stamp Seal
                ctx.fillStyle = '#B8321F';
                ctx.fillRect(38, 34, 52, 52);
                ctx.strokeStyle = '#EFE6D2';
                ctx.lineWidth = 1.5;
                ctx.strokeRect(41, 37, 46, 46);
                ctx.fillStyle = '#EFE6D2';
                ctx.font = 'bold 24px Georgia, serif';
                ctx.textAlign = 'center';
                ctx.fillText(cfg.isUraGarb ? '裏' : '表', 64, 68);

                ctx.textAlign = 'left';
                ctx.fillStyle = textPrimary;
                ctx.font = 'bold 15px Georgia, serif';
                ctx.fillText(cfg.topTitle || '東雲 颯真 • Pedagang Keliling (Omote)', 102, 46);
                ctx.font = '13px "Segoe UI", sans-serif';
                ctx.fillText(cfg.topSub1 || 'Pasar Kaki Kastil • Sore Cerah (16:40)', 102, 68);
                ctx.fillStyle = isNight ? '#E8A33D' : '#5E1F18';
                ctx.font = 'bold 13px "Segoe UI", sans-serif';
                ctx.fillText(cfg.topSub2 || 'Bekal: 610 Mon  |  Curiga Warga: Rendah (8%)', 102, 90);
                ctx.restore();

                // 2. Top-Right District & Camera Perspective Indicator (Diegetic Scroll Tag)
                ctx.save();
                ctx.fillStyle = panelBg;
                ctx.strokeStyle = isNight ? '#B9C7D8' : '#1C1B1A';
                ctx.lineWidth = 2.0;
                ctx.fillRect(820, 22, 436, 54);
                ctx.strokeRect(820, 22, 436, 54);
                ctx.fillStyle = textPrimary;
                ctx.font = 'bold 14px Georgia, serif';
                ctx.fillText(cfg.locationBanner || '📍 Distrik Kaki Kastil Kurokawa', 836, 45);
                ctx.font = '12.5px "Segoe UI", sans-serif';
                ctx.fillStyle = isNight ? '#B9C7D8' : '#6B5A44';
                ctx.fillText(cfg.objectiveHint || 'Tujuan: Berdagang & Kumpulkan Kabar Papan Tinta', 836, 65);
                ctx.restore();

                // 3. Optional Center/Bottom Diegetic Overlays (Dialog Box, Kosatsu Board, Intervention Prompt, or Nisshi Scroll)
                if (cfg.dialogBox) {
                    const db = cfg.dialogBox;
                    ctx.save();
                    ctx.fillStyle = panelBg;
                    ctx.strokeStyle = '#1C1B1A';
                    ctx.lineWidth = 2.8;
                    ctx.fillRect(180, 515, 920, 172);
                    ctx.strokeRect(180, 515, 920, 172);
                    ctx.fillStyle = '#B8321F';
                    ctx.fillRect(180, 515, 920, 6);

                    ctx.fillStyle = textAccent;
                    ctx.font = 'bold 17px Georgia, serif';
                    ctx.fillText(db.speaker, 206, 546);

                    ctx.fillStyle = isNight ? '#B9C7D8' : '#6B5A44';
                    ctx.font = 'italic 13.5px Georgia, serif';
                    ctx.fillText(db.jpBark || '', 206, 568);

                    ctx.fillStyle = textPrimary;
                    ctx.font = '15.5px "Segoe UI", sans-serif';
                    ctx.fillText(db.line1 || '', 206, 596);
                    if (db.line2) ctx.fillText(db.line2, 206, 620);

                    if (db.choices && db.choices.length > 0) {
                        let cx = 206;
                        for (let c = 0; c < db.choices.length; c++) {
                            const ch = db.choices[c];
                            const w = Math.max(210, ch.length * 8.2 + 28);
                            ctx.fillStyle = c === 0 ? '#B8321F' : (isNight ? '#27406B' : '#6B5A44');
                            ctx.fillRect(cx, 638, w, 34);
                            ctx.fillStyle = '#EFE6D2';
                            ctx.font = 'bold 13.5px "Segoe UI", sans-serif';
                            ctx.fillText(ch, cx + 14, 660);
                            cx += w + 14;
                        }
                    }
                    ctx.restore();
                }

                if (cfg.kosatsuOverlay) {
                    ctx.save();
                    // Wooden Noticeboard (Kosatsu)
                    ctx.fillStyle = 'rgba(107, 90, 68, 0.95)';
                    ctx.strokeStyle = '#1C1B1A';
                    ctx.lineWidth = 4;
                    ctx.fillRect(240, 130, 800, 440);
                    ctx.strokeRect(240, 130, 800, 440);

                    // Washi paper pinned to board
                    ctx.fillStyle = '#EFE6D2';
                    ctx.fillRect(272, 162, 736, 376);
                    ctx.strokeStyle = '#6B5A44';
                    ctx.lineWidth = 2;
                    ctx.strokeRect(272, 162, 736, 376);

                    ctx.fillStyle = '#1C1B1A';
                    ctx.font = 'bold 22px Georgia, serif';
                    ctx.fillText('高札 • PAPAN PENGUMUMAN & JEJAK KABAR PASAR', 302, 205);

                    ctx.fillStyle = '#B8321F';
                    ctx.font = 'bold 15px "Segoe UI", sans-serif';
                    ctx.fillText('1. [KABAR KUAT — 2 Saksi Independen: Kojirō & Pak Tua Tome]', 302, 248);
                    ctx.fillStyle = '#1C1B1A';
                    ctx.font = '15px "Segoe UI", sans-serif';
                    ctx.fillText('   "Penjaga Ryōta meninggalkan pos Gerbang Selatan lebih awal saat senja."', 302, 274);

                    ctx.fillStyle = '#D2692E';
                    ctx.font = 'bold 15px "Segoe UI", sans-serif';
                    ctx.fillText('2. [DESAS-DESUS MENYIMPANG — Salah Tuduh Pelaku di Pasar]', 302, 320);
                    ctx.fillStyle = '#1C1B1A';
                    ctx.font = '15px "Segoe UI", sans-serif';
                    ctx.fillText('   "Makelar Daigō menuduh O-Kiku menyembunyikan buku timbangan garam."', 302, 346);

                    ctx.fillStyle = '#27406B';
                    ctx.font = 'bold 15px "Segoe UI", sans-serif';
                    ctx.fillText('3. [PESANAN MINGGUAN KELOMPOK — Tenggat Hari Ke-7]', 302, 392);
                    ctx.fillStyle = '#1C1B1A';
                    ctx.font = '15px "Segoe UI", sans-serif';
                    ctx.fillText('   "Petakan celah giliran jaga Gerbang Selatan & letakkan di Pohon Aras Tua (+120 Mon)."', 302, 418);

                    // Red Hanko Seal on Washi
                    ctx.strokeStyle = '#B8321F';
                    ctx.lineWidth = 3;
                    ctx.strokeRect(910, 445, 68, 68);
                    ctx.fillStyle = '#B8321F';
                    ctx.font = 'bold 22px Georgia, serif';
                    ctx.fillText('検証', 922, 488);
                    ctx.restore();
                }

                if (cfg.nisshiOverlay) {
                    ctx.save();
                    // Open Horizontal Washi Scroll (Nisshi)
                    ctx.fillStyle = '#6B5A44';
                    ctx.fillRect(190, 130, 22, 450);
                    ctx.fillRect(1068, 130, 22, 450);
                    ctx.fillStyle = '#EFE6D2';
                    ctx.fillRect(212, 142, 856, 426);
                    ctx.strokeStyle = '#1C1B1A';
                    ctx.lineWidth = 3;
                    ctx.strokeRect(212, 142, 856, 426);

                    ctx.fillStyle = '#1C1B1A';
                    ctx.font = 'bold 23px Georgia, serif';
                    ctx.fillText('日誌 • GULUNGAN CATATAN HARIAN SŌMA (NISSHI)', 252, 190);

                    const entries = [
                        ['Musim Semi • Hari 1', 'Membuka kotak pikul obat & teh di Pasar Kaki Kastil (+80 Mon).'],
                        ['Musim Semi • Hari 4', 'Menyerahkan kesaksian silang kepada Ryōta; O-Kiku bebas dari tuduhan salah paham.'],
                        ['Musim Semi • Hari 7', 'Melunasi sewa kamar Nagaya 350 Mon tepat waktu kepada O-Hana.'],
                        ['Musim Panas • Hari 12', 'Malam Obon: seribu lentera arwah menyala di lembah, tak ada darah yang tumpah.'],
                        ['Musim Dingin • Hari 23', 'Menempuh Ujian Kesetiaan di Pohon Aras Tua; jalur kelompok pulih kembali.']
                    ];
                    let ey = 240;
                    for (let i = 0; i < entries.length; i++) {
                        ctx.fillStyle = '#B8321F';
                        ctx.font = 'bold 15px Georgia, serif';
                        ctx.fillText('• ' + entries[i][0], 252, ey);
                        ctx.fillStyle = '#1C1B1A';
                        ctx.font = '15.5px "Segoe UI", sans-serif';
                        ctx.fillText('  ' + entries[i][1], 252, ey + 24);
                        ey += 58;
                    }

                    ctx.strokeStyle = '#B8321F';
                    ctx.lineWidth = 3;
                    ctx.strokeRect(968, 468, 72, 72);
                    ctx.fillStyle = '#B8321F';
                    ctx.font = 'bold 24px Georgia, serif';
                    ctx.fillText('影穴', 980, 512);
                    ctx.restore();
                }

                // Composite WebGL 3D canvas + Diegetic HUD canvas into outCanvas and return PNG base64
                const octx = outCanvas.getContext('2d');
                octx.drawImage(glCanvas, 0, 0, 1280, 720);
                octx.drawImage(hudCanvas, 0, 0, 1280, 720);
                return outCanvas.toDataURL('image/png').split(',')[1];
            };
            """
        )

        # Define the 10 scenes across 240 frames (24 frames = 1.0 second per scene, with smooth camera/character motion!)
        scenes = [
            {
                "png_name": "Gameplay_01_Pasar_Kaki_Kastil_Omote.png",
                "title": "1. Siang/Sore (Omote): Berjalan di Pasar Kaki Kastil sebagai Pedagang Keliling",
                "make_cfg": lambda u: {
                    "timePreset": "SORE",
                    "showThirdPersonSoma": True,
                    "isUraGarb": False,
                    "somaMoving": True,
                    "animPhase": u * 12.0,
                    "somaX": -0.6,
                    "somaY": 0.0,
                    "somaZ": -21.0 + u * 5.0,
                    "somaYaw": 0.0,
                    "camX": -1.35,
                    "camY": 1.75,
                    "camZ": -24.2 + u * 5.0,
                    "camYaw": 0.08,
                    "camPitch": -0.05,
                    "topTitle": "東雲 颯真 • Pedagang Keliling (Omote)",
                    "topSub1": "Pasar Kaki Kastil • Sore Cerah (16:15)",
                    "topSub2": "Bekal: 540 Mon  |  Barang: Obat & Teh  |  Curiga: 0%",
                    "locationBanner": "📍 Pasar Kaki Kastil & Gerbang Selatan",
                    "objectiveHint": "[A / E] Sapa Warga  •  [X / F] Tawarkan Dagangan",
                    "dialogBox": {
                        "speaker": "Suasana Pasar Kaki Kastil",
                        "jpBark": "「いらっしゃい！良い薬と茶葉が入ったよ。」",
                        "line1": "Para pedagang merapikan lapak menjelang senja sementara penjaga mengawasi jalan batu.",
                        "line2": "Berbaurlah sebagai pedagang jujur untuk membuka percakapan dan mengumpulkan kabar.",
                        "choices": ["[A] Hampiri Kedai Teh O-Kiku", "[X] Tawarkan Obat Herbal", "[Y] Periksa Papan Kōsatsu"]
                    }
                }
            },
            {
                "png_name": "Gameplay_02_Berdagang_Kedai_Teh_OKiku.png",
                "title": "2. Kamera Dialog 2-Bidikan: Berdagang & Mendengar Bisikan di Kedai Teh O-Kiku",
                "make_cfg": lambda u: {
                    "timePreset": "SORE",
                    "showThirdPersonSoma": True,
                    "isUraGarb": False,
                    "somaMoving": False,
                    "animPhase": u * 3.0,
                    "somaX": 8.2,
                    "somaY": 0.0,
                    "somaZ": 1.8,
                    "somaYaw": 0.45,
                    "camX": 7.1 + u * 0.25,
                    "camY": 1.58,
                    "camZ": 0.2 + u * 0.2,
                    "camYaw": 0.52,
                    "camPitch": -0.02,
                    "npcOverrides": [
                        {"x": 9.1, "z": 3.4, "yaw": -2.6, "tunicColor": "#D2692E", "archetype": "PEASANT", "isMoving": False}
                    ],
                    "topTitle": "東雲 颯真 • Berdagang di Kedai Teh (Omote)",
                    "topSub1": "Kedai Teh & Izakaya O-Kiku • Sore (16:45)",
                    "topSub2": "Bekal: 620 Mon (+80 Mon)  |  Kepercayaan O-Kiku: Hangat",
                    "locationBanner": "📍 Kedai Teh O-Kiku (Distrik Pasar)",
                    "objectiveHint": "Transaksi jujur membuka bisikan kabar bernilai",
                    "dialogBox": {
                        "speaker": "O-Kiku (Pemilik Kedai Teh Pasar)",
                        "jpBark": "「温かいお茶をどうぞ。お耳に入れたい話が……」",
                        "line1": "\"Terima kasih atas kiriman daun tehnya, Sōma-san. Ngomong-ngomong, hati-hati di dekat gerbang...\"",
                        "line2": "\"Makelar Daigō baru saja menyebarkan desas-desus keliru kepada penjaga Ryōta soal buku garam.\"",
                        "choices": ["[A] \"Siapa saksi aslinya, O-Kiku-san?\"", "[X] Catat ke Papan Tinta", "[B] Pamit dengan Sopan"]
                    }
                }
            },
            {
                "png_name": "Gameplay_03_Papan_Pengumuman_Kosatsu.png",
                "title": "3. Papan Pengumuman Kōsatsu: Memeriksa Rantai Kabar & Pesanan Kelompok",
                "make_cfg": lambda u: {
                    "timePreset": "SORE",
                    "showThirdPersonSoma": False,
                    "camX": 0.0,
                    "camY": 1.65,
                    "camZ": -12.0 + u * 0.3,
                    "camYaw": 0.0,
                    "camPitch": 0.02,
                    "topTitle": "東雲 颯真 • Memeriksa Papan Kōsatsu",
                    "topSub1": "Persimpangan Pasar Kaki Kastil • Menjelang Senja (17:10)",
                    "topSub2": "Kabar Terverifikasi (>=2 Saksi): 2 Gulungan Kuat",
                    "locationBanner": "📍 Papan Pengumuman Kōsatsu",
                    "objectiveHint": "Bandingkan kesaksian warga sebelum bertindak",
                    "kosatsuOverlay": True
                }
            },
            {
                "png_name": "Gameplay_04_Salah_Paham_Penjaga_Ryota.png",
                "title": "4. Rantai Salah Paham: Penjaga Ryōta Menuduh Warga yang Tak Bersalah",
                "make_cfg": lambda u: {
                    "timePreset": "SORE",
                    "showThirdPersonSoma": True,
                    "isUraGarb": False,
                    "somaMoving": False,
                    "animPhase": u * 4.0,
                    "somaX": -1.4,
                    "somaY": 0.0,
                    "somaZ": -8.8,
                    "somaYaw": 0.15,
                    "camX": -2.3 + u * 0.2,
                    "camY": 1.68,
                    "camZ": -11.4 + u * 0.3,
                    "camYaw": 0.24,
                    "camPitch": -0.04,
                    "npcOverrides": [
                        {"x": -0.4, "z": -6.2, "yaw": 3.14, "tunicColor": "#27406B", "archetype": "GUARD", "windupTimer": 0.2},
                        {"x": 0.5, "z": -6.8, "yaw": -1.2, "tunicColor": "#D2692E", "archetype": "PEASANT"}
                    ],
                    "topTitle": "東雲 颯真 • Menyaksikan Salah Paham",
                    "topSub1": "Pos Barak Gerbang Selatan • Senja (17:35)",
                    "topSub2": "Peringatan: Warga tak bersalah terancam denda 35 Mon!",
                    "locationBanner": "📍 Pos Gerbang Selatan (Ryōta)",
                    "objectiveHint": "Putuskan: Turun tangan atau biarkan demi samaran",
                    "dialogBox": {
                        "speaker": "Ryōta (Penjaga Gerbang Selatan)",
                        "jpBark": "「おい待て！お前が帳簿を隠したと聞いたぞ！」",
                        "line1": "\"Hei berhenti! Daigō melapor bahwa kau yang menyembunyikan buku timbangan garam di kedai!\"",
                        "line2": "\"Bayar denda 35 mon sekarang juga atau lapakmu kusita!\"",
                        "choices": ["[Y] Serahkan Bukti Silang 2 Saksi", "[X] Bersaksi Tanpa Bukti", "[B] Diam & Biarkan"]
                    }
                }
            },
            {
                "png_name": "Gameplay_05_Intervensi_Bukti_Silang.png",
                "title": "5. Intervensi Sōma: Menyerahkan Bukti Kesaksian Silang & Membebaskan Warga",
                "make_cfg": lambda u: {
                    "timePreset": "SORE",
                    "showThirdPersonSoma": True,
                    "isUraGarb": False,
                    "somaMoving": True,
                    "animPhase": u * 6.0,
                    "somaX": -0.8,
                    "somaY": 0.0,
                    "somaZ": -7.4 + u * 0.4,
                    "somaYaw": 0.22,
                    "camX": -1.8,
                    "camY": 1.62,
                    "camZ": -9.6 + u * 0.3,
                    "camYaw": 0.28,
                    "camPitch": -0.02,
                    "npcOverrides": [
                        {"x": -0.3, "z": -6.0, "yaw": 3.0, "tunicColor": "#27406B", "archetype": "GUARD"},
                        {"x": 0.6, "z": -6.6, "yaw": -1.4, "tunicColor": "#D2692E", "archetype": "PEASANT"}
                    ],
                    "vfxDecals": [
                        {"type": "SPARK", "x": -0.4, "y": 1.35, "z": -6.5, "size": 0.28, "color": "#E8A33D", "life": 1.0}
                    ],
                    "topTitle": "東雲 颯真 • Campur Tangan Berhasil!",
                    "topSub1": "Pos Barak Gerbang Selatan • Senja (17:42)",
                    "topSub2": "O-Kiku Bebas dari Tuduhan  |  Hati: Hangat (+15)  |  Curiga Ryōta: +8%",
                    "locationBanner": "📍 Pos Gerbang Selatan",
                    "objectiveHint": "Kebenaran terungkap lewat kesaksian Kojirō & Pak Tua Tome",
                    "dialogBox": {
                        "speaker": "Shinonome Sōma → Penjaga Ryōta",
                        "jpBark": "「待ってください。別の証人が二人います。」",
                        "line1": "Sōma memperlihatkan catatan kesaksian silang dari Kojirō dan Pak Tua Tome di dermaga.",
                        "line2": "Ryōta tertegun: \"Apa...? Jadi tadi salah orang? Baiklah, tuduhan terhadap kedai teh kubatalkan.\"",
                        "choices": ["[A] Lanjutkan Perjalanan ke Nagaya"]
                    }
                }
            },
            {
                "png_name": "Gameplay_06_Senja_Nagaya_Dan_OHana.png",
                "title": "6. Senja di Rumah Sewa Nagaya: Membayar Uang Sewa Kamar kepada O-Hana",
                "make_cfg": lambda u: {
                    "timePreset": "SORE",
                    "showThirdPersonSoma": True,
                    "isUraGarb": False,
                    "somaMoving": False,
                    "animPhase": u * 4.0,
                    "somaX": -8.2,
                    "somaY": 0.0,
                    "somaZ": -10.2,
                    "somaYaw": -1.4,
                    "camX": -6.2 - u * 0.2,
                    "camY": 1.66,
                    "camZ": -11.4,
                    "camYaw": -1.25,
                    "camPitch": -0.02,
                    "npcOverrides": [
                        {"x": -9.6, "z": -10.0, "yaw": 1.57, "tunicColor": "#A37E56", "archetype": "PEASANT"}
                    ],
                    "topTitle": "東雲 颯真 • Rumah Sewa Nagaya (Omote)",
                    "topSub1": "Serambi Nagaya O-Hana • Senja Lentera Menyala (18:15)",
                    "topSub2": "Sewa Mingguan Lunas (-350 Mon)  |  Sisa Bekal: 270 Mon",
                    "locationBanner": "📍 Rumah Sewa Nagaya & Kamar Sōma",
                    "objectiveHint": "Lentera Andon menyala — malam segera tiba",
                    "dialogBox": {
                        "speaker": "O-Hana (Induk Semang Nagaya)",
                        "jpBark": "「ふん、今月の店賃はきっちり受け取ったよ！」",
                        "line1": "\"Hmph, tiga ratus lima puluh mon pas! Kejujuranmu masih kuhargai, Sōma.\"",
                        "line2": "\"Malam ini angin lembah dingin, jangan keluyuran melewati jam malam penjaga kastil!\"",
                        "choices": ["[A] Masuk Kamar & Ganti Pakaian Malam (Ura)", "[B] Istirahat hingga Pagi"]
                    }
                }
            },
            {
                "png_name": "Gameplay_07_Malam_Ura_Menyelinap_Gang.png",
                "title": "7. Malam Bulan Purnama (Ura): Menyelinap di Bayangan Gang Belakang",
                "make_cfg": lambda u: {
                    "timePreset": "MALAM",
                    "showThirdPersonSoma": True,
                    "isUraGarb": True,
                    "somaCrouching": True,
                    "somaMoving": True,
                    "animPhase": u * 10.0,
                    "somaX": -6.2,
                    "somaY": 0.0,
                    "somaZ": -15.5 + u * 4.5,
                    "somaYaw": 0.05,
                    "camX": -6.8,
                    "camY": 1.48,
                    "camZ": -18.2 + u * 4.5,
                    "camYaw": 0.12,
                    "camPitch": -0.06,
                    "npcOverrides": [
                        {"x": -1.5, "z": -8.5 + u * 2.0, "yaw": 0.0, "tunicColor": "#27406B", "archetype": "GUARD", "isMoving": True, "animPhase": u * 8.0}
                    ],
                    "topTitle": "東雲 颯真 • Bayangan Malam (Ura — Nila Gelap)",
                    "topSub1": "Gang Belakang Kaki Kastil • Malam Purnama (22:10)",
                    "topSub2": "Kemampuan Bayangan: 88% (Pekat)  |  Suara Langkah: 3 dB (Senyap)",
                    "locationBanner": "📍 Gang Belakang & Kolam Bayangan",
                    "objectiveHint": "[Z / RB] Menyelam Bayangan  •  [LT / V] Fokus Mata Telinga",
                    "dialogBox": {
                        "speaker": "Pengendapan Malam (Ura)",
                        "jpBark": "「……提灯の明かりを避けて、影から影へ。」",
                        "line1": "Pakaian malam nila gelap (#141B33) menyatu dengan bayangan atap tanpa memantulkan cahaya lentera.",
                        "line2": "Penjaga patroli lewat di jalan batu utama tanpa menyadari kehadiran Sōma di balik pagar bambu.",
                        "choices": ["[LT / V] Aktifkan Fokus Mata Telinga", "[Z] Lompat Antar Bayangan"]
                    }
                }
            },
            {
                "png_name": "Gameplay_08_Mata_Telinga_Riak_Suara_Tinta.png",
                "title": "8. Fokus 'Mata Telinga': Dunia Kertas Washi & Riak Tinta Merah Langkah Penjaga",
                "make_cfg": lambda u: {
                    "timePreset": "MALAM",
                    "listenMode": True,
                    "showThirdPersonSoma": True,
                    "isUraGarb": True,
                    "somaCrouching": True,
                    "somaMoving": False,
                    "animPhase": u * 4.0,
                    "somaX": -4.5,
                    "somaY": 0.0,
                    "somaZ": -5.5,
                    "somaYaw": 0.35,
                    "camX": -5.8,
                    "camY": 1.62,
                    "camZ": -8.2,
                    "camYaw": 0.42,
                    "camPitch": -0.08,
                    "npcOverrides": [
                        {"x": -1.2, "z": -1.5, "yaw": 1.57, "tunicColor": "#B8321F", "archetype": "GUARD", "isMoving": True},
                        {"x": 2.4, "z": 4.2, "yaw": 3.14, "tunicColor": "#B8321F", "archetype": "COMMANDER", "isMoving": True}
                    ],
                    "inkRipples": [
                        {"x": -1.2, "z": -1.5, "r": 1.2 + u * 2.5, "isLethal": True},
                        {"x": -1.2, "z": -1.5, "r": 2.8 + u * 2.5, "isLethal": True},
                        {"x": 2.4, "z": 4.2, "r": 1.8 + u * 3.0, "isLethal": True}
                    ],
                    "topTitle": "東雲 颯真 • Fokus Mata Telinga (Suara = Tinta)",
                    "topSub1": "Pelataran Dalam • Mode Persepsi Tinta Washi (22:45)",
                    "topSub2": "2 Sumber Suara Terlacak: Langkah Penjaga (24 dB) & Komandan (28 dB)",
                    "locationBanner": "📍 Pelataran Tengah (Mata Telinga Aktif)",
                    "objectiveHint": "Cincin tinta merah menunjukkan jangkauan langkah & arah patroli",
                    "dialogBox": {
                        "speaker": "Persepsi Mata Telinga (心眼・耳目)",
                        "jpBark": "「足音の波紋が見える……二人とも東を向いている。」",
                        "line1": "Saat memejamkan mata sejenak, dunia memudar menjadi lembaran kertas washi (#EFE6D2).",
                        "line2": "Setiap derap kaki penjaga menggambar riak tinta merah Shu (#B8321F) di lantai pelataran.",
                        "choices": ["[L / LB] Lontarkan Kaginawa ke Atap", "[Z] Menyelam ke Bayangan Utara"]
                    }
                }
            },
            {
                "png_name": "Gameplay_09_Kaginawa_Atap_Dan_Tebasan_Iai.png",
                "title": "9. Puncak Aksi di Atap Kastil: Kuda-Kuda Satu Tebasan Iai di Bawah Bulan Purnama",
                "make_cfg": lambda u: {
                    "timePreset": "MALAM",
                    "showThirdPersonSoma": True,
                    "isUraGarb": True,
                    "somaMoving": True,
                    "iaiGlow": True,
                    "iaiSlashArc": True,
                    "animPhase": u * 8.0,
                    "somaX": 0.0,
                    "somaY": 3.35,
                    "somaZ": 13.5 + u * 2.2,
                    "somaYaw": 0.0,
                    "camX": -1.1,
                    "camY": 5.15,
                    "camZ": 10.6 + u * 2.2,
                    "camYaw": 0.22,
                    "camPitch": -0.10,
                    "npcOverrides": [
                        {"x": 0.0, "y": 3.35, "z": 16.5, "yaw": 3.14, "tunicColor": "#B8321F", "archetype": "COMMANDER", "windupTimer": 0.3}
                    ],
                    "vfxDecals": [
                        {"type": "SPARK", "x": 0.0, "y": 4.6, "z": 15.6, "size": 0.42, "color": "#E8A33D", "life": 1.0}
                    ],
                    "topTitle": "東雲 颯真 • Balok Atap Menara Utara (Ura)",
                    "topSub1": "Atap Menara Pengintai • Duel Satu Tebasan Iai (23:30)",
                    "topSub2": "Kuda-Kuda Iaijutsu Aktif  |  Target: Penjaga Menara",
                    "locationBanner": "📍 Atap Menara Pengintai Utara",
                    "objectiveHint": "Satu tebasan kilat dari sarung pedang menentukan hidup-mati",
                    "dialogBox": {
                        "speaker": "Tebasan Kilat Iaijutsu (居合・一閃)",
                        "jpBark": "「一太刀で決める……！」",
                        "line1": "Melesat ke balok atap dengan Kaginawa, Sōma menahan napas dalam satu bingkai keheningan.",
                        "line2": "Kilatan cahaya merah Shu (#B8321F) membelah udara malam tepat saat penjaga menara lengah.",
                        "choices": ["[A] Ambil Salinan Buku Pemeriksaan", "[B] Turun ke Hutan Pohon Aras"]
                    }
                }
            },
            {
                "png_name": "Gameplay_10_Gulungan_Nisshi_Dan_Fajar.png",
                "title": "10. Fajar Menyingsing: Membuka Gulungan Catatan Harian Nisshi Terkurasi",
                "make_cfg": lambda u: {
                    "timePreset": "SORE",
                    "showThirdPersonSoma": True,
                    "isUraGarb": False,
                    "somaMoving": False,
                    "somaX": 0.0,
                    "somaY": 0.0,
                    "somaZ": -18.0,
                    "somaYaw": 0.0,
                    "camX": 0.0,
                    "camY": 2.2,
                    "camZ": -21.5 + u * 0.4,
                    "camYaw": 0.0,
                    "camPitch": -0.05,
                    "topTitle": "東雲 颯真 • Membuka Gulungan Nisshi [J / View]",
                    "topSub1": "Lembah Kurokawa • Fajar Baru Menyingsing (06:00)",
                    "topSub2": "Kepercayaan Kelompok: Pulih (59/100)  |  Status: Dipercaya Kembali",
                    "locationBanner": "📍 Gulungan Nisshi (Catatan Hidup Sōma)",
                    "objectiveHint": "Setiap tindakan meninggalkan jejak bermakna di lembah",
                    "nisshiOverlay": True
                }
            }
        ]

        frame_idx = 0
        saved_screenshots = []
        frames_per_scene = 24  # 10 scenes * 24 fps = 240 frames = 10.0 seconds

        for s_idx, sc in enumerate(scenes):
            for f in range(frames_per_scene):
                u = f / float(max(1, frames_per_scene - 1))
                cfg = sc["make_cfg"](u)
                b64_png = driver.execute_script("return window.renderPlayerGameplayFrame(arguments[0]);", cfg)
                raw_png = base64.b64decode(b64_png)

                frame_file = tmp_dir / f"frame_{frame_idx:04d}.png"
                frame_file.write_bytes(raw_png)

                # Save the representative mid-scene frame as one of the 10 standalone HD PNG deliverables!
                if f == 12:
                    out_png = OUT_DIR / sc["png_name"]
                    out_png.write_bytes(raw_png)
                    saved_screenshots.append(out_png)
                    print(f"[Screenshot {s_idx+1}/10] Saved {out_png.name} ({len(raw_png):,} bytes)")

                frame_idx += 1

        # Generate 10-second audio WAV and encode 10-second MP4 video with ffmpeg
        wav_path = tmp_dir / "gameplay_audio_10s.wav"
        synthesize_10s_gameplay_audio(wav_path)

        mp4_path = OUT_DIR / "KageAna_Gameplay_Asli_Player_10s.mp4"
        subprocess.run([
            "ffmpeg", "-y",
            "-framerate", "24",
            "-i", str(tmp_dir / "frame_%04d.png"),
            "-i", str(wav_path),
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            "-profile:v", "high",
            "-crf", "18",
            "-c:a", "aac",
            "-b:a", "192k",
            "-shortest",
            "-movflags", "+faststart",
            str(mp4_path)
        ], check=True)
        print(f"[Video 10s] Saved {mp4_path} ({mp4_path.stat().st_size:,} bytes)")

    finally:
        driver.quit()
        shutil.rmtree(tmp_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
