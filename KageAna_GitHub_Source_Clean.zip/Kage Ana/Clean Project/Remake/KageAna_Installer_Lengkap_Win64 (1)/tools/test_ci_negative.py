#!/usr/bin/env python3
"""
tools/test_ci_negative.py — Mandatory Negative CI Verification Suite (15 Cases: L0.1 + L1.5 + L1.9 + Gelombang A).

Deliberately injects 15 distinct violations into temporary copies of the repository / renderer
and verifies that the CI tools FAIL (non-zero exit code) for every single case:

  L0.1 Negative Cases (1..6):
    (1) NPC knows a fact never experienced (`violations > 0` in C# NoFreeKnowledgeGuard).
    (2) Prohibited buzzword (`AAA` / `authentic` / `photorealistic`) in a governance document (`DECISIONS.md`).
    (3) Gig with `< 3` distinct approaches (`approaches: ["Quiet", "Loud"]` -> only 2).
    (4) Overlapping unconditional NPC schedule blocks (`08:00-12:00` and `10:30-14:00`).
    (5) Reference to a nonexistent place ID and nonexistent NPC ID in NPC & Gig data.
    (6) Flipping the sign of `projMat[0]` AND `frontFace` in a temporary copy of `webgl_vertical_slice/`.

  L1.5 Negative Cases (7..11 — Lampiran A Validators):
    (7) Cross-reference failure `dagangan -> tempat akses`: Ware in `wares.json` references nonexistent place ID (`place_istana_awan_palsu_999`).
    (8) Cross-reference failure `kabar -> NPC`: Kabar in `kabar_catalog.json` references nonexistent `subjectNpcId` & `verifiedBy` NPC ID.
    (9) Cross-reference failure `pesanan -> kabar`: Group Order in `group_orders.json` references nonexistent `requiredKabarIds` (`kabar_fiktif_belum_ada_999`).
   (10) Prohibited lore invention on `[ISI-PENGGUNA]` fields in `souma.json` (missing `TEMP_` prefix).
   (11) Invalid `true_face.json` / `wares.json` tuning (< 8 ware categories and tampered Stage 2 witness suspicion cost).

  L1.9 Negative Case (12 — Paket Uji Coba M0 Validator):
   (12) Dishonest M0 naming ('game', 'playable', 'build final') injected into `installer/KageAna_M0_PaketUjiCoba.iss`
        and missing `<SelfContained>true</SelfContained>` in `unity_project/KageAna.SimCli.csproj`.

  Gelombang A Negative Cases (13..15 — L1.95 Sandbox Honest Naming, L2 Place Graph, L3 Rumor Chains):
   (13) Dishonest Sandbox naming ('playable', 'build final') & stripped mandatory title
        `"Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)"` in `docs/CARA_UJI_COBA.md` & `SandboxProgram.cs`.
   (14) L2 Place Graph violation: broken neighbor place ID (`place_istana_langit_999`) & non-positive `travelMinutes` (`-5`) in `kurokawa_places.json`.
   (15) L3 Rumor Chain violation: `< 2` distortions & unknown witness NPC (`npc_saksi_fiktif_999`) in `rumor_chains.json`.
"""

import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import tempfile

REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent


def write_meta_for(asset_path: pathlib.Path, repo_root: pathlib.Path):
    rel_posix = asset_path.relative_to(repo_root / "unity_project").as_posix()
    guid = hashlib.md5(f"KageAna_NegTestMeta::{rel_posix}".encode("utf-8")).hexdigest()
    meta_path = pathlib.Path(str(asset_path) + ".meta")
    meta_path.write_text(
        "fileFormatVersion: 2\n"
        f"guid: {guid}\n"
        "TextScriptImporter:\n"
        "  externalObjects: {}\n"
        "  userData: \n"
        "  assetBundleName: \n"
        "  assetBundleVariant: \n",
        encoding="utf-8",
    )


def make_temp_repo_copy(tmpdir: str) -> pathlib.Path:
    dst = pathlib.Path(tmpdir) / "repo_copy"
    dst.mkdir(parents=True, exist_ok=True)
    for doc in [
        "AGENTS.md",
        "CLAUDE.md",
        "DECISIONS.md",
        "IDEAS.md",
        "ART_BIBLE.md",
        "ARCHITECTURE.md",
        "ASSETS_LICENSE.md",
        "README_VERIFY.md",
        "BANGUN_PAKET.bat",
        "BUAT_INSTALLER.bat",
        "CARA_UJI_COBA.md",
        "Jalankan_Sandbox.bat",
    ]:
        if (REPO_ROOT / doc).exists():
            shutil.copy2(REPO_ROOT / doc, dst / doc)
    for folder in [".github", "docs", "installer", "staging", "tools", "unity_project"]:
        if (REPO_ROOT / folder).exists():
            shutil.copytree(REPO_ROOT / folder, dst / folder)
    for extra_rel in [
        "docs/schemas/salience.schema.json",
        "unity_project/Assets/_Project/Data/tuning/salience.json",
        "unity_project/Assets/_Project/Data/tuning/salience.json.meta",
        "staging/Data/tuning/salience.json",
        "tools/validate_installer.py",
        "installer/KageAna.iss",
        "installer/KageAna_IExpress.sed",
        "installer/pasang.cmd",
        "installer/kageana_icon.ico",
        ".github/workflows/installer.yml",
    ]:
        src_f = REPO_ROOT / extra_rel
        dst_f = dst / extra_rel
        if src_f.exists():
            dst_f.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_f, dst_f)
    return dst


def run_negative_case(case_num: int, title: str, cmd: list[str], cwd: pathlib.Path) -> bool:
    proc = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True)
    combined = (proc.stdout + "\n" + proc.stderr).strip()
    failed_as_expected = proc.returncode != 0
    status_str = "EXPECTED_CI_FAIL -> PASS" if failed_as_expected else "UNEXPECTED_CI_PASS -> FAIL"
    print(f"\n----------------------------------------------------------------------")
    print(f"CASE ({case_num}): {title}")
    print(f"Command : {' '.join(cmd)}")
    print(f"ExitCode: {proc.returncode} [{status_str}]")
    print("Captured Output:")
    for line in combined.splitlines():
        if line.strip():
            print(f"  | {line}")
    return failed_as_expected


def main() -> int:
    print("======================================================================")
    print("KAGE-ANA v3.0 — NEGATIVE CI TEST SUITE (15 Cases: L0.1..Gelombang A)")
    print("======================================================================")

    all_passed = True

    # CASE (1): NPC knows a fact never experienced (violations > 0)
    with tempfile.TemporaryDirectory(prefix="kageana_neg1_") as tmpdir:
        out_json = pathlib.Path(tmpdir) / "neg1_report.json"
        ok1 = run_negative_case(
            1,
            "NPC knows a fact never experienced (violations > 0 in C# NoFreeKnowledgeGuard)",
            [
                "python3",
                "tools/run_headless_sim.py",
                "--seed",
                "7",
                "--days",
                "1",
                "--inject-free-knowledge",
                "--out",
                str(out_json),
            ],
            REPO_ROOT,
        )
        all_passed = all_passed and ok1

    # CASE (2): Prohibited buzzword in governance documentation
    with tempfile.TemporaryDirectory(prefix="kageana_neg2_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        decisions_file = repo_copy / "DECISIONS.md"
        decisions_file.write_text(
            decisions_file.read_text(encoding="utf-8")
            + "\n<!-- Injected violation: This is an AAA photorealistic authentic ninja game. -->\n",
            encoding="utf-8",
        )
        ok2 = run_negative_case(
            2,
            "Prohibited buzzword ('AAA', 'photorealistic', 'authentic') injected into DECISIONS.md",
            ["python3", "tools/run_ci.py", "--repo-root", str(repo_copy), "--check-red-flags-only"],
            repo_copy,
        )
        all_passed = all_passed and ok2

    # CASE (3): Gig with < 3 distinct approaches
    with tempfile.TemporaryDirectory(prefix="kageana_neg3_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        bad_gig_file = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "gigs" / "bad_gig.json"
        bad_gig_file.write_text(
            json.dumps(
                [
                    {
                        "id": "gig_broken_only_2_approaches",
                        "giver": "npc_ohana",
                        "locations": ["place_kedai_teh"],
                        "approaches": ["Quiet", "Loud"],
                        "rippleTemplates": ["ripple_guard_shift"],
                    }
                ],
                indent=2,
            ),
            encoding="utf-8",
        )
        write_meta_for(bad_gig_file, repo_copy)

        ok3 = run_negative_case(
            3,
            "Gig with < 3 approaches (only 2 approaches: ['Quiet', 'Loud'])",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok3

    # CASE (4): Overlapping NPC schedule blocks
    with tempfile.TemporaryDirectory(prefix="kageana_neg4_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        overlap_npc_file = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "npcs" / "bad_schedule_npc.json"
        overlap_npc_file.write_text(
            json.dumps(
                [
                    {
                        "id": "npc_ryota_overlap",
                        "displayName": "Ryota",
                        "role": "GateGuard",
                        "home": "place_barak_gerbang",
                        "traits": ["Strict"],
                        "speechHabit": "Gruff",
                        "schedule": [
                            {
                                "from": "08:00",
                                "to": "12:00",
                                "activity": "MorningGateWatch",
                                "place": "place_barak_gerbang",
                                "interruptible": True,
                            },
                            {
                                "from": "10:30",
                                "to": "14:00",
                                "activity": "OverlappingPatrol",
                                "place": "place_barak_gerbang",
                                "interruptible": True,
                            },
                        ],
                        "secrets": ["secret_bribe"],
                    }
                ],
                indent=2,
            ),
            encoding="utf-8",
        )
        write_meta_for(overlap_npc_file, repo_copy)

        ok4 = run_negative_case(
            4,
            "Overlapping unconditional NPC schedule blocks (08:00-12:00 overlaps 10:30-14:00)",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok4

    # CASE (5): Reference to nonexistent place ID and nonexistent NPC ID
    with tempfile.TemporaryDirectory(prefix="kageana_neg5_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        bad_ref_npc_file = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "npcs" / "bad_ref_npc.json"
        bad_ref_npc_file.write_text(
            json.dumps(
                [
                    {
                        "id": "npc_ghost_monk",
                        "displayName": "Takeda Ghost",
                        "role": "Monk",
                        "home": "place_nonexistent_ghost_castle",
                        "traits": ["Calm"],
                        "speechHabit": "Soft",
                        "schedule": [
                            {
                                "from": "06:00",
                                "to": "18:00",
                                "activity": "Pray",
                                "place": "place_nonexistent_temple_hall",
                                "interruptible": True,
                            }
                        ],
                        "secrets": ["secret_scroll"],
                    }
                ],
                indent=2,
            ),
            encoding="utf-8",
        )
        write_meta_for(bad_ref_npc_file, repo_copy)

        bad_ref_gig_file = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "gigs" / "bad_ref_gig.json"
        bad_ref_gig_file.write_text(
            json.dumps(
                [
                    {
                        "id": "gig_ghost_refs",
                        "giver": "npc_nonexistent_giver_999",
                        "locations": ["place_nonexistent_market_999"],
                        "approaches": ["Quiet", "Social", "Clever"],
                        "rippleTemplates": ["ripple_rumor"],
                    }
                ],
                indent=2,
            ),
            encoding="utf-8",
        )
        write_meta_for(bad_ref_gig_file, repo_copy)

        ok5 = run_negative_case(
            5,
            "Reference to nonexistent place ID and nonexistent NPC ID in NPC & Gig data",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok5

    # CASE (6): Flip sign of projMat[0] AND frontFace in a temporary copy of renderer
    with tempfile.TemporaryDirectory(prefix="kageana_neg6_") as tmpdir:
        webgl_copy = pathlib.Path(tmpdir) / "webgl_vertical_slice_broken"
        shutil.copytree(REPO_ROOT / "webgl_vertical_slice", webgl_copy)

        renderer_js = webgl_copy / "src" / "renderer" / "WebGLRenderer.js"
        r_txt = renderer_js.read_text(encoding="utf-8")
        r_txt_flipped = r_txt.replace("this.projMat[0] = -this.projMat[0];", "this.projMat[0] = +this.projMat[0];").replace(
            "gl.frontFace(gl.CW);", "gl.frontFace(gl.CCW);"
        )
        renderer_js.write_text(r_txt_flipped, encoding="utf-8")

        ok6 = run_negative_case(
            6,
            "Flip sign of projMat[0] (-projMat[0] -> +projMat[0]) & frontFace (CW -> CCW) in renderer copy",
            ["python3", "tools/test_handedness.py", "--webgl-dir", str(webgl_copy)],
            REPO_ROOT,
        )
        all_passed = all_passed and ok6

    # CASE (7): L1.5 Validator — `dagangan -> tempat akses` references nonexistent place ID
    with tempfile.TemporaryDirectory(prefix="kageana_neg7_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        wares_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "items" / "wares.json"
        wdata = json.loads(wares_path.read_text(encoding="utf-8"))
        wdata["wares"][0]["accessPlaces"].append("place_istana_awan_palsu_999")
        wares_path.write_text(json.dumps(wdata, indent=2), encoding="utf-8")

        ok7 = run_negative_case(
            7,
            "L1.5 Cross-Ref (dagangan -> tempat akses): Ware references nonexistent place 'place_istana_awan_palsu_999'",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok7

    # CASE (8): L1.5 Validator — `kabar -> NPC` references nonexistent NPC ID
    with tempfile.TemporaryDirectory(prefix="kageana_neg8_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        kabar_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "rumors" / "kabar_catalog.json"
        kdata = json.loads(kabar_path.read_text(encoding="utf-8"))
        kdata["kabars"][0]["subjectNpcId"] = "npc_mata_mata_palsu_999"
        kdata["kabars"][0]["verifiedBy"].append("npc_saksi_hantu_888")
        kabar_path.write_text(json.dumps(kdata, indent=2), encoding="utf-8")

        ok8 = run_negative_case(
            8,
            "L1.5 Cross-Ref (kabar -> NPC): Kabar references nonexistent subjectNpcId & verifiedBy NPC ID",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok8

    # CASE (9): L1.5 Validator — `pesanan -> kabar` references nonexistent kabar ID
    with tempfile.TemporaryDirectory(prefix="kageana_neg9_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        orders_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "gigs" / "group_orders.json"
        odata = json.loads(orders_path.read_text(encoding="utf-8"))
        odata["orders"][0]["requiredKabarIds"].append("kabar_fiktif_belum_ada_999")
        orders_path.write_text(json.dumps(odata, indent=2), encoding="utf-8")

        ok9 = run_negative_case(
            9,
            "L1.5 Cross-Ref (pesanan -> kabar): Group Order references nonexistent kabar 'kabar_fiktif_belum_ada_999'",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok9

    # CASE (10): L1.5 Validator — `[ISI-PENGGUNA]` field in `souma.json` filled without `TEMP_` prefix
    with tempfile.TemporaryDirectory(prefix="kageana_neg10_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        souma_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "player" / "souma.json"
        sdata = json.loads(souma_path.read_text(encoding="utf-8"))
        sdata["givenNameKanji_ISI_PENGGUNA"] = "颯真"
        sdata["personalBackstory_ISI_PENGGUNA"]["originRegion"] = "Desa Iga Karangan AI"
        souma_path.write_text(json.dumps(sdata, indent=2), encoding="utf-8")

        ok10 = run_negative_case(
            10,
            "L1.5 [ISI-PENGGUNA] Guard: Invented lore without 'TEMP_' prefix in souma.json",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok10

    # CASE (11): L1.5 Validator — Wajah Asli (`true_face.json`) & Wares (`wares.json`) schema violation
    with tempfile.TemporaryDirectory(prefix="kageana_neg11_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        tf_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "tuning" / "true_face.json"
        tfdata = json.loads(tf_path.read_text(encoding="utf-8"))
        tfdata["witnessCosts"]["witnessSuspicionSpike"] = 5
        tf_path.write_text(json.dumps(tfdata, indent=2), encoding="utf-8")

        wares_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "items" / "wares.json"
        wdata = json.loads(wares_path.read_text(encoding="utf-8"))
        wdata["wares"] = wdata["wares"][:5]
        wares_path.write_text(json.dumps(wdata, indent=2), encoding="utf-8")

        ok11 = run_negative_case(
            11,
            "L1.5 Schema/Tuning Guard: < 8 ware categories in wares.json & tampered witnessSuspicionSpike in true_face.json",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok11

    # CASE (12): L1.9 Validator — Dishonest M0 package naming ('game', 'playable', 'build final') & broken SimCli csproj
    with tempfile.TemporaryDirectory(prefix="kageana_neg12_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        iss_path = repo_copy / "installer" / "KageAna_M0_PaketUjiCoba.iss"
        iss_txt = iss_path.read_text(encoding="utf-8")
        iss_txt = iss_txt.replace(
            "Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)",
            "KAGE-ANA Playable Game Build Final",
        )
        iss_path.write_text(iss_txt, encoding="utf-8")

        csproj_path = repo_copy / "unity_project" / "KageAna.SimCli.csproj"
        csproj_txt = csproj_path.read_text(encoding="utf-8").replace(
            "<SelfContained>true</SelfContained>",
            "<SelfContained>false</SelfContained>",
        )
        csproj_path.write_text(csproj_txt, encoding="utf-8")

        ok12 = run_negative_case(
            12,
            "L1.9 M0 Package Guard: Dishonest terms ('playable', 'game', 'build final') in Inno Setup & SelfContained=false in SimCli.csproj",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok12

    # CASE (13): Gelombang A Sandbox Honest Naming Guard
    with tempfile.TemporaryDirectory(prefix="kageana_neg13_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        sb_path = repo_copy / "unity_project" / "Sandbox" / "SandboxProgram.cs"
        sb_txt = sb_path.read_text(encoding="utf-8").replace(
            "Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)",
            "Playable Build Final KageAna",
        )
        sb_path.write_text(sb_txt, encoding="utf-8")

        ok13 = run_negative_case(
            13,
            "Gelombang A Sandbox Honest Naming Guard: Replaced mandatory honest title with 'Playable Build Final'",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok13

    # CASE (14): L2 Place Graph Validator — Broken neighbor place ID & non-positive travelMinutes
    with tempfile.TemporaryDirectory(prefix="kageana_neg14_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        places_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "places" / "kurokawa_places.json"
        pdata = json.loads(places_path.read_text(encoding="utf-8"))
        pdata[0]["neighbors"].append({"to": "place_istana_langit_999", "travelMinutes": -5, "routeType": "jalan_utama"})
        places_path.write_text(json.dumps(pdata, indent=2), encoding="utf-8")

        ok14 = run_negative_case(
            14,
            "L2 Place Graph Guard: Neighbor edge references nonexistent 'place_istana_langit_999' with travelMinutes=-5",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok14

    # CASE (15): A2-1 Event-Driven Rumor Guard — Re-introducing hand-authored rumor_chains.json & removing {motive} slot in claim_templates.json
    with tempfile.TemporaryDirectory(prefix="kageana_neg15_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        rchains_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "rumors" / "rumor_chains.json"
        rchains_path.write_text(json.dumps({"rumorChains": []}, indent=2), encoding="utf-8")
        write_meta_for(rchains_path, repo_copy)

        ct_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "rumors" / "claim_templates.json"
        ct_data = json.loads(ct_path.read_text(encoding="utf-8"))
        ct_data["templates"][0]["templateId"] = "Kalimat tulis tangan tanpa slot"
        ct_path.write_text(json.dumps(ct_data, indent=2), encoding="utf-8")

        ok15 = run_negative_case(
            15,
            "A2-1 Event-Driven Rumor Guard: Hand-authored rumor_chains.json present & missing template slots in claim_templates.json",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok15

    # CASE (16): A2-2 Kitab 7.1 Canonical Role Guard — Swapping ohana and okiku roles/homes
    with tempfile.TemporaryDirectory(prefix="kageana_neg16_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        npcs_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "npcs" / "kurokawa_npcs.json"
        ndata = json.loads(npcs_path.read_text(encoding="utf-8"))
        for n in ndata:
            if n["id"] == "ohana":
                n["home"] = "place_kedai_teh"
                n["roleCategory"] = "Merchant"
                n["role"] = "Pemilik Kedai Teh Pasar"
        npcs_path.write_text(json.dumps(ndata, indent=2), encoding="utf-8")

        ok16 = run_negative_case(
            16,
            "A2-2 Kitab 7.1 Canon Guard: Swapped ohana role from Nagaya Landlady to Kedai Teh Owner",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok16

    # CASE (17): A2-3 Build Isolation & BANGUN_PAKET.bat SEBAGIAN Guard
    with tempfile.TemporaryDirectory(prefix="kageana_neg17_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        props_path = repo_copy / "unity_project" / "Directory.Build.props"
        props_txt = props_path.read_text(encoding="utf-8").replace(
            "<BaseIntermediateOutputPath>obj/$(MSBuildProjectName)/</BaseIntermediateOutputPath>",
            ""
        )
        props_path.write_text(props_txt, encoding="utf-8")

        bangun_path = repo_copy / "BANGUN_PAKET.bat"
        bangun_txt = bangun_path.read_text(encoding="utf-8").replace("STATUS AKHIR: SEBAGIAN", "SEMUA_OK")
        bangun_path.write_text(bangun_txt, encoding="utf-8")

        ok17 = run_negative_case(
            17,
            "A2-3 Build Guard: Missing BaseIntermediateOutputPath in Directory.Build.props & missing STATUS AKHIR: SEBAGIAN in BANGUN_PAKET.bat",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok17

    # CASE (18): L4 Clothing Guard — Injecting prohibited pure black (#000000 / shozoku hitam) into garments.json
    with tempfile.TemporaryDirectory(prefix="kageana_neg18_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        garm_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "clothing" / "garments.json"
        gdata = json.loads(garm_path.read_text(encoding="utf-8"))
        gdata["garments"][1]["primaryHex"] = "#000000"
        gdata["garments"][1]["name"] = "Shozoku Hitam Total Hollywood"
        garm_path.write_text(json.dumps(gdata, indent=2), encoding="utf-8")

        ok18 = run_negative_case(
            18,
            "L4 Clothing Guard: Prohibited pure black (#000000 / Shozoku Hitam Total) in garments.json",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok18

    # CASE (19): L7 Micro-Story Condition Guard — Fixed-hour trigger ("fixed_hour") & unknown NPC in micro_stories.json
    with tempfile.TemporaryDirectory(prefix="kageana_neg19_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        st_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "stories" / "micro_stories.json"
        sdata = json.loads(st_path.read_text(encoding="utf-8"))
        sdata[0]["trigger"]["conditionType"] = "fixed_hour"
        sdata[0]["trigger"]["primaryNpcId"] = "npc_hantu_999"
        st_path.write_text(json.dumps(sdata, indent=2), encoding="utf-8")

        ok19 = run_negative_case(
            19,
            "L7 Micro-Story Guard: Prohibited fixed_hour trigger & unknown primaryNpcId in micro_stories.json",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok19

    # CASE (20): L8 Festival & 26-NPC Guard — Tampered Obon violenceTabooMultiplier & missing 26th canonical NPC
    with tempfile.TemporaryDirectory(prefix="kageana_neg20_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        fest_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "festivals" / "kurokawa_festivals.json"
        fdata = json.loads(fest_path.read_text(encoding="utf-8"))
        for f in fdata["festivals"]:
            if f["id"] == "Obon":
                f["violenceTabooMultiplier"] = 1
        fest_path.write_text(json.dumps(fdata, indent=2), encoding="utf-8")

        npcs_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "npcs" / "kurokawa_npcs.json"
        ndata = json.loads(npcs_path.read_text(encoding="utf-8"))
        npcs_path.write_text(json.dumps(ndata[:-1], indent=2), encoding="utf-8")

        ok20 = run_negative_case(
            20,
            "L8 Festival & 26-NPC Guard: Tampered Obon violenceTabooMultiplier=1 & missing 26th canonical NPC shino",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok20


    # CASE (21): D-1 Salience Tuning Guard — Inverted thresholds & < 15 actionProfiles in salience.json
    with tempfile.TemporaryDirectory(prefix="kageana_neg21_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        sal_path = repo_copy / "unity_project" / "Assets" / "_Project" / "Data" / "tuning" / "salience.json"
        sdata = json.loads(sal_path.read_text(encoding="utf-8"))
        sdata["thresholds"]["routineMaxSalience"] = 0.85
        sdata["thresholds"]["salientMinSalience"] = 0.39
        sdata["actionProfiles"] = sdata["actionProfiles"][:3]
        sal_path.write_text(json.dumps(sdata, indent=2), encoding="utf-8")

        ok21 = run_negative_case(
            21,
            "D-1 Salience Tuning Guard: Inverted routineMaxSalience >= salientMinSalience & < 15 actionProfiles in salience.json",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok21

    # CASE (22): D-7 Uji Anekdot v2 Guard — Removing non-leading Question 1 ("Ceritakan satu kejadian yang kamu ingat")
    with tempfile.TemporaryDirectory(prefix="kageana_neg22_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        ua_path = repo_copy / "docs" / "UJI_ANEKDOT.md"
        ua_txt = ua_path.read_text(encoding="utf-8").replace(
            "Ceritakan satu kejadian yang kamu ingat",
            "Ceritakan kabar burung yang berubah bentuk dari 3 mata rantai"
        )
        ua_path.write_text(ua_txt, encoding="utf-8")

        ok22 = run_negative_case(
            22,
            "D-7 Uji Anekdot v2 Guard: Replaced non-leading Question 1 with leading rumor prompt in docs/UJI_ANEKDOT.md",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok22

    # CASE (23): D-9.5 Installer-Lint Guard — Deleting one canonical data file from staging/Data/
    with tempfile.TemporaryDirectory(prefix="kageana_neg23_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        (repo_copy / "staging" / "Data" / "tuning" / "salience.json").unlink()

        ok23 = run_negative_case(
            23,
            "D-9.5 Installer-Lint Guard: Deleted staging/Data/tuning/salience.json -> rejected by validate_installer.py",
            ["python3", "tools/validate_installer.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok23

    # CASE (24): D-9.5 Installer-Lint Guard — Changing MyAppVersion in KageAna.iss without updating AppId
    with tempfile.TemporaryDirectory(prefix="kageana_neg24_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        iss_path = repo_copy / "installer" / "KageAna.iss"
        iss_txt = iss_path.read_text(encoding="utf-8").replace(
            "#define MyAppVersion \"0.4.0\"",
            "#define MyAppVersion \"0.5.0\""
        )
        iss_path.write_text(iss_txt, encoding="utf-8")

        ok24 = run_negative_case(
            24,
            "D-9.5 Installer-Lint Guard: Changed MyAppVersion to 0.5.0 without updating AppId in installer/KageAna.iss",
            ["python3", "tools/validate_installer.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok24

    # CASE (25): D-9.5 Installer-Lint Guard — Machine-specific absolute path & forbidden word in installer/KageAna.iss
    with tempfile.TemporaryDirectory(prefix="kageana_neg25_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        iss_path = repo_copy / "installer" / "KageAna.iss"
        iss_txt = iss_path.read_text(encoding="utf-8") + "\n; C:\\Users\\DeveloperPribadi\\Desktop\\playable_build_final.exe\n"
        iss_path.write_text(iss_txt, encoding="utf-8")

        ok25 = run_negative_case(
            25,
            "D-9.5 Installer-Lint Guard: Machine-specific absolute path (C:\\Users\\...) & forbidden words in KageAna.iss",
            ["python3", "tools/validate_installer.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok25


    # CASE (26): E1.2 Sim Portability Guard — Injecting System.Text.Json & UnityEngine into Runtime/Sim and breaking netstandard2.1
    with tempfile.TemporaryDirectory(prefix="kageana_neg26_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        sim_cs = repo_copy / "unity_project" / "Assets" / "_Project" / "Runtime" / "Sim" / "SimDataModels.cs"
        sim_cs.write_text("using System.Text.Json;\nusing UnityEngine;\n" + sim_cs.read_text(encoding="utf-8"), encoding="utf-8")
        sim_proj = repo_copy / "unity_project" / "KageAna.Sim.csproj"
        sim_proj.write_text(sim_proj.read_text(encoding="utf-8").replace("netstandard2.1", "net9.0"), encoding="utf-8")

        ok26 = run_negative_case(
            26,
            "E1.2 Sim Portability Guard: Injected System.Text.Json & UnityEngine into Runtime/Sim/SimDataModels.cs & removed netstandard2.1",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok26

    # CASE (27): E2.1 Anti-Filler Guard — Simulating modulus quota filler (--inject-modulus-filler) rejected by anti-filler metrics
    with tempfile.TemporaryDirectory(prefix="kageana_neg27_") as tmpdir:
        out_json = pathlib.Path(tmpdir) / "neg27_report.json"
        ok27 = run_negative_case(
            27,
            "E2.1 Anti-Filler Guard: Simulated modulus quota filler (--inject-modulus-filler) rejected by anti-filler metrics",
            [
                "python3",
                "tools/run_headless_sim.py",
                "--seed",
                "7",
                "--days",
                "1",
                "--inject-modulus-filler",
                "--out",
                str(out_json),
            ],
            REPO_ROOT,
        )
        all_passed = all_passed and ok27

    # CASE (28): E2.2 Hardcoded NPC ID Scanner — Injecting literal NPC IDs ("ohana", "matsubei") into Runtime/Sim/Rumor/SimEconomyAndPressureSystem.cs
    with tempfile.TemporaryDirectory(prefix="kageana_neg28_") as tmpdir:
        repo_copy = make_temp_repo_copy(tmpdir)
        econ_cs = repo_copy / "unity_project" / "Assets" / "_Project" / "Runtime" / "Sim" / "Rumor" / "SimEconomyAndPressureSystem.cs"
        econ_cs.write_text(
            econ_cs.read_text(encoding="utf-8") + "\n// Injected violation:\nnamespace KageAna.Sim { internal static class BadId { internal static string X = \"ohana\"; internal static string Y = \"matsubei\"; } }\n",
            encoding="utf-8",
        )

        ok28 = run_negative_case(
            28,
            "E2.2 Hardcoded NPC ID Guard: Injected literal NPC IDs ('ohana', 'matsubei') into Runtime/Sim/Rumor/SimEconomyAndPressureSystem.cs",
            ["python3", "tools/validate_data.py", "--repo-root", str(repo_copy)],
            repo_copy,
        )
        all_passed = all_passed and ok28

    print("\n======================================================================")
    if all_passed:
        print("NEGATIVE CI SUITE RESULT: ALL 28/28 INJECTED VIOLATIONS CAUGHT (PASS)")
        print("======================================================================")
        return 0
    else:
        print("NEGATIVE CI SUITE RESULT: ONE OR MORE INJECTED VIOLATIONS ESCAPED (FAIL)")
        print("======================================================================")
        return 1


if __name__ == "__main__":
    sys.exit(main())
