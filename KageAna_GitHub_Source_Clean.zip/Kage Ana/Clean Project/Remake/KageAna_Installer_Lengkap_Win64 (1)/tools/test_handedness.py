#!/usr/bin/env python3
"""
KAGE-ANA v3.0 — Real 4-Part Handedness Regression Suite (Section 12.6 & L0.1b)
Executes ALL FOUR tests directly against the real, unmodified WebGL game code
(Shaders.js, ProceduralTextures.js, MeshBuilder.js, WebGLRenderer.js, SceneAssembler.js,
GameplayControllers.js, and main.js) inside headless Chromium WebGL:
  1. Mathematical Test (Sim): Calls real `player.update(dt, keys, ...)` on `window.KAGE_VERTICAL_SLICE.player`
     (`PlayerController` from `GameplayControllers.js`) and verifies that moving forward (`KeyW`) after `+yaw`
     displaces `player.x` toward `+X` (screen-right), and strafing right (`KeyD`) at `yaw=0` displaces `player.x > 0`.
  2. Projection Test (Render): Calls real `renderer.renderScene(cam, ...)` on `window.KAGE_VERTICAL_SLICE.renderer`
     (`WebGLRenderer` from `WebGLRenderer.js`), inspects the actual `renderer.projMat[0]`, `renderer.viewProjMat`,
     and WebGL `gl.getParameter(gl.FRONT_FACE)` state (`gl.CW`), and transforms `P_right = player + forward*10 + right*3`
     (`NDC.x > 0`) and `P_left = player + forward*10 - right*3` (`NDC.x < 0`) using `renderer.viewProjMat`.
  3. Input Simulation Test: Dispatches real `MouseEvent('mousemove')` events on `window` with Pointer Lock mocked
     to `canvas` so `main.js`'s actual `mousemove` listener and actual `applyLook(dx, dy)` execute!
     Verifies `movementX = +50 -> yaw = +0.1100` (`50 * 0.0022`), `movementX = -100 -> yaw = -0.1100`,
     and `movementY = -50 -> pitch = +0.1000` (`50 * 0.0020`, using `main.js`'s real `MOUSE_SENS_PITCH = 0.0020`).
  4. Visual Test (Headless WebGL Framebuffer): Renders a high-contrast red marker box "R" at `player + forward*10 + right*3`
     via `renderer.renderScene` and verifies via `gl.readPixels` that all of the marker pixels appear on the right
     half of the screen (`redRightPixels > 100`, `redLeftPixels == 0`, `centroidNormalizedX > 0.55`).
"""

import os
import re
import sys
import json
import argparse
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def run_all_4_handedness_tests(webgl_dir: str) -> dict:
    opts = Options()
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=640,360")
    opts.add_argument("--use-gl=angle")
    opts.add_argument("--use-angle=swiftshader")
    opts.add_argument("--enable-webgl")
    opts.add_argument("--ignore-gpu-blocklist")

    driver = webdriver.Chrome(options=opts)
    try:
        driver.get("about:blank")
        css_content = open(os.path.join(webgl_dir, "css", "sengoku_ui.css"), "r", encoding="utf-8").read()
        index_html = open(os.path.join(webgl_dir, "index.html"), "r", encoding="utf-8").read()
        body_match = re.search(r"<body[^>]*>(.*?)<script", index_html, re.DOTALL)
        body_html = body_match.group(1) if body_match else index_html

        driver.execute_script(
            """
            const style = document.createElement('style');
            style.textContent = arguments[0];
            document.head.appendChild(style);
            document.body.innerHTML = arguments[1];
            """,
            css_content,
            body_html,
        )

        js_files = [
            "src/data_bundle.js",
            "src/renderer/Shaders.js",
            "src/renderer/ProceduralTextures.js",
            "src/renderer/MeshBuilder.js",
            "src/renderer/WebGLRenderer.js",
            "src/game/SceneAssembler.js",
            "src/game/GameplayControllers.js",
            "src/main.js",
        ]
        for jf in js_files:
            code = open(os.path.join(webgl_dir, jf), "r", encoding="utf-8").read()
            driver.execute_script(code)

        res = driver.execute_script(
            """
            const s = window.KAGE_VERTICAL_SLICE;
            s.state.paused = true; // Stop background rAF loop for deterministic inspection

            // =========================================================================
            // TEST 1: Mathematical Test via REAL PlayerController.update()
            // =========================================================================
            s.player.reset();
            s.player.x = 0.0; s.player.z = -20.0; s.player.yaw = 0.15;
            s.player.vx = 0; s.player.vz = 0;
            s.player.update(0.1, { KeyW: true }, [], [], [], [], 'SORE', null);
            const fwdDisplacedX = s.player.x;
            const fwdDisplacedZ = s.player.z - (-20.0);

            s.player.reset();
            s.player.x = 0.0; s.player.z = -20.0; s.player.yaw = 0.0;
            s.player.vx = 0; s.player.vz = 0;
            s.player.update(0.1, { KeyD: true }, [], [], [], [], 'SORE', null);
            const rightDisplacedX = s.player.x;

            // =========================================================================
            // TEST 2 & TEST 4: Projection & Visual Test via REAL WebGLRenderer.renderScene()
            // =========================================================================
            // Spy on gl.frontFace during main pass before viewmodel pass resets it
            const gl = s.renderer.gl;
            let mainPassFrontFace = null;
            const origDrawPass = s.renderer.drawPassWithCelAndOutlines.bind(s.renderer);
            s.renderer.drawPassWithCelAndOutlines = function(items, lightCfg, camera, lanterns, onStats) {
                if (mainPassFrontFace === null) {
                    mainPassFrontFace = gl.getParameter(gl.FRONT_FACE);
                }
                return origDrawPass(items, lightCfg, camera, lanterns, onStats);
            };

            const cam = { x: 0.0, y: 1.68, z: -25.0, yaw: 0.0, pitch: 0.0, roll: 0.0 };
            // Place bright emissive Cinnabar marker "R" at player + forward*10 + right*3 = (+3.0, 1.68, -15.0)
            const markerR = [{
                mesh: 'box', tex: 'shoji', color: '#ff1010', emissive: 2.0,
                x: 3.0, y: 1.68, z: -15.0, sx: 1.2, sy: 1.2, sz: 1.2,
                outlineWidth: 0, noShadow: true
            }];
            s.renderer.renderScene(cam, markerR, [], []);

            // Transform P_right (+3, 1.68, -15) and P_left (-3, 1.68, -15) using the REAL renderer.viewProjMat
            const vp = s.renderer.viewProjMat;
            function projectWorldToNDC(wx, wy, wz) {
                const cx = vp[0]*wx + vp[4]*wy + vp[8]*wz + vp[12];
                const cy = vp[1]*wx + vp[5]*wy + vp[9]*wz + vp[13];
                const cz = vp[2]*wx + vp[6]*wy + vp[10]*wz + vp[14];
                const cw = vp[3]*wx + vp[7]*wy + vp[11]*wz + vp[15];
                return { x: cx / cw, y: cy / cw, z: cz / cw };
            }
            const ndcRight = projectWorldToNDC(3.0, 1.68, -15.0);
            const ndcLeft  = projectWorldToNDC(-3.0, 1.68, -15.0);

            // Sample WebGL framebuffer pixels for Visual Test 4
            const w = s.renderer.width;
            const h = s.renderer.height;
            const pixels = new Uint8Array(w * h * 4);
            gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, pixels);
            let redLeftCount = 0;
            let redRightCount = 0;
            let sumX = 0;
            for (let y = 0; y < h; y++) {
                for (let x = 0; x < w; x++) {
                    const idx = (y * w + x) * 4;
                    if (pixels[idx] > 210 && pixels[idx + 1] < 60 && pixels[idx + 2] < 60) {
                        if (x < w * 0.5) redLeftCount++;
                        else redRightCount++;
                        sumX += x;
                    }
                }
            }
            const totalRed = redLeftCount + redRightCount;

            // =========================================================================
            // TEST 3: Input Test via REAL window mousemove listener & REAL applyLook() in main.js
            // =========================================================================
            s.state.paused = false;
            s.state.missionFailed = false;
            s.state.missionWon = false;
            s.player.yaw = 0.0;
            s.player.pitch = 0.0;

            const canvasEl = document.getElementById('webglCanvas');
            Object.defineProperty(document, 'pointerLockElement', {
                value: canvasEl,
                configurable: true
            });

            window.dispatchEvent(new MouseEvent('mousemove', { movementX: 50, movementY: 0 }));
            const yawAfterRight50 = s.player.yaw;

            window.dispatchEvent(new MouseEvent('mousemove', { movementX: -100, movementY: 0 }));
            const yawAfterLeft100 = s.player.yaw;

            window.dispatchEvent(new MouseEvent('mousemove', { movementX: 0, movementY: -50 }));
            const pitchAfterUp50 = s.player.pitch;

            s.state.paused = true;

            return {
                test1_math: {
                    fwdDisplacedX: Number(fwdDisplacedX.toFixed(5)),
                    fwdDisplacedZ: Number(fwdDisplacedZ.toFixed(5)),
                    rightDisplacedX: Number(rightDisplacedX.toFixed(5))
                },
                test2_projection: {
                    projMat0: Number(s.renderer.projMat[0].toFixed(4)),
                    mainPassFrontFaceIsCW: mainPassFrontFace === gl.CW,
                    ndcRightX: Number(ndcRight.x.toFixed(4)),
                    ndcLeftX: Number(ndcLeft.x.toFixed(4))
                },
                test3_input: {
                    yawAfterRight50: Number(yawAfterRight50.toFixed(4)),
                    yawAfterLeft100: Number(yawAfterLeft100.toFixed(4)),
                    pitchAfterUp50: Number(pitchAfterUp50.toFixed(4))
                },
                test4_visual: {
                    redRightPixels: redRightCount,
                    redLeftPixels: redLeftCount,
                    centroidNormalizedX: totalRed > 0 ? Number(((sumX / totalRed) / w).toFixed(4)) : -1
                }
            };
            """
        )
        return res
    finally:
        driver.quit()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--webgl-dir", default=os.path.join(REPO_ROOT, "webgl_vertical_slice"))
    args = parser.parse_args()

    res = run_all_4_handedness_tests(args.webgl_dir)
    t1 = res["test1_math"]
    t2 = res["test2_projection"]
    t3 = res["test3_input"]
    t4 = res["test4_visual"]

    failures = []
    if not (t1["fwdDisplacedX"] > 0.0 and t1["fwdDisplacedZ"] > 0.0 and t1["rightDisplacedX"] > 0.0):
        failures.append(f"Test 1 (Math via real PlayerController.update) failed: {t1}")
    if not (t2["projMat0"] < 0.0 and t2["mainPassFrontFaceIsCW"] and t2["ndcRightX"] > 0.0 and t2["ndcLeftX"] < 0.0):
        failures.append(f"Test 2 (Projection via real WebGLRenderer.renderScene) failed: {t2}")
    if not (abs(t3["yawAfterRight50"] - 0.1100) < 1e-4 and t3["yawAfterLeft100"] < 0.0 and abs(t3["pitchAfterUp50"] - 0.1000) < 1e-4):
        failures.append(f"Test 3 (Input via real main.js mousemove -> applyLook) failed: {t3}")
    if not (t4["redRightPixels"] > 100 and t4["redLeftPixels"] == 0 and t4["centroidNormalizedX"] > 0.55):
        failures.append(f"Test 4 (Visual 'R' marker framebuffer readback) failed: {t4}")

    if failures:
        print("[test_handedness] FAILED:")
        for f in failures:
            print("  -", f)
        return 1

    print(
        "[test_handedness] PASS (4/4 Kitab 12.6 checks executing REAL game code):\n"
        f"  1. Math Test (Real PlayerController.update):   +yaw KeyW dx=+{t1['fwdDisplacedX']} (>0), yaw=0 KeyD dx=+{t1['rightDisplacedX']} (>0)\n"
        f"  2. Projection Test (Real WebGLRenderer):       projMat[0]={t2['projMat0']} (<0), frontFace=CW ({t2['mainPassFrontFaceIsCW']}), P_right.ndc.x=+{t2['ndcRightX']}, P_left.ndc.x={t2['ndcLeftX']}\n"
        f"  3. Input Test (Real main.js applyLook):        movementX(+50)->yaw=+{t3['yawAfterRight50']:.4f}, movementY(-50)->pitch=+{t3['pitchAfterUp50']:.4f} (50 * 0.0020)\n"
        f"  4. Visual Test (Real WebGL 'R' Box Readback):  right_pixels={t4['redRightPixels']}, left_pixels={t4['redLeftPixels']}, screen_centroid_x={t4['centroidNormalizedX']} (>0.50 right half)"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
