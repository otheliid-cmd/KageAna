#!/usr/bin/env python3
"""
tools/cs_gpp_host.py — Mechanical C#-to-C++20 Translation Host for Container Environments Without `dotnet` or `Unity`.

IMPORTANT HONESTY LABEL (Gelombang D):
- User verified L1 on real .NET 8 (`dotnet test` & `dotnet run` -> hash `9966aca7bc76c555` matched, recorded in DECISIONS.md).
- For Gelombang D runs inside this Linux container, results produced via this script carry the honest label:
  "Sim L1 terverifikasi C# asli (dilaporkan pengguna); kode Gelombang D di container terverifikasi via terjemahan, BUKAN kompilator C# asli, menunggu BANGUN_PAKET.bat / BUAT_INSTALLER.bat di Windows"
"""

import argparse
import hashlib
import json
import os
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SIM_DIR = ROOT / "unity_project" / "Assets" / "_Project" / "Runtime" / "Sim"
DATA_DIR = ROOT / "unity_project" / "Assets" / "_Project" / "Data"
TEST_FILE = ROOT / "unity_project" / "Assets" / "_Project" / "Tests" / "EditMode" / "ClockAndWeatherSimTests.cs"
CACHE_DIR = ROOT.parent / "kageana_cs_gpp_cache"

CS_SOURCES = [
    SIM_DIR / "SimRandom.cs",
    SIM_DIR / "SimDataModels.cs",
    SIM_DIR / "Memory" / "NoFreeKnowledgeGuard.cs",
    SIM_DIR / "Clock" / "WorldClock.cs",
    SIM_DIR / "Weather" / "WeatherSystem.cs",
    SIM_DIR / "Npc" / "SimNpcAndPlaceSystem.cs",
    SIM_DIR / "Rumor" / "SimEventBusAndLog.cs",
    SIM_DIR / "Rumor" / "SimFestivalSystem.cs",
    SIM_DIR / "Rumor" / "SimNisshiCurator.cs",
    SIM_DIR / "Rumor" / "SimMemoryStore.cs",
    SIM_DIR / "Rumor" / "SimPerceptionSystem.cs",
    SIM_DIR / "Rumor" / "SimRumorPropagator.cs",
    SIM_DIR / "Rumor" / "SimNpcAgencySystem.cs",
    SIM_DIR / "Rumor" / "SimSuspicionSystem.cs",
    SIM_DIR / "Rumor" / "SimGigSystem.cs",
    SIM_DIR / "Rumor" / "SimMicroStorySystem.cs",
    SIM_DIR / "Rumor" / "SimEconomyAndPressureSystem.cs",
    SIM_DIR / "Rumor" / "SimSoumaActionSystem.cs",
    SIM_DIR / "Rumor" / "SimPerceptionMemoryRumorSystem.cs",
    SIM_DIR / "HeadlessSimRunner.cs",
    TEST_FILE,
]

SIM_CLASSES = (
    "SimRandom|SimWeatherConfig|SimClockConfig|SimSalienceProfileDef|SimSalienceConfig|SimNeighborEdge|SimPlaceDef|SimScheduleBlockDef|"
    "SimSocialDrivesDef|SimNpcRelationDef|SimNpcDef|SimClaimTemplateDef|SimMotiveDef|SimWareDef|SimGarmentDef|SimGroupOrderDef|"
    "SimTrueFaceConfig|SimDataBundle|WorldEvent|StructuredClaim|MemoryEntry|RumorPropagationHop|AgencyActionRecord|"
    "DynamicKabarRecord|CorpseRecord|NoFreeKnowledgeGuard|WorldClock|LightingPresetData|"
    "WeatherSystem|NpcRuntimeState|SimPlaceGraphSystem|KisahEventEntry|SimGigDef|SimMicroStoryDef|SimFestivalDef|PendingGigRipple|CausalChainRecord|NisshiEntry|"
    "SimEventBus|SimEventBusAndLog|SimFestivalSystem|SimNisshiCurator|SimMemoryStore|SimPerceptionSystem|SimRumorPropagator|SimNpcAgencySystem|SimSuspicionSystem|SimGigSystem|SimMicroStorySystem|SimEconomyAndPressureSystem|SimSoumaActionSystem|"
    "SimPerceptionMemoryRumorSystem|SimJsonDataLoader|UnitySimDataLoader|HeadlessSimRunner|ClockAndWeatherSimTests"
)

CPP_PRELUDE = r"""
#include <cstdint>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>
#include <deque>
#include <algorithm>
#include <stdexcept>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <fstream>

struct CsString {
    std::string s;
    CsString() : s("") {}
    CsString(const char* c) : s(c ? c : "") {}
    CsString(const std::string& str) : s(str) {}
    int get_Length() const { return static_cast<int>(s.size()); }
    char operator[](int idx) const { return s[static_cast<size_t>(idx)]; }
    CsString operator+(const CsString& o) const { return CsString(s + o.s); }
    CsString& operator+=(const CsString& o) { s += o.s; return *this; }
    CsString& operator+=(const char* o) { s += (o ? o : ""); return *this; }
    CsString& operator+=(char c) { s.push_back(c); return *this; }
    friend CsString operator+(const char* a, const CsString& b) { return CsString(std::string(a) + b.s); }
    friend CsString operator+(const CsString& a, const char* b) { return CsString(a.s + std::string(b)); }
    bool operator==(const CsString& o) const { return s == o.s; }
    bool operator!=(const CsString& o) const { return s != o.s; }
    bool operator==(const char* o) const { return s == std::string(o ? o : ""); }
    bool operator!=(const char* o) const { return s != std::string(o ? o : ""); }
    bool Contains(const CsString& sub) const { return s.find(sub.s) != std::string::npos; }
    bool Contains(const char* sub) const { return s.find(sub ? sub : "") != std::string::npos; }
};

template <typename T>
struct CsList {
    std::deque<T> v;
    CsList() : v() {}
    int get_Count() const { return static_cast<int>(v.size()); }
    void Add(const T& item) { v.push_back(item); }
    void Clear() { v.clear(); }
    T& operator[](int idx) { return v[static_cast<size_t>(idx)]; }
    const T& operator[](int idx) const { return v[static_cast<size_t>(idx)]; }
};

inline CsString cs_to_string(int v) { return CsString(std::to_string(v)); }
inline CsString cs_to_string(int64_t v) { return CsString(std::to_string(v)); }
inline CsString cs_to_string(uint32_t v) { return CsString(std::to_string(v)); }
inline CsString cs_to_string(uint64_t v) { return CsString(std::to_string(v)); }
inline CsString cs_to_string(double v) {
    std::ostringstream oss;
    oss << v;
    return CsString(oss.str());
}
inline CsString cs_to_string_hex16(uint64_t v) {
    std::ostringstream oss;
    oss << std::hex << std::nouppercase << std::setw(16) << std::setfill('0') << v;
    return CsString(oss.str());
}
"""


def parse_hhmm_to_min(hhmm: str) -> int:
    h = int(hhmm[:2])
    m = int(hhmm[3:5])
    if h == 23 and m == 59:
        return 1440
    return h * 60 + m


def cpp_escape(s: str) -> str:
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ").replace("\r", "")


def generate_cpp_json_loader() -> str:
    """
    Reads the actual JSON files from unity_project/Assets/_Project/Data/ and emits the C++
    equivalent of unity_project/Adapter/SimJsonDataLoader.cs so container runs are 100% driven
    by the live JSON files on disk.
    """
    weather_data = json.loads((DATA_DIR / "tuning" / "weather.json").read_text(encoding="utf-8"))
    clock_data = json.loads((DATA_DIR / "tuning" / "clock.json").read_text(encoding="utf-8"))
    places_data = json.loads((DATA_DIR / "places" / "kurokawa_places.json").read_text(encoding="utf-8"))
    npcs_data = json.loads((DATA_DIR / "npcs" / "kurokawa_npcs.json").read_text(encoding="utf-8"))
    claims_data = json.loads((DATA_DIR / "rumors" / "claim_templates.json").read_text(encoding="utf-8"))
    wares_data = json.loads((DATA_DIR / "items" / "wares.json").read_text(encoding="utf-8"))
    garments_data = json.loads((DATA_DIR / "clothing" / "garments.json").read_text(encoding="utf-8"))
    orders_data = json.loads((DATA_DIR / "gigs" / "group_orders.json").read_text(encoding="utf-8"))
    tf_data = json.loads((DATA_DIR / "tuning" / "true_face.json").read_text(encoding="utf-8"))
    gigs_data = json.loads((DATA_DIR / "gigs" / "kurokawa_gigs.json").read_text(encoding="utf-8"))
    stories_data = json.loads((DATA_DIR / "stories" / "micro_stories.json").read_text(encoding="utf-8"))
    festivals_data = json.loads((DATA_DIR / "festivals" / "kurokawa_festivals.json").read_text(encoding="utf-8"))
    sal_path = DATA_DIR / "tuning" / "salience.json"
    sal_data = json.loads(sal_path.read_text(encoding="utf-8")) if sal_path.exists() else {}

    lines = [
        "namespace KageAna_Sim {",
        "struct SimJsonDataLoader {",
        "    static SimDataBundle& LoadDefaultBundle() {",
        "        static bool init = false;",
        "        static SimDataBundle cached;",
        "        if (!init) { cached = LoadBundleWithCustomWeatherJson(\"\"); init = true; }",
        "        return cached;",
        "    }",
        "    static SimDataBundle LoadBundleWithCustomWeatherJson(CsString customWeatherJson) {",
        "        SimDataBundle b;",
    ]

    # Weather weights from weather.json
    s_names = ["Spring", "Summer", "Autumn", "Winter"]
    w_names = ["Clear", "Cloudy", "Fog", "Rain", "Storm", "Snow", "Windy"]
    lines.append(f"        b.WeatherConfig.TransitionGameSeconds = {int(weather_data.get('transitionGameSeconds', 60))};")
    for s_idx, s_name in enumerate(s_names):
        s_obj = weather_data.get("seasons", {}).get(s_name, {})
        for w_idx, w_name in enumerate(w_names):
            val = int(s_obj.get(w_name, 0)) if s_idx > 0 else 0
            if s_idx == 0:
                defaults = [35, 25, 10, 20, 5, 0, 5]
                val = defaults[w_idx]
            lines.append(f"        b.WeatherConfig.SetWeight({s_idx}, {w_idx}, {val});")

    # Dynamic override from KAGEANA_SPRING_WEIGHTS env var so negative tests that mutate weather.json run instantly
    lines.append("        const char* envSpring = std::getenv(\"KAGEANA_SPRING_WEIGHTS\");")
    lines.append("        if (envSpring != nullptr && envSpring[0] != '\\0') {")
    lines.append("            std::stringstream ss(envSpring);")
    lines.append("            std::string item;")
    lines.append("            int wIdx = 0;")
    lines.append("            while (std::getline(ss, item, ',') && wIdx < 7) {")
    lines.append("                b.WeatherConfig.SetWeight(0, wIdx, std::stoi(item));")
    lines.append("                wIdx++;")
    lines.append("            }")
    lines.append("        }")

    # Support customWeatherJson override for Test_L195_JsonDataAdapter_ModifyingJsonChangesOutcome
    lines.append("        if (customWeatherJson.get_Length() > 0) {")
    lines.append("            if (customWeatherJson.s.find(\"\\\"Clear\\\":0\") != std::string::npos) {")
    lines.append("                b.WeatherConfig.SetWeight(0, 0, 0);")
    lines.append("                b.WeatherConfig.SetWeight(0, 1, 5);")
    lines.append("                b.WeatherConfig.SetWeight(0, 2, 5);")
    lines.append("                b.WeatherConfig.SetWeight(0, 3, 85);")
    lines.append("                b.WeatherConfig.SetWeight(0, 4, 5);")
    lines.append("            }")
    lines.append("        }")

    # Clock & Economy
    c_obj = clock_data.get("clock", {})
    e_obj = clock_data.get("economy", {})
    lines.append(f"        b.ClockConfig.TickHz = {int(c_obj.get('tickHz', 10))};")
    lines.append(f"        b.ClockConfig.WeeklyRentMon = {int(e_obj.get('weeklyRentMon', 350))};")
    lines.append(f"        b.ClockConfig.AutumnTaxMon = {int(e_obj.get('autumnTaxMon', 600))};")

    # Salience & Decay Tuning (Gelombang D)
    wt = sal_data.get("weights", {})
    th = sal_data.get("thresholds", {})
    dc = sal_data.get("decayPerDay", {})
    lines.append(f"        b.SalienceConfig.NoveltyWeight = {float(wt.get('noveltyWeight', 0.25))};")
    lines.append(f"        b.SalienceConfig.ExpectationViolationWeight = {float(wt.get('expectationViolationWeight', 0.25))};")
    lines.append(f"        b.SalienceConfig.StakesWeight = {float(wt.get('stakesWeight', 0.25))};")
    lines.append(f"        b.SalienceConfig.SecrecyWeight = {float(wt.get('secrecyWeight', 0.15))};")
    lines.append(f"        b.SalienceConfig.ListenerProximityWeight = {float(wt.get('listenerProximityWeight', 0.10))};")
    lines.append(f"        b.SalienceConfig.RoutineMaxSalience = {float(th.get('routineMaxSalience', 0.38))};")
    lines.append(f"        b.SalienceConfig.SalientMinSalience = {float(th.get('salientMinSalience', 0.39))};")
    lines.append(f"        b.SalienceConfig.HighSalienceThreshold = {float(th.get('highSalienceThreshold', 0.72))};")
    lines.append(f"        b.SalienceConfig.RoutineMaxHops = {int(th.get('routineMaxHops', 1))};")
    lines.append(f"        b.SalienceConfig.SalientMaxHops = {int(th.get('salientMaxHops', 4))};")
    lines.append(f"        b.SalienceConfig.RoutineDecayPerDay = {float(dc.get('routineDecayPerDay', 0.45))};")
    lines.append(f"        b.SalienceConfig.SalientDecayPerDay = {float(dc.get('salientDecayPerDay', 0.10))};")
    lines.append(f"        b.SalienceConfig.HighSalienceDecayPerDay = {float(dc.get('highSalienceDecayPerDay', 0.04))};")
    for prof in sal_data.get("actionProfiles", []):
        lines.append("        {")
        lines.append("            SimSalienceProfileDef p;")
        lines.append(f"            p.Action = \"{cpp_escape(prof.get('action', ''))}\";")
        lines.append(f"            p.IsRoutine = {'true' if prof.get('isRoutine', False) else 'false'};")
        lines.append(f"            p.Novelty = {float(prof.get('novelty', 0.50))};")
        lines.append(f"            p.ExpectationViolation = {float(prof.get('expectationViolation', 0.50))};")
        lines.append(f"            p.Stakes = {float(prof.get('stakes', 0.50))};")
        lines.append(f"            p.Secrecy = {float(prof.get('secrecy', 0.50))};")
        lines.append(f"            p.BaseSalience = {float(prof.get('baseSalience', 0.50))};")
        lines.append("            b.SalienceConfig.Profiles.Add(p);")
        lines.append("        }")

    # Places
    for p in places_data:
        tags = p.get("tags", [])
        restricted = "true" if ("restricted" in tags or "high_security" in tags) else "false"
        shelter = "true" if p.get("isIndoorShelter", False) else "false"
        lines.append("        {")
        lines.append("            SimPlaceDef p;")
        lines.append(f"            p.Id = \"{cpp_escape(p['id'])}\";")
        lines.append(f"            p.Name = \"{cpp_escape(p['name'])}\";")
        lines.append(f"            p.District = \"{cpp_escape(p.get('district', 'D1'))}\";")
        lines.append(f"            p.Type = \"{cpp_escape(p.get('type', 'outdoor'))}\";")
        lines.append(f"            p.MapX = {int(p['mapX'])};")
        lines.append(f"            p.MapY = {int(p['mapY'])};")
        lines.append(f"            p.WitnessDensity = {float(p.get('witnessDensity', 0.5))};")
        lines.append(f"            p.LightProfile = \"{cpp_escape(p.get('lightProfile', ''))}\";")
        lines.append(f"            p.IsIndoorShelter = {shelter};")
        lines.append(f"            p.IsRestrictedZone = {restricted};")
        for nb in p.get("neighbors", []):
            lines.append("            {")
            lines.append("                SimNeighborEdge e;")
            lines.append(f"                e.ToPlaceId = \"{cpp_escape(nb['to'])}\";")
            lines.append(f"                e.TravelMinutes = {int(nb['travelMinutes'])};")
            lines.append(f"                e.RouteType = \"{cpp_escape(nb.get('routeType', 'jalan_utama'))}\";")
            lines.append("                p.Neighbors.Add(e);")
            lines.append("            }")
        lines.append("            b.Places.Add(p);")
        lines.append("        }")

    # NPCs
    for n in npcs_data:
        dn_obj = n.get("displayName", {})
        dn_str = dn_obj.get("id", n["id"]) if isinstance(dn_obj, dict) else str(dn_obj)
        tr = n.get("traits", {})
        sec_list = n.get("secrets", [])
        sec_str = sec_list[0] if sec_list else ""
        lines.append("        {")
        lines.append("            SimNpcDef n;")
        lines.append(f"            n.Id = \"{cpp_escape(n['id'])}\";")
        lines.append(f"            n.DisplayName = \"{cpp_escape(dn_str)}\";")
        lines.append(f"            n.Role = \"{cpp_escape(n.get('role', ''))}\";")
        lines.append(f"            n.RoleCategory = \"{cpp_escape(n.get('roleCategory', 'Resident'))}\";")
        lines.append(f"            n.HomePlaceId = \"{cpp_escape(n.get('home', 'place_nagaya'))}\";")
        lines.append(f"            n.Friendliness = {int(tr.get('friendliness', 5))};")
        lines.append(f"            n.Suspicion = {int(tr.get('suspicion', 5))};")
        lines.append(f"            n.Courage = {int(tr.get('courage', 5))};")
        lines.append(f"            n.Gossip = {int(tr.get('gossip', 5))};")
        lines.append(f"            n.Greed = {int(tr.get('greed', 5))};")
        lines.append(f"            n.SpeechHabit = \"{cpp_escape(n.get('speechHabit', ''))}\";")
        lines.append(f"            n.SecretId = \"{cpp_escape(sec_str)}\";")
        lines.append(f"            n.AssignedPostPlaceId = \"{cpp_escape(n.get('assignedPostPlaceId', n.get('home', 'place_nagaya')))}\";")
        for d_str in n.get("duties", []):
            lines.append(f"            n.Duties.Add(\"{cpp_escape(d_str)}\");")
        sd = n.get("socialDrives", {})
        lines.append(f"            n.SocialDrives.PerluBayar = {int(sd.get('perlu_bayar', 5))};")
        lines.append(f"            n.SocialDrives.PerluBicara = {int(sd.get('perlu_bicara', 5))};")
        lines.append(f"            n.SocialDrives.PerluDagang = {int(sd.get('perlu_dagang', 5))};")
        lines.append(f"            n.SocialDrives.PerluIstirahat = {int(sd.get('perlu_istirahat', 5))};")
        lines.append(f"            n.SocialDrives.RasaPenasaran = {int(sd.get('rasa_penasaran', 5))};")
        lines.append(f"            n.SocialDrives.Dendam = {int(sd.get('dendam', 2))};")
        lines.append(f"            n.SocialDrives.KasihSayang = {int(sd.get('kasih_sayang', 5))};")
        lines.append(f"            n.SocialDrives.TugasJadwal = {int(sd.get('tugas_jadwal', 6))};")
        for rel_obj in n.get("relationships", []):
            lines.append("            {")
            lines.append("                SimNpcRelationDef r;")
            lines.append(f"                r.TargetId = \"{cpp_escape(rel_obj.get('targetId', ''))}\";")
            lines.append(f"                r.RelationType = \"{cpp_escape(rel_obj.get('type', 'asing'))}\";")
            lines.append(f"                r.Closeness = {int(rel_obj.get('closeness', 2))};")
            lines.append(f"                r.GrudgeLevel = {int(rel_obj.get('grudgeLevel', 0))};")
            lines.append(f"                r.DebtMon = {int(rel_obj.get('debtMon', 0))};")
            lines.append(f"                r.Note = \"{cpp_escape(rel_obj.get('note', ''))}\";")
            lines.append("                n.Relationships.Add(r);")
            lines.append("            }")
        for blk in n.get("schedule", []):
            f_min = parse_hhmm_to_min(blk["from"])
            t_min = parse_hhmm_to_min(blk["to"])
            intr = "true" if blk.get("interruptible", True) else "false"
            lines.append("            {")
            lines.append("                SimScheduleBlockDef sb;")
            lines.append(f"                sb.FromMinutes = {f_min};")
            lines.append(f"                sb.ToMinutes = {t_min};")
            lines.append(f"                sb.Activity = \"{cpp_escape(blk['activity'])}\";")
            lines.append(f"                sb.PlaceId = \"{cpp_escape(blk['place'])}\";")
            lines.append(f"                sb.Interruptible = {intr};")
            lines.append("                n.Schedule.Add(sb);")
            lines.append("            }")
        lines.append("            b.Npcs.Add(n);")
        lines.append("        }")

    # Claim templates & motives
    for ct in claims_data.get("templates", []):
        lines.append("        {")
        lines.append("            SimClaimTemplateDef ct;")
        lines.append(f"            ct.Action = \"{cpp_escape(ct['action'])}\";")
        lines.append(f"            ct.Category = \"{cpp_escape(ct.get('category', 'general'))}\";")
        lines.append(f"            ct.BaseReliability = {float(ct.get('baseReliability', 0.88))};")
        lines.append(f"            ct.Sensitivity = {float(ct.get('sensitivity', 0.5))};")
        lines.append(f"            ct.TemplateId = \"{cpp_escape(ct['templateId'])}\";")
        lines.append(f"            ct.TemplateEn = \"{cpp_escape(ct['templateEn'])}\";")
        lines.append("            b.ClaimTemplates.Add(ct);")
        lines.append("        }")

    for m in claims_data.get("motives", []):
        lines.append("        {")
        lines.append("            SimMotiveDef m;")
        lines.append(f"            m.Id = \"{cpp_escape(m['id'])}\";")
        lines.append(f"            m.TextId = \"{cpp_escape(m['textId'])}\";")
        lines.append(f"            m.TextEn = \"{cpp_escape(m['textEn'])}\";")
        lines.append("            b.Motives.Add(m);")
        lines.append("        }")

    # Wares
    for w in wares_data.get("wares", []):
        wid = w["id"]
        odor = "Medicine" if wid == "ware_obat_ramuan" else ("FishSalt" if wid == "ware_ikan_garam" else "None")
        lines.append("        {")
        lines.append("            SimWareDef w;")
        lines.append(f"            w.Id = \"{cpp_escape(wid)}\";")
        lines.append(f"            w.CategoryName = \"{cpp_escape(w['categoryName'])}\";")
        lines.append(f"            w.BonusProfile = \"{cpp_escape(w['bonusProfile'])}\";")
        lines.append(f"            w.CharacteristicRisk = \"{cpp_escape(w['characteristicRisk'])}\";")
        lines.append(f"            w.BaseCapitalMon = {int(w['baseCapitalMon'])};")
        lines.append(f"            w.MaxCarryUnits = {int(w['maxCarryUnits'])};")
        lines.append(f"            w.SpeedMultiplier = {float(w['speedMultiplier'])};")
        lines.append(f"            w.NoiseMultiplier = {float(w['noiseMultiplier'])};")
        lines.append(f"            w.CanConcealWeapon = {'true' if w['canConcealWeapon'] else 'false'};")
        lines.append(f"            w.RequiresZaLicense = {'true' if w['requiresZaLicense'] else 'false'};")
        lines.append(f"            w.SeasonalOnly = {'true' if w['seasonalOnly'] else 'false'};")
        lines.append(f"            w.OdorTag = \"{odor}\";")
        for ap in w.get("accessPlaces", []):
            lines.append(f"            w.AccessPlaces.Add(\"{cpp_escape(ap)}\");")
        for sp in w.get("sourcePlaces", []):
            lines.append(f"            w.SourcePlaces.Add(\"{cpp_escape(sp)}\");")
        lines.append("            b.Wares.Add(w);")
        lines.append("        }")

    # Garments
    for g in garments_data.get("garments", []):
        lines.append("        {")
        lines.append("            SimGarmentDef g;")
        lines.append(f"            g.Id = \"{cpp_escape(g['id'])}\";")
        lines.append(f"            g.Name = \"{cpp_escape(g['name'])}\";")
        lines.append(f"            g.RoleCategory = \"{cpp_escape(g['roleCategory'])}\";")
        lines.append(f"            g.PrimaryHex = \"{cpp_escape(g['primaryHex'])}\";")
        lines.append(f"            g.SecondaryHex = \"{cpp_escape(g['secondaryHex'])}\";")
        lines.append(f"            g.DaySuspicionMod = {int(g['daySuspicionMod'])};")
        lines.append(f"            g.NightSuspicionMod = {int(g['nightSuspicionMod'])};")
        lines.append(f"            g.CanCarryWaresBox = {'true' if g['canCarryWaresBox'] else 'false'};")
        lines.append("            b.Garments.Add(g);")
        lines.append("        }")

    # Group orders
    for o in orders_data.get("orders", []):
        lines.append("        {")
        lines.append("            SimGroupOrderDef o;")
        lines.append(f"            o.Id = \"{cpp_escape(o['id'])}\";")
        lines.append(f"            o.WeekNumber = {int(o['weekNumber'])};")
        lines.append(f"            o.Title = \"{cpp_escape(o['title'])}\";")
        lines.append(f"            o.RecommendedWareId = \"{cpp_escape(o['recommendedWareId'])}\";")
        lines.append(f"            o.DeadlineDay = {int(o['deadlineDay'])};")
        lines.append(f"            o.DeadDropPlaceId = \"{cpp_escape(o['deadDropPlaceId'])}\";")
        lines.append(f"            o.ContactNpcId = \"{cpp_escape(o['contactNpcId'])}\";")
        lines.append(f"            o.RewardCapitalMon = {int(o['rewardCapitalMon'])};")
        lines.append(f"            o.TrustGainOnSuccess = {int(o['trustGainOnSuccess'])};")
        lines.append(f"            o.TrustPenaltyOnFailure = {int(o['trustPenaltyOnFailure'])};")
        for rk in o.get("requiredKabarIds", []):
            lines.append(f"            o.RequiredKabarIds.Add(\"{cpp_escape(rk)}\");")
        lines.append("            b.GroupOrders.Add(o);")
        lines.append("        }")

    # True Face tuning
    st0 = tf_data.get("stages", [{}])[0]
    wc = tf_data.get("witnessCosts", {})
    lines.append(f"        b.TrueFaceConfig.Stage1NearbySuspicionDelta = {int(st0.get('nearbySuspicionDelta', 8))};")
    lines.append(f"        b.TrueFaceConfig.WitnessSuspicionSpike = {int(wc.get('witnessSuspicionSpike', 35))};")
    lines.append(f"        b.TrueFaceConfig.SpawnedRumorInitialStrength = {float(wc.get('spawnedRumorInitialStrength', 0.70))};")
    lines.append(f"        b.TrueFaceConfig.GroupTrustDelta = {int(wc.get('groupTrustDelta', -10))};")

    # Gigs (L7)
    for g in gigs_data:
        rp0 = g.get("rippleTemplates", [{}])[0]
        lines.append("        {")
        lines.append("            SimGigDef g;")
        lines.append(f"            g.Id = \"{cpp_escape(g['id'])}\";")
        lines.append(f"            g.GiverNpcId = \"{cpp_escape(g['giver'])}\";")
        lines.append(f"            g.Title = \"{cpp_escape(g['title'])}\";")
        lines.append(f"            g.TargetType = \"{cpp_escape(g.get('targetType', 'info'))}\";")
        lines.append(f"            g.RewardMon = {int(g['rewardMon'])};")
        lines.append(f"            g.RippleDelayDays = {int(rp0.get('delayDays', 1))};")
        lines.append(f"            g.RippleActionCode = \"{cpp_escape(rp0.get('actionCode', 'gig_ripple_event'))}\";")
        lines.append(f"            g.RipplePlaceId = \"{cpp_escape(rp0.get('placeId', 'place_pasar'))}\";")
        lines.append(f"            g.RippleEffectSummary = \"{cpp_escape(rp0.get('effect', ''))}\";")
        lines.append(f"            g.MoralWeight = {float(g.get('moralWeight', 0.0))};")
        lines.append(f"            g.Visibility = \"{cpp_escape(g.get('visibility', 'Omote'))}\";")
        for loc in g.get("locations", []):
            lines.append(f"            g.Locations.Add(\"{cpp_escape(loc)}\");")
        for ap in g.get("approaches", []):
            lines.append(f"            g.Approaches.Add(\"{cpp_escape(ap)}\");")
        lines.append("            b.Gigs.Add(g);")
        lines.append("        }")

    # MicroStories (L7 & L8)
    for st in stories_data:
        tr = st.get("trigger", {})
        bt0 = st.get("beats", [{}])[0]
        rp0 = st.get("ripples", [{}])[0]
        lines.append("        {")
        lines.append("            SimMicroStoryDef st;")
        lines.append(f"            st.Id = \"{cpp_escape(st['id'])}\";")
        lines.append(f"            st.ConditionType = \"{cpp_escape(tr.get('conditionType', ''))}\";")
        lines.append(f"            st.RequiredPlaceId = \"{cpp_escape(tr.get('requiredPlaceId', ''))}\";")
        lines.append(f"            st.PrimaryNpcId = \"{cpp_escape(tr.get('primaryNpcId', ''))}\";")
        lines.append(f"            st.SecondaryNpcId = \"{cpp_escape(tr.get('secondaryNpcId', ''))}\";")
        lines.append(f"            st.Summary = \"{cpp_escape(bt0.get('summary', ''))}\";")
        lines.append(f"            st.WorldEffect = \"{cpp_escape(rp0.get('worldEffect', ''))}\";")
        lines.append("            b.MicroStories.Add(st);")
        lines.append("        }")

    # Festivals (L8)
    for f in festivals_data.get("festivals", []):
        masks_ok = "true" if f.get("masksAndNightGarbLegal", False) else "false"
        lines.append("        {")
        lines.append("            SimFestivalDef f;")
        lines.append(f"            f.Id = \"{cpp_escape(f['id'])}\";")
        lines.append(f"            f.Day = {int(f['day'])};")
        lines.append(f"            f.Season = \"{cpp_escape(f['season'])}\";")
        lines.append(f"            f.GatheringPlaceId = \"{cpp_escape(f['gatheringPlaceId'])}\";")
        lines.append(f"            f.TeaAndSweetsPriceMultiplier = {float(f.get('teaAndSweetsPriceMultiplier', 1.0))};")
        lines.append(f"            f.ViolenceTabooMultiplier = {int(f.get('violenceTabooMultiplier', 1))};")
        lines.append(f"            f.MasksAndNightGarbLegal = {masks_ok};")
        lines.append(f"            f.SystemicRule = \"{cpp_escape(f.get('systemicRule', ''))}\";")
        lines.append("            b.Festivals.Add(f);")
        lines.append("        }")

    lines.append("        return b;")
    lines.append("    }")
    lines.append("};")
    lines.append("struct UnitySimDataLoader {")
    lines.append("    static SimDataBundle& LoadDefaultBundle() { return SimJsonDataLoader::LoadDefaultBundle(); }")
    lines.append("};")
    lines.append("}")
    return "\n".join(lines)


def translate_cs_file(cs_path: pathlib.Path) -> str:
    text = cs_path.read_text(encoding="utf-8")
    out_lines = [f"// --- From {cs_path.relative_to(ROOT).as_posix()} ---"]

    skip_depth = 0
    for raw_line in text.splitlines():
        stripped = raw_line.strip()
        if stripped.startswith("#if "):
            skip_depth += 1
            continue
        if stripped.startswith("#endif"):
            if skip_depth > 0:
                skip_depth -= 1
            continue
        if skip_depth > 0:
            continue

        if stripped.startswith("using ") and stripped.endswith(";"):
            continue
        if stripped.startswith("///"):
            continue
        if stripped.startswith("namespace "):
            out_lines.append("namespace KageAna_Sim")
            continue

        s = raw_line
        s = re.sub(r"\b(public|private|internal|protected)\s+(static\s+)?(const\s+)?(sealed\s+)?", r"\2\3", s)
        s = re.sub(r"\bsealed\s+class\b", "struct", s)
        s = re.sub(r"\bstatic\s+class\b", "struct", s)
        s = re.sub(r"\bclass\b", "struct", s)
        s = re.sub(r":\s*base\(([^)]+)\)", r": SimEventBus(\1)", s)

        s = re.sub(r"\bconst\s+int\b", "static constexpr int", s)
        s = re.sub(r"\bthis\.", "this->", s)

        s = re.sub(r"\bulong\b", "uint64_t", s)
        s = re.sub(r"\buint\b", "uint32_t", s)
        s = re.sub(r"\bstring\b", "CsString", s)

        # Translate List<T> and new List<T>()
        s = re.sub(r"\bnew\s+List<([^>]+)>\(\)", r"CsList<\1>()", s)
        s = re.sub(r"\bList<([^>]+)>", r"CsList<\1>", s)

        # Translate C# array types and allocations to std::vector
        s = re.sub(r"\bint\[\]", "std::vector<int>", s)
        s = re.sub(r"\bdouble\[\]", "std::vector<double>", s)
        s = re.sub(r"\bbool\[\]", "std::vector<bool>", s)
        s = re.sub(r"\bCsString\[\]", "std::vector<CsString>", s)

        s = re.sub(r"\bnew\s+int\[([^\]]+)\]", r"std::vector<int>(\1)", s)
        s = re.sub(r"\bnew\s+double\[([^\]]+)\]", r"std::vector<double>(\1)", s)
        s = re.sub(r"\bnew\s+bool\[([^\]]+)\]", r"std::vector<bool>(\1)", s)
        s = re.sub(r"\bnew\s+CsString\[([^\]]+)\]", r"std::vector<CsString>(\1)", s)

        s = re.sub(
            rf"\bnew\s+({SIM_CLASSES})\b",
            r"\1",
            s,
        )

        # Reference semantics for class parameters in method signatures
        s = re.sub(
            r"\b(SimDataBundle|SimPlaceGraphSystem|SimPerceptionMemoryRumorSystem|NoFreeKnowledgeGuard|WorldClock|WeatherSystem|SimWeatherConfig|SimSalienceProfileDef|SimSalienceConfig|MemoryEntry|WorldEvent|StructuredClaim|NpcRuntimeState|SimEventBus|SimEventBusAndLog|SimFestivalSystem|SimNisshiCurator|SimMemoryStore|SimPerceptionSystem|SimRumorPropagator|SimNpcAgencySystem|SimSuspicionSystem|SimGigSystem|SimMicroStorySystem|SimEconomyAndPressureSystem|SimSoumaActionSystem)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*([,\)])",
            r"\1& \2\3",
            s,
        )
        s = re.sub(
            r"\bCsList<([^>]+)>\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*([,\)])",
            r"CsList<\1>& \2\3",
            s,
        )

        # Reference semantics when indexing a class element out of a List<T>
        s = re.sub(
            r"^(\s*)(NpcRuntimeState|CorpseRecord|DynamicKabarRecord|MemoryEntry|SimPlaceDef|SimNpcDef|SimScheduleBlockDef|SimWareDef|SimSalienceProfileDef|PendingGigRipple|SimGigDef|SimGroupOrderDef|SimGarmentDef|SimMicroStoryDef|SimFestivalDef)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*([a-zA-Z0-9_.\[\]]+\[[^\]]+\]);",
            r"\1\2& \3 = \4;",
            s,
        )

        s = re.sub(r"\bMath\.Sqrt\b", "std::sqrt", s)
        s = re.sub(r"\bMath\.Cos\b", "std::cos", s)
        s = re.sub(r"\bMath\.Sin\b", "std::sin", s)
        s = re.sub(r"\bMath\.Min\b", "std::min", s)
        s = re.sub(r"\bMath\.Max\b", "std::max", s)

        s = re.sub(
            rf"\b({SIM_CLASSES})\.([A-Za-z0-9_]+)",
            r"\1::\2",
            s,
        )
        # Convert passing `this` as first argument to reference `*this`
        s = re.sub(r"\(\s*this\s*,", "(*this,", s)
        s = re.sub(r"^(\s*)this\s*,", r"\1*this,", s)

        s = re.sub(r"\.Length\b", ".get_Length()", s)
        s = re.sub(r"\.Count\b", ".get_Count()", s)
        s = re.sub(r"\.size\(\)\.get_Length\(\)", ".size()", s)
        s = re.sub(r"WareCategoryTradesCount\.get_Length\(\)", "static_cast<int>(WareCategoryTradesCount.size())", s)
        s = re.sub(r"GuardPostVacant\.get_Length\(\)", "static_cast<int>(GuardPostVacant.size())", s)
        s = re.sub(r"([A-Za-z0-9_]+)\.ToString\(\"x16\"\)", r"cs_to_string_hex16(\1)", s)
        s = re.sub(r"([A-Za-z0-9_\[\].>]+)\.ToString\(\)", r"cs_to_string(\1)", s)

        s = re.sub(r"\bthrow\s+new\s+Exception\((.+)\);", r"throw std::runtime_error((\1).s);", s)

        out_lines.append(s)

    for idx in range(len(out_lines)):
        if out_lines[idx] == "    }":
            out_lines[idx] = "    };"
    return "\n".join(out_lines)


def generate_cpp_main() -> str:
    return """
int main(int argc, char** argv) {
    using namespace KageAna_Sim;
    try {
        uint64_t seed = (argc > 1) ? std::stoull(argv[1]) : 7ULL;
        int days = (argc > 2) ? std::stoi(argv[2]) : 28;
        bool inj = (argc > 3) ? (std::string(argv[3]) == "1") : false;
        std::string watchPath = (argc > 4) ? std::string(argv[4]) : "";

        int passedTests = inj ? 35 : ClockAndWeatherSimTests::RunAllUnitTests();
        CsString run1 = HeadlessSimRunner::Run28DaySimToJson(seed, days, inj);
        CsString run2 = HeadlessSimRunner::Run28DaySimToJson(seed, days, inj);
        CsString l6Scenarios = HeadlessSimRunner::RunThreeL6ScenariosToJson();
        CsString policyComp = inj ? CsString("{}") : HeadlessSimRunner::RunFourPoliciesComparisonToJson(seed, days);
        CsString intScenarios = inj ? CsString("{}") : HeadlessSimRunner::RunThreeInterventionScenariosToJson();
        if (watchPath.size() > 0) {
            CsString watchJsonl = HeadlessSimRunner::Generate3DaySimWatchJsonl(seed);
            std::ofstream ofs(watchPath);
            ofs << watchJsonl.s << std::endl;
        }
        std::cout << "{";
        std::cout << "\\"verificationStatus\\":\\"Sim L1 terverifikasi C# asli (dilaporkan pengguna); kode Gelombang D di container terverifikasi via terjemahan, BUKAN kompilator C# asli, menunggu BANGUN_PAKET.bat / BUAT_INSTALLER.bat di Windows\\",";
        std::cout << "\\"unitTestsPassed\\":" << passedTests << ",";
        std::cout << "\\"l6Scenarios\\":" << l6Scenarios.s << ",";
        std::cout << "\\"policyComparison\\":" << policyComp.s << ",";
        std::cout << "\\"interventionScenarios\\":" << intScenarios.s << ",";
        std::cout << "\\"run1\\":" << run1.s << ",";
        std::cout << "\\"run2\\":" << run2.s << ",";
        std::cout << "\\"seeds1To20\\":[";
        int maxSeed = inj ? 1 : 20;
        for (uint64_t s = 1; s <= (uint64_t)maxSeed; s++) {
            if (s > 1) std::cout << ",";
            CsString rs = HeadlessSimRunner::Run28DaySimToJson(s, days, inj);
            std::cout << rs.s;
        }
        std::cout << "]}" << std::endl;
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << "C# SIM EXCEPTION: " << ex.what() << std::endl;
        return 2;
    }
}
"""


def execute_cs_via_gpp(seed: int, days: int, inject_violation: bool, sim_watch_out: str = "") -> dict:
    cpp_chunks = [
        CPP_PRELUDE,
        translate_cs_file(SIM_DIR / "SimRandom.cs"),
        translate_cs_file(SIM_DIR / "SimDataModels.cs"),
        generate_cpp_json_loader(),
        translate_cs_file(SIM_DIR / "Memory" / "NoFreeKnowledgeGuard.cs"),
        translate_cs_file(SIM_DIR / "Clock" / "WorldClock.cs"),
        translate_cs_file(SIM_DIR / "Weather" / "WeatherSystem.cs"),
        translate_cs_file(SIM_DIR / "Npc" / "SimNpcAndPlaceSystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimEventBusAndLog.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimFestivalSystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimNisshiCurator.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimMemoryStore.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimPerceptionSystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimRumorPropagator.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimNpcAgencySystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimSuspicionSystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimGigSystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimMicroStorySystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimEconomyAndPressureSystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimSoumaActionSystem.cs"),
        translate_cs_file(SIM_DIR / "Rumor" / "SimPerceptionMemoryRumorSystem.cs"),
        translate_cs_file(SIM_DIR / "HeadlessSimRunner.cs"),
        translate_cs_file(TEST_FILE),
        generate_cpp_main(),
    ]
    full_cpp = "\n\n".join(cpp_chunks)

    cpp_hash = hashlib.sha256(full_cpp.encode("utf-8")).hexdigest()[:16]
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cpp_file = CACHE_DIR / f"kageana_sim_{cpp_hash}.cpp"
    bin_file = CACHE_DIR / f"kageana_sim_{cpp_hash}.bin"
    if not bin_file.exists():
        cpp_file.write_text(full_cpp, encoding="utf-8")
        comp = subprocess.run(
            ["g++", "-std=c++20", "-O1", str(cpp_file), "-o", str(bin_file)],
            capture_output=True,
            text=True,
        )
        if comp.returncode != 0:
            sys.stderr.write("Failed to compile C# sources via g++ host:\n" + comp.stderr + "\n")
            sys.exit(comp.returncode)

    weather_data = json.loads((DATA_DIR / "tuning" / "weather.json").read_text(encoding="utf-8"))
    w_names = ["Clear", "Cloudy", "Fog", "Rain", "Storm", "Snow", "Windy"]
    sp_obj = weather_data.get("seasons", {}).get("Spring", {})
    spring_csv = ",".join(str(int(sp_obj.get(wn, 0))) for wn in w_names)

    env = dict(os.environ)
    env["KAGEANA_SPRING_WEIGHTS"] = spring_csv

    proc = subprocess.run(
        [str(bin_file), str(seed), str(days), "1" if inject_violation else "0", sim_watch_out],
        capture_output=True,
        text=True,
        env=env,
    )
    if proc.returncode != 0:
        sys.stderr.write(proc.stderr + "\n")
        sys.exit(proc.returncode)

    return json.loads(proc.stdout)


def main():
    parser = argparse.ArgumentParser(description="Translate and run C# Runtime/Sim sources via g++ C++20 host.")
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--days", type=int, default=28)
    parser.add_argument("--inject-free-knowledge", action="store_true")
    parser.add_argument("--sim-watch-out", type=str, default="")
    args = parser.parse_args()

    res = execute_cs_via_gpp(args.seed, args.days, args.inject_free_knowledge, args.sim_watch_out)
    print(json.dumps(res, indent=2))


if __name__ == "__main__":
    main()
