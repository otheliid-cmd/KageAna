#!/usr/bin/env python3
"""
tools/build_win64_exe.py — Builds a true standalone 64-bit Windows PE32+ GUI executable
(`KageAna_Mandiri_Langsung_Jalan.exe`) directly from the C# simulation sources + Win32 GDI Sandbox UI.

Zero external dependencies on Windows:
- Imports ONLY from KERNEL32.dll, USER32.dll, GDI32.dll, SHELL32.dll.
- Does NOT require .NET, Unity, Python, or Admin/UAC privileges.
- Immediately launches KAGE-ANA v0.4.0 [d4f039b3] — Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)
  in Manual Mode (default) with the 1-screen non-modal Starter Guide, 12 places, 26 canonical NPCs,
  4 live narrative/inspector/ink-board/Nisshi panels, silent background setup in %LOCALAPPDATA%\KageAna,
  and `--selftest` headless verification mode.
"""

import os
import re
import struct
import subprocess
import sys
import pathlib

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "tools"))
import cs_gpp_host

WIN32_IMPORTS = {
    "KERNEL32.dll": [
        "ExitProcess",
        "GetProcessHeap",
        "HeapAlloc",
        "HeapFree",
        "GetCommandLineA",
        "GetEnvironmentVariableA",
        "CreateDirectoryA",
        "CreateFileA",
        "WriteFile",
        "CloseHandle",
        "CreateMutexA",
        "GetLastError",
        "GetSystemTime",
    ],
    "USER32.dll": [
        "RegisterClassExA",
        "CreateWindowExA",
        "ShowWindow",
        "UpdateWindow",
        "GetMessageA",
        "TranslateMessage",
        "DispatchMessageA",
        "DefWindowProcA",
        "PostQuitMessage",
        "SetTimer",
        "InvalidateRect",
        "GetClientRect",
        "BeginPaint",
        "EndPaint",
        "MessageBoxA",
        "CreateMenu",
        "CreatePopupMenu",
        "AppendMenuA",
        "SetMenu",
        "FindWindowA",
        "SetForegroundWindow",
        "FillRect",
        "DrawTextA",
        "LoadCursorA",
    ],
    "GDI32.dll": [
        "CreateCompatibleDC",
        "CreateCompatibleBitmap",
        "DeleteDC",
        "DeleteObject",
        "SelectObject",
        "BitBlt",
        "CreateSolidBrush",
        "CreatePen",
        "CreateFontA",
        "SetBkMode",
        "SetTextColor",
        "Ellipse",
        "MoveToEx",
        "LineTo",
        "TextOutA",
        "GetStockObject",
        "Rectangle",
    ],
    "SHELL32.dll": [
        "ShellExecuteA",
    ],
}


def generate_idata_asm() -> str:
    lines = [
        '.section .idata, "aw"',
        '.align 8',
        '.global __idata_start',
        '__idata_start:',
    ]
    for dll_name in WIN32_IMPORTS:
        tag = dll_name.split(".")[0].lower()
        lines.append(f"    /* Import Descriptor: {dll_name} */")
        lines.append(f"    .long __ilt_{tag} - 0x00400000")
        lines.append("    .long 0")
        lines.append("    .long 0")
        lines.append(f"    .long __name_{tag} - 0x00400000")
        lines.append(f"    .long __iat_{tag} - 0x00400000")
    lines.append("    /* Null terminator descriptor */")
    lines.append("    .long 0, 0, 0, 0, 0")
    lines.append(".global __idata_desc_end")
    lines.append("__idata_desc_end:")
    lines.append("")
    lines.append(".align 8")
    for dll_name, funcs in WIN32_IMPORTS.items():
        tag = dll_name.split(".")[0].lower()
        lines.append(f"__ilt_{tag}:")
        for fn in funcs:
            lines.append(f"    .quad __hn_{fn} - 0x00400000")
        lines.append("    .quad 0")
    lines.append("")
    lines.append(".align 8")
    lines.append(".global __iat_start")
    lines.append("__iat_start:")
    for dll_name, funcs in WIN32_IMPORTS.items():
        tag = dll_name.split(".")[0].lower()
        lines.append(f"__iat_{tag}:")
        for fn in funcs:
            lines.append(f".global __imp_{fn}")
            lines.append(f"__imp_{fn}:")
            lines.append(f"    .quad __hn_{fn} - 0x00400000")
        lines.append("    .quad 0")
    lines.append(".global __iat_end")
    lines.append("__iat_end:")
    lines.append("")
    for dll_name in WIN32_IMPORTS:
        tag = dll_name.split(".")[0].lower()
        lines.append(f"__name_{tag}:")
        lines.append(f'    .asciz "{dll_name}"')
    lines.append("")
    for dll_name, funcs in WIN32_IMPORTS.items():
        for fn in funcs:
            lines.append(".align 2")
            lines.append(f"__hn_{fn}:")
            lines.append("    .short 0")
            lines.append(f'    .asciz "{fn}"')
    lines.append(".align 8")
    lines.append(".global __idata_end")
    lines.append("__idata_end:")
    lines.append('.section .note.GNU-stack,"",@progbits')
    return "\n".join(lines) + "\n"


FREESTANDING_CORE_RUNTIME = r"""
typedef signed char int8_t;
typedef short int16_t;
typedef int int32_t;
typedef long long int64_t;
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long uint64_t;
typedef __SIZE_TYPE__ size_t;

#ifdef KAGEANA_WIN64
extern "C" {
    extern void* (*__imp_GetProcessHeap)();
    extern void* (*__imp_HeapAlloc)(void*, uint32_t, size_t);
    extern int   (*__imp_HeapFree)(void*, uint32_t, void*);
}
static void* g_proc_heap = nullptr;
extern "C" void* k_malloc(size_t sz) {
    if (!g_proc_heap) g_proc_heap = __imp_GetProcessHeap();
    return __imp_HeapAlloc(g_proc_heap, 8 /* HEAP_ZERO_MEMORY */, sz > 0 ? sz : 1);
}
extern "C" void k_free(void* p) {
    if (!p) return;
    if (!g_proc_heap) g_proc_heap = __imp_GetProcessHeap();
    __imp_HeapFree(g_proc_heap, 0, p);
}
#else
extern "C" void* malloc(size_t);
extern "C" void free(void*);
extern "C" void* k_malloc(size_t sz) { return malloc(sz > 0 ? sz : 1); }
extern "C" void k_free(void* p) { if (p) free(p); }
#endif

extern "C" {
#ifdef KAGEANA_WIN64
    void* __dso_handle = nullptr;
    int __cxa_atexit(void (*)(void*), void*, void*) { return 0; }
#endif

    void* memcpy(void* dst, const void* src, size_t n) {
        unsigned char* d = (unsigned char*)dst;
        const unsigned char* s = (const unsigned char*)src;
        for (size_t i = 0; i < n; i++) d[i] = s[i];
        return dst;
    }
    void* memmove(void* dst, const void* src, size_t n) {
        unsigned char* d = (unsigned char*)dst;
        const unsigned char* s = (const unsigned char*)src;
        if (d < s || d >= s + n) {
            for (size_t i = 0; i < n; i++) d[i] = s[i];
        } else if (n > 0) {
            for (size_t i = n; i > 0; i--) d[i - 1] = s[i - 1];
        }
        return dst;
    }
    void* memset(void* dst, int val, size_t n) {
        unsigned char* d = (unsigned char*)dst;
        unsigned char v = (unsigned char)val;
        for (size_t i = 0; i < n; i++) d[i] = v;
        return dst;
    }
    int memcmp(const void* a, const void* b, size_t n) {
        const unsigned char* pa = (const unsigned char*)a;
        const unsigned char* pb = (const unsigned char*)b;
        for (size_t i = 0; i < n; i++) {
            if (pa[i] != pb[i]) return (int)pa[i] - (int)pb[i];
        }
        return 0;
    }
    size_t strlen(const char* s) {
        if (!s) return 0;
        size_t n = 0;
        while (s[n]) n++;
        return n;
    }
    int strcmp(const char* a, const char* b) {
        if (!a) a = "";
        if (!b) b = "";
        while (*a && (*a == *b)) { a++; b++; }
        return *(const unsigned char*)a - *(const unsigned char*)b;
    }
    int strncmp(const char* a, const char* b, size_t n) {
        if (n == 0) return 0;
        if (!a) a = "";
        if (!b) b = "";
        for (size_t i = 0; i < n; i++) {
            if (a[i] != b[i] || a[i] == 0) return (unsigned char)a[i] - (unsigned char)b[i];
        }
        return 0;
    }
    char* strstr(const char* hay, const char* needle) {
        if (!hay || !needle) return nullptr;
        size_t nl = strlen(needle);
        if (nl == 0) return (char*)hay;
        for (const char* p = hay; *p; p++) {
            if (*p == *needle && strncmp(p, needle, nl) == 0) return (char*)p;
        }
        return nullptr;
    }
    double k_sqrt(double x) {
        if (x <= 0.0) return 0.0;
        double r = x;
        __asm__ volatile ("sqrtsd %1, %0" : "=x"(r) : "x"(x));
        return r;
    }
    double k_sin(double x) {
        // Normalize x to [-pi, pi]
        const double PI = 3.14159265358979323846;
        const double TWO_PI = 6.28318530717958647692;
        int k = (int)(x / TWO_PI);
        x -= k * TWO_PI;
        if (x > PI) x -= TWO_PI;
        if (x < -PI) x += TWO_PI;
        double x2 = x * x;
        return x * (1.0 - x2 / 6.0 * (1.0 - x2 / 20.0 * (1.0 - x2 / 42.0 * (1.0 - x2 / 72.0))));
    }
    double k_cos(double x) {
        return k_sin(x + 1.57079632679489661923);
    }
}

void* operator new(size_t sz) { return k_malloc(sz); }
void* operator new[](size_t sz) { return k_malloc(sz); }
void operator delete(void* p) noexcept { k_free(p); }
void operator delete[](void* p) noexcept { k_free(p); }
void operator delete(void* p, size_t) noexcept { k_free(p); }
void operator delete[](void* p, size_t) noexcept { k_free(p); }

static bool g_sim_threw_exception = false;
static char g_sim_exception_msg[256] = {0};

struct CsString {
    char* buf;
    int len;
    int cap;

    void init_from(const char* c, int n) {
        if (n < 0) n = 0;
        len = n;
        cap = n + 16;
        buf = (char*)k_malloc(cap);
        if (c && n > 0) memcpy(buf, c, n);
        buf[len] = 0;
    }
    constexpr CsString() : buf(nullptr), len(0), cap(0) {}
    CsString(const char* c) : buf(nullptr), len(0), cap(0) {
        int n = c ? (int)strlen(c) : 0;
        if (n > 0) init_from(c, n);
    }
    CsString(const char* c, int n) : buf(nullptr), len(0), cap(0) {
        if (n > 0) init_from(c, n);
    }
    CsString(const CsString& o) : buf(nullptr), len(0), cap(0) {
        if (o.len > 0) init_from(o.buf, o.len);
    }
    CsString(CsString&& o) noexcept : buf(o.buf), len(o.len), cap(o.cap) {
        o.buf = nullptr; o.len = 0; o.cap = 0;
    }
    CsString& operator=(const CsString& o) {
        if (this == &o) return *this;
        char* old = buf;
        init_from(o.buf, o.len);
        if (old) k_free(old);
        return *this;
    }
    CsString& operator=(CsString&& o) noexcept {
        if (this == &o) return *this;
        if (buf) k_free(buf);
        buf = o.buf; len = o.len; cap = o.cap;
        o.buf = nullptr; o.len = 0; o.cap = 0;
        return *this;
    }
    ~CsString() { if (buf) k_free(buf); }

    const char* c_str() const { return buf ? buf : ""; }
    int get_Length() const { return len; }
    char operator[](int idx) const { return (idx >= 0 && idx < len) ? buf[idx] : 0; }

    void append_raw(const char* c, int n) {
        if (!c || n <= 0) return;
        if (!buf) init_from("", 0);
        if (len + n + 1 > cap) {
            int ncap = (cap * 2 > len + n + 16) ? cap * 2 : (len + n + 64);
            char* nbuf = (char*)k_malloc(ncap);
            if (len > 0) memcpy(nbuf, buf, len);
            k_free(buf);
            buf = nbuf;
            cap = ncap;
        }
        memcpy(buf + len, c, n);
        len += n;
        buf[len] = 0;
    }

    CsString operator+(const CsString& o) const {
        if (len + o.len <= 0) return CsString();
        CsString r(nullptr, len + o.len);
        if (len > 0 && buf) memcpy(r.buf, buf, len);
        if (o.len > 0 && o.buf) memcpy(r.buf + len, o.buf, o.len);
        r.len = len + o.len;
        r.buf[r.len] = 0;
        return r;
    }
    CsString& operator+=(const CsString& o) { append_raw(o.buf, o.len); return *this; }
    CsString& operator+=(const char* o) { if (o) append_raw(o, (int)strlen(o)); return *this; }
    CsString& operator+=(char c) { append_raw(&c, 1); return *this; }
    friend CsString operator+(const char* a, const CsString& b) { return CsString(a) + b; }
    friend CsString operator+(const CsString& a, const char* b) { return a + CsString(b); }
    bool operator==(const CsString& o) const { return len == o.len && strcmp(c_str(), o.c_str()) == 0; }
    bool operator!=(const CsString& o) const { return !(*this == o); }
    bool operator==(const char* o) const { return strcmp(c_str(), o ? o : "") == 0; }
    bool operator!=(const char* o) const { return !(*this == o); }
    bool contains_sub(const char* sub) const { return strstr(c_str(), sub) != nullptr; }
    bool Contains(const CsString& sub) const { return strstr(c_str(), sub.c_str()) != nullptr; }
    bool Contains(const char* sub) const { return sub && strstr(c_str(), sub) != nullptr; }
};

template <typename T>
struct CsList {
    T** items;
    int count;
    int cap;
    CsList() : items(nullptr), count(0), cap(0) {}
    CsList(const CsList<T>& o) : items(nullptr), count(0), cap(0) {
        if (o.count > 0) {
            reserve(o.count);
            for (int i = 0; i < o.count; i++) items[i] = new T(*o.items[i]);
            count = o.count;
        }
    }
    CsList<T>& operator=(const CsList<T>& o) {
        if (this == &o) return *this;
        Clear();
        if (o.count > 0) {
            reserve(o.count);
            for (int i = 0; i < o.count; i++) items[i] = new T(*o.items[i]);
            count = o.count;
        }
        return *this;
    }
    ~CsList() {
        Clear();
        if (items) k_free(items);
    }
    void reserve(int n) {
        if (n <= cap) return;
        int ncap = cap == 0 ? 16 : cap * 2;
        while (ncap < n) ncap *= 2;
        T** nd = (T**)k_malloc(ncap * sizeof(T*));
        for (int i = 0; i < count; i++) nd[i] = items[i];
        if (items) k_free(items);
        items = nd;
        cap = ncap;
    }
    int get_Count() const { return count; }
    void Add(const T& item) {
        reserve(count + 1);
        items[count] = new T(item);
        count++;
    }
    void Clear() {
        for (int i = 0; i < count; i++) delete items[i];
        count = 0;
    }
    T& operator[](int idx) { return *items[idx]; }
    const T& operator[](int idx) const { return *items[idx]; }
};

template <typename T>
struct CsArr {
    T* data;
    int sz;
    CsArr() : data(nullptr), sz(0) {}
    explicit CsArr(int n) : data(nullptr), sz(n) {
        if (n > 0) data = new T[n]();
    }
    CsArr(const CsArr<T>& o) : data(nullptr), sz(o.sz) {
        if (sz > 0) {
            data = new T[sz]();
            for (int i = 0; i < sz; i++) data[i] = o.data[i];
        }
    }
    CsArr<T>& operator=(const CsArr<T>& o) {
        if (this == &o) return *this;
        if (data) delete[] data;
        sz = o.sz;
        data = sz > 0 ? new T[sz]() : nullptr;
        for (int i = 0; i < sz; i++) data[i] = o.data[i];
        return *this;
    }
    ~CsArr() { if (data) delete[] data; }
    int size() const { return sz; }
    int get_Length() const { return sz; }
    T& operator[](int idx) { return data[idx]; }
    const T& operator[](int idx) const { return data[idx]; }
};

static CsString k_int64_to_str(int64_t v) {
    char b[32];
    int pos = 31;
    b[pos] = 0;
    bool neg = v < 0;
    uint64_t u = neg ? (uint64_t)(-v) : (uint64_t)v;
    if (u == 0) { b[--pos] = '0'; }
    while (u > 0) {
        b[--pos] = (char)('0' + (u % 10));
        u /= 10;
    }
    if (neg) b[--pos] = '-';
    return CsString(b + pos);
}

static CsString k_uint64_to_str(uint64_t u) {
    char b[32];
    int pos = 31;
    b[pos] = 0;
    if (u == 0) { b[--pos] = '0'; }
    while (u > 0) {
        b[--pos] = (char)('0' + (u % 10));
        u /= 10;
    }
    return CsString(b + pos);
}

inline CsString cs_to_string(int v) { return k_int64_to_str(v); }
inline CsString cs_to_string(int64_t v) { return k_int64_to_str(v); }
inline CsString cs_to_string(uint32_t v) { return k_uint64_to_str(v); }
inline CsString cs_to_string(uint64_t v) { return k_uint64_to_str(v); }
inline CsString cs_to_string(double v) {
    if (v < 0) return CsString("-") + cs_to_string(-v);
    int64_t iv = (int64_t)v;
    double frac = v - (double)iv;
    int f2 = (int)(frac * 100.0 + 0.5);
    if (f2 >= 100) { iv++; f2 -= 100; }
    if (f2 == 0) return k_int64_to_str(iv);
    if (f2 % 10 == 0) return k_int64_to_str(iv) + "." + k_int64_to_str(f2 / 10);
    CsString fs = f2 < 10 ? (CsString("0") + k_int64_to_str(f2)) : k_int64_to_str(f2);
    return k_int64_to_str(iv) + "." + fs;
}
inline CsString cs_to_string_hex16(uint64_t v) {
    const char* hex = "0123456789abcdef";
    char b[17];
    b[16] = 0;
    for (int i = 15; i >= 0; i--) {
        b[i] = hex[v & 0xF];
        v >>= 4;
    }
    return CsString(b, 16);
}

namespace sim_math {
    template <typename T> inline T min_v(T a, T b) { return a < b ? a : b; }
    template <typename T> inline T max_v(T a, T b) { return a > b ? a : b; }
}
"""

def build_translated_simulation_cpp() -> str:
    json_loader = cs_gpp_host.generate_cpp_json_loader()
    # Fix Spring weather weights to use actual weather.json values directly (35, 20, 20, 18, 2, 0, 5)
    json_loader = json_loader.replace("defaults = [35, 25, 10, 20, 5, 0, 5]", "defaults = [35, 20, 20, 18, 2, 0, 5]")
    # Wait: generate_cpp_json_loader already generated the C++ lines with 35,25,10,20,5,0,5 for s_idx==0!
    # Let's replace the generated s_idx==0 lines with the actual weather.json Spring weights (35, 20, 20, 18, 2, 0, 5):
    json_loader = json_loader.replace("b.WeatherConfig.SetWeight(0, 1, 25);", "b.WeatherConfig.SetWeight(0, 1, 20);")
    json_loader = json_loader.replace("b.WeatherConfig.SetWeight(0, 2, 10);", "b.WeatherConfig.SetWeight(0, 2, 20);")
    json_loader = json_loader.replace("b.WeatherConfig.SetWeight(0, 3, 20);", "b.WeatherConfig.SetWeight(0, 3, 18);")
    json_loader = json_loader.replace("b.WeatherConfig.SetWeight(0, 4, 5);", "b.WeatherConfig.SetWeight(0, 4, 2);")
    # Remove std::getenv block
    json_loader = re.sub(r"\s*const char\* envSpring = std::getenv.*?while \(std::getline.*?\}\s*\}", "", json_loader, flags=re.S)

    chunks = [
        FREESTANDING_CORE_RUNTIME,
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "SimRandom.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "SimDataModels.cs"),
        json_loader,
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Memory" / "NoFreeKnowledgeGuard.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Clock" / "WorldClock.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Weather" / "WeatherSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Npc" / "SimNpcAndPlaceSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimEventBusAndLog.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimFestivalSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimNisshiCurator.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimMemoryStore.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimPerceptionSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimRumorPropagator.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimNpcAgencySystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimSuspicionSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimGigSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimMicroStorySystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimEconomyAndPressureSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimSoumaActionSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "Rumor" / "SimPerceptionMemoryRumorSystem.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.SIM_DIR / "HeadlessSimRunner.cs"),
        cs_gpp_host.translate_cs_file(cs_gpp_host.TEST_FILE),
    ]
    code = "\n\n".join(chunks)
    code = code.replace("std::vector<", "CsArr<")
    code = code.replace("std::sqrt", "k_sqrt")
    code = code.replace("std::cos", "k_cos")
    code = code.replace("std::sin", "k_sin")
    code = code.replace("std::min", "sim_math::min_v")
    code = code.replace("std::max", "sim_math::max_v")
    code = code.replace('customWeatherJson.s.find("\\"Clear\\":0") != std::string::npos', 'customWeatherJson.contains_sub("\\"Clear\\":0")')
    code = re.sub(r"throw std::runtime_error\(\((.+?)\)\.s\);", r"{ g_sim_threw_exception = true; }", code)
    return code



WIN32_SANDBOX_GUI_CPP = r"""
#ifdef KAGEANA_WIN64

#pragma pack(push, 1)
struct WNDCLASSEXA {
    uint32_t cbSize;
    uint32_t style;
    void*    lpfnWndProc;
    int32_t  cbClsExtra;
    int32_t  cbWndExtra;
    void*    hInstance;
    void*    hIcon;
    void*    hCursor;
    void*    hbrBackground;
    const char* lpszMenuName;
    const char* lpszClassName;
    void*    hIconSm;
};
#pragma pack(pop)

struct POINT { int32_t x; int32_t y; };
struct RECT  { int32_t left; int32_t top; int32_t right; int32_t bottom; };
struct MSG {
    void*    hwnd;
    uint32_t message;
    uint64_t wParam;
    int64_t  lParam;
    uint32_t time;
    POINT    pt;
    uint32_t lPrivate;
};
struct PAINTSTRUCT {
    void*    hdc;
    int32_t  fErase;
    RECT     rcPaint;
    int32_t  fRestore;
    int32_t  fIncUpdate;
    uint8_t  rgbReserved[32];
};
struct SYSTEMTIME {
    uint16_t wYear, wMonth, wDayOfWeek, wDay, wHour, wMinute, wSecond, wMilliseconds;
};

extern "C" {
    // KERNEL32.dll
    extern void     (*__imp_ExitProcess)(uint32_t);
    extern char*    (*__imp_GetCommandLineA)();
    extern uint32_t (*__imp_GetEnvironmentVariableA)(const char*, char*, uint32_t);
    extern int32_t  (*__imp_CreateDirectoryA)(const char*, void*);
    extern void*    (*__imp_CreateFileA)(const char*, uint32_t, uint32_t, void*, uint32_t, uint32_t, void*);
    extern int32_t  (*__imp_WriteFile)(void*, const void*, uint32_t, uint32_t*, void*);
    extern int32_t  (*__imp_CloseHandle)(void*);
    extern void*    (*__imp_CreateMutexA)(void*, int32_t, const char*);
    extern uint32_t (*__imp_GetLastError)();
    extern void     (*__imp_GetSystemTime)(SYSTEMTIME*);

    // USER32.dll
    extern uint16_t (*__imp_RegisterClassExA)(const WNDCLASSEXA*);
    extern void*    (*__imp_CreateWindowExA)(uint32_t, const char*, const char*, uint32_t, int32_t, int32_t, int32_t, int32_t, void*, void*, void*, void*);
    extern int32_t  (*__imp_ShowWindow)(void*, int32_t);
    extern int32_t  (*__imp_UpdateWindow)(void*);
    extern int32_t  (*__imp_GetMessageA)(MSG*, void*, uint32_t, uint32_t);
    extern int32_t  (*__imp_TranslateMessage)(const MSG*);
    extern int64_t  (*__imp_DispatchMessageA)(const MSG*);
    extern int64_t  (*__imp_DefWindowProcA)(void*, uint32_t, uint64_t, int64_t);
    extern void     (*__imp_PostQuitMessage)(int32_t);
    extern uint64_t (*__imp_SetTimer)(void*, uint64_t, uint32_t, void*);
    extern int32_t  (*__imp_InvalidateRect)(void*, const RECT*, int32_t);
    extern int32_t  (*__imp_GetClientRect)(void*, RECT*);
    extern void*    (*__imp_BeginPaint)(void*, PAINTSTRUCT*);
    extern int32_t  (*__imp_EndPaint)(void*, const PAINTSTRUCT*);
    extern int32_t  (*__imp_MessageBoxA)(void*, const char*, const char*, uint32_t);
    extern void*    (*__imp_CreateMenu)();
    extern void*    (*__imp_CreatePopupMenu)();
    extern int32_t  (*__imp_AppendMenuA)(void*, uint32_t, uint64_t, const char*);
    extern int32_t  (*__imp_SetMenu)(void*, void*);
    extern void*    (*__imp_FindWindowA)(const char*, const char*);
    extern int32_t  (*__imp_SetForegroundWindow)(void*);
    extern int32_t  (*__imp_FillRect)(void*, const RECT*, void*);
    extern int32_t  (*__imp_DrawTextA)(void*, const char*, int32_t, RECT*, uint32_t);
    extern void*    (*__imp_LoadCursorA)(void*, const char*);

    // GDI32.dll
    extern void*    (*__imp_CreateCompatibleDC)(void*);
    extern void*    (*__imp_CreateCompatibleBitmap)(void*, int32_t, int32_t);
    extern int32_t  (*__imp_DeleteDC)(void*);
    extern int32_t  (*__imp_DeleteObject)(void*);
    extern void*    (*__imp_SelectObject)(void*, void*);
    extern int32_t  (*__imp_BitBlt)(void*, int32_t, int32_t, int32_t, int32_t, void*, int32_t, int32_t, uint32_t);
    extern void*    (*__imp_CreateSolidBrush)(uint32_t);
    extern void*    (*__imp_CreatePen)(int32_t, int32_t, uint32_t);
    extern void*    (*__imp_CreateFontA)(int32_t, int32_t, int32_t, int32_t, int32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, uint32_t, const char*);
    extern int32_t  (*__imp_SetBkMode)(void*, int32_t);
    extern uint32_t (*__imp_SetTextColor)(void*, uint32_t);
    extern int32_t  (*__imp_Ellipse)(void*, int32_t, int32_t, int32_t, int32_t);
    extern int32_t  (*__imp_MoveToEx)(void*, int32_t, int32_t, void*);
    extern int32_t  (*__imp_LineTo)(void*, int32_t, int32_t);
    extern int32_t  (*__imp_TextOutA)(void*, int32_t, int32_t, const char*, int32_t);
    extern void*    (*__imp_GetStockObject)(int32_t);
    extern int32_t  (*__imp_Rectangle)(void*, int32_t, int32_t, int32_t, int32_t);

    // SHELL32.dll
    extern void*    (*__imp_ShellExecuteA)(void*, const char*, const char*, const char*, const char*, int32_t);
}

static inline uint32_t WIN_RGB(uint8_t r, uint8_t g, uint8_t b) {
    return (uint32_t)r | ((uint32_t)g << 8) | ((uint32_t)b << 16);
}

static CsString GetEnvStr(const char* name) {
    char buf[512];
    uint32_t n = __imp_GetEnvironmentVariableA(name, buf, 510);
    if (n == 0 || n >= 510) return CsString("");
    buf[n] = 0;
    return CsString(buf, (int)n);
}

static CsString GetUtcTimestampStr(bool compact) {
    SYSTEMTIME st;
    __imp_GetSystemTime(&st);
    auto pad2 = [](int v) -> CsString {
        return v < 10 ? (CsString("0") + cs_to_string(v)) : cs_to_string(v);
    };
    if (compact) {
        return cs_to_string((int)st.wYear) + pad2(st.wMonth) + pad2(st.wDay) + "_" + pad2(st.wHour) + pad2(st.wMinute) + pad2(st.wSecond);
    }
    return cs_to_string((int)st.wYear) + "-" + pad2(st.wMonth) + "-" + pad2(st.wDay) + "T" + pad2(st.wHour) + ":" + pad2(st.wMinute) + ":" + pad2(st.wSecond) + "Z";
}

static bool WriteFileBytes(const CsString& path, const void* data, uint32_t len, bool appendMode) {
    const uint32_t GENERIC_WRITE = 0x40000000U;
    const uint32_t FILE_APPEND_DATA = 0x00000004U;
    const uint32_t CREATE_ALWAYS = 2U;
    const uint32_t OPEN_ALWAYS = 4U;
    void* h = __imp_CreateFileA(
        path.c_str(),
        appendMode ? FILE_APPEND_DATA : GENERIC_WRITE,
        1U,
        nullptr,
        appendMode ? OPEN_ALWAYS : CREATE_ALWAYS,
        0x80U,
        nullptr
    );
    if (h == (void*)(int64_t)-1 || h == nullptr) return false;
    uint32_t written = 0;
    __imp_WriteFile(h, data, len, &written, nullptr);
    __imp_CloseHandle(h);
    return written == len;
}

static CsString g_localKageAnaDir;
static CsString g_programInstallDir;
static CsString g_sessionFilePath;
static CsString g_lastRecordedPlaceId;

static void EnsureLocalAppDataSetup() {
    CsString localApp = GetEnvStr("LOCALAPPDATA");
    if (localApp.get_Length() == 0) localApp = ".";
    g_localKageAnaDir = localApp + "\\KageAna";
    CsString sesiDir = g_localKageAnaDir + "\\Sesi";
    CsString logDir  = g_localKageAnaDir + "\\Log";
    CsString progBase = localApp + "\\Programs";
    g_programInstallDir = progBase + "\\KageAna";

    __imp_CreateDirectoryA(g_localKageAnaDir.c_str(), nullptr);
    __imp_CreateDirectoryA(sesiDir.c_str(), nullptr);
    __imp_CreateDirectoryA(logDir.c_str(), nullptr);
    __imp_CreateDirectoryA(progBase.c_str(), nullptr);
    __imp_CreateDirectoryA(g_programInstallDir.c_str(), nullptr);

    g_sessionFilePath = sesiDir + "\\sesi_" + GetUtcTimestampStr(true) + ".jsonl";
}

static void RecordSessionLine(const char* kind, const CsString& target, const CsString& detail) {
    if (g_sessionFilePath.get_Length() == 0) return;
    CsString line = CsString("{\"utc\":\"") + GetUtcTimestampStr(false)
        + "\",\"jenis\":\"" + kind
        + "\",\"target\":\"" + target
        + "\",\"rincian\":\"" + detail + "\"}\r\n";
    WriteFileBytes(g_sessionFilePath, line.c_str(), (uint32_t)line.get_Length(), true);
}

using namespace KageAna_Sim;

struct UiButton {
    int id;
    int x, y, w, h;
    const char* label;
    uint32_t bgCol;
};

struct SandboxAppState {
    SimDataBundle bundle;
    WorldClock clock;
    WeatherSystem weather;
    NoFreeKnowledgeGuard guard;
    SimPlaceGraphSystem* world;
    SimPerceptionMemoryRumorSystem* rumorSys;

    uint64_t seed;
    int currentDay;
    CsString currentSeason;
    CsString currentWeather;
    CsString currentFestival;
    int minuteInCurrentHour;

    bool isPaused;
    int speedMultiplier;
    int selectedNpcIndex;
    int nextGigIndex;
    bool isManualMode;
    bool showStarterGuide;
    CsString lastDiegeticDialogue;
    int highlightedKisahIndex;

    CsString lblTopStatus;
    CsString lblMetersAndCover;
    CsString txtKisahHariIni;
    CsString txtNpcInspector;
    CsString txtPapanTinta;
    CsString txtNisshi;

    UiButton buttons[26];
    int buttonCount;

    SandboxAppState() : world(nullptr), rumorSys(nullptr), seed(7ULL), currentDay(1),
        minuteInCurrentHour(0), isPaused(false), speedMultiplier(1), selectedNpcIndex(0),
        nextGigIndex(0), isManualMode(true), showStarterGuide(true), highlightedKisahIndex(-1),
        buttonCount(0) {}
};

static SandboxAppState* g_app = nullptr;
static void* g_hwnd = nullptr;

enum ButtonIds {
    BTN_PAUSE = 101,
    BTN_SPD1,
    BTN_SPD10,
    BTN_SPD60,
    BTN_DAY1,
    BTN_DAY7,
    BTN_DAY28,
    BTN_WARE,
    BTN_TRADE,
    BTN_SLEEP,
    BTN_HIGHLIGHT,
    BTN_REPORT,
    BTN_GUIDE,
    BTN_RESET,
    BTN_INQUIRE,
    BTN_GIG,
    BTN_RENT,
    BTN_DEADDROP,
    BTN_STEAL,
    BTN_SILENT_KILL,
    BTN_LOUD_KILL,
    BTN_TF1,
    BTN_TF2,
    BTN_TF3,
    BTN_WEBGL3D,
    BTN_CLOSE_GUIDE,
    MENU_MODE_MANUAL = 201,
    MENU_POL_IDLE,
    MENU_POL_HONEST,
    MENU_POL_INFORMANT,
    MENU_POL_RECKLESS,
    MENU_EXPORT_NISSHI,
    MENU_OPEN_WEBGL3D,
    MENU_HELP_GUIDE,
    MENU_HELP_REPORT
};

static void SetupButtons(SandboxAppState* app) {
    int n = 0;
    auto add = [&](int id, int x, int y, int w, const char* lbl, uint32_t col) {
        app->buttons[n++] = UiButton{id, x, y, w, 26, lbl, col};
    };
    uint32_t defCol = WIN_RGB(34, 45, 68);
    add(BTN_PAUSE,     8,   44, 78,  "Jeda/Jalan", defCol);
    add(BTN_SPD1,      90,  44, 36,  "x1", defCol);
    add(BTN_SPD10,     130, 44, 40,  "x10", defCol);
    add(BTN_SPD60,     174, 44, 40,  "x60", defCol);
    add(BTN_DAY1,      218, 44, 66,  "+1 Hari", defCol);
    add(BTN_DAY7,      288, 44, 70,  "+7 Hari", WIN_RGB(42, 68, 94));
    add(BTN_DAY28,     362, 44, 76,  "+28 Hari", WIN_RGB(48, 78, 62));
    add(BTN_WARE,      442, 44, 114, "Ganti Dagangan", defCol);
    add(BTN_TRADE,     560, 44, 88,  "Berdagang", defCol);
    add(BTN_SLEEP,     652, 44, 132, "Tidur/Cuci (Nagaya)", defCol);
    add(BTN_HIGHLIGHT, 788, 44, 110, "Sorot Kisah Ini", WIN_RGB(68, 52, 28));
    add(BTN_REPORT,    902, 44, 126, "Kirim Laporan Uji", WIN_RGB(36, 76, 64));
    add(BTN_GUIDE,     1032,44, 92,  "Petunjuk [?]", defCol);
    add(BTN_RESET,     1128,44, 92,  "Ulang (Reset)", defCol);
    add(BTN_WEBGL3D,   1224,44, 96,  "Lab 3D WebGL", WIN_RGB(110, 42, 28));

    add(BTN_INQUIRE,     8,   76, 128, "Tanya NPC (Dialog)", WIN_RGB(52, 74, 108));
    add(BTN_GIG,         140, 76, 102, "Jalankan Gig", WIN_RGB(44, 72, 82));
    add(BTN_RENT,        246, 76, 128, "Bayar Sewa O-Hana", defCol);
    add(BTN_DEADDROP,    378, 76, 130, "Lapor Sabu (Hutan)", defCol);
    add(BTN_STEAL,       512, 76, 92,  "Curi Barang", defCol);
    add(BTN_SILENT_KILL, 608, 76, 100, "Bunuh Senyap", defCol);
    add(BTN_LOUD_KILL,   712, 76, 100, "Bunuh Gaduh", defCol);
    add(BTN_TF1,         816, 76, 128, "Wajah Asli 1: Retak", WIN_RGB(88, 42, 34));
    add(BTN_TF2,         948, 76, 140, "Wajah Asli 2: Terbuka!", WIN_RGB(145, 28, 34));
    add(BTN_TF3,         1092,76, 138, "Wajah Asli 3: Hilang", WIN_RGB(95, 24, 52));

    app->buttonCount = n;
}

static CsString GetCurrentPlaceId(SandboxAppState* app) {
    if (!app->world || app->world->Places.get_Count() == 0) return CsString("place_nagaya");
    return app->world->Places[app->world->SoumaCurrentPlaceIdx].Id;
}

static void RefreshTextPanels(SandboxAppState* app) {
    CsString hh = app->clock.CurrentHour < 10 ? (CsString("0") + cs_to_string(app->clock.CurrentHour)) : cs_to_string(app->clock.CurrentHour);
    CsString mm = app->clock.CurrentMinute < 10 ? (CsString("0") + cs_to_string(app->clock.CurrentMinute)) : cs_to_string(app->clock.CurrentMinute);
    CsString festInfo = app->currentFestival.get_Length() > 0 ? (CsString(" | Festival: ") + app->currentFestival) : CsString("");
    CsString stateLabel = app->isPaused ? CsString("DIJEDA") : (CsString("JALAN x") + cs_to_string(app->speedMultiplier));
    CsString modeStr = app->isManualMode ? CsString("MANUAL (Default)") : (CsString("Uji Kebijakan: ") + app->world->ActiveSoumaPolicy);

    app->lblTopStatus = CsString("Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final) | ")
        + stateLabel + " | Mode: " + modeStr
        + " | Hari " + cs_to_string(app->currentDay) + " (" + app->currentSeason + ") "
        + hh + ":" + mm + " [" + app->clock.CurrentSegment + "] | Cuaca: " + app->currentWeather
        + festInfo + " | Agensi NPC: " + cs_to_string(app->rumorSys->AgencyActionsEmittedCount)
        + " | Rantai: " + cs_to_string(app->rumorSys->CausalChains.get_Count());

    int maxSusp = 0;
    for (int i = 0; i < app->world->Agents.get_Count(); i++) {
        if (app->world->Agents[i].SuspicionTowardSouma > maxSusp) maxSusp = app->world->Agents[i].SuspicionTowardSouma;
    }
    CsString wareName = app->world->Data.Wares.get_Count() > 0 ? app->world->Data.Wares[app->world->ActiveWareIdx].CategoryName : CsString("-");
    CsString heartLabel = app->world->HeartWarmCold >= 25 ? CsString("Hangat") : (app->world->HeartWarmCold <= -25 ? CsString("Dingin") : CsString("Tenang"));
    int yieldPct = app->world->TotalTradesExecuted > 0 ? ((app->world->TradesYieldingKabarOrAccess * 100) / app->world->TotalTradesExecuted) : 0;

    app->lblMetersAndCover = CsString("Uang: ") + cs_to_string(app->world->SoumaMon) + " mon (Utang: " + cs_to_string(app->world->UnpaidRentDebtMon) + " mon)"
        + " | Dagangan: " + wareName + " (Stok:" + cs_to_string(app->world->CarryUnits) + ", Hasil:" + cs_to_string(yieldPct) + "%)"
        + " | Curiga:" + cs_to_string(maxSusp) + "/100"
        + " | Hati:" + cs_to_string(app->world->HeartWarmCold) + " (" + heartLabel + ")"
        + " | Kepercayaan Kelompok:" + cs_to_string(app->world->GroupTrust) + "/100";

    CsString kisahText("");
    int kCount = app->rumorSys->KisahEvents.get_Count();
    int kStart = kCount > 5 ? (kCount - 5) : 0;
    for (int k = kCount - 1; k >= kStart; k--) {
        KisahEventEntry& ke = app->rumorSys->KisahEvents[k];
        CsString whyPart = ke.WhyLinkText.get_Length() > 0 ? ke.WhyLinkText : (CsString("Terjadi di ") + ke.PlaceId);
        CsString witPart = ke.WitnessNpcId.get_Length() > 0 ? (CsString("Saksi: ") + ke.WitnessNpcId) : CsString("Saksi warga sekitar");
        CsString srcPart = ke.SourceEventId.get_Length() > 0 ? (CsString("Sumber: ") + ke.SourceEventId) : CsString("Kejadian langsung");
        kisahText += CsString("* [H") + cs_to_string(ke.Day) + " " + cs_to_string(ke.Hour) + ":00] " + ke.Summary + "\r\n"
            + "  -> MENGAPA? (" + witPart + " | " + srcPart + "): " + whyPart + "\r\n";
    }
    if (kisahText.get_Length() == 0) {
        kisahText = "* Pagi baru dimulai di Lembah Kurokawa. Klik Kanan tempat di peta (atau tekan WASD) untuk berjalan, atau klik warga lalu tekan 'Tanya NPC (Dialog)'.";
    }
    app->txtKisahHariIni = kisahText;

    if (app->selectedNpcIndex < 0 || app->selectedNpcIndex >= app->world->Agents.get_Count()) {
        app->txtNpcInspector = CsString("DIALOG TERAKHIR:\r\n  ") + app->lastDiegeticDialogue + "\r\n\r\n"
            + "ENTITAS: Shinonome Soma (Mode: " + modeStr + ")\r\n"
            + "Tempat Kini   : " + app->world->Places[app->world->SoumaCurrentPlaceIdx].Name + " | Aktivitas: " + app->world->SoumaCurrentActivity + "\r\n"
            + "Tunggakan Sewa: " + cs_to_string(app->world->UnpaidRentWeeks) + " minggu (Utang: " + cs_to_string(app->world->UnpaidRentDebtMon) + " mon)\r\n"
            + "Sumber Event  : Jadwal=" + cs_to_string(app->rumorSys->EventsFromScheduleTransition)
            + ", Interaksi=" + cs_to_string(app->rumorSys->EventsFromEntityInteraction)
            + ", Soma=" + cs_to_string(app->rumorSys->EventsFromSoumaAction)
            + ", Dunia=" + cs_to_string(app->rumorSys->EventsFromWorldCondition);
    } else {
        NpcRuntimeState& ag = app->world->Agents[app->selectedNpcIndex];
        CsString suspReasons("");
        for (int r = 0; r < ag.WhySuspiciousReasons.get_Count(); r++) {
            suspReasons += CsString("  ! ") + ag.WhySuspiciousReasons[r] + "\r\n";
        }
        if (suspReasons.get_Length() == 0) suspReasons = "  (Tidak menaruh curiga khusus terhadap Soma)\r\n";

        app->txtNpcInspector = CsString("DIALOG DIEGETIK (") + ag.DisplayName + " - Sikap: " + ag.AttitudeTowardSouma + "):\r\n  "
            + app->lastDiegeticDialogue + "\r\n\r\n"
            + "NPC [" + cs_to_string(app->selectedNpcIndex + 1) + "/" + cs_to_string(app->world->Agents.get_Count()) + "]: " + ag.DisplayName + " (" + ag.Role + ")\r\n"
            + "Tempat Kini : " + app->world->Places[ag.CurrentPlaceIdx].Name + " | Interaksi Hari Ini: " + cs_to_string(ag.DailyInteractionsCount) + "\r\n"
            + "MENGAPA IA DI SINI: " + ag.WhyHereReason + "\r\n"
            + "MENGAPA IA CURIGA (" + cs_to_string(ag.SuspicionTowardSouma) + "/100):\r\n" + suspReasons;
    }

    CsString ptText = CsString("=== KABAR DI PAPAN TINTA (") + cs_to_string(app->rumorSys->KabarUpgradedCount) + " Terverifikasi >=2 Sumber) ===\r\n";
    int kbCount = app->rumorSys->Kabars.get_Count();
    int kbStart = kbCount > 4 ? (kbCount - 4) : 0;
    for (int k = kbStart; k < kbCount; k++) {
        DynamicKabarRecord& kb = app->rumorSys->Kabars[k];
        ptText += CsString("* [") + kb.Id + "] " + kb.StatusLabel + " -> " + kb.FormattedClaimId + "\r\n";
    }
    ptText += CsString("\r\n=== GIG SAMPINGAN (") + cs_to_string(app->world->CompletedGigIds.get_Count()) + "/" + cs_to_string(app->world->Data.Gigs.get_Count()) + ") ===\r\n";
    for (int g = 0; g < app->world->Data.Gigs.get_Count(); g++) {
        SimGigDef& gig = app->world->Data.Gigs[g];
        bool done = false;
        for (int c = 0; c < app->world->CompletedGigIds.get_Count(); c++) {
            if (app->world->CompletedGigIds[c] == gig.Id) done = true;
        }
        ptText += CsString(done ? "[SELESAI] " : "[TERSEDIA] ") + gig.Title + " (+" + cs_to_string(gig.RewardMon) + " mon)\r\n";
    }
    app->txtPapanTinta = ptText;

    CsString nsText = CsString("=== NISSHI TERKURASI (") + cs_to_string(app->rumorSys->NisshiEntries.get_Count()) + " Butir dari " + cs_to_string(app->rumorSys->RawNisshiCandidates.get_Count()) + " Kandidat) ===\r\n";
    int nCount = app->rumorSys->NisshiEntries.get_Count();
    int nStart = nCount > 4 ? (nCount - 4) : 0;
    for (int n = nCount - 1; n >= nStart; n--) {
        NisshiEntry& ne = app->rumorSys->NisshiEntries[n];
        nsText += CsString("[") + ne.Category + "|" + ne.SourceEventId + "] " + ne.EntryText + "\r\n";
    }
    nsText += CsString("\r\n=== RANTAI AGENSI & SALAH PAHAM NPC (") + cs_to_string(app->rumorSys->CausalChains.get_Count()) + " Rantai) ===\r\n";
    int cCount = app->rumorSys->CausalChains.get_Count();
    int cStart = cCount > 3 ? (cCount - 3) : 0;
    for (int c = cCount - 1; c >= cStart; c--) {
        CausalChainRecord& cc = app->rumorSys->CausalChains[c];
        nsText += CsString("* [") + cc.ChainId + "] " + cc.FullTraceText + "\r\n";
    }
    app->txtNisshi = nsText;
}

static void ResetSimulation(SandboxAppState* app, uint64_t seed, bool firstStart) {
    app->seed = seed;
    app->bundle = SimJsonDataLoader::LoadDefaultBundle();
    app->clock = WorldClock();
    app->weather = WeatherSystem();
    app->weather.SetConfig(app->bundle.WeatherConfig);
    app->guard = NoFreeKnowledgeGuard();
    if (app->world) delete app->world;
    if (app->rumorSys) delete app->rumorSys;
    app->world = new SimPlaceGraphSystem(app->bundle);
    app->isManualMode = true;
    app->world->SoumaManualOverride = true;
    app->world->ActiveSoumaPolicy = "Manual";
    app->rumorSys = new SimPerceptionMemoryRumorSystem(app->bundle);

    app->currentDay = 1;
    app->currentSeason = WorldClock::ComputeSeasonForDay(1);
    app->currentWeather = app->weather.DrawDailyWeather(app->seed, 1, app->currentSeason);
    app->currentFestival = WorldClock::GetScheduledEventForDay(1);
    app->minuteInCurrentHour = 0;
    app->lastDiegeticDialogue = "Pilih salah satu warga di peta lalu klik 'Tanya NPC (Dialog)' untuk mendengar apa yang ia ketahui, dari siapa, dan seberapa yakin ia.";
    if (firstStart) app->showStarterGuide = true;
    RefreshTextPanels(app);
}

static void AdvanceSimMinutes(SandboxAppState* app, int minutesCount) {
    for (int i = 0; i < minutesCount; i++) {
        int prevDay = app->clock.CurrentDay;
        int ticksThisMin = (app->minuteInCurrentHour % 2 == 0) ? 7 : 8;
        app->clock.AdvanceTicks(ticksThisMin);
        for (int t = 0; t < ticksThisMin; t++) {
            app->weather.StepTransitionTick();
        }
        if (app->clock.CurrentDay != prevDay) {
            app->currentDay = app->clock.CurrentDay;
            app->world->GrantedRestrictedAccessToday = false;
            app->currentSeason = WorldClock::ComputeSeasonForDay(app->currentDay);
            app->currentWeather = app->weather.DrawDailyWeather(app->seed, app->currentDay, app->currentSeason);
            app->currentFestival = WorldClock::GetScheduledEventForDay(app->currentDay);
        }
        app->world->StepOneGameMinute(app->seed, app->currentDay, app->clock.CurrentHour, app->minuteInCurrentHour, app->currentWeather, app->currentFestival);
        app->minuteInCurrentHour = (app->minuteInCurrentHour + 1) % 60;
        if (app->minuteInCurrentHour == 0) {
            app->rumorSys->EvaluateHourlyWorldEventsAndRumors(
                app->seed,
                app->clock.TotalTicks,
                app->currentDay,
                app->clock.CurrentHour,
                app->clock.CurrentSegment,
                app->currentWeather,
                *app->world,
                app->guard
            );
            CsString curPid = GetCurrentPlaceId(app);
            if (curPid != g_lastRecordedPlaceId) {
                g_lastRecordedPlaceId = curPid;
                RecordSessionLine("JALUR_SOMA", curPid, CsString("H") + cs_to_string(app->currentDay) + " " + cs_to_string(app->clock.CurrentHour) + ":00");
            }
        }
    }
}

static void ExportNisshiToFile(SandboxAppState* app) {
    app->rumorSys->CurateYearlyNisshi(*app->world);
    CsString outPath = g_localKageAnaDir + "\\Nisshi_Soma.txt";
    CsString content = CsString("======================================================================\r\n")
        + "NISSHI TERKURASI (12-20 BUTIR BERMAKNA SHINONOME SOMA - KITAB 8.10)\r\n"
        + "Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)\r\n"
        + "Mode/Kebijakan: " + app->world->ActiveSoumaPolicy + " | Hari Kini: " + cs_to_string(app->currentDay) + " (" + app->currentSeason + ")\r\n"
        + "======================================================================\r\n\r\n";
    for (int i = 0; i < app->rumorSys->NisshiEntries.get_Count(); i++) {
        NisshiEntry& ne = app->rumorSys->NisshiEntries[i];
        content += CsString("[") + ne.Season + " | " + ne.Category + " | " + ne.SourceEventId + "] " + ne.EntryText + "\r\n";
    }
    WriteFileBytes(outPath, content.c_str(), (uint32_t)content.get_Length(), false);
    CsString msg = CsString("Nisshi terkurasi berhasil disimpan ke:\r\n") + outPath;
    __imp_MessageBoxA(g_hwnd, msg.c_str(), "Ekspor Nisshi Selesai", 0x40U);
}

static void ExportTestReportSummary(SandboxAppState* app) {
    CsString userProfile = GetEnvStr("USERPROFILE");
    CsString desktopDir = userProfile.get_Length() > 0 ? (userProfile + "\\Desktop") : g_localKageAnaDir;
    CsString reportPath = desktopDir + "\\Laporan_Uji_KageAna_" + GetUtcTimestampStr(true) + ".txt";

    CsString body = CsString("LAPORAN UJI KAGE-ANA (OTOMATIS TANPA DATA PRIBADI)\r\n")
        + "Judul Aplikasi : Kage-Ana v0.4.0 [d4f039b3] - Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)\r\n"
        + "Waktu Kemas UTC: " + GetUtcTimestampStr(false) + "\r\n"
        + "Mode Aktif     : " + app->world->ActiveSoumaPolicy + " (Manual=" + (app->isManualMode ? "Ya" : "Tidak") + ")\r\n"
        + "Hari Simulasi  : Hari " + cs_to_string(app->currentDay) + " (" + app->currentSeason + ")\r\n"
        + "Uang / Utang   : " + cs_to_string(app->world->SoumaMon) + " mon / Utang " + cs_to_string(app->world->UnpaidRentDebtMon) + " mon\r\n"
        + "Jejak Kejadian : " + cs_to_string(app->rumorSys->EventLog.get_Count()) + " WorldEvent, " + cs_to_string(app->rumorSys->CausalChains.get_Count()) + " Rantai Sebab-Akibat\r\n"
        + "Berkas Sesi    : " + g_sessionFilePath + "\r\n";

    if (!WriteFileBytes(reportPath, body.c_str(), (uint32_t)body.get_Length(), false)) {
        reportPath = g_localKageAnaDir + "\\Laporan_Uji_KageAna_" + GetUtcTimestampStr(true) + ".txt";
        WriteFileBytes(reportPath, body.c_str(), (uint32_t)body.get_Length(), false);
    }
    __imp_ShellExecuteA(g_hwnd, "open", "explorer.exe", (CsString("/select,\"") + reportPath + "\"").c_str(), nullptr, 1);
    CsString msg = CsString("Laporan uji & rekaman sesi berhasil disimpan ke:\r\n") + reportPath + "\r\n\r\nSilakan kirimkan berkas tersebut kepada pembuatnya.";
    __imp_MessageBoxA(g_hwnd, msg.c_str(), "Laporan Uji Siap Dikirim", 0x40U);
}

extern const unsigned char kEmbeddedWebGlHtml[];
extern const uint32_t kEmbeddedWebGlHtmlLen;

static void LaunchEmbeddedWebGl3D() {
    CsString htmlPath = g_programInstallDir + "\\KageAna_3D_WowSlice.html";
    WriteFileBytes(htmlPath, kEmbeddedWebGlHtml, kEmbeddedWebGlHtmlLen, false);
    __imp_ShellExecuteA(g_hwnd, "open", htmlPath.c_str(), nullptr, nullptr, 1);
}

static void HandleCommandButton(SandboxAppState* app, int id) {
    if (!app) return;
    switch (id) {
        case BTN_PAUSE:
            app->isPaused = !app->isPaused;
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Jeda/Jalan");
            break;
        case BTN_SPD1:
            app->speedMultiplier = 1; app->isPaused = false;
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "x1");
            break;
        case BTN_SPD10:
            app->speedMultiplier = 10; app->isPaused = false;
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "x10");
            break;
        case BTN_SPD60:
            app->speedMultiplier = 60; app->isPaused = false;
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "x60");
            break;
        case BTN_DAY1:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "+1 Hari");
            AdvanceSimMinutes(app, 1440);
            break;
        case BTN_DAY7:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "+7 Hari");
            AdvanceSimMinutes(app, 7 * 1440);
            break;
        case BTN_DAY28:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "+28 Hari");
            AdvanceSimMinutes(app, 28 * 1440);
            break;
        case BTN_WARE:
            app->world->SelectWareCategory((app->world->ActiveWareIdx + 1) % app->world->Data.Wares.get_Count());
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Ganti Dagangan");
            break;
        case BTN_TRADE:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Berdagang");
            app->rumorSys->ExecuteSoumaTrade(app->seed, app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
            break;
        case BTN_SLEEP: {
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Tidur/Cuci Nagaya");
            int nagIdx = app->world->FindPlaceIndexById("place_nagaya");
            if (nagIdx >= 0) app->world->CommandSoumaMoveToPlace(nagIdx, "Pulang ke Kamar Sewa Nagaya untuk tidur & mencuci noda darah.");
            app->world->SoumaCurrentPlaceIdx = nagIdx >= 0 ? nagIdx : 0;
            app->world->SoumaIsInTransit = false;
            app->rumorSys->ExecuteSoumaSleepAndCleanInNagaya(app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
            break;
        }
        case BTN_HIGHLIGHT: {
            int kc = app->rumorSys->KisahEvents.get_Count();
            if (kc > 0) {
                app->highlightedKisahIndex = (app->highlightedKisahIndex + 1) % kc;
                int actualIdx = kc - 1 - (app->highlightedKisahIndex % sim_math::min_v(8, kc));
                if (actualIdx >= 0 && actualIdx < kc) {
                    KisahEventEntry& ke = app->rumorSys->KisahEvents[actualIdx];
                    RecordSessionLine("SOROT_KEJADIAN", ke.SourceEventId, ke.Summary);
                }
            }
            break;
        }
        case BTN_REPORT:
        case MENU_HELP_REPORT:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Kirim Laporan Uji");
            ExportTestReportSummary(app);
            break;
        case BTN_GUIDE:
        case MENU_HELP_GUIDE:
            app->showStarterGuide = !app->showStarterGuide;
            break;
        case BTN_CLOSE_GUIDE:
            app->showStarterGuide = false;
            break;
        case BTN_RESET:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Reset");
            ResetSimulation(app, 7ULL, false);
            break;
        case BTN_WEBGL3D:
        case MENU_OPEN_WEBGL3D:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Buka Lab 3D WebGL");
            LaunchEmbeddedWebGl3D();
            break;
        case BTN_INQUIRE:
            if (app->selectedNpcIndex >= 0 && app->selectedNpcIndex < app->world->Agents.get_Count()) {
                NpcRuntimeState& targetAg = app->world->Agents[app->selectedNpcIndex];
                RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), CsString("Tanya NPC:") + targetAg.Id);
                app->rumorSys->ExecuteSoumaInquireNpc(app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, targetAg.Id, *app->world, app->guard);
                app->lastDiegeticDialogue = app->rumorSys->GenerateDiegeticNpcDialogue(targetAg.Id, *app->world);
                RecordSessionLine("SOROT_KEJADIAN", CsString("dialog_") + targetAg.Id, app->lastDiegeticDialogue);
            }
            break;
        case BTN_GIG:
            if (app->world->Data.Gigs.get_Count() > 0) {
                int gIdx = app->nextGigIndex % app->world->Data.Gigs.get_Count();
                SimGigDef& g = app->world->Data.Gigs[gIdx];
                CsString appStr = g.Approaches.get_Count() > 0 ? g.Approaches[0] : CsString("Clever");
                RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), CsString("Jalankan Gig:") + g.Id);
                app->rumorSys->ExecuteSoumaCompleteGig(gIdx, appStr, app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
                app->nextGigIndex = (app->nextGigIndex + 1) % app->world->Data.Gigs.get_Count();
            }
            break;
        case BTN_RENT:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Bayar Sewa O-Hana");
            app->rumorSys->ExecuteSoumaPayRentToOhana(app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
            break;
        case BTN_DEADDROP:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Lapor Sabu");
            app->rumorSys->ExecuteSoumaDeadDropReport(app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
            break;
        case BTN_STEAL:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Curi Barang");
            app->rumorSys->ExecuteSoumaSteal(app->clock.TotalTicks, app->clock.CurrentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
            break;
        case BTN_SILENT_KILL:
            if (app->selectedNpcIndex >= 0 && app->selectedNpcIndex < app->world->Agents.get_Count()) {
                NpcRuntimeState& targetAg = app->world->Agents[app->selectedNpcIndex];
                RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), CsString("Bunuh Senyap:") + targetAg.Id);
                app->rumorSys->ExecuteSoumaElimination(app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, targetAg.Id, false, true, *app->world, app->guard);
            }
            break;
        case BTN_LOUD_KILL:
            if (app->selectedNpcIndex >= 0 && app->selectedNpcIndex < app->world->Agents.get_Count()) {
                NpcRuntimeState& targetAg = app->world->Agents[app->selectedNpcIndex];
                RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), CsString("Bunuh Gaduh:") + targetAg.Id);
                app->rumorSys->ExecuteSoumaElimination(app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, targetAg.Id, true, false, *app->world, app->guard);
            }
            break;
        case BTN_TF1:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Wajah Asli 1");
            app->rumorSys->ExecuteSoumaTrueFace(1, app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
            break;
        case BTN_TF2:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Wajah Asli 2");
            app->rumorSys->ExecuteSoumaTrueFace(2, app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
            break;
        case BTN_TF3:
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Wajah Asli 3");
            app->rumorSys->ExecuteSoumaTrueFace(3, app->clock.TotalTicks, app->currentDay, app->clock.CurrentHour, app->clock.CurrentSegment, app->currentWeather, *app->world, app->guard);
            break;
        case MENU_MODE_MANUAL:
            app->isManualMode = true;
            app->world->SoumaManualOverride = true;
            app->world->ActiveSoumaPolicy = "Manual";
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), "Mode:Manual");
            break;
        case MENU_POL_IDLE:
        case MENU_POL_HONEST:
        case MENU_POL_INFORMANT:
        case MENU_POL_RECKLESS: {
            const char* pol = (id == MENU_POL_IDLE) ? "Idle" :
                              (id == MENU_POL_HONEST) ? "HonestTrader" :
                              (id == MENU_POL_INFORMANT) ? "TraderInformant" : "RecklessLoud";
            app->isManualMode = false;
            app->world->SoumaManualOverride = false;
            app->world->ActiveSoumaPolicy = pol;
            RecordSessionLine("TOMBOL", GetCurrentPlaceId(app), CsString("MenuDev:Kebijakan:") + pol);
            break;
        }
        case MENU_EXPORT_NISSHI:
            ExportNisshiToFile(app);
            break;
    }
    RefreshTextPanels(app);
    if (g_hwnd) __imp_InvalidateRect(g_hwnd, nullptr, 0);
}

static void MapWorldToScreen(int mapLeft, int mapTop, int mapW, int mapH, double wx, double wy, int& sx, int& sy) {
    double cx = mapLeft + mapW * 0.50;
    double cy = mapTop + mapH * 0.54;
    double minDim = (double)(mapW < mapH ? mapW : mapH);
    double scale = minDim / 520.0;
    sx = (int)(cx + wx * scale);
    sy = (int)(cy - wy * scale);
}

static void RenderSandboxWindow(void* hwnd, void* hdcWin) {
    if (!g_app || !g_app->world) return;
    RECT rcClient;
    __imp_GetClientRect(hwnd, &rcClient);
    int W = rcClient.right - rcClient.left;
    int H = rcClient.bottom - rcClient.top;
    if (W <= 0 || H <= 0) return;

    void* hdc = __imp_CreateCompatibleDC(hdcWin);
    void* hbm = __imp_CreateCompatibleBitmap(hdcWin, W, H);
    void* oldBm = __imp_SelectObject(hdc, hbm);

    __imp_SetBkMode(hdc, 1);

    void* fontBold = __imp_CreateFontA(-13, 0, 0, 0, 700, 0, 0, 0, 0, 0, 0, 4, 0, "Segoe UI");
    void* fontSmallBold = __imp_CreateFontA(-12, 0, 0, 0, 700, 0, 0, 0, 0, 0, 0, 4, 0, "Segoe UI");
    void* fontMono = __imp_CreateFontA(-12, 0, 0, 0, 400, 0, 0, 0, 0, 0, 0, 4, 0, "Consolas");

    auto fillBox = [&](int x, int y, int w, int h, uint32_t col) {
        RECT r{x, y, x + w, y + h};
        void* br = __imp_CreateSolidBrush(col);
        __imp_FillRect(hdc, &r, br);
        __imp_DeleteObject(br);
    };

    fillBox(0, 0, W, H, WIN_RGB(13, 18, 28));

    int topH = 110;
    fillBox(0, 0, W, topH, WIN_RGB(22, 30, 46));

    void* oldFont = __imp_SelectObject(hdc, fontBold);
    __imp_SetTextColor(hdc, WIN_RGB(245, 176, 65));
    __imp_TextOutA(hdc, 8, 4, g_app->lblTopStatus.c_str(), g_app->lblTopStatus.get_Length());

    __imp_SetTextColor(hdc, WIN_RGB(234, 224, 200));
    __imp_TextOutA(hdc, 8, 22, g_app->lblMetersAndCover.c_str(), g_app->lblMetersAndCover.get_Length());

    __imp_SelectObject(hdc, fontSmallBold);
    void* btnBorderPen = __imp_CreatePen(0, 1, WIN_RGB(95, 110, 138));
    void* oldPen = __imp_SelectObject(hdc, btnBorderPen);
    for (int i = 0; i < g_app->buttonCount; i++) {
        UiButton& b = g_app->buttons[i];
        void* br = __imp_CreateSolidBrush(b.bgCol);
        void* prevBr = __imp_SelectObject(hdc, br);
        __imp_Rectangle(hdc, b.x, b.y, b.x + b.w, b.y + b.h);
        __imp_SelectObject(hdc, prevBr);
        __imp_DeleteObject(br);

        RECT tr{b.x, b.y, b.x + b.w, b.y + b.h};
        __imp_SetTextColor(hdc, WIN_RGB(244, 239, 230));
        __imp_DrawTextA(hdc, b.label, -1, &tr, 0x01 | 0x04 | 0x20);
    }

    int rightW = 530;
    int mapLeft = 0;
    int mapTop = topH;
    int mapW = (W > rightW + 200) ? (W - rightW) : (W / 2);
    int mapH = H - topH;
    int rightX = mapW;

    fillBox(rightX, topH, W - rightX, mapH, WIN_RGB(20, 27, 41));

    auto drawPanelBox = [&](int py, int ph, const char* title, const CsString& body) {
        __imp_SelectObject(hdc, fontSmallBold);
        __imp_SetTextColor(hdc, WIN_RGB(245, 176, 65));
        __imp_TextOutA(hdc, rightX + 8, py, title, (int)strlen(title));

        int bx = rightX + 8, by = py + 17, bw = (W - rightX) - 16, bh = ph - 20;
        fillBox(bx, by, bw, bh, WIN_RGB(14, 19, 30));
        RECT br{bx + 4, by + 3, bx + bw - 4, by + bh - 3};
        __imp_SelectObject(hdc, fontMono);
        __imp_SetTextColor(hdc, WIN_RGB(234, 224, 200));
        __imp_DrawTextA(hdc, body.c_str(), body.get_Length(), &br, 0x10);
    };

    int availH = mapH - 8;
    int pH = availH / 4;
    drawPanelBox(topH + 4,          pH, "1. KISAH HARI INI (Kalimat Biasa & Tautan 'Mengapa' ke Saksi/Sumber)", g_app->txtKisahHariIni);
    drawPanelBox(topH + 4 + pH,     pH, "2. DIALOG NPC ('Tanya NPC') & INSPEKTUR (Mengapa Ia Tahu / Curiga)", g_app->txtNpcInspector);
    drawPanelBox(topH + 4 + pH * 2, pH, "3. PAPAN TINTA (Kabar, Pesanan Kelompok, Gig Sampingan, & Kisah Kecil)", g_app->txtPapanTinta);
    drawPanelBox(topH + 4 + pH * 3, pH, "4. NISSHI TERKURASI (12-20 Butir) & RANTAI SEBAB-AKIBAT (Agensi NPC)", g_app->txtNisshi);

    int pCount = g_app->world->Places.get_Count();
    void* roadPen  = __imp_CreatePen(0, 2, WIN_RGB(120, 115, 100));
    void* alleyPen = __imp_CreatePen(0, 1, WIN_RGB(70, 95, 140));
    __imp_SelectObject(hdc, fontMono);
    __imp_SetTextColor(hdc, WIN_RGB(165, 155, 135));

    for (int i = 0; i < pCount; i++) {
        int x0, y0;
        MapWorldToScreen(mapLeft, mapTop, mapW, mapH, g_app->world->Places[i].MapX, g_app->world->Places[i].MapY, x0, y0);
        for (int j = i + 1; j < pCount; j++) {
            int mins = g_app->world->DirectEdgeMinutes[i * pCount + j];
            if (mins < 9999) {
                int x1, y1;
                MapWorldToScreen(mapLeft, mapTop, mapW, mapH, g_app->world->Places[j].MapX, g_app->world->Places[j].MapY, x1, y1);
                CsString& rt = g_app->world->EdgeRouteTypes[i * pCount + j];
                __imp_SelectObject(hdc, rt == "jalan_utama" ? roadPen : alleyPen);
                __imp_MoveToEx(hdc, x0, y0, nullptr);
                __imp_LineTo(hdc, x1, y1);
                CsString mLbl = cs_to_string(mins) + "m";
                __imp_TextOutA(hdc, (x0 + x1) / 2 + 2, (y0 + y1) / 2 - 6, mLbl.c_str(), mLbl.get_Length());
            }
        }
    }
    __imp_DeleteObject(roadPen);
    __imp_DeleteObject(alleyPen);

    void* indoorBr  = __imp_CreateSolidBrush(WIN_RGB(32, 48, 72));
    void* outdoorBr = __imp_CreateSolidBrush(WIN_RGB(42, 38, 32));
    void* nullBr    = __imp_GetStockObject(5);
    void* placePen  = __imp_CreatePen(0, 2, WIN_RGB(234, 224, 200));
    void* poiPen    = __imp_CreatePen(0, 3, WIN_RGB(245, 176, 65));
    void* vacPen    = __imp_CreatePen(0, 2, WIN_RGB(224, 90, 43));

    __imp_SelectObject(hdc, fontSmallBold);
    for (int i = 0; i < pCount; i++) {
        SimPlaceDef& pl = g_app->world->Places[i];
        bool isPoi = (g_app->currentDay <= 2) && (pl.Id == "place_pasar" || pl.Id == "place_kedai_teh" || pl.Id == "place_apotek_soan");
        bool vacant = (i < g_app->world->GuardPostVacant.get_Length() && g_app->world->GuardPostVacant[i]);
        int px, py;
        MapWorldToScreen(mapLeft, mapTop, mapW, mapH, pl.MapX, pl.MapY, px, py);
        int r = 16;
        if (isPoi) {
            __imp_SelectObject(hdc, nullBr);
            __imp_SelectObject(hdc, poiPen);
            __imp_Ellipse(hdc, px - (r + 5), py - (r + 5), px + (r + 5), py + (r + 5));
        }
        __imp_SelectObject(hdc, pl.IsIndoorShelter ? indoorBr : outdoorBr);
        __imp_SelectObject(hdc, vacant ? vacPen : placePen);
        __imp_Ellipse(hdc, px - r, py - r, px + r, py + r);

        CsString pTitle = vacant ? (pl.Name + " [POS KOSONG]") : (isPoi ? (CsString("* ") + pl.Name) : pl.Name);
        __imp_SetTextColor(hdc, isPoi ? WIN_RGB(245, 176, 65) : WIN_RGB(244, 239, 230));
        __imp_TextOutA(hdc, px - 48, py - 30, pTitle.c_str(), pTitle.get_Length());
    }
    __imp_DeleteObject(indoorBr);
    __imp_DeleteObject(outdoorBr);
    __imp_DeleteObject(placePen);
    __imp_DeleteObject(poiPen);
    __imp_DeleteObject(vacPen);

    void* soumaBr = __imp_CreateSolidBrush(WIN_RGB(200, 35, 44));
    void* l0Br    = __imp_CreateSolidBrush(WIN_RGB(245, 176, 65));
    void* l1Br    = __imp_CreateSolidBrush(WIN_RGB(92, 136, 196));
    void* l2Br    = __imp_CreateSolidBrush(WIN_RGB(128, 136, 150));
    void* deadBr  = __imp_CreateSolidBrush(WIN_RGB(90, 30, 30));
    void* selPen  = __imp_CreatePen(0, 2, WIN_RGB(255, 255, 255));
    void* suspPen = __imp_CreatePen(0, 2, WIN_RGB(224, 43, 54));
    void* darkPen = __imp_CreatePen(0, 1, WIN_RGB(10, 14, 22));

    int sx, sy;
    MapWorldToScreen(mapLeft, mapTop, mapW, mapH, g_app->world->SoumaPosX, g_app->world->SoumaPosY, sx, sy);
    __imp_SelectObject(hdc, soumaBr);
    __imp_SelectObject(hdc, g_app->selectedNpcIndex == -1 ? selPen : darkPen);
    __imp_Ellipse(hdc, sx - 8, sy - 8, sx + 8, sy + 8);
    CsString sLbl = CsString("SOMA [") + (g_app->isManualMode ? CsString("MANUAL") : g_app->world->ActiveSoumaPolicy) + "]";
    __imp_SetTextColor(hdc, WIN_RGB(255, 230, 210));
    __imp_TextOutA(hdc, sx + 10, sy - 6, sLbl.c_str(), sLbl.get_Length());

    for (int n = 0; n < g_app->world->Agents.get_Count(); n++) {
        NpcRuntimeState& ag = g_app->world->Agents[n];
        int nx, ny;
        MapWorldToScreen(mapLeft, mapTop, mapW, mapH, ag.PosX, ag.PosY, nx, ny);
        void* nb = l2Br;
        if (ag.IsDead) nb = deadBr;
        else if (ag.LodLevel == "L0_Full") nb = l0Br;
        else if (ag.LodLevel == "L1_Light") nb = l1Br;

        __imp_SelectObject(hdc, nb);
        __imp_SelectObject(hdc, g_app->selectedNpcIndex == n ? selPen : (ag.SuspicionTowardSouma >= 35 ? suspPen : darkPen));
        __imp_Ellipse(hdc, nx - 6, ny - 6, nx + 6, ny + 6);

        CsString tag = ag.SuspicionTowardSouma > 0 ? (ag.DisplayName + " [" + cs_to_string(ag.SuspicionTowardSouma) + "]") : ag.DisplayName;
        __imp_SetTextColor(hdc, WIN_RGB(255, 255, 255));
        __imp_TextOutA(hdc, nx + 8, ny - 6, tag.c_str(), tag.get_Length());
    }

    __imp_DeleteObject(soumaBr);
    __imp_DeleteObject(l0Br);
    __imp_DeleteObject(l1Br);
    __imp_DeleteObject(l2Br);
    __imp_DeleteObject(deadBr);
    __imp_DeleteObject(selPen);
    __imp_DeleteObject(suspPen);
    __imp_DeleteObject(darkPen);

    if (g_app->showStarterGuide) {
        int gx = 14, gy = topH + 14, gw = 430, gh = 205;
        fillBox(gx, gy, gw, gh, WIN_RGB(24, 34, 52));
        void* cardPen = __imp_CreatePen(0, 2, WIN_RGB(245, 176, 65));
        __imp_SelectObject(hdc, nullBr);
        __imp_SelectObject(hdc, cardPen);
        __imp_Rectangle(hdc, gx, gy, gx + gw, gy + gh);
        __imp_DeleteObject(cardPen);

        __imp_SelectObject(hdc, fontSmallBold);
        __imp_SetTextColor(hdc, WIN_RGB(245, 176, 65));
        const char* gTitle = "PETUNJUK AWAL (1 LAYAR - BISA DITUTUP KAPAN SAJA)";
        __imp_TextOutA(hdc, gx + 10, gy + 8, gTitle, (int)strlen(gTitle));

        fillBox(gx + 344, gy + 5, 76, 22, WIN_RGB(145, 28, 34));
        RECT closeRc{gx + 344, gy + 5, gx + 420, gy + 27};
        __imp_SetTextColor(hdc, WIN_RGB(255, 255, 255));
        __imp_DrawTextA(hdc, "Tutup [X]", -1, &closeRc, 0x01 | 0x04 | 0x20);

        const char* gBody =
            "Selamat datang di Lembah Kurokawa. Anda berperan sebagai Shinonome Soma.\r\n\r\n"
            "1. GERAK MANUAL (Default): Klik Kanan lingkaran tempat di peta (atau tekan WASD).\r\n"
            "   Tempat menarik disorot emas: Pasar Kaki Kastil, Kedai Teh O-Kiku, & Apotek Soan.\r\n"
            "2. INTERAKSI & DIALOG: Klik titik warga di peta lalu tekan 'Tanya NPC (Dialog)' atau 'Berdagang'.\r\n"
            "3. IKUTI CERITA: Baca panel '1. KISAH HARI INI' di kanan untuk melihat kejadian & alasan saksi.\r\n"
            "4. TEKANAN HIDUP: Makan harian (15 mon) & sewa O-Hana (350 mon tiap Hari 7) harus dibayar.\r\n"
            "5. SELESAI UJI: Klik 'Kirim Laporan Uji' di baris atas (atau coba 'Lab 3D WebGL').";
        RECT bodyRc{gx + 10, gy + 32, gx + gw - 10, gy + gh - 8};
        __imp_SelectObject(hdc, fontMono);
        __imp_SetTextColor(hdc, WIN_RGB(234, 224, 200));
        __imp_DrawTextA(hdc, gBody, -1, &bodyRc, 0x10);
    }

    __imp_BitBlt(hdcWin, 0, 0, W, H, hdc, 0, 0, 0x00CC0020U);

    __imp_SelectObject(hdc, oldPen);
    __imp_DeleteObject(btnBorderPen);
    __imp_SelectObject(hdc, oldFont);
    __imp_DeleteObject(fontBold);
    __imp_DeleteObject(fontSmallBold);
    __imp_DeleteObject(fontMono);
    __imp_SelectObject(hdc, oldBm);
    __imp_DeleteObject(hbm);
    __imp_DeleteDC(hdc);
}

static int64_t WndProc(void* hwnd, uint32_t msg, uint64_t wParam, int64_t lParam) {
    switch (msg) {
        case 0x0002:
            __imp_PostQuitMessage(0);
            return 0;

        case 0x0111: {
            int cmdId = (int)(wParam & 0xFFFF);
            HandleCommandButton(g_app, cmdId);
            return 0;
        }

        case 0x0113:
            if (g_app && !g_app->isPaused) {
                int mins = 1;
                if (g_app->speedMultiplier == 10) mins = 4;
                else if (g_app->speedMultiplier == 60) mins = 20;
                AdvanceSimMinutes(g_app, mins);
                RefreshTextPanels(g_app);
                __imp_InvalidateRect(hwnd, nullptr, 0);
            }
            return 0;

        case 0x0100:
            if (g_app && g_app->world) {
                double step = 14.0;
                bool moved = false;
                if (wParam == 'W' || wParam == 0x26) {
                    g_app->isManualMode = true;
                    g_app->world->MoveSoumaByWasdDelta(0.0, step);
                    moved = true;
                } else if (wParam == 'S' || wParam == 0x28) {
                    g_app->isManualMode = true;
                    g_app->world->MoveSoumaByWasdDelta(0.0, -step);
                    moved = true;
                } else if (wParam == 'A' || wParam == 0x25) {
                    g_app->isManualMode = true;
                    g_app->world->MoveSoumaByWasdDelta(-step, 0.0);
                    moved = true;
                } else if (wParam == 'D' || wParam == 0x27) {
                    g_app->isManualMode = true;
                    g_app->world->MoveSoumaByWasdDelta(step, 0.0);
                    moved = true;
                }
                if (moved) {
                    RefreshTextPanels(g_app);
                    __imp_InvalidateRect(hwnd, nullptr, 0);
                }
            }
            return 0;

        case 0x0201: {
            if (!g_app || !g_app->world) return 0;
            int mx = (int)(int16_t)(lParam & 0xFFFF);
            int my = (int)(int16_t)((lParam >> 16) & 0xFFFF);

            for (int i = 0; i < g_app->buttonCount; i++) {
                UiButton& b = g_app->buttons[i];
                if (mx >= b.x && mx <= b.x + b.w && my >= b.y && my <= b.y + b.h) {
                    HandleCommandButton(g_app, b.id);
                    return 0;
                }
            }

            int topH = 110;
            if (g_app->showStarterGuide) {
                int gx = 14, gy = topH + 14;
                if (mx >= gx + 344 && mx <= gx + 420 && my >= gy + 5 && my <= gy + 27) {
                    HandleCommandButton(g_app, BTN_CLOSE_GUIDE);
                    return 0;
                }
            }

            RECT rcClient;
            __imp_GetClientRect(hwnd, &rcClient);
            int W = rcClient.right - rcClient.left;
            int H = rcClient.bottom - rcClient.top;
            int rightW = 530;
            int mapW = (W > rightW + 200) ? (W - rightW) : (W / 2);
            int mapH = H - topH;

            if (mx < mapW && my >= topH) {
                int sx, sy;
                MapWorldToScreen(0, topH, mapW, mapH, g_app->world->SoumaPosX, g_app->world->SoumaPosY, sx, sy);
                double minDist = 26.0;
                int picked = g_app->selectedNpcIndex;
                double sDist = k_sqrt((double)((sx - mx) * (sx - mx) + (sy - my) * (sy - my)));
                if (sDist < minDist) {
                    minDist = sDist;
                    picked = -1;
                }
                for (int n = 0; n < g_app->world->Agents.get_Count(); n++) {
                    int nx, ny;
                    MapWorldToScreen(0, topH, mapW, mapH, g_app->world->Agents[n].PosX, g_app->world->Agents[n].PosY, nx, ny);
                    double d = k_sqrt((double)((nx - mx) * (nx - mx) + (ny - my) * (ny - my)));
                    if (d < minDist) {
                        minDist = d;
                        picked = n;
                    }
                }
                g_app->selectedNpcIndex = picked;
                if (picked >= 0 && picked < g_app->world->Agents.get_Count()) {
                    g_app->lastDiegeticDialogue = g_app->rumorSys->GenerateDiegeticNpcDialogue(g_app->world->Agents[picked].Id, *g_app->world);
                }
                RefreshTextPanels(g_app);
                __imp_InvalidateRect(hwnd, nullptr, 0);
            }
            return 0;
        }

        case 0x0204: {
            if (!g_app || !g_app->world) return 0;
            int mx = (int)(int16_t)(lParam & 0xFFFF);
            int my = (int)(int16_t)((lParam >> 16) & 0xFFFF);
            int topH = 110;
            RECT rcClient;
            __imp_GetClientRect(hwnd, &rcClient);
            int W = rcClient.right - rcClient.left;
            int H = rcClient.bottom - rcClient.top;
            int rightW = 530;
            int mapW = (W > rightW + 200) ? (W - rightW) : (W / 2);
            int mapH = H - topH;

            if (mx < mapW && my >= topH) {
                int bestPlace = -1;
                double bestDist = 38.0;
                for (int i = 0; i < g_app->world->Places.get_Count(); i++) {
                    int px, py;
                    MapWorldToScreen(0, topH, mapW, mapH, g_app->world->Places[i].MapX, g_app->world->Places[i].MapY, px, py);
                    double d = k_sqrt((double)((px - mx) * (px - mx) + (py - my) * (py - my)));
                    if (d < bestDist) {
                        bestDist = d;
                        bestPlace = i;
                    }
                }
                if (bestPlace >= 0) {
                    g_app->isManualMode = true;
                    g_app->world->CommandSoumaMoveToPlace(bestPlace, CsString("Perintah Klik Kanan: Soma berjalan ke ") + g_app->world->Places[bestPlace].Name + ".");
                    RecordSessionLine("TOMBOL", g_app->world->Places[bestPlace].Id, CsString("KlikKananJalan:") + g_app->world->Places[bestPlace].Id);
                    RefreshTextPanels(g_app);
                    __imp_InvalidateRect(hwnd, nullptr, 0);
                }
            }
            return 0;
        }

        case 0x000F: {
            PAINTSTRUCT ps;
            void* hdc = __imp_BeginPaint(hwnd, &ps);
            RenderSandboxWindow(hwnd, hdc);
            __imp_EndPaint(hwnd, &ps);
            return 0;
        }

        case 0x0014:
            return 1;
    }
    return __imp_DefWindowProcA(hwnd, msg, wParam, lParam);
}

static int RunWin64SelfTest() {
    EnsureLocalAppDataSetup();
    CsString outFile = g_localKageAnaDir + "\\selftest.txt";
    int passed = ClockAndWeatherSimTests::RunAllUnitTests();
    CsString json3Days = HeadlessSimRunner::Run28DaySimToJson(7ULL, 3, false);
    bool ok = (passed == 30)
        && json3Days.contains_sub("\"violations\":0")
        && json3Days.contains_sub("\"unclassifiedEvents\":0")
        && json3Days.contains_sub("\"seed\":7");

    CsString report = CsString("KAGE-ANA SANDBOX SELFTEST (3 HARI, SEED 7)\r\n")
        + "Versi       : 0.4.0 [d4f039b3]\r\n"
        + "Waktu UTC   : " + GetUtcTimestampStr(false) + "\r\n"
        + "Unit Tests  : " + cs_to_string(passed) + "/30\r\n"
        + "Status      : " + (ok ? "LULUS (0 pelanggaran invarian)" : "GAGAL") + "\r\n"
        + "Ringkasan   : " + json3Days + "\r\n";
    WriteFileBytes(outFile, report.c_str(), (uint32_t)report.get_Length(), false);
    return ok ? 0 : 1;
}

extern "C" void __attribute__((section(".text.startup"))) WinMainCRTStartup() {
    char* cmdLine = __imp_GetCommandLineA();
    if (cmdLine && strstr(cmdLine, "--selftest")) {
        int rc = RunWin64SelfTest();
        __imp_ExitProcess((uint32_t)rc);
    }

    __imp_CreateMutexA(nullptr, 1, "Local\\KageAna_Sandbox_Uji_Sistem_Mutex");
    if (__imp_GetLastError() == 183U) {
        void* existing = __imp_FindWindowA("KageAnaSandboxWndClass", nullptr);
        if (existing) {
            __imp_ShowWindow(existing, 9);
            __imp_SetForegroundWindow(existing);
        }
        __imp_ExitProcess(0);
    }

    EnsureLocalAppDataSetup();
    RecordSessionLine("MULAI_SESI", "place_nagaya", "Sesi uji dimulai langsung tanpa wizard setup (Mode Manual default).");

    g_app = new SandboxAppState();
    SetupButtons(g_app);
    ResetSimulation(g_app, 7ULL, true);

    WNDCLASSEXA wc;
    memset(&wc, 0, sizeof(wc));
    wc.cbSize = sizeof(WNDCLASSEXA);
    wc.style = 0x0003U;
    wc.lpfnWndProc = (void*)&WndProc;
    wc.hInstance = (void*)0x00400000ULL;
    wc.hCursor = __imp_LoadCursorA(nullptr, (const char*)32512ULL);
    wc.lpszClassName = "KageAnaSandboxWndClass";
    __imp_RegisterClassExA(&wc);

    void* hMenuBar = __imp_CreateMenu();
    void* hMenuDev = __imp_CreatePopupMenu();
    __imp_AppendMenuA(hMenuDev, 0U, MENU_MODE_MANUAL,   "Mode Manual (Default Pemain - Kendali WASD / Klik Kanan)");
    __imp_AppendMenuA(hMenuDev, 0U, MENU_POL_IDLE,      "Alat Uji Kebijakan Otomatis: Idle");
    __imp_AppendMenuA(hMenuDev, 0U, MENU_POL_HONEST,    "Alat Uji Kebijakan Otomatis: HonestTrader");
    __imp_AppendMenuA(hMenuDev, 0U, MENU_POL_INFORMANT, "Alat Uji Kebijakan Otomatis: TraderInformant");
    __imp_AppendMenuA(hMenuDev, 0U, MENU_POL_RECKLESS,  "Alat Uji Kebijakan Otomatis: RecklessLoud");
    __imp_AppendMenuA(hMenuDev, 0U, MENU_EXPORT_NISSHI, "Ekspor Nisshi ke Berkas Teks (.txt)");
    __imp_AppendMenuA(hMenuDev, 0U, MENU_OPEN_WEBGL3D,  "Buka Lab 3D WebGL (KageAna 3D)");

    void* hMenuHelp = __imp_CreatePopupMenu();
    __imp_AppendMenuA(hMenuHelp, 0U, MENU_HELP_GUIDE,  "Tampilkan Kartu Petunjuk Awal (1 Layar)");
    __imp_AppendMenuA(hMenuHelp, 0U, MENU_HELP_REPORT, "Kirim laporan uji (Simpan ke Desktop)");

    __imp_AppendMenuA(hMenuBar, 0x10U, (uint64_t)hMenuDev,  "Pengembang (Alat Uji Kebijakan)");
    __imp_AppendMenuA(hMenuBar, 0x10U, (uint64_t)hMenuHelp, "Bantuan");

    g_hwnd = __imp_CreateWindowExA(
        0U,
        "KageAnaSandboxWndClass",
        "KAGE-ANA v0.4.0 [d4f039b3] - Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final) [Langsung Jalan Tanpa Setup]",
        0x00CF0000U | 0x10000000U,
        40, 20, 1340, 735,
        nullptr,
        hMenuBar,
        (void*)0x00400000ULL,
        nullptr
    );

    __imp_ShowWindow(g_hwnd, 5);
    __imp_UpdateWindow(g_hwnd);
    __imp_SetTimer(g_hwnd, 1ULL, 100U, nullptr);

    MSG msg;
    while (__imp_GetMessageA(&msg, nullptr, 0U, 0U) > 0) {
        __imp_TranslateMessage(&msg);
        __imp_DispatchMessageA(&msg);
    }

    __imp_ExitProcess(0);
}
#endif
"""


def generate_embedded_webgl_cpp() -> str:
    html_path = ROOT / "KageAna_Langsung_Main_PC.html"
    raw = html_path.read_bytes() if html_path.exists() else b"<html><body>KageAna 3D</body></html>"
    hex_str = ", ".join(f"0x{b:02x}" for b in raw)
    return (
        f"extern const unsigned char kEmbeddedWebGlHtml[] = {{ {hex_str}, 0x00 }};\n"
        f"extern const uint32_t kEmbeddedWebGlHtmlLen = {len(raw)}U;\n"
    )

def align_up(v: int, a: int) -> int:
    return (v + a - 1) & ~(a - 1)

def build_standalone_pe32plus_exe(out_exe_path: pathlib.Path):
    sim_cpp = build_translated_simulation_cpp()
    webgl_cpp = generate_embedded_webgl_cpp()
    full_win64_cpp = sim_cpp + "\n\n" + webgl_cpp + "\n\n" + WIN32_SANDBOX_GUI_CPP

    work_dir = ROOT.parent / "kageana_pe_build"
    work_dir.mkdir(parents=True, exist_ok=True)

    cpp_path = work_dir / "kageana_win64.cpp"
    o_path   = work_dir / "kageana_win64.o"
    s_path   = work_dir / "pe_idata.S"
    so_path  = work_dir / "pe_idata.o"
    ld_path  = work_dir / "pe_link.ld"
    elf_path = work_dir / "kageana_win64.elf"

    cpp_path.write_text(full_win64_cpp, encoding="utf-8")
    s_path.write_text(generate_idata_asm(), encoding="utf-8")

    ld_script = '''ENTRY(WinMainCRTStartup)
SECTIONS
{
    . = 0x00401000;
    .text ALIGN(0x1000) : {
        *(.text.startup)
        *(.text*)
        *(.rodata*)
        *(.data*)
        . = ALIGN(16);
        *(.bss*)
        *(COMMON)
        . = ALIGN(16);
        BYTE(0);
    }
    .idata ALIGN(0x1000) : {
        *(.idata*)
    }
    /DISCARD/ : {
        *(.note*)
        *(.comment*)
        *(.eh_frame*)
    }
}
'''
    ld_path.write_text(ld_script, encoding="utf-8")

    subprocess.run([
        "g++", "-std=c++20", "-O2", "-DKAGEANA_WIN64",
        "-m64", "-mabi=ms", "-mno-red-zone", "-mno-stack-arg-probe",
        "-fno-tree-loop-distribute-patterns",
        "-fno-exceptions", "-fno-rtti", "-fno-threadsafe-statics",
        "-fno-stack-protector", "-fno-pic", "-fno-pie",
        "-fno-asynchronous-unwind-tables", "-fno-unwind-tables",
        "-c", str(cpp_path), "-o", str(o_path)
    ], check=True)

    subprocess.run(["as", "--64", str(s_path), "-o", str(so_path)], check=True)
    subprocess.run(["ld", "-m", "elf_x86_64", "-T", str(ld_path), str(o_path), str(so_path), "-o", str(elf_path)], check=True)

    sec_text_bin  = work_dir / "sec_text.bin"
    sec_idata_bin = work_dir / "sec_idata.bin"
    subprocess.run(["objcopy", "-O", "binary", "--only-section=.text", str(elf_path), str(sec_text_bin)], check=True)
    subprocess.run(["objcopy", "-O", "binary", "--only-section=.idata", str(elf_path), str(sec_idata_bin)], check=True)

    # Read symbol table from elf_path via nm to get exact __idata_desc_end, __iat_start, __iat_end
    nm_out = subprocess.check_output(["nm", str(elf_path)], text=True)
    sym_map = {}
    for line in nm_out.splitlines():
        parts = line.split()
        if len(parts) == 3:
            sym_map[parts[2]] = int(parts[0], 16)

    text_raw  = sec_text_bin.read_bytes()
    idata_raw = sec_idata_bin.read_bytes()

    IMAGE_BASE = 0x00400000
    SEC_ALIGN  = 0x1000
    FILE_ALIGN = 0x200

    text_rva   = 0x1000
    text_vsize = len(text_raw)
    text_fsize = align_up(text_vsize, FILE_ALIGN)
    text_padded = text_raw + b"\x00" * (text_fsize - text_vsize)

    idata_rva   = sym_map["__idata_start"] - IMAGE_BASE
    idata_vsize = len(idata_raw)
    idata_fsize = align_up(idata_vsize, FILE_ALIGN)
    idata_padded = idata_raw + b"\x00" * (idata_fsize - idata_vsize)

    iat_rva  = sym_map["__iat_start"] - IMAGE_BASE
    iat_size = sym_map["__iat_end"] - sym_map["__iat_start"]
    desc_size = sym_map["__idata_desc_end"] - sym_map["__idata_start"]

    headers_fsize = 0x200
    text_foff  = headers_fsize
    idata_foff = text_foff + text_fsize
    size_of_image = idata_rva + align_up(max(1, idata_vsize), SEC_ALIGN)

    dos_hdr = bytearray(0x80)
    dos_hdr[0:2] = b"MZ"
    struct.pack_into("<I", dos_hdr, 0x3C, 0x80)

    pe_sig = b"PE\x00\x00"
    coff_hdr = struct.pack(
        "<HHIIIHH",
        0x8664,         # Machine: AMD64
        2,              # NumberOfSections
        0x67180000,     # TimeDateStamp
        0, 0,
        240,            # SizeOfOptionalHeader (PE32+)
        0x0022          # EXECUTABLE_IMAGE | LARGE_ADDRESS_AWARE
    )

    opt_hdr = bytearray(240)
    struct.pack_into(
        "<HBBIIIIIQIIHHHHHHIIIIHHQQQQII",
        opt_hdr, 0,
        0x020B,         # Magic: PE32+
        14, 0,
        text_fsize,     # SizeOfCode
        idata_fsize,    # SizeOfInitializedData
        0,              # SizeOfUninitializedData
        text_rva,       # AddressOfEntryPoint (RVA = 0x1000)
        text_rva,       # BaseOfCode
        IMAGE_BASE,     # ImageBase = 0x00400000
        SEC_ALIGN,
        FILE_ALIGN,
        6, 0,
        0, 0,
        6, 0,
        0,
        size_of_image,
        headers_fsize,
        0,
        2,              # Subsystem: IMAGE_SUBSYSTEM_WINDOWS_GUI (2)
        0x0000,
        0x400000,       # SizeOfStackReserve (4MB)
        0x100000,       # SizeOfStackCommit  (1MB pre-committed!)
        0x2000000,      # SizeOfHeapReserve  (32MB)
        0x100000,       # SizeOfHeapCommit   (1MB)
        0,
        16
    )

    # DataDirectory[1]: Import Directory Table
    struct.pack_into("<II", opt_hdr, 112 + 1 * 8, idata_rva, desc_size)
    # DataDirectory[12]: Import Address Table (IAT)
    struct.pack_into("<II", opt_hdr, 112 + 12 * 8, iat_rva, iat_size)

    sec_text_hdr = struct.pack(
        "<8sIIIIIIHHI",
        b".text\x00\x00\x00",
        text_vsize,
        text_rva,
        text_fsize,
        text_foff,
        0, 0, 0, 0,
        0xE0000060      # CNT_CODE | CNT_INITIALIZED_DATA | MEM_EXECUTE | MEM_READ | MEM_WRITE
    )

    sec_idata_hdr = struct.pack(
        "<8sIIIIIIHHI",
        b".idata\x00\x00",
        idata_vsize,
        idata_rva,
        idata_fsize,
        idata_foff,
        0, 0, 0, 0,
        0xC0000040      # CNT_INITIALIZED_DATA | MEM_READ | MEM_WRITE
    )

    hdr_raw = dos_hdr + pe_sig + coff_hdr + opt_hdr + sec_text_hdr + sec_idata_hdr
    hdr_padded = hdr_raw + b"\x00" * (headers_fsize - len(hdr_raw))

    out_exe_path.parent.mkdir(parents=True, exist_ok=True)
    out_exe_path.write_bytes(hdr_padded + text_padded + idata_padded)
    print(f"Built standalone Win64 PE32+ executable: {out_exe_path} ({out_exe_path.stat().st_size:,} bytes)")
    print(f"  .text  RVA=0x{text_rva:06x} VSize=0x{text_vsize:06x} FSize=0x{text_fsize:06x}")
    print(f"  .idata RVA=0x{idata_rva:06x} VSize=0x{idata_vsize:06x} FSize=0x{idata_fsize:06x}")
    print(f"  IAT    RVA=0x{iat_rva:06x} Size=0x{iat_size:04x}")

if __name__ == "__main__":
    out_target = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else (ROOT / "Keluaran" / "KageAna_Mandiri_Langsung_Jalan.exe")
    build_standalone_pe32plus_exe(out_target)
