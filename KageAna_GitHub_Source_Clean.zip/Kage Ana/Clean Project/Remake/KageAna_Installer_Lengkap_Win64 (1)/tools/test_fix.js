#!/usr/bin/env node
/**
 * tools/test_fix.js — Delegates to tools/test_handedness.py so all 4 handedness checks
 * execute the REAL game code in headless Chromium WebGL (no copied formulas).
 */
const { spawnSync } = require('child_process');
const path = require('path');

const scriptPath = path.join(__dirname, 'test_handedness.py');
const res = spawnSync('python3', [scriptPath], { stdio: 'inherit' });
process.exit(res.status !== null ? res.status : 1);
