#!/usr/bin/env python3
"""
KAGE-ANA v3.0 — Unified Continuous Integration Runner (Section 11.2 #10 & Section 12)
Executes:
  1. Frozen Lab Check: Verifies webgl_vertical_slice/ has 0 modifications relative to v2.0.1 baseline.
  2. Red-Flag Audit (Section 12.5): Scans v3.0 docs & Runtime/Sim for forbidden marketing terms,
     GameObject.Find in Sim, or unseeded UnityEngine.Random in Sim.
  3. Data & Schema Validation: tools/validate_data.py
  4. Handedness Regression Suite (4/4 checks): tools/test_handedness.py
  5. Deterministic C# Headless Simulation & Unit Tests (28 days, seed=7): tools/run_headless_sim.py
"""

import argparse
import os
import re
import sys
import subprocess

sys.stdout.reconfigure(line_buffering=True)

DEFAULT_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def check_frozen_webgl_lab(repo_root: str) -> bool:
    res = subprocess.run(
        ["git", "status", "--porcelain", "webgl_vertical_slice/"],
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=True,
    )
    if res.stdout.strip():
        print("[red_flags] FAILED: webgl_vertical_slice/ was modified (must remain frozen):")
        print(res.stdout)
        return False
    print("[frozen_lab] PASS: webgl_vertical_slice/ has 0 modifications relative to v2.0.1 baseline.")
    return True


def check_red_flags(repo_root: str) -> bool:
    banned_words = [
        re.compile(r"\bAAA\b"),
        re.compile(r"\bauthentic\b", re.IGNORECASE),
        re.compile(r"\bphotorealistic\b", re.IGNORECASE),
    ]
    v3_docs = [
        "AGENTS.md",
        "CLAUDE.md",
        "DECISIONS.md",
        "IDEAS.md",
        "ART_BIBLE.md",
        "ARCHITECTURE.md",
        "ASSETS_LICENSE.md",
    ]
    issues = []

    for doc in v3_docs:
        p = os.path.join(repo_root, doc)
        if not os.path.exists(p):
            issues.append(f"Missing required governance doc: {doc}")
            continue
        text = open(p, "r", encoding="utf-8").read()
        for pat in banned_words:
            if pat.search(text):
                issues.append(f"{doc}: contains prohibited red-flag word matching '{pat.pattern}'")

    sim_dir = os.path.join(repo_root, "unity_project", "Assets", "_Project", "Runtime", "Sim")
    for root, _dirs, files in os.walk(sim_dir):
        for fname in files:
            if not fname.endswith(".cs"):
                continue
            fpath = os.path.join(root, fname)
            rel = os.path.relpath(fpath, repo_root)
            code = open(fpath, "r", encoding="utf-8").read()
            if "GameObject.Find" in code or "UnityEngine.Random" in code or "MonoBehaviour" in code:
                issues.append(f"{rel}: Runtime/Sim must not use MonoBehaviour, GameObject.Find, or UnityEngine.Random")

    if issues:
        print("[red_flags] FAILED:")
        for i in issues:
            print("  -", i)
        return False

    print("[red_flags] PASS: 0 prohibited buzzwords in v3 docs; 0 forbidden Unity/RNG calls in Runtime/Sim.")
    return True


def run_step(title: str, cmd: list, cwd: str) -> bool:
    print(f"\n=== {title} ===")
    res = subprocess.run(cmd, cwd=cwd)
    return res.returncode == 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=DEFAULT_REPO_ROOT)
    parser.add_argument("--check-red-flags-only", action="store_true")
    args = parser.parse_args()

    repo_root = os.path.abspath(args.repo_root)

    if args.check_red_flags_only:
        return 0 if check_red_flags(repo_root) else 1

    print("==================================================================")
    print("  KAGE-ANA v3.0 — CI PIPELINE (Tasks L0.1 & L1)")
    print("==================================================================")

    if not check_frozen_webgl_lab(repo_root):
        return 1
    if not check_red_flags(repo_root):
        return 1
    if not run_step(
        "1. Data, Schema & Unity-Safety Validator (tools/validate_data.py)",
        ["python3", "tools/validate_data.py", "--repo-root", repo_root],
        repo_root,
    ):
        return 1
    if not run_step(
        "2. Real Handedness Regression Suite 12.6 (tools/test_handedness.py)",
        ["python3", "tools/test_handedness.py"],
        repo_root,
    ):
        return 1
    if not run_step(
        "3. Pure C# Headless Simulation & Unit Tests (tools/run_headless_sim.py)",
        ["python3", "tools/run_headless_sim.py", "--seed", "7", "--days", "28"],
        repo_root,
    ):
        return 1
    if not run_step(
        "4. Static Installer Linter Butir 9.5 (tools/validate_installer.py)",
        ["python3", "tools/validate_installer.py", "--repo-root", repo_root],
        repo_root,
    ):
        return 1

    print("\n==================================================================")
    print("  CI STATUS: ALL CHECKS GREEN (PASS)")
    print("==================================================================")
    return 0


if __name__ == "__main__":
    sys.exit(main())
