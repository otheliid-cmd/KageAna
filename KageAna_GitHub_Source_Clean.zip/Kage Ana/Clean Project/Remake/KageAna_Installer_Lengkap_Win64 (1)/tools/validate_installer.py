#!/usr/bin/env python3
"""
tools/validate_installer.py — Pemeriksa Statis Installer ("installer-lint", Gelombang D Butir 9.5)

Memeriksa secara statis (JUJUR: tanpa menjalankan ISCC.exe/iexpress.exe Windows di container Linux):
1. Keberadaan berkas `BUAT_INSTALLER.bat`, `installer/KageAna.iss`, `installer/KageAna_IExpress.sed`,
   `installer/pasang.cmd`, `installer/kageana_icon.ico`, `CARA_UJI_COBA.md`, dan `.github/workflows/installer.yml`.
2. Parsing `installer/KageAna.iss` & `installer/KageAna_IExpress.sed`:
   - Semua berkas yang dirujuk di `[Files]` (`.iss`) dan `[SourceFiles0]` (`.sed`) benar-benar ada di `staging/`.
   - Seluruh berkas data JSON kanonis di `unity_project/Assets/_Project/Data/` ada salinannya di `staging/Data/`.
3. Tidak ada jalur absolut milik mesin lain (`C:\\Users\\`, `/home/`, `/working_dir/`, dsb.).
4. Tidak ada kata terlarang (`game`, `playable`, `build final`) pada string pengguna.
5. Konsistensi versi (`MyAppVersion`) dan `MyAppId`: jika versi diubah tanpa memperbarui AppId / sinkronisasi versi csproj,
   pemeriksa mengeluarkan peringatan (`[PERINGATAN]`) dan menolak pada mode ketat CI.
"""

import argparse
import os
import pathlib
import re
import sys

REPO_ROOT = pathlib.Path(__file__).resolve().parent.parent

FORBIDDEN_PATTERNS = [
    (re.compile(r"\bgame\b", re.IGNORECASE), "game"),
    (re.compile(r"\bplayable\b", re.IGNORECASE), "playable"),
    (re.compile(r"\bbuild\s+final\b", re.IGNORECASE), "build final"),
]

ABSOLUTE_PATH_PATTERNS = [
    re.compile(r"[A-Za-z]:\\Users\\", re.IGNORECASE),
    re.compile(r"/home/[A-Za-z0-9_]+"),
    re.compile(r"/working_dir/"),
    re.compile(r"/tmp/"),
]

CANONICAL_APP_VERSION = "0.4.0"
CANONICAL_APP_ID = "{{8F4E2A91-5C3B-4D18-9A72-1E6C8B04F3D2}"


def validate_installer(repo_root: pathlib.Path, fail_on_warning: bool = True) -> tuple[list[str], list[str]]:
    errors: list[str] = []
    warnings: list[str] = []

    required_files = [
        "BUAT_INSTALLER.bat",
        "CARA_UJI_COBA.md",
        "installer/KageAna.iss",
        "installer/KageAna_IExpress.sed",
        "installer/pasang.cmd",
        "installer/kageana_icon.ico",
        ".github/workflows/installer.yml",
    ]
    for rel in required_files:
        p = repo_root / rel
        if not p.exists():
            errors.append(f"installer-lint: missing required file '{rel}'")
        elif p.stat().st_size == 0:
            errors.append(f"installer-lint: file '{rel}' is empty (0 bytes)")

    if errors:
        return errors, warnings

    # 1. Check forbidden terms & machine-specific absolute paths
    text_files_to_check = [
        "BUAT_INSTALLER.bat",
        "CARA_UJI_COBA.md",
        "installer/KageAna.iss",
        "installer/KageAna_IExpress.sed",
        "installer/pasang.cmd",
    ]
    for rel in text_files_to_check:
        txt = (repo_root / rel).read_text(encoding="utf-8")
        for pat, label in FORBIDDEN_PATTERNS:
            if pat.search(txt):
                errors.append(f"installer-lint: '{rel}' contains prohibited word '{label}'")
        for apat in ABSOLUTE_PATH_PATTERNS:
            if apat.search(txt):
                errors.append(f"installer-lint: '{rel}' contains machine-specific absolute path matching '{apat.pattern}'")

    # 2. Check staging/ directory & canonical JSON data parity
    staging_dir = repo_root / "staging"
    data_src_dir = repo_root / "unity_project" / "Assets" / "_Project" / "Data"
    staging_data_dir = staging_dir / "Data"

    if not staging_dir.exists():
        errors.append("installer-lint: missing 'staging/' directory")
    elif not staging_data_dir.exists():
        errors.append("installer-lint: missing 'staging/Data/' directory")
    else:
        for src_json in sorted(data_src_dir.rglob("*.json")):
            rel_json = src_json.relative_to(data_src_dir)
            staged_json = staging_data_dir / rel_json
            if not staged_json.exists():
                errors.append(
                    f"installer-lint: canonical data file 'Data/{rel_json.as_posix()}' is missing from 'staging/Data/'"
                )
            elif staged_json.stat().st_size == 0:
                errors.append(
                    f"installer-lint: staged data file 'staging/Data/{rel_json.as_posix()}' is empty (0 bytes)"
                )

    # 3. Parse installer/KageAna.iss
    iss_path = repo_root / "installer" / "KageAna.iss"
    iss_txt = iss_path.read_text(encoding="utf-8")

    for req_token in (
        "PrivilegesRequired=lowest",
        "DefaultDirName={localappdata}\\Programs\\KageAna",
        "UsePreviousAppDir=yes",
        "Flags: postinstall nowait skipifsilent",
        "Check: WizardSilent",
    ):
        if req_token not in iss_txt:
            errors.append(f"installer-lint: installer/KageAna.iss missing required setting '{req_token}'")

    ver_m = re.search(r'^#define\s+MyAppVersion\s+"([^"]+)"', iss_txt, re.MULTILINE)
    id_m = re.search(r'^#define\s+MyAppId\s+"([^"]+)"', iss_txt, re.MULTILINE)
    if not ver_m or not id_m:
        errors.append("installer-lint: installer/KageAna.iss must define both MyAppVersion and MyAppId")
    else:
        iss_ver = ver_m.group(1)
        iss_id = id_m.group(1)
        if iss_ver != CANONICAL_APP_VERSION and iss_id == CANONICAL_APP_ID:
            warnings.append(
                f"installer-lint [PERINGATAN]: MyAppVersion di KageAna.iss diubah menjadi '{iss_ver}' "
                f"(dari '{CANONICAL_APP_VERSION}') tanpa mengubah AppId '{iss_id}' atau memperbarui csproj!"
            )

    for src_m in re.finditer(r'^\s*Source:\s*"([^"]+)"', iss_txt, re.MULTILINE):
        raw_src = src_m.group(1).replace("\\", "/")
        if raw_src.endswith("/*"):
            dir_rel = raw_src[:-2]
            resolved_dir = (iss_path.parent / dir_rel).resolve()
            if not resolved_dir.exists() or not any(resolved_dir.iterdir()):
                errors.append(f"installer-lint: KageAna.iss Source wildcard '{raw_src}' does not resolve to non-empty staging folder")
        else:
            resolved_file = (iss_path.parent / raw_src).resolve()
            if not resolved_file.exists():
                errors.append(f"installer-lint: KageAna.iss Source file '{raw_src}' not found in staging/")
            elif resolved_file.stat().st_size == 0:
                errors.append(f"installer-lint: KageAna.iss Source file '{raw_src}' is 0 bytes")

    # 4. Parse installer/KageAna_IExpress.sed
    sed_path = repo_root / "installer" / "KageAna_IExpress.sed"
    sed_txt = sed_path.read_text(encoding="utf-8")
    for file_m in re.finditer(r'^FILE\d+="([^"]+)"', sed_txt, re.MULTILINE):
        fname = file_m.group(1)
        staged_f = staging_dir / fname
        if not staged_f.exists():
            errors.append(f"installer-lint: KageAna_IExpress.sed references missing staging file '{fname}'")

    # 5. Check BUAT_INSTALLER.bat required steps
    bat_txt = (repo_root / "BUAT_INSTALLER.bat").read_text(encoding="utf-8")
    for step_idx in range(1, 7):
        token = f"LANGKAH {step_idx}/6:"
        if token not in bat_txt:
            errors.append(f"installer-lint: BUAT_INSTALLER.bat missing step marker '{token}'")
    for req_bat in ("--selftest", "PublishSingleFile=true", "ISCC.exe", "iexpress.exe", "Compress-Archive", "HASIL_BANGUN.txt"):
        if req_bat not in bat_txt:
            errors.append(f"installer-lint: BUAT_INSTALLER.bat missing required token '{req_bat}'")

    # 6. Check .github/workflows/installer.yml honesty marker
    wf_txt = (repo_root / ".github" / "workflows" / "installer.yml").read_text(encoding="utf-8")
    if "BELUM PERNAH DIJALANKAN" not in wf_txt:
        errors.append("installer-lint: .github/workflows/installer.yml must be explicitly marked 'BELUM PERNAH DIJALANKAN'")

    if fail_on_warning and warnings:
        errors.extend(warnings)

    return errors, warnings


def main() -> int:
    parser = argparse.ArgumentParser(description="KAGE-ANA Static Installer Linter (Butir 9.5)")
    parser.add_argument("--repo-root", default=str(REPO_ROOT))
    parser.add_argument("--allow-warnings", action="store_true")
    args = parser.parse_args()

    root = pathlib.Path(args.repo_root).resolve()
    errors, warnings = validate_installer(root, fail_on_warning=not args.allow_warnings)

    for w in warnings:
        print(f"  [WARN] {w}")
    if errors:
        print(f"[FAIL] installer-lint failed with {len(errors)} error(s):", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
        return 1

    print("[PASS] installer-lint: KageAna.iss, KageAna_IExpress.sed, BUAT_INSTALLER.bat, CARA_UJI_COBA.md, and staging/ verified.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
