#!/usr/bin/env python3
"""
E5.3 Procedural Audio Placeholder Generator (NumPy).
Generates Karplus-Strong plucked strings (koto/biwa kasar), wind/water noise,
low taiko drum pulse, and footsteps per surface (Tanah, Kayu, Jerami, Tatami, Batu).
All outputs are strictly labeled PLACEHOLDER in filenames and AUDIO_MANIFEST.csv.
"""
import csv
import pathlib
import wave
import numpy as np

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / "unity_project" / "Assets" / "_Project" / "Art" / "AudioPlaceholders"
SR = 22050


def save_wav(path: pathlib.Path, samples: np.ndarray):
    path.parent.mkdir(parents=True, exist_ok=True)
    peak = np.max(np.abs(samples))
    if peak > 1e-6:
        samples = samples / peak * 0.75
    pcm16 = np.clip(samples * 32767.0, -32768, 32767).astype(np.int16)
    with wave.open(str(path), "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(SR)
        wf.writeframes(pcm16.tobytes())


def karplus_strong(freq: float, duration_sec: float, decay: float = 0.994, seed: int = 7) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n_samples = int(SR * duration_sec)
    n_delay = max(2, int(SR / freq))
    buf = rng.uniform(-1.0, 1.0, n_delay).astype(np.float64)
    out = np.zeros(n_samples, dtype=np.float64)
    for i in range(n_samples):
        out[i] = buf[i % n_delay]
        avg = 0.5 * (buf[i % n_delay] + buf[(i + 1) % n_delay]) * decay
        buf[i % n_delay] = avg
    return out


def generate_all():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(7)

    # 1. Koto/Biwa plucked pentatonic phrase (In-sen D-Eb-G-A-C)
    freqs = [146.83, 155.56, 196.00, 220.00, 155.56]
    koto = np.concatenate([karplus_strong(f, 0.45, 0.995, seed=10 + i) for i, f in enumerate(freqs)])
    save_wav(OUT_DIR / "PLACEHOLDER_BGM_KotoBiwa_Siang.wav", koto)

    # 2. Shakuhachi/Drone night breath + sparse pulse
    t = np.linspace(0, 2.0, int(SR * 2.0), endpoint=False)
    breath = rng.normal(0, 0.08, len(t))
    drone = 0.45 * np.sin(2 * np.pi * 146.83 * t) + 0.20 * np.sin(2 * np.pi * 220.0 * t) + breath
    env = np.sin(np.pi * t / 2.0)
    save_wav(OUT_DIR / "PLACEHOLDER_BGM_ShakuhachiDrone_Malam.wav", drone * env)

    # 3. Low Taiko distant pulse
    t_drum = np.linspace(0, 0.8, int(SR * 0.8), endpoint=False)
    f_sweep = 92.0 * np.exp(-t_drum * 5.5) + 42.0
    taiko = np.sin(2 * np.pi * f_sweep * t_drum) * np.exp(-t_drum * 6.0)
    save_wav(OUT_DIR / "PLACEHOLDER_SFX_TaikoDenyutJauh.wav", taiko)

    # 4. Wind & Rain Ambience
    t_amb = np.linspace(0, 1.5, int(SR * 1.5), endpoint=False)
    white = rng.normal(0, 0.3, len(t_amb))
    # Simple moving average low-pass for wind/water
    kernel = np.ones(16) / 16.0
    wind = np.convolve(white, kernel, mode="same")
    save_wav(OUT_DIR / "PLACEHOLDER_AMB_AnginDanHujan.wav", wind)

    # 5. Footsteps per 5 surfaces: Tanah, Kayu, Jerami, Tatami, Batu
    surfaces = [
        ("Tanah", 180.0, 28.0, 0.15),
        ("Kayu", 310.0, 35.0, 0.08),
        ("Jerami", 520.0, 22.0, 0.35),
        ("Tatami", 240.0, 30.0, 0.18),
        ("Batu", 680.0, 45.0, 0.10),
    ]
    for name, freq, damp, noise_mix in surfaces:
        ts = np.linspace(0, 0.22, int(SR * 0.22), endpoint=False)
        thump = np.sin(2 * np.pi * freq * np.exp(-ts * 12.0) * ts) * np.exp(-ts * damp)
        grit = rng.normal(0, noise_mix, len(ts)) * np.exp(-ts * (damp * 0.8))
        save_wav(OUT_DIR / f"PLACEHOLDER_SFX_Langkah_{name}.wav", thump + grit)


if __name__ == "__main__":
    generate_all()
    print("[generate_placeholder_audio] Generated 9 PLACEHOLDER WAV files.")
