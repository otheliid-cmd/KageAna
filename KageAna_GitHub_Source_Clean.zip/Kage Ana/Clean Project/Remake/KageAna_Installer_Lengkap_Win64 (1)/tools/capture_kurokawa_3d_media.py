#!/usr/bin/env python3
"""
Verifies KageAna_Dunia_Lembah_Kurokawa_3D.html in headless Chromium with True WebGL 2.0 Shaders
(--enable-unsafe-swiftshader), captures 10 HD Player-POV Gameplay Screenshots across the expanded
16-location Lembah Kurokawa world, and records a 10.0-second MP4 gameplay video.
"""
import time
import subprocess
from pathlib import Path
from selenium import webdriver
from selenium.webdriver.chrome.options import Options

OUT_DIR = Path("/working_dir/c_66e5364d2f871b20/artifacts/file_generation/ttl=63d/output")
HTML_PATH = OUT_DIR / "KageAna_Dunia_Lembah_Kurokawa_3D.html"
FRAMES_DIR = Path("/tmp/kurokawa_3d_frames")


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    FRAMES_DIR.mkdir(parents=True, exist_ok=True)
    for f in FRAMES_DIR.glob("*.png"):
        f.unlink()

    opts = Options()
    opts.binary_location = "/usr/bin/chromium"
    opts.add_argument("--headless=new")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=1280,720")
    opts.add_argument("--use-gl=angle")
    opts.add_argument("--use-angle=swiftshader")
    opts.add_argument("--enable-unsafe-swiftshader")
    opts.add_argument("--enable-webgl")
    opts.add_argument("--ignore-gpu-blocklist")
    opts.add_argument("--hide-scrollbars")
    opts.set_capability("goog:loggingPrefs", {"browser": "ALL"})

    driver = webdriver.Chrome(options=opts)
    try:
        driver.execute_cdp_cmd("Emulation.setDeviceMetricsOverride", {
            "width": 1280, "height": 720, "deviceScaleFactor": 1, "mobile": False
        })
        driver.get("about:blank")
        tree = driver.execute_cdp_cmd("Page.getFrameTree", {})
        fid = tree["frameTree"]["frame"]["id"]
        html = HTML_PATH.read_text(encoding="utf-8")
        driver.execute_cdp_cmd("Page.setDocumentContent", {"frameId": fid, "html": html})
        time.sleep(0.4)
        driver.execute_script("window.dispatchEvent(new Event('resize'));")

        shots = [
            (
                "Kurokawa_01_Panorama_Lembah_12_Distrik.png",
                "window.KAGE_WORLD.setScenePose({ day:1, hour:9.5, garbMode:'OMOTE', carrierIdx:0, viewMode:'THIRD_PERSON', listenMode:0, placeId:'place_taman_sakura', offsetX:-5, offsetZ:-7, yaw:0.38, pitch:0.22, camDist:7.2, walkCycle:0.8, bringCustomerFront:true });"
            ),
            (
                "Kurokawa_02_Siang_Pedagang_Omote_Pasar_Za.png",
                "window.KAGE_WORLD.selectWare(1); window.KAGE_WORLD.setScenePose({ day:1, hour:11.0, garbMode:'OMOTE', carrierIdx:1, viewMode:'THIRD_PERSON', listenMode:0, placeId:'place_kediaman_warga', offsetX:-2, offsetZ:-8, yaw:0.22, pitch:0.18, camDist:7.4, walkCycle:1.6, bringCustomerFront:true }); window.KAGE_WORLD.askCustomerOption(2);"
            ),
            (
                "Kurokawa_03_Menguping_Bisikan_Kedai_Teh_Okiku.png",
                "window.KAGE_WORLD.selectWare(5); window.KAGE_WORLD.setScenePose({ day:1, hour:15.5, garbMode:'OMOTE', carrierIdx:2, viewMode:'THIRD_PERSON', listenMode:0, placeId:'place_pemandian_onsen', offsetX:2, offsetZ:-9, yaw:-0.18, pitch:0.20, camDist:8.2, walkCycle:2.4, bringCustomerFront:true }); window.KAGE_WORLD.askCustomerOption(3);"
            ),
            (
                "Kurokawa_04_Nagaya_OHana_Dan_Apotek_Soan.png",
                "window.KAGE_WORLD.selectWare(0); window.KAGE_WORLD.setScenePose({ day:2, hour:10.2, garbMode:'OMOTE', carrierIdx:0, viewMode:'FIRST_PERSON', listenMode:0, placeId:'place_kebun_teh_air_terjun', offsetX:0, offsetZ:-8, yaw:0.08, pitch:0.12, walkCycle:1.1, bringCustomerFront:true });"
            ),
            (
                "Kurokawa_05_Papan_Tinta_Verifikasi_Silang_Kabar.png",
                "window.KAGE_WORLD.setScenePose({ day:2, hour:13.0, garbMode:'OMOTE', carrierIdx:0, viewMode:'THIRD_PERSON', listenMode:0, placeId:'place_taman_sakura', drawer:'map' });"
            ),
            (
                "Kurokawa_06_Intervensi_Salah_Paham_Warga.png",
                "window.KAGE_WORLD.setScenePose({ day:2, hour:14.5, garbMode:'OMOTE', carrierIdx:0, viewMode:'THIRD_PERSON', listenMode:0, placeId:'place_kediaman_warga', drawer:'wares' });"
            ),
            (
                "Kurokawa_07_Malam_Mata_Mata_Ura_Dermaga_Garam.png",
                "window.KAGE_WORLD.closeDrawers(); window.KAGE_WORLD.setScenePose({ day:2, hour:17.2, garbMode:'OMOTE', carrierIdx:3, viewMode:'THIRD_PERSON', listenMode:0, placeId:'place_titik_serah_hutan', offsetX:-2, offsetZ:-10, yaw:0.15, pitch:0.18, camDist:8.0, bringSabuFront:true });"
            ),
            (
                "Kurokawa_08_Mata_Telinga_Balai_Juru_Tulis_Gensai.png",
                "window.KAGE_WORLD.setScenePose({ day:2, hour:21.5, garbMode:'URA', nightCamoIdx:0, viewMode:'THIRD_PERSON', listenMode:0, placeId:'place_dermaga', offsetX:4, offsetZ:-5, yaw:0.30, pitch:0.18, camDist:7.8, walkCycle:1.4 });"
            ),
            (
                "Kurokawa_09_Jembatan_Batu_Kuil_Jikai_Dan_Kediaman_Samurai.png",
                "window.KAGE_WORLD.setScenePose({ day:2, hour:22.8, garbMode:'URA', nightCamoIdx:1, viewMode:'THIRD_PERSON', listenMode:1, placeId:'place_benteng_juru_tulis', offsetX:0, offsetZ:-6, yaw:0.0, pitch:0.20, camDist:8.4 });"
            ),
            (
                "Kurokawa_10_Titik_Serah_Pohon_Aras_Sabu_Dan_Nisshi.png",
                "window.KAGE_WORLD.setScenePose({ day:3, hour:23.2, garbMode:'URA', nightCamoIdx:2, viewMode:'THIRD_PERSON', listenMode:0, placeId:'place_titik_serah_hutan', drawer:'orders' });"
            ),
        ]

        for fname, js_cmd in shots:
            driver.execute_script(js_cmd)
            out_p = OUT_DIR / fname
            driver.save_screenshot(str(out_p))
            print(f"Saved screenshot: {out_p.name} ({out_p.stat().st_size:,} bytes)")

        print("Recording 80 keyframes (10.0s gameplay journey) across the 16-location Lembah Kurokawa...")
        driver.execute_script("window.KAGE_WORLD.closeDrawers();")
        total_frames = 80
        for fidx in range(total_frames):
            if fidx < 22:
                # Scene 1: Sōma pushing wooden handcart in Taman Sakura with animated stepping legs & approaching customer
                p = fidx / 22.0
                driver.execute_script(f"""
                  window.KAGE_WORLD.setScenePose({{
                    day: 1, hour: {9.2 + p * 1.5:.2f}, garbMode: 'OMOTE', carrierIdx: 0, viewMode: 'THIRD_PERSON', listenMode: 0,
                    placeId: 'place_taman_sakura', offsetX: {-4.0 + p * 8.0:.2f}, offsetZ: {-14.0 + p * 8.0:.2f},
                    yaw: {0.18 - p * 0.25:.3f}, pitch: 0.20, camDist: 7.8, walkCycle: {fidx * 0.55:.2f},
                    bringCustomerFront: {'true' if fidx >= 10 else 'false'}
                  }});
                """)
                if fidx == 14:
                    driver.execute_script("window.KAGE_WORLD.askCustomerOption(1);")
                elif fidx == 18:
                    driver.execute_script("window.KAGE_WORLD.askCustomerOption(3);")
            elif fidx < 42:
                # Scene 2: Sōma carrying Tentengan bundles in Kompleks Kediaman Warga & switching to 1st-Person view
                p = (fidx - 22) / 20.0
                vmode = 'FIRST_PERSON' if (32 <= fidx <= 39) else 'THIRD_PERSON'
                driver.execute_script(f"""
                  window.KAGE_WORLD.setScenePose({{
                    day: 1, hour: {13.5 + p * 2.5:.2f}, garbMode: 'OMOTE', carrierIdx: 1, viewMode: '{vmode}', listenMode: 0,
                    placeId: 'place_kediaman_warga', offsetX: {-5.0 + p * 10.0:.2f}, offsetZ: {-12.0 + p * 9.0:.2f},
                    yaw: {-0.15 + p * 0.30:.3f}, pitch: 0.16, camDist: 7.4, walkCycle: {fidx * 0.6:.2f},
                    bringCustomerFront: {'true' if fidx >= 28 else 'false'}
                  }});
                """)
                if fidx == 30:
                    driver.execute_script("window.KAGE_WORLD.askCustomerOption(2);")
            elif fidx < 56:
                # Scene 3: Sunset meeting with Comrade Sabu at Pohon Aras Tua
                p = (fidx - 42) / 14.0
                driver.execute_script(f"""
                  window.KAGE_WORLD.setScenePose({{
                    day: 1, hour: {17.2 + p * 0.6:.2f}, garbMode: 'OMOTE', carrierIdx: 3, viewMode: 'THIRD_PERSON', listenMode: 0,
                    placeId: 'place_titik_serah_hutan', offsetX: -2.0, offsetZ: {-12.0 + p * 3.0:.2f},
                    yaw: 0.12, pitch: 0.18, camDist: 8.0, walkCycle: {fidx * 0.5:.2f}, bringSabuFront: true
                  }});
                """)
            else:
                # Scene 4: Nighttime infiltration in realistic Indigo/Charcoal camouflage & Mata Telinga
                p = (fidx - 56) / 24.0
                listen = 1 if (66 <= fidx <= 73) else 0
                driver.execute_script(f"""
                  window.KAGE_WORLD.setScenePose({{
                    day: 1, hour: {21.2 + p * 2.0:.2f}, garbMode: 'URA', nightCamoIdx: 0, viewMode: 'THIRD_PERSON', listenMode: {listen},
                    placeId: 'place_benteng_juru_tulis', offsetX: {-4.0 + p * 8.0:.2f}, offsetZ: {-10.0 + p * 12.0:.2f},
                    yaw: {0.20 - p * 0.35:.3f}, pitch: 0.19, camDist: 8.0, walkCycle: {fidx * 0.65:.2f}
                  }});
                """)
                if fidx == 76:
                    driver.execute_script("window.KAGE_WORLD.triggerPrimaryAction();")

            frame_file = FRAMES_DIR / f"frame_{fidx:04d}.png"
            driver.save_screenshot(str(frame_file))

        logs = driver.get_log("browser")
        severe = [l for l in logs if l.get("level") == "SEVERE"]
        print("Browser severe logs:", severe)
        if severe:
            raise RuntimeError(f"Severe browser logs found: {severe}")
    finally:
        driver.quit()

    mp4_path = OUT_DIR / "KageAna_Gameplay_Lembah_Kurokawa_10s.mp4"
    cmd = [
        "ffmpeg", "-y",
        "-framerate", "8",
        "-i", str(FRAMES_DIR / "frame_%04d.png"),
        "-r", "24",
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-crf", "20",
        "-preset", "fast",
        "-movflags", "+faststart",
        str(mp4_path)
    ]
    subprocess.run(cmd, check=True)
    print(f"Saved 10s Gameplay Video: {mp4_path} ({mp4_path.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
