#!/usr/bin/env python3
"""
E6.3 Validator untuk folder incoming_concept/<id>/.
Memeriksa penamaan berkas, ukuran PNG minimal (resolusi >= 512x512), dan rasio aspek.
"""
import os
import pathlib
import struct
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
INCOMING = ROOT / "incoming_concept"


def read_png_dimensions(path: pathlib.Path) -> tuple[int, int]:
    with open(path, "rb") as f:
        header = f.read(24)
    if len(header) < 24 or header[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("Bukan berkas PNG yang sah")
    w, h = struct.unpack(">II", header[16:24])
    return w, h


def main() -> int:
    if not INCOMING.exists():
        print("[validate_concept_art] Folder incoming_concept/ belum ada.")
        return 1
    checked = 0
    errors = []
    for sub in sorted(INCOMING.iterdir()):
        if not sub.is_dir() or sub.name.startswith("."):
            continue
        for png in sorted(sub.glob("*.png")):
            checked += 1
            try:
                w, h = read_png_dimensions(png)
                if w < 512 or h < 512:
                    errors.append(f"{png}: resolusi terlalu kecil ({w}x{h} < 512x512)")
            except Exception as exc:
                errors.append(f"{png}: {exc}")
    if errors:
        for e in errors:
            print("  [GALAT]", e)
        return 1
    print(f"[validate_concept_art] LULUS: {checked} berkas gambar konsep diperiksa (0 galat).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
