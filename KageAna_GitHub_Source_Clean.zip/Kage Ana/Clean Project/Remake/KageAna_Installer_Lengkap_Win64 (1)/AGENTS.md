# AGENTS.md — Master Instructions v3.0 for KAGE-ANA (影穴)

> **Version:** 3.0 (Synchronized with `KageAna_Kitab_Dunia_dan_Instruksi_Maha_Lengkap.md`)
> **Authority Hierarchy:**
> 1. Direct user instructions in the active session (if conflicting with Section 1 rules, point out the conflict and ask).
> 2. Section 1 Rules of the World Book (*Kitab Dunia*) summarized below.
> 3. Sections 2–9 (World Canon, Systems, Content) and Section 10 (Art Standard).
> 4. Sections 11–13 (Architecture, Verification, Open Decisions) and Section 14 (Roadmap & Gates).
> 5. Companion docs (`DECISIONS.md`, `IDEAS.md`, `ART_BIBLE.md`, `ARCHITECTURE.md`, `ASSETS_LICENSE.md`).

---

## 1. Core Soul of the Game (Non-Negotiable)

**KAGE-ANA is not a stage-clearing game; it is a simulation of living the double life of an ordinary villager who happens to be the last shinobi of Ryū Kage-Ana in Kurokawa Valley.**
- **By Day (*Omote* / 表):** The player is a known neighbor in Nagaya and East Market with a rented room at Ohana's house, a cover job, weekly rent, social etiquette, habits, and relationships with 26 named villagers.
- **By Night (*Ura* / 裏):** The player slips through rooftops, understage tunnels, and shadow pools (*kage-ana*) to carry out covert gigs, gather secrets, or strike targets without being identified.
- **Core Tension:** All meaning, tension, and dry humor arise at the **seam between the two lives** (a night wound smelled by Physician Sōan the next morning, unexplainable wealth raising social suspicion, distorted rumors spreading through the teahouse).
- **Emergent, Not Story-Driven:** Stories emerge from schedules, perception, memories, beliefs, and the rumor graph across a 28-day (4-season) year, closing each year with a factual **Nisshi** diary scroll rather than a mission-complete rank screen.

### The Three "Living World Test" Questions (*Uji Hidup*)
Every task must answer these three questions in writing:
1. **Inhabited World (*Dunia dihuni*)?** Does this make the world feel inhabited by people with lives, schedules, and memories?
2. **Unexpected Stories (*Kisah tak terduga*)?** Does this increase the likelihood of unscripted emergent anecdotes?
3. **Seam of Two Faces (*Sambungan dua wajah*)?** Does this strengthen the tension between daytime (*Omote*) and nighttime (*Ura*) life?
If all three are "No", propose deferring the task; do not build it.

---

## 2. Mandatory Working Rules (Section 1.3)

1. **Systems First, Art Later:** Before **Gate 1 (Anecdote Test / *Uji Anekdot*)** passes, polishing visuals, adding decorative effects, or building final art assets is forbidden. Greybox/capsules are valid. After Gate 1 passes, Section 10 Art Standards are mandatory and non-regressive.
2. **Simulation Separated from View:** World logic in `unity_project/Assets/_Project/Runtime/Sim/` must be pure C# with zero dependency on `UnityEngine.GameObject` or rendering, and must run headlessly with a fixed deterministic seed (`SimRandom(seed, stream)`).
3. **All Content is Data-Driven:** No literal content (names, schedules, prices, dialogue) in C# code. All content lives in `unity_project/Assets/_Project/Data/` and is validated by `tools/validate_data.py`.
4. **No Mission-Complete / Rank Screen:** Closure is the year-end *Nisshi* scroll (Section 8.10). There is no single win condition.
5. **Violence Has a Price:** Every violent act leaves systemic traces (witnesses, bloodstains, scent, corpses, rumors, Heart shifting toward Cold, social ripples).
6. **Routines Must Be Short, Meaningful, and Skippable:** Every routine yields at least one of: information, access, relationship, or surprise.
7. **Radical Engineering Honesty:** Never use unverified marketing superlatives or claim unverified completion. Code comments explain what the code does. Every report states what is **not** yet finished or what failed.
8. **Single Production Codebase (Unity 6 + URP):** `webgl_vertical_slice/` is a **frozen look-dev laboratory (`LAB_`)** preserved as a visual reference. Do not duplicate gameplay logic across WebGL and Unity. Derivative bundles (`data_bundle.js`, `KageAna_Langsung_Main_PC.html`) are script-generated, never hand-edited.
9. **Mandatory Evidence:**
   - System tasks end with a deterministic **headless simulation report** (`SIM REPORT`, seed, N days, event counts, `violations: 0`).
   - Visual tasks end with screenshots/clips from a running build.
   - Frame-rate numbers from software rasterizers (e.g., headless SwiftShader) must always be labeled `"software, bukan kinerja nyata"`.
10. **Clean & Recorded Assets:** All assets must be logged in `ASSETS_LICENSE.md` before use. Procedural placeholders must carry the `TEMP_` prefix.
11. **Coordinate & Handedness Convention (Mandatory):**
    - Left-handed world space: `+X` = screen-right, `+Y` = up, `+Z` = forward when `yaw = 0`.
    - `forward = (sin yaw, cos yaw)`, `right = (cos yaw, -sin yaw)`.
    - Mouse right (`movementX > 0`) increases `yaw` (turns right); mouse up (`movementY < 0`) increases `pitch` (looks up, unless inverted).
    - In the frozen WebGL lab, `Mat4.lookAt` is right-handed so projection `projMat[0]` is negated and main-pass front faces use `gl.CW` (v2.0.1 fix). Never alter camera/projection handedness without running the 4 automated handedness tests (`tools/test_handedness.py`, Section 12.6).
12. **Small Branches, Clear Commits:** One task per branch (`L0 -> L1 -> ...`). Never delete user files without permission.
13. **Ask Before Major Decisions:** Open decisions (Section 13: D1–D10) use the recommended defaults marked `"Proposed / Diusulkan"` in `DECISIONS.md` until confirmed by the user.
14. **Language Policy:** Communicate with the user in **Bahasa Indonesia**. Write all code, identifiers, comments, and filenames in **English**. Keep cultural terms in Japanese per the Glossary (Section 1.6).
15. **Strict Phase Discipline:** Do not build features outside the active task (`L0 -> L1 -> ...`). Record extra ideas in `IDEAS.md`.

---

## 3. Sequential Phases, Gates, and Task Order (Section 14)

| Phase | Tasks | Deliverable | Gate |
|---|---|---|---|
| **F0 Sync** | **L0** | Repo aligned, `AGENTS.md` v3, `DECISIONS.md`, `IDEAS.md`, `validate_data.py`, `test_handedness.py`, `run_headless_sim.py`, CI green | **G0:** Docs & CI green |
| **F1 Core Sim** | **L1–L3** | `World.Clock` (10 Hz), 28-day calendar, weather, NPC schedules, NavMesh/LOD, perception, memory, beliefs, rumor graph | **G0.5:** 28-day sim `violations: 0` |
| **F2 Two Faces** | **L4–L6** | Social suspicion, physical traces, clothing, player room, 4 cover jobs, economy, Heart (`Warm <-> Cold`), wounds, corpses | **G1: Anecdote Test (>= 3/5)** |
| **F3 Content** | **L7–L8** | 26 NPCs, 12 systemic gigs (>= 3 approaches + ripples), 24 small stories, aspirations, 4 festivals, *Nisshi* scroll | **G2:** 28 days without dead-ends |
| **F4 Art** | **L9** | Final modular art assets per Section 10, 12-shot reference gallery + `[F4]` grayscale gate | **G3:** Visual gate |
| **F5 Polish** | **L10** | Real-GPU profiling, accessibility, localization (ID/EN/JP), organic audio, release candidate | **G4:** Public demo |
