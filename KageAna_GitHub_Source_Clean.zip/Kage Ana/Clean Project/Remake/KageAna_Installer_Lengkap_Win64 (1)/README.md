# KAGE-ANA (影穴) — v2.0 "Wow Slice" & Unity 6 Foundation

> **"Kage-Ana: stealth Sengoku orang-pertama di mana bayanganmu adalah senjata, suara adalah tinta, dan satu tebasan menentukan hidup."**
>
> *Jadilah bayangan. Lukis dengan tinta. Satu tebasan.*

---

## 1. Status Proyek Secara Jujur (Sesuai `AGENTS.md` v2)

Repositori v2.0 ini menindaklanjuti seluruh temuan dari `KageAna_Audit_v1_dan_Strategi_Kompetitif.md`:

1. **Laboratorium Look-Dev & Gameplay WebGL (`webgl_vertical_slice/`)**:
   - Berfungsi sebagai purwarupa interaktif yang langsung dapat dijalankan lewat installer desktop (`Install_KageAna_Windows.bat` / `Install_KageAna_Linux_Mac.sh`) untuk menguji ketiga pilar utama (**Bayangan Hidup**, **Suara sebagai Tinta / Mata Telinga**, dan **Satu Tebasan + Kage-Echo**), hierarki nilai *Art Bible v2*, dan alur misi hingga klimaks Menara Utara.
   - **Catatan Kejujuran Teknis**: Karakter dan tangan orang pertama pada purwarupa WebGL masih menggunakan *hierarchical procedural articulated meshes* (bukan *skeletal skinning* glTF/FBX dari Blender) dan ditandai sebagai `TEMP_` hingga aset pahatan manusia diimpor ke Unity 6 pada tahap W3.
2. **Basis Kode Produk Utama Unity 6 + URP (`unity_project/`)**:
   - Menyimpan **satu-satunya sumber data JSON kanonis** di `unity_project/Assets/_Project/Data/*.json` (berkas `webgl_vertical_slice/src/data_bundle.js` dibuat otomatis oleh `tools/sync_data.py`).
   - Mencakup scene `VerticalSlice_Blockout.unity` dengan hierarki objek awal, konfigurasi URP (`KageAna_URP_Asset.asset`), `KageAna_InputActions.inputactions`, skrip C# untuk ketiga pilar (`ShadowAndSoundPillars.cs`, `GuardStealthAI.cs`, `IaiCombatController.cs`, `SurfaceAcoustics.cs`, `VerticalSliceManager.cs`), serta *Editor Wizard* (`KageAnaAutoSceneAndBuildInstaller.cs`) untuk merakit dan mem-build `.exe` Windows secara otomatis di Unity 6.
3. **Arsip Mekanik v0.7 (`legacy/KageAna_v0.7_Legacy_Mechanics_Archive.zip`)**:
   - Menyimpan skrip C# dan desain *sandbox* sosial/anatomi dari v0.7 agar dapat dipakai kembali pada mode pasca-demo.

---

## 2. Cara Instal & Menjalankan (PC Installer)

### A. Windows (1-Klik Installer & Native App Window)
1. Ekstrak `KageAna_v2.0_WowSlice_Installer.zip` ke folder pilihan Anda.
2. Klik dua kali **`Install_KageAna_Windows.bat`**.
3. Skrip installer (`installer/KageAna_Setup_Wizard.ps1`) akan:
   - Menginstal berkas ke `%LOCALAPPDATA%\KageAna_v2`.
   - Membuat pintasan di Desktop Anda bernama **`KAGE-ANA v2.0 (影穴)`**.
   - Membuka KAGE-ANA v2.0 dalam jendela aplikasi desktop tanpa bingkai browser (`--app` mode) dengan akselerasi perangkat keras GPU aktif.
   - Jika Unity 6 terpasang di PC Anda, Anda juga dapat menjalankan `powershell -ExecutionPolicy Bypass -File installer\KageAna_Setup_Wizard.ps1 -BuildUnityExe` untuk mem-build `Build\Windows\KageAna_v2.exe`.

### B. Linux / macOS
1. Buka terminal di folder hasil ekstrak, lalu jalankan:
   ```bash
   ./Install_KageAna_Linux_Mac.sh
   ```
2. Skrip akan menyalin berkas ke `~/.local/share/KageAna_v2`, membuat entri aplikasi desktop, dan meluncurkan jendela permainan.

---

## 3. Tiga Pilar Kompetitif & Kontrol Permainan

| Pilar | Tombol | Mekanik Inti |
|---|---|---|
| **Pilar 1: Bayangan Hidup (*Kage-Ana*)** | **`Z`** / **`Alt`** | **Shadow-Meld**: Menyelam ke dalam kolam bayangan dan berpindah cepat ke bayangan lentera/bangunan terdekat tanpa terlihat. |
| | **`E`** / **`R`** | **Manipulasi Lentera 2 Arah**: Tekan `E` untuk memadamkan lentera (memperluas bayangan) atau menyalakannya kembali (memancing penjaga). Tekan `R` untuk menggeser posisi lentera. |
| | **`L`** | **Kaginawa Grapple**: Mengait ke atap bangunan atau masuk ke terowongan bawah panggung (rute 3 lapis). |
| **Pilar 2: Suara sebagai Tinta (*Mata Telinga*)** | **`V`** / **`Tab`** | **Mode "Mata Telinga"**: Dunia memudar menjadi kertas *washi* krem; penjaga di balik dinding dan sumber suara tampak sebagai sapuan kuas cinnabar & tinta sumi-e. |
| | **`P`** | **Mode Foto Ukiyo-e**: Mengubah layar menjadi cetakan cukil kayu berbingkai kertas *washi* lengkap dengan stempel *hanko* merah. |
| **Pilar 3: Satu Tebasan & *Kage-Echo*** | **`B`** + **Klik Kiri** | **Iaijutsu Standoff**: Sarungkan katana dengan `B`. Serangan pertama dari sarung adalah tebasan *Iai* satu pukulan mematikan dengan jangkauan ekstra namun bersuara keras (`42 dB`). |
| | **`F`** / **Klik Kanan** | **Eliminasi Senyap (`F`)** dari belakang/bayangan, atau **Tangkisan Tepat (`Klik Kanan`)** untuk membuka kuda-kuda lawan. |
| | **Otomatis saat Gugur / `H`** | **Gema Bayangan (*Kage-Echo*)**: Saat gugur dan mengulang cepat (`< 1 detik`), bayangan 10 detik terakhir Anda muncul kembali sebagai umpan yang memancing penjaga. |

### Tombol Cuaca, Diagnostik, & Uji Otomatis
- **`1` / `2` / `3` / `4`**: Ganti cuaca & waktu seketika (`1` Senja Cinnabar, `2` Malam Purnama, `3` Kabut Pagi, `4` Hujan Deras).
- **`F1`**: Tampilkan/sembunyikan panel telemetri teknis (disembunyikan secara bawaan).
- **`F4`**: Uji Struktur Nilai Grayscale (*Art Bible v2*).
- **`F5`**: Mode Sinematik (sembunyikan seluruh HUD untuk rekaman klip/trailer).
- **`F9`**: Jalankan 5 Skenario Uji Otomatis AI Stealth (`runAutomatedStealthScenarios`).
