// KAGE-ANA v0.4.0 [d4f039b3] — Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final) — Gerbang 1 Pilot (Gelombang D)
// Pure WinForms GDI+ 2D presenter, session recorder, & command dispatcher. Zero simulation logic in UI layer (Decision C-07 & D-06).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using KageAna.Runtime.Sim;

namespace KageAna.Sandbox
{
    public sealed class BufferedMapPanel : Panel
    {
        public BufferedMapPanel()
        {
            this.DoubleBuffered = true;
            this.ResizeRedraw = true;
        }
    }

    public sealed class SessionRecorder
    {
        private readonly string _sessionFilePath;
        private readonly List<string> _entries = new List<string>();
        private string _lastRecordedPlaceId = "";

        public string SessionFilePath { get { return _sessionFilePath; } }

        public SessionRecorder()
        {
            string baseDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "KageAna",
                "Sesi"
            );
            try { Directory.CreateDirectory(baseDir); } catch { }
            string stamp = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
            _sessionFilePath = Path.Combine(baseDir, "sesi_" + stamp + ".jsonl");
            RecordEntry("MULAI_SESI", "place_nagaya", "Sesi uji dimulai dalam mode Manual (default).");
        }

        public static string RedactPersonalInfo(string raw)
        {
            if (string.IsNullOrEmpty(raw)) return "";
            string s = raw;
            try
            {
                string user = Environment.UserName;
                if (!string.IsNullOrEmpty(user))
                {
                    s = s.Replace(user, "<PENGGUNA>");
                }
                string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
                if (!string.IsNullOrEmpty(profile))
                {
                    s = s.Replace(profile, "<FOLDER_PENGGUNA>");
                }
            }
            catch { }
            return s;
        }

        public void RecordSoumaLocationIfChanged(int day, int hour, string placeId, string placeName)
        {
            if (placeId == _lastRecordedPlaceId) return;
            _lastRecordedPlaceId = placeId;
            RecordEntry("JALUR_SOMA", placeId, "H" + day.ToString() + " " + hour.ToString() + ":00 -> " + placeName);
        }

        public void RecordButtonUsed(int day, int hour, string placeId, string buttonName)
        {
            RecordEntry("TOMBOL", placeId, "H" + day.ToString() + " " + hour.ToString() + ":00 [" + buttonName + "]");
        }

        public void RecordHighlightedEvent(int day, int hour, string eventId, string summary)
        {
            RecordEntry("SOROT_KEJADIAN", eventId, "H" + day.ToString() + " " + hour.ToString() + ":00 " + summary);
        }

        private void RecordEntry(string kind, string target, string detail)
        {
            string safeDetail = RedactPersonalInfo(detail).Replace("\"", "'").Replace("\r", " ").Replace("\n", " ");
            string line = "{\"utc\":\"" + DateTime.UtcNow.ToString("o")
                + "\",\"jenis\":\"" + kind
                + "\",\"target\":\"" + target
                + "\",\"rincian\":\"" + safeDetail + "\"}";
            _entries.Add(line);
            try
            {
                File.AppendAllText(_sessionFilePath, line + Environment.NewLine, Encoding.UTF8);
            }
            catch { }
        }
    }

    public sealed class SandboxMainForm : Form
    {
        public const string AppVersion = "0.4.0";
        public const string BuildHash8 = "d4f039b3";

        private SimDataBundle _bundle;
        private WorldClock _clock;
        private WeatherSystem _weather;
        private NoFreeKnowledgeGuard _guard;
        private SimPlaceGraphSystem _world;
        private SimPerceptionMemoryRumorSystem _rumorSys;
        private SessionRecorder _recorder;

        private ulong _seed = 7UL;
        private int _currentDay = 1;
        private string _currentSeason = "Spring";
        private string _currentWeather = "Clear";
        private string _currentFestival = "";
        private int _minuteInCurrentHour = 0;

        private bool _isPaused = false;
        private int _speedMultiplier = 1;
        private int _selectedNpcIndex = 0;
        private int _nextGigIndex = 0;
        private bool _isManualMode = true; // Butir 6d: Mode manual adalah default!
        private string _lastDiegeticDialogue = "Pilih salah satu warga di peta lalu klik 'Tanya NPC (Dialog)' untuk mendengar apa yang ia ketahui, dari siapa, dan seberapa yakin ia.";
        private int _highlightedKisahIndex = -1;

        private System.Windows.Forms.Timer _uiTimer;
        private Label _lblTopStatus;
        private Label _lblMetersAndCover;
        private BufferedMapPanel _mapPanel;
        private Panel _starterGuideCard;
        private TextBox _txtKisahHariIni;
        private TextBox _txtNpcInspector;
        private TextBox _txtPapanTintaAndKabar;
        private TextBox _txtNisshiAndAnecdotes;

        public SandboxMainForm()
        {
            this.Text = "KAGE-ANA v" + AppVersion + " [" + BuildHash8 + "] — Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)";
            this.AutoScaleMode = AutoScaleMode.Dpi;
            this.Size = new Size(1340, 735);
            this.MinimumSize = new Size(1240, 680);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(16, 22, 34);
            this.ForeColor = Color.FromArgb(234, 224, 200);
            this.KeyPreview = true;
            this.KeyDown += OnMainFormKeyDown;

            _recorder = new SessionRecorder();
            BuildUserInterface();
            ResetSimulation(7UL, true);

            _uiTimer = new System.Windows.Forms.Timer();
            _uiTimer.Interval = 100;
            _uiTimer.Tick += OnTimerTick;
            _uiTimer.Start();
        }

        private void BuildUserInterface()
        {
            // MenuStrip (Butir 6d Menu Pengembang & Butir 9.3 Menu Bantuan -> Kirim laporan uji)
            MenuStrip menuStrip = new MenuStrip();
            menuStrip.BackColor = Color.FromArgb(14, 19, 30);
            menuStrip.ForeColor = Color.FromArgb(234, 224, 200);

            ToolStripMenuItem menuDev = new ToolStripMenuItem("Pengembang (Alat Uji Kebijakan)");
            menuDev.ForeColor = Color.FromArgb(245, 176, 65);

            ToolStripMenuItem itemManual = new ToolStripMenuItem("Mode Manual (Default Pemain — Kendali WASD / Klik Kanan)");
            itemManual.Click += delegate { ActivateManualPlayMode(); };
            menuDev.DropDownItems.Add(itemManual);
            menuDev.DropDownItems.Add(new ToolStripSeparator());

            string[] pols = new string[] { "Idle", "HonestTrader", "TraderInformant", "RecklessLoud", "Pemulih" };
            for (int i = 0; i < pols.Length; i++)
            {
                string pName = pols[i];
                ToolStripMenuItem itemPol = new ToolStripMenuItem("Alat Uji Kebijakan Otomatis: " + pName);
                itemPol.Click += delegate { ActivateDeveloperPolicy(pName); };
                menuDev.DropDownItems.Add(itemPol);
            }
            menuDev.DropDownItems.Add(new ToolStripSeparator());
            ToolStripMenuItem itemExportNisshi = new ToolStripMenuItem("Ekspor Nisshi ke Berkas Teks (.txt)");
            itemExportNisshi.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Menu:EksporNisshi");
                ExportNisshiToTextFile();
            };
            menuDev.DropDownItems.Add(itemExportNisshi);

            ToolStripMenuItem menuHelp = new ToolStripMenuItem("Bantuan");
            menuHelp.ForeColor = Color.FromArgb(245, 176, 65);

            ToolStripMenuItem itemShowGuide = new ToolStripMenuItem("Tampilkan Kartu Petunjuk Awal (1 Layar)");
            itemShowGuide.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Bantuan:TampilkanPetunjuk");
                if (_starterGuideCard != null) _starterGuideCard.Visible = true;
            };
            menuHelp.DropDownItems.Add(itemShowGuide);

            ToolStripMenuItem itemSendReport = new ToolStripMenuItem("Kirim laporan uji (Kemas ZIP ke Desktop)");
            itemSendReport.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Bantuan:KirimLaporanUji");
                PackageTestReportToDesktopZip();
            };
            menuHelp.DropDownItems.Add(itemSendReport);

            menuStrip.Items.Add(menuDev);
            menuStrip.Items.Add(menuHelp);
            this.MainMenuStrip = menuStrip;
            this.Controls.Add(menuStrip);

            Panel topBar = new Panel();
            topBar.Dock = DockStyle.Top;
            topBar.Height = 114;
            topBar.BackColor = Color.FromArgb(22, 30, 46);
            this.Controls.Add(topBar);

            _lblTopStatus = new Label();
            _lblTopStatus.Location = new Point(8, 4);
            _lblTopStatus.Size = new Size(1310, 18);
            _lblTopStatus.Font = new Font("Segoe UI", 8.8f, FontStyle.Bold);
            _lblTopStatus.ForeColor = Color.FromArgb(245, 176, 65);
            topBar.Controls.Add(_lblTopStatus);

            _lblMetersAndCover = new Label();
            _lblMetersAndCover.Location = new Point(8, 23);
            _lblMetersAndCover.Size = new Size(1310, 18);
            _lblMetersAndCover.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            _lblMetersAndCover.ForeColor = Color.FromArgb(234, 224, 200);
            topBar.Controls.Add(_lblMetersAndCover);

            // Row 1 Controls (fit within 1320px width for 1366x768)
            Button btnPause = CreateStyledButton("Jeda/Jalan", 8, 44, 78);
            btnPause.Click += delegate
            {
                _isPaused = !_isPaused;
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Jeda/Jalan");
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnPause);

            Button btnSpd1 = CreateStyledButton("x1", 90, 44, 38);
            btnSpd1.Click += delegate { SetSpeed(1); };
            topBar.Controls.Add(btnSpd1);

            Button btnSpd10 = CreateStyledButton("x10", 132, 44, 42);
            btnSpd10.Click += delegate { SetSpeed(10); };
            topBar.Controls.Add(btnSpd10);

            Button btnSpd60 = CreateStyledButton("x60", 178, 44, 42);
            btnSpd60.Click += delegate { SetSpeed(60); };
            topBar.Controls.Add(btnSpd60);

            Button btnStepDay = CreateStyledButton("+1 Hari", 224, 44, 68);
            btnStepDay.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "+1 Hari");
                AdvanceSimMinutes(1440);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnStepDay);

            Button btnStep7Days = CreateStyledButton("+7 Hari", 296, 44, 74);
            btnStep7Days.BackColor = Color.FromArgb(42, 68, 94);
            btnStep7Days.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "+7 Hari");
                AdvanceSimMinutes(7 * 1440);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnStep7Days);

            Button btnStep28Days = CreateStyledButton("+28 Hari", 374, 44, 80);
            btnStep28Days.BackColor = Color.FromArgb(48, 78, 62);
            btnStep28Days.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "+28 Hari");
                AdvanceSimMinutes(28 * 1440);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnStep28Days);

            Button btnNextWare = CreateStyledButton("Ganti Dagangan", 458, 44, 118);
            btnNextWare.Click += delegate
            {
                _world.SelectWareCategory((_world.ActiveWareIdx + 1) % _world.Data.Wares.Count);
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Ganti Dagangan");
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnNextWare);

            Button btnTrade = CreateStyledButton("Berdagang", 580, 44, 96);
            btnTrade.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Berdagang");
                _rumorSys.ExecuteSoumaTrade(_seed, _clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnTrade);

            Button btnSleepNagaya = CreateStyledButton("Tidur/Cuci (Nagaya)", 680, 44, 136);
            btnSleepNagaya.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Tidur/Cuci Nagaya");
                int nagIdx = _world.FindPlaceIndexById("place_nagaya");
                if (nagIdx >= 0) _world.CommandSoumaMoveToPlace(nagIdx, "Pulang ke Kamar Sewa Nagaya untuk tidur & mencuci noda darah.");
                _world.SoumaCurrentPlaceIdx = nagIdx >= 0 ? nagIdx : 0;
                _world.SoumaIsInTransit = false;
                _rumorSys.ExecuteSoumaSleepAndCleanInNagaya(_clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnSleepNagaya);

            Button btnHighlightKisah = CreateStyledButton("Sorot Kisah Ini", 820, 44, 116);
            btnHighlightKisah.BackColor = Color.FromArgb(68, 52, 28);
            btnHighlightKisah.Click += delegate { HighlightNextKisahToday(); };
            topBar.Controls.Add(btnHighlightKisah);

            Button btnSendReportBar = CreateStyledButton("Kirim Laporan Uji", 940, 44, 132);
            btnSendReportBar.BackColor = Color.FromArgb(36, 76, 64);
            btnSendReportBar.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Kirim Laporan Uji");
                PackageTestReportToDesktopZip();
            };
            topBar.Controls.Add(btnSendReportBar);

            Button btnGuideToggle = CreateStyledButton("Petunjuk [?]", 1076, 44, 96);
            btnGuideToggle.Click += delegate
            {
                if (_starterGuideCard != null) _starterGuideCard.Visible = !_starterGuideCard.Visible;
            };
            topBar.Controls.Add(btnGuideToggle);

            Button btnReset = CreateStyledButton("Ulang (Reset)", 1176, 44, 98);
            btnReset.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Reset");
                ResetSimulation(7UL, false);
            };
            topBar.Controls.Add(btnReset);

            // Row 2: Inquire (Diegetic Dialog), Gig, Pay Rent, Dead Drop, Steal, Silent/Loud Kill, Wajah Asli 1/2/3
            Button btnInquire = CreateStyledButton("Tanya NPC (Dialog)", 8, 78, 132);
            btnInquire.BackColor = Color.FromArgb(52, 74, 108);
            btnInquire.Click += delegate
            {
                if (_selectedNpcIndex >= 0 && _selectedNpcIndex < _world.Agents.Count)
                {
                    NpcRuntimeState targetAg = _world.Agents[_selectedNpcIndex];
                    _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Tanya NPC:" + targetAg.Id);
                    _rumorSys.ExecuteSoumaInquireNpc(_clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, targetAg.Id, _world, _guard);
                    _lastDiegeticDialogue = _rumorSys.GenerateDiegeticNpcDialogue(targetAg.Id, _world);
                    _recorder.RecordHighlightedEvent(_currentDay, _clock.CurrentHour, "dialog_" + targetAg.Id, _lastDiegeticDialogue);
                    RefreshTextPanels();
                }
            };
            topBar.Controls.Add(btnInquire);

            Button btnGig = CreateStyledButton("Jalankan Gig", 144, 78, 106);
            btnGig.BackColor = Color.FromArgb(44, 72, 82);
            btnGig.Click += delegate
            {
                if (_world.Data.Gigs.Count > 0)
                {
                    SimGigDef g = _world.Data.Gigs[_nextGigIndex % _world.Data.Gigs.Count];
                    string app = g.Approaches.Count > 0 ? g.Approaches[0] : "Clever";
                    _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Jalankan Gig:" + g.Id);
                    _rumorSys.ExecuteSoumaCompleteGig(_nextGigIndex % _world.Data.Gigs.Count, app, _clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                    _nextGigIndex = (_nextGigIndex + 1) % _world.Data.Gigs.Count;
                    RefreshTextPanels();
                }
            };
            topBar.Controls.Add(btnGig);

            Button btnPayRent = CreateStyledButton("Bayar Sewa O-Hana", 254, 78, 132);
            btnPayRent.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Bayar Sewa O-Hana");
                _rumorSys.ExecuteSoumaPayRentToOhana(_clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnPayRent);

            Button btnDeadDrop = CreateStyledButton("Lapor Sabu (Hutan)", 390, 78, 134);
            btnDeadDrop.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Lapor Dead Drop Sabu");
                _rumorSys.ExecuteSoumaDeadDropReport(_clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnDeadDrop);

            Button btnSteal = CreateStyledButton("Curi Barang", 528, 78, 94);
            btnSteal.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Curi Barang");
                _rumorSys.ExecuteSoumaSteal(_clock.TotalTicks, _clock.CurrentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnSteal);

            Button btnSilentKill = CreateStyledButton("Bunuh Senyap", 626, 78, 102);
            btnSilentKill.Click += delegate
            {
                if (_selectedNpcIndex >= 0 && _selectedNpcIndex < _world.Agents.Count)
                {
                    _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Bunuh Senyap:" + _world.Agents[_selectedNpcIndex].Id);
                    _rumorSys.ExecuteSoumaElimination(_clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world.Agents[_selectedNpcIndex].Id, false, true, _world, _guard);
                    _mapPanel.Invalidate();
                    RefreshTextPanels();
                }
            };
            topBar.Controls.Add(btnSilentKill);

            Button btnLoudKill = CreateStyledButton("Bunuh Gaduh", 732, 78, 102);
            btnLoudKill.Click += delegate
            {
                if (_selectedNpcIndex >= 0 && _selectedNpcIndex < _world.Agents.Count)
                {
                    _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Bunuh Gaduh:" + _world.Agents[_selectedNpcIndex].Id);
                    _rumorSys.ExecuteSoumaElimination(_clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world.Agents[_selectedNpcIndex].Id, true, false, _world, _guard);
                    _mapPanel.Invalidate();
                    RefreshTextPanels();
                }
            };
            topBar.Controls.Add(btnLoudKill);

            Button btnTf1 = CreateStyledButton("Wajah Asli 1: Retak", 838, 78, 128);
            btnTf1.BackColor = Color.FromArgb(88, 42, 34);
            btnTf1.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Wajah Asli 1");
                _rumorSys.ExecuteSoumaTrueFace(1, _clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnTf1);

            Button btnTf2 = CreateStyledButton("Wajah Asli 2: Terbuka!", 970, 78, 142);
            btnTf2.BackColor = Color.FromArgb(145, 28, 34);
            btnTf2.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Wajah Asli 2");
                _rumorSys.ExecuteSoumaTrueFace(2, _clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnTf2);

            Button btnTf3 = CreateStyledButton("Wajah Asli 3: Hilang", 1116, 78, 142);
            btnTf3.BackColor = Color.FromArgb(95, 24, 52);
            btnTf3.Click += delegate
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Wajah Asli 3");
                _rumorSys.ExecuteSoumaTrueFace(3, _clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            };
            topBar.Controls.Add(btnTf3);

            // Right Container (4 Readable Panels fitting comfortably in 1366x768)
            Panel rightContainer = new Panel();
            rightContainer.Dock = DockStyle.Right;
            rightContainer.Width = 540;
            rightContainer.BackColor = Color.FromArgb(20, 27, 41);
            this.Controls.Add(rightContainer);

            Label lblKisah = new Label();
            lblKisah.Text = "1. KISAH HARI INI (Kalimat Biasa & Tautan 'Mengapa' ke Saksi/Sumber)";
            lblKisah.Location = new Point(8, 4);
            lblKisah.Size = new Size(524, 16);
            lblKisah.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblKisah.ForeColor = Color.FromArgb(245, 176, 65);
            rightContainer.Controls.Add(lblKisah);

            _txtKisahHariIni = CreateReadOnlyLogBox(8, 22, 524, 128);
            rightContainer.Controls.Add(_txtKisahHariIni);

            Label lblInsp = new Label();
            lblInsp.Text = "2. DIALOG NPC ('Tanya NPC') & INSPEKTUR (Mengapa Ia Tahu / Curiga)";
            lblInsp.Location = new Point(8, 154);
            lblInsp.Size = new Size(524, 16);
            lblInsp.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblInsp.ForeColor = Color.FromArgb(245, 176, 65);
            rightContainer.Controls.Add(lblInsp);

            _txtNpcInspector = CreateReadOnlyLogBox(8, 172, 524, 148);
            rightContainer.Controls.Add(_txtNpcInspector);

            Label lblPapan = new Label();
            lblPapan.Text = "3. PAPAN TINTA (Kabar, Pesanan Kelompok, Gig Sampingan, & Kisah Kecil)";
            lblPapan.Location = new Point(8, 324);
            lblPapan.Size = new Size(524, 16);
            lblPapan.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblPapan.ForeColor = Color.FromArgb(245, 176, 65);
            rightContainer.Controls.Add(lblPapan);

            _txtPapanTintaAndKabar = CreateReadOnlyLogBox(8, 342, 524, 120);
            rightContainer.Controls.Add(_txtPapanTintaAndKabar);

            Label lblNisshi = new Label();
            lblNisshi.Text = "4. NISSHI TERKURASI (12-20 Butir) & RANTAI SEBAB-AKIBAT (Agensi NPC)";
            lblNisshi.Location = new Point(8, 466);
            lblNisshi.Size = new Size(524, 16);
            lblNisshi.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblNisshi.ForeColor = Color.FromArgb(245, 176, 65);
            rightContainer.Controls.Add(lblNisshi);

            _txtNisshiAndAnecdotes = CreateReadOnlyLogBox(8, 484, 524, 132);
            rightContainer.Controls.Add(_txtNisshiAndAnecdotes);

            _mapPanel = new BufferedMapPanel();
            _mapPanel.Dock = DockStyle.Fill;
            _mapPanel.BackColor = Color.FromArgb(13, 18, 28);
            _mapPanel.Paint += OnMapPaint;
            _mapPanel.MouseDown += OnMapMouseDown;
            this.Controls.Add(_mapPanel);
            _mapPanel.BringToFront();

            BuildNonModalStarterGuideCard();
        }

        // Butir 6c: Kartu Petunjuk Awal 1 layar TANPA modal (bisa ditutup kapan saja + menyorot tempat menarik di peta)
        private void BuildNonModalStarterGuideCard()
        {
            _starterGuideCard = new Panel();
            _starterGuideCard.Location = new Point(14, 14);
            _starterGuideCard.Size = new Size(420, 210);
            _starterGuideCard.BackColor = Color.FromArgb(24, 34, 52);
            _starterGuideCard.BorderStyle = BorderStyle.FixedSingle;

            Label lblTitle = new Label();
            lblTitle.Text = "PETUNJUK AWAL (1 LAYAR — BISA DITUTUP KAPAN SAJA)";
            lblTitle.Location = new Point(10, 8);
            lblTitle.Size = new Size(310, 18);
            lblTitle.Font = new Font("Segoe UI", 8.5f, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(245, 176, 65);
            _starterGuideCard.Controls.Add(lblTitle);

            Button btnCloseCard = new Button();
            btnCloseCard.Text = "Tutup [X]";
            btnCloseCard.Location = new Point(332, 5);
            btnCloseCard.Size = new Size(76, 24);
            btnCloseCard.FlatStyle = FlatStyle.Flat;
            btnCloseCard.BackColor = Color.FromArgb(145, 28, 34);
            btnCloseCard.ForeColor = Color.White;
            btnCloseCard.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold);
            btnCloseCard.Click += delegate { _starterGuideCard.Visible = false; };
            _starterGuideCard.Controls.Add(btnCloseCard);

            Label lblBody = new Label();
            lblBody.Location = new Point(10, 32);
            lblBody.Size = new Size(398, 170);
            lblBody.Font = new Font("Segoe UI", 8.2f, FontStyle.Regular);
            lblBody.ForeColor = Color.FromArgb(234, 224, 200);
            lblBody.Text =
                "Selamat datang di Lembah Kurokawa. Anda berperan sebagai Shinonome Soma (pedagang keliling).\r\n\r\n" +
                "1. GERAK MANUAL (Default): Klik Kanan lingkaran tempat di peta (atau tekan WASD) untuk berjalan.\r\n" +
                "   Tempat menarik disorot lingkaran emas: Pasar Kaki Kastil, Kedai Teh O-Kiku, & Apotek Soan.\r\n" +
                "2. INTERAKSI & DIALOG: Klik titik warga di peta lalu tekan 'Tanya NPC (Dialog)' atau 'Berdagang'.\r\n" +
                "3. IKUTI CERITA: Baca panel '1. KISAH HARI INI' di kanan untuk melihat kejadian dan alasan saksi.\r\n" +
                "4. TEKANAN HIDUP: Makan harian (15 mon) & sewa kamar O-Hana (350 mon tiap Hari 7) harus dibayar.\r\n" +
                "5. SELESAI UJI (20 Menit): Klik 'Kirim Laporan Uji' (atau menu Bantuan -> Kirim laporan uji).";
            _starterGuideCard.Controls.Add(lblBody);

            _mapPanel.Controls.Add(_starterGuideCard);
            _starterGuideCard.BringToFront();
        }

        private string GetCurrentPlaceId()
        {
            if (_world == null || _world.Places.Count == 0) return "place_nagaya";
            return _world.Places[_world.SoumaCurrentPlaceIdx].Id;
        }

        private void ActivateManualPlayMode()
        {
            _isManualMode = true;
            _world.SoumaManualOverride = true;
            _world.ActiveSoumaPolicy = "Manual";
            _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Mode:Manual");
            RefreshTextPanels();
        }

        private void ActivateDeveloperPolicy(string policyName)
        {
            _isManualMode = false;
            _world.SoumaManualOverride = false;
            _world.ActiveSoumaPolicy = policyName;
            _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "MenuDev:Kebijakan:" + policyName);
            RefreshTextPanels();
        }

        private void HighlightNextKisahToday()
        {
            if (_rumorSys == null || _rumorSys.KisahEvents.Count == 0) return;
            _highlightedKisahIndex = (_highlightedKisahIndex + 1) % _rumorSys.KisahEvents.Count;
            int actualIdx = _rumorSys.KisahEvents.Count - 1 - (_highlightedKisahIndex % Math.Min(8, _rumorSys.KisahEvents.Count));
            if (actualIdx >= 0 && actualIdx < _rumorSys.KisahEvents.Count)
            {
                KisahEventEntry ke = _rumorSys.KisahEvents[actualIdx];
                _recorder.RecordHighlightedEvent(_currentDay, _clock.CurrentHour, ke.SourceEventId, ke.Summary);
            }
            RefreshTextPanels();
        }

        private Button CreateStyledButton(string text, int x, int y, int w)
        {
            Button btn = new Button();
            btn.Text = text;
            btn.Location = new Point(x, y);
            btn.Size = new Size(w, 28);
            btn.FlatStyle = FlatStyle.Flat;
            btn.BackColor = Color.FromArgb(34, 45, 68);
            btn.ForeColor = Color.FromArgb(234, 224, 200);
            btn.Font = new Font("Segoe UI", 7.8f, FontStyle.Bold);
            btn.TabStop = false;
            return btn;
        }

        private TextBox CreateReadOnlyLogBox(int x, int y, int w, int h)
        {
            TextBox tb = new TextBox();
            tb.Multiline = true;
            tb.ReadOnly = true;
            tb.ScrollBars = ScrollBars.Vertical;
            tb.Location = new Point(x, y);
            tb.Size = new Size(w, h);
            tb.BackColor = Color.FromArgb(14, 19, 30);
            tb.ForeColor = Color.FromArgb(234, 224, 200);
            tb.Font = new Font("Consolas", 8.2f, FontStyle.Regular);
            tb.TabStop = false;
            return tb;
        }

        private void ExportNisshiToTextFile()
        {
            _rumorSys.CurateYearlyNisshi(_world);
            string outPath = "Nisshi_Soma.txt";
            string content = "======================================================================\r\n"
                + "NISSHI TERKURASI (12-20 BUTIR BERMAKNA SHINONOME SOMA - KITAB 8.10)\r\n"
                + "Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)\r\n"
                + "Mode/Kebijakan: " + _world.ActiveSoumaPolicy + " | Hari Kini: " + _currentDay.ToString() + " (" + _currentSeason + ")\r\n"
                + "Aspirasi (8.9): " + _world.ActiveAspirationId + " (" + _world.AspirationProgressScore.ToString() + "/100)\r\n"
                + "======================================================================\r\n\r\n"
                + "--- A. CATATAN NISSHI TERKURASI (12-20 BUTIR DARI LOG KEJADIAN NYATA) ---\r\n";

            for (int i = 0; i < _rumorSys.NisshiEntries.Count; i++)
            {
                NisshiEntry ne = _rumorSys.NisshiEntries[i];
                content += "[" + ne.Season + " | " + ne.Category + " | " + ne.SourceEventId + "] " + ne.EntryText + "\r\n";
            }

            content += "\r\n--- B. RANTAI SEBAB-AKIBAT & AGENSI NPC (>=3 MATA RANTAI & >=3 NPC) ---\r\n";
            for (int c = 0; c < _rumorSys.CausalChains.Count; c++)
            {
                CausalChainRecord cc = _rumorSys.CausalChains[c];
                content += "* [" + cc.ChainId + " | H" + cc.DayCompleted.ToString() + " | " + cc.DistinctNpcCount.ToString() + " NPC] " + cc.FullTraceText + "\r\n";
            }

            File.WriteAllText(outPath, content, Encoding.UTF8);
            MessageBox.Show("Nisshi terkurasi berhasil diekspor ke berkas: " + SessionRecorder.RedactPersonalInfo(Path.GetFullPath(outPath)), "Ekspor Nisshi Selesai", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        // Butir 9.3: Menu "Bantuan -> Kirim laporan uji" -> Kemas rekaman sesi + log galat + info sistem (disamarkan) ke ZIP di Desktop
        private void PackageTestReportToDesktopZip()
        {
            try
            {
                string localApp = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "KageAna"
                );
                string desktopDir = Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
                if (string.IsNullOrEmpty(desktopDir) || !Directory.Exists(desktopDir))
                {
                    desktopDir = AppDomain.CurrentDomain.BaseDirectory;
                }

                string stamp = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
                string zipPath = Path.Combine(desktopDir, "Laporan_Uji_KageAna_" + stamp + ".zip");

                using (FileStream fs = new FileStream(zipPath, FileMode.Create))
                using (ZipArchive zip = new ZipArchive(fs, ZipArchiveMode.Create))
                {
                    // 1. Info sistem tanpa data pribadi
                    ZipArchiveEntry sysEntry = zip.CreateEntry("info_sistem.txt");
                    using (StreamWriter sw = new StreamWriter(sysEntry.Open(), Encoding.UTF8))
                    {
                        sw.WriteLine("Judul Aplikasi : Kage-Ana — Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)");
                        sw.WriteLine("Versi Aplikasi : " + AppVersion + " [" + BuildHash8 + "]");
                        sw.WriteLine("Waktu Kemas UTC: " + DateTime.UtcNow.ToString("o"));
                        sw.WriteLine("Sistem Operasi : " + SessionRecorder.RedactPersonalInfo(Environment.OSVersion.VersionString));
                        sw.WriteLine("Versi Runtime  : .NET " + Environment.Version.ToString());
                        sw.WriteLine("Mode Aktif     : " + _world.ActiveSoumaPolicy + " (Manual=" + (_isManualMode ? "Ya" : "Tidak") + ")");
                        sw.WriteLine("Hari Simulasi  : Hari " + _currentDay.ToString() + " (" + _currentSeason + ")");
                        sw.WriteLine("Uang / Utang   : " + _world.SoumaMon.ToString() + " mon / Utang " + _world.UnpaidRentDebtMon.ToString() + " mon");
                        sw.WriteLine("Jejak Kejadian : " + _rumorSys.EventLog.Count.ToString() + " WorldEvent, " + _rumorSys.CausalChains.Count.ToString() + " Rantai Sebab-Akibat");
                    }

                    // 2. Rekaman Sesi
                    string sesiDir = Path.Combine(localApp, "Sesi");
                    if (Directory.Exists(sesiDir))
                    {
                        string[] sesiFiles = Directory.GetFiles(sesiDir, "*.jsonl");
                        for (int i = 0; i < sesiFiles.Length; i++)
                        {
                            string fname = Path.GetFileName(sesiFiles[i]);
                            string sanitized = SessionRecorder.RedactPersonalInfo(File.ReadAllText(sesiFiles[i], Encoding.UTF8));
                            ZipArchiveEntry e = zip.CreateEntry("Sesi/" + fname);
                            using (StreamWriter sw = new StreamWriter(e.Open(), Encoding.UTF8))
                            {
                                sw.Write(sanitized);
                            }
                        }
                    }

                    // 3. Log Galat (jika ada)
                    string logDir = Path.Combine(localApp, "Log");
                    if (Directory.Exists(logDir))
                    {
                        string[] logFiles = Directory.GetFiles(logDir, "galat_*.txt");
                        for (int i = 0; i < logFiles.Length; i++)
                        {
                            string fname = Path.GetFileName(logFiles[i]);
                            string sanitized = SessionRecorder.RedactPersonalInfo(File.ReadAllText(logFiles[i], Encoding.UTF8));
                            ZipArchiveEntry e = zip.CreateEntry("Log/" + fname);
                            using (StreamWriter sw = new StreamWriter(e.Open(), Encoding.UTF8))
                            {
                                sw.Write(sanitized);
                            }
                        }
                    }

                    // 4. Selftest (jika ada)
                    string selfTestFile = Path.Combine(localApp, "selftest.txt");
                    if (File.Exists(selfTestFile))
                    {
                        string sanitized = SessionRecorder.RedactPersonalInfo(File.ReadAllText(selfTestFile, Encoding.UTF8));
                        ZipArchiveEntry e = zip.CreateEntry("selftest.txt");
                        using (StreamWriter sw = new StreamWriter(e.Open(), Encoding.UTF8))
                        {
                            sw.Write(sanitized);
                        }
                    }
                }

                try
                {
                    Process.Start("explorer.exe", "/select,\"" + zipPath + "\"");
                }
                catch { }

                MessageBox.Show(
                    "Laporan uji berhasil dikemas (tanpa data pribadi) ke Desktop:\r\n" + Path.GetFileName(zipPath) + "\r\n\r\nSilakan kirimkan berkas ZIP tersebut kepada pembuatnya.",
                    "Laporan Uji Siap Dikirim",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "Gagal mengemas laporan uji: " + SessionRecorder.RedactPersonalInfo(ex.Message),
                    "Peringatan Laporan Uji",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
            }
        }

        private void OnMainFormKeyDown(object sender, KeyEventArgs e)
        {
            double step = 14.0;
            if (e.KeyCode == Keys.W || e.KeyCode == Keys.Up)
            {
                _isManualMode = true;
                _world.MoveSoumaByWasdDelta(0.0, step);
                _recorder.RecordSoumaLocationIfChanged(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), _world.Places[_world.SoumaCurrentPlaceIdx].Name);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            }
            else if (e.KeyCode == Keys.S || e.KeyCode == Keys.Down)
            {
                _isManualMode = true;
                _world.MoveSoumaByWasdDelta(0.0, -step);
                _recorder.RecordSoumaLocationIfChanged(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), _world.Places[_world.SoumaCurrentPlaceIdx].Name);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            }
            else if (e.KeyCode == Keys.A || e.KeyCode == Keys.Left)
            {
                _isManualMode = true;
                _world.MoveSoumaByWasdDelta(-step, 0.0);
                _recorder.RecordSoumaLocationIfChanged(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), _world.Places[_world.SoumaCurrentPlaceIdx].Name);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            }
            else if (e.KeyCode == Keys.G)
            {
                _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "IntervensiSalahPaham:MenyerahkanBukti");
                _rumorSys.ExecuteSoumaInterveneMisunderstanding("MenyerahkanBukti", _clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                RefreshTextPanels();
            }
            else if (e.KeyCode == Keys.D || e.KeyCode == Keys.Right)
            {
                _isManualMode = true;
                _world.MoveSoumaByWasdDelta(step, 0.0);
                _recorder.RecordSoumaLocationIfChanged(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), _world.Places[_world.SoumaCurrentPlaceIdx].Name);
                _mapPanel.Invalidate();
                RefreshTextPanels();
            }
        }

        private void SetSpeed(int mult)
        {
            _speedMultiplier = mult;
            _isPaused = false;
            _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), "Kecepatan:x" + mult.ToString());
            RefreshTextPanels();
        }

        private void ResetSimulation(ulong seed, bool firstStart)
        {
            _seed = seed;
            _bundle = SimJsonDataLoader.LoadDefaultBundle();
            _clock = new WorldClock();
            _weather = new WeatherSystem();
            _weather.SetConfig(_bundle.WeatherConfig);
            _guard = new NoFreeKnowledgeGuard();
            _world = new SimPlaceGraphSystem(_bundle);
            // Butir 6d: Mode manual adalah default!
            _isManualMode = true;
            _world.SoumaManualOverride = true;
            _world.ActiveSoumaPolicy = "Manual";
            _rumorSys = new SimPerceptionMemoryRumorSystem(_bundle);

            _currentDay = 1;
            _currentSeason = WorldClock.ComputeSeasonForDay(1);
            _currentWeather = _weather.DrawDailyWeather(_seed, 1, _currentSeason);
            _currentFestival = WorldClock.GetScheduledEventForDay(1);
            _minuteInCurrentHour = 0;

            if (firstStart && _starterGuideCard != null)
            {
                _starterGuideCard.Visible = true;
            }

            _mapPanel.Invalidate();
            RefreshTextPanels();
        }


        [StructLayout(LayoutKind.Sequential)]
        private struct XInputGamepad
        {
            public ushort wButtons;
            public byte bLeftTrigger;
            public byte bRightTrigger;
            public short sThumbLX;
            public short sThumbLY;
            public short sThumbRX;
            public short sThumbRY;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct XInputState
        {
            public uint dwPacketNumber;
            public XInputGamepad Gamepad;
        }

        [DllImport("xinput1_4.dll", EntryPoint = "XInputGetState")]
        private static extern uint XInputGetState14(uint dwUserIndex, out XInputState pState);

        private ushort _prevGamepadButtons = 0;

        private void PollGamepadIfConnected()
        {
            try
            {
                XInputState st;
                if (XInputGetState14(0, out st) == 0)
                {
                    double dx = 0.0;
                    double dy = 0.0;
                    if (st.Gamepad.sThumbLX > 12000 || (st.Gamepad.wButtons & 0x0008) != 0) dx = 8.0;
                    else if (st.Gamepad.sThumbLX < -12000 || (st.Gamepad.wButtons & 0x0004) != 0) dx = -8.0;
                    if (st.Gamepad.sThumbLY > 12000 || (st.Gamepad.wButtons & 0x0001) != 0) dy = 8.0;
                    else if (st.Gamepad.sThumbLY < -12000 || (st.Gamepad.wButtons & 0x0002) != 0) dy = -8.0;

                    if (dx != 0.0 || dy != 0.0)
                    {
                        _isManualMode = true;
                        _world.MoveSoumaByWasdDelta(dx, dy);
                        _mapPanel.Invalidate();
                    }

                    ushort pressed = (ushort)(st.Gamepad.wButtons & ~_prevGamepadButtons);
                    _prevGamepadButtons = st.Gamepad.wButtons;
                    if ((pressed & 0x8000) != 0) // Y button -> Intervene Misunderstanding (E2.4)
                    {
                        _rumorSys.ExecuteSoumaInterveneMisunderstanding("MenyerahkanBukti", _clock.TotalTicks, _currentDay, _clock.CurrentHour, _clock.CurrentSegment, _currentWeather, _world, _guard);
                        RefreshTextPanels();
                    }
                }
            }
            catch { }
        }

        private void OnTimerTick(object sender, EventArgs e)
        {
            PollGamepadIfConnected();
            if (_isPaused) return;

            int minutesToStep = 1;
            if (_speedMultiplier == 10) minutesToStep = 4;
            else if (_speedMultiplier == 60) minutesToStep = 20;

            AdvanceSimMinutes(minutesToStep);
            _mapPanel.Invalidate();
            RefreshTextPanels();
        }

        private void AdvanceSimMinutes(int minutesCount)
        {
            for (int i = 0; i < minutesCount; i++)
            {
                int prevDay = _clock.CurrentDay;
                int ticksThisMin = (_minuteInCurrentHour % 2 == 0) ? 7 : 8;
                _clock.AdvanceTicks(ticksThisMin);
                for (int t = 0; t < ticksThisMin; t++)
                {
                    _weather.StepTransitionTick();
                }

                if (_clock.CurrentDay != prevDay)
                {
                    _currentDay = _clock.CurrentDay;
                    _world.GrantedRestrictedAccessToday = false;
                    _currentSeason = WorldClock.ComputeSeasonForDay(_currentDay);
                    _currentWeather = _weather.DrawDailyWeather(_seed, _currentDay, _currentSeason);
                    _currentFestival = WorldClock.GetScheduledEventForDay(_currentDay);
                }

                _world.StepOneGameMinute(_seed, _currentDay, _clock.CurrentHour, _minuteInCurrentHour, _currentWeather, _currentFestival);
                _minuteInCurrentHour = (_minuteInCurrentHour + 1) % 60;

                if (_minuteInCurrentHour == 0)
                {
                    _rumorSys.EvaluateHourlyWorldEventsAndRumors(
                        _seed,
                        _clock.TotalTicks,
                        _currentDay,
                        _clock.CurrentHour,
                        _clock.CurrentSegment,
                        _currentWeather,
                        _world,
                        _guard
                    );
                    _recorder.RecordSoumaLocationIfChanged(_currentDay, _clock.CurrentHour, GetCurrentPlaceId(), _world.Places[_world.SoumaCurrentPlaceIdx].Name);
                }
            }
        }

        private PointF WorldToScreen(double wx, double wy)
        {
            float cx = _mapPanel.ClientSize.Width * 0.50f;
            float cy = _mapPanel.ClientSize.Height * 0.54f;
            float scale = Math.Min(_mapPanel.ClientSize.Width, _mapPanel.ClientSize.Height) / 520.0f;
            return new PointF(cx + (float)(wx * scale), cy - (float)(wy * scale));
        }

        private void OnMapPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.Clear(Color.FromArgb(13, 18, 28));
            int pCount = _world.Places.Count;

            using (Pen roadPen = new Pen(Color.FromArgb(90, 234, 224, 200), 1.8f))
            using (Pen alleyPen = new Pen(Color.FromArgb(80, 92, 136, 196), 1.4f))
            using (Font edgeFont = new Font("Segoe UI", 7.8f, FontStyle.Regular))
            using (Brush edgeBrush = new SolidBrush(Color.FromArgb(170, 160, 140)))
            {
                for (int i = 0; i < pCount; i++)
                {
                    PointF p0 = WorldToScreen(_world.Places[i].MapX, _world.Places[i].MapY);
                    for (int j = i + 1; j < pCount; j++)
                    {
                        int mins = _world.DirectEdgeMinutes[i * pCount + j];
                        if (mins < 9999)
                        {
                            PointF p1 = WorldToScreen(_world.Places[j].MapX, _world.Places[j].MapY);
                            string rt = _world.EdgeRouteTypes[i * pCount + j];
                            g.DrawLine(rt == "jalan_utama" ? roadPen : alleyPen, p0, p1);
                            float mx = (p0.X + p1.X) * 0.5f;
                            float my = (p0.Y + p1.Y) * 0.5f;
                            g.DrawString(mins.ToString() + "m", edgeFont, edgeBrush, mx + 2, my - 6);
                        }
                    }
                }
            }

            using (Brush indoorBrush = new SolidBrush(Color.FromArgb(32, 48, 72)))
            using (Brush outdoorBrush = new SolidBrush(Color.FromArgb(42, 38, 32)))
            using (Pen placeBorder = new Pen(Color.FromArgb(234, 224, 200), 1.5f))
            using (Pen highlightPoiPen = new Pen(Color.FromArgb(245, 176, 65), 2.8f))
            using (Pen vacantBorder = new Pen(Color.FromArgb(224, 90, 43), 2.4f))
            using (Font placeFont = new Font("Segoe UI", 8.0f, FontStyle.Bold))
            using (Brush placeTextBrush = new SolidBrush(Color.FromArgb(244, 239, 230)))
            using (Brush highlightTextBrush = new SolidBrush(Color.FromArgb(245, 176, 65)))
            {
                for (int i = 0; i < pCount; i++)
                {
                    string pid = _world.Places[i].Id;
                    bool isPoiHighlight = (_currentDay <= 2) && (pid == "place_pasar" || pid == "place_kedai_teh" || pid == "place_apotek_soan");
                    PointF pt = WorldToScreen(_world.Places[i].MapX, _world.Places[i].MapY);
                    float r = 16.5f;
                    g.FillEllipse(_world.Places[i].IsIndoorShelter ? indoorBrush : outdoorBrush, pt.X - r, pt.Y - r, r * 2, r * 2);
                    bool vacant = (i < _world.GuardPostVacant.Length && _world.GuardPostVacant[i]);
                    if (isPoiHighlight)
                    {
                        g.DrawEllipse(highlightPoiPen, pt.X - (r + 4), pt.Y - (r + 4), (r + 4) * 2, (r + 4) * 2);
                    }
                    g.DrawEllipse(vacant ? vacantBorder : placeBorder, pt.X - r, pt.Y - r, r * 2, r * 2);
                    string pTitle = vacant ? (_world.Places[i].Name + " [POS KOSONG]") : (isPoiHighlight ? ("★ " + _world.Places[i].Name) : _world.Places[i].Name);
                    g.DrawString(pTitle, placeFont, isPoiHighlight ? highlightTextBrush : placeTextBrush, pt.X - 54, pt.Y - 31);
                }
            }

            using (Brush soumaBrush = new SolidBrush(Color.FromArgb(200, 35, 44)))
            using (Brush l0Brush = new SolidBrush(Color.FromArgb(245, 176, 65)))
            using (Brush l1Brush = new SolidBrush(Color.FromArgb(92, 136, 196)))
            using (Brush l2Brush = new SolidBrush(Color.FromArgb(128, 136, 150)))
            using (Brush deadBrush = new SolidBrush(Color.FromArgb(90, 30, 30)))
            using (Pen selPen = new Pen(Color.White, 2.5f))
            using (Pen suspPen = new Pen(Color.FromArgb(224, 43, 54), 2.2f))
            using (Pen darkPen = new Pen(Color.Black, 1.2f))
            using (Font npcFont = new Font("Segoe UI", 7.8f, FontStyle.Bold))
            using (Brush npcTextBrush = new SolidBrush(Color.White))
            {
                PointF sPt = WorldToScreen(_world.SoumaPosX, _world.SoumaPosY);
                g.FillEllipse(soumaBrush, sPt.X - 8, sPt.Y - 8, 16, 16);
                g.DrawEllipse(_selectedNpcIndex == -1 ? selPen : darkPen, sPt.X - 8, sPt.Y - 8, 16, 16);
                g.DrawString("SOMA [" + (_isManualMode ? "MANUAL" : _world.ActiveSoumaPolicy) + "]", npcFont, npcTextBrush, sPt.X + 10, sPt.Y - 6);

                for (int n = 0; n < _world.Agents.Count; n++)
                {
                    NpcRuntimeState ag = _world.Agents[n];
                    PointF nPt = WorldToScreen(ag.PosX, ag.PosY);
                    Brush nb = l2Brush;
                    if (ag.IsDead) nb = deadBrush;
                    else if (ag.LodLevel == "L0_Full") nb = l0Brush;
                    else if (ag.LodLevel == "L1_Light") nb = l1Brush;

                    g.FillEllipse(nb, nPt.X - 5.5f, nPt.Y - 5.5f, 11.0f, 11.0f);
                    Pen ringPen = (_selectedNpcIndex == n) ? selPen : (ag.SuspicionTowardSouma >= 35 ? suspPen : darkPen);
                    g.DrawEllipse(ringPen, nPt.X - 5.5f, nPt.Y - 5.5f, 11.0f, 11.0f);
                    string tag = ag.SuspicionTowardSouma > 0 ? (ag.DisplayName + " [" + ag.SuspicionTowardSouma.ToString() + "]") : ag.DisplayName;
                    g.DrawString(tag, npcFont, npcTextBrush, nPt.X + 8, nPt.Y - 6);
                }
            }
        }

        private void OnMapMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                int bestPlace = -1;
                double bestDist = 36.0;
                for (int i = 0; i < _world.Places.Count; i++)
                {
                    PointF pt = WorldToScreen(_world.Places[i].MapX, _world.Places[i].MapY);
                    double d = Math.Sqrt((pt.X - e.X) * (pt.X - e.X) + (pt.Y - e.Y) * (pt.Y - e.Y));
                    if (d < bestDist)
                    {
                        bestDist = d;
                        bestPlace = i;
                    }
                }
                if (bestPlace >= 0)
                {
                    _isManualMode = true;
                    _world.CommandSoumaMoveToPlace(bestPlace, "Perintah Klik Kanan: Soma berjalan ke " + _world.Places[bestPlace].Name + ".");
                    _recorder.RecordButtonUsed(_currentDay, _clock.CurrentHour, _world.Places[bestPlace].Id, "KlikKananJalan:" + _world.Places[bestPlace].Id);
                    _mapPanel.Invalidate();
                    RefreshTextPanels();
                }
                return;
            }

            PointF sPt = WorldToScreen(_world.SoumaPosX, _world.SoumaPosY);
            double sDist = Math.Sqrt((sPt.X - e.X) * (sPt.X - e.X) + (sPt.Y - e.Y) * (sPt.Y - e.Y));
            int picked = _selectedNpcIndex;
            double minDist = 26.0;
            if (sDist < minDist)
            {
                minDist = sDist;
                picked = -1;
            }

            for (int n = 0; n < _world.Agents.Count; n++)
            {
                PointF nPt = WorldToScreen(_world.Agents[n].PosX, _world.Agents[n].PosY);
                double d = Math.Sqrt((nPt.X - e.X) * (nPt.X - e.X) + (nPt.Y - e.Y) * (nPt.Y - e.Y));
                if (d < minDist)
                {
                    minDist = d;
                    picked = n;
                }
            }

            _selectedNpcIndex = picked;
            if (picked >= 0 && picked < _world.Agents.Count)
            {
                _lastDiegeticDialogue = _rumorSys.GenerateDiegeticNpcDialogue(_world.Agents[picked].Id, _world);
            }
            _mapPanel.Invalidate();
            RefreshTextPanels();
        }

        private void RefreshTextPanels()
        {
            string hh = _clock.CurrentHour < 10 ? ("0" + _clock.CurrentHour.ToString()) : _clock.CurrentHour.ToString();
            string mm = _clock.CurrentMinute < 10 ? ("0" + _clock.CurrentMinute.ToString()) : _clock.CurrentMinute.ToString();
            string festInfo = _currentFestival.Length > 0 ? (" | Festival: " + _currentFestival) : "";
            string stateLabel = _isPaused ? "DIJEDA" : ("JALAN x" + _speedMultiplier.ToString());
            string modeStr = _isManualMode ? "MANUAL (Default)" : ("Uji Kebijakan: " + _world.ActiveSoumaPolicy);

            _lblTopStatus.Text = "Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final) | "
                + stateLabel + " | Mode: " + modeStr
                + " | Hari " + _currentDay.ToString() + " (" + _currentSeason + ") "
                + hh + ":" + mm + " [" + _clock.CurrentSegment + "] | Cuaca: " + _currentWeather
                + festInfo + " | Agensi NPC: " + _rumorSys.AgencyActionsEmittedCount.ToString()
                + " | Rantai: " + _rumorSys.CausalChains.Count.ToString();

            int maxSusp = 0;
            for (int i = 0; i < _world.Agents.Count; i++)
            {
                if (_world.Agents[i].SuspicionTowardSouma > maxSusp) maxSusp = _world.Agents[i].SuspicionTowardSouma;
            }
            string wareName = _world.Data.Wares.Count > 0 ? _world.Data.Wares[_world.ActiveWareIdx].CategoryName : "-";
            string heartLabel = _world.HeartWarmCold >= 25 ? "Hangat" : (_world.HeartWarmCold <= -25 ? "Dingin" : "Tenang");
            int yieldPct = _world.TotalTradesExecuted > 0 ? ((_world.TradesYieldingKabarOrAccess * 100) / _world.TotalTradesExecuted) : 0;

            _lblMetersAndCover.Text = "Uang: " + _world.SoumaMon.ToString() + " mon (Utang: " + _world.UnpaidRentDebtMon.ToString() + " mon)"
                + " | Dagangan: " + wareName + " (Stok:" + _world.CarryUnits.ToString() + ", Hasil:" + yieldPct.ToString() + "%)"
                + " | Curiga:" + maxSusp.ToString() + "/100"
                + " | Hati:" + _world.HeartWarmCold.ToString() + " (" + heartLabel + ")"
                + " | Kepercayaan Kelompok:" + _world.GroupTrust.ToString() + "/100";

            // 1. Panel "Kisah Hari Ini" (Butir 6a: Umpan kalimat biasa dengan tautan "Mengapa" ke saksi dan sumbernya)
            string kisahText = "";
            int kStart = _rumorSys.KisahEvents.Count > 6 ? (_rumorSys.KisahEvents.Count - 6) : 0;
            for (int k = _rumorSys.KisahEvents.Count - 1; k >= kStart; k--)
            {
                KisahEventEntry ke = _rumorSys.KisahEvents[k];
                string whyPart = ke.WhyLinkText.Length > 0 ? ke.WhyLinkText : ("Terjadi di " + ke.PlaceId);
                string witPart = ke.WitnessNpcId.Length > 0 ? ("Saksi: " + ke.WitnessNpcId) : "Saksi warga sekitar";
                string srcPart = ke.SourceEventId.Length > 0 ? ("Sumber: " + ke.SourceEventId) : "Kejadian langsung";
                kisahText += "• [Hari " + ke.Day.ToString() + " " + ke.Hour.ToString() + ":00] " + ke.Summary + "\r\n"
                    + "   ↳ MENGAPA? (" + witPart + " | " + srcPart + "): " + whyPart + "\r\n";
            }
            if (kisahText.Length == 0)
            {
                kisahText = "• Pagi baru dimulai di Lembah Kurokawa. Berjalanlah ke Pasar Kaki Kastil (Klik Kanan di peta) atau ajak bicara warga dengan 'Tanya NPC (Dialog)'.\r\n";
            }
            _txtKisahHariIni.Text = kisahText;

            // 2. Dialog Diegetik (Butir 6b) & Inspektur NPC
            if (_selectedNpcIndex == -1 || _selectedNpcIndex >= _world.Agents.Count)
            {
                _txtNpcInspector.Text = "DIALOG TERAKHIR:\r\n  " + _lastDiegeticDialogue + "\r\n\r\n"
                    + "ENTITAS: Shinonome Soma (souma - Mode: " + modeStr + ")\r\n"
                    + "Tempat Kini   : " + _world.Places[_world.SoumaCurrentPlaceIdx].Name + " | Aktivitas: " + _world.SoumaCurrentActivity + "\r\n"
                    + "Tunggakan Sewa: " + _world.UnpaidRentWeeks.ToString() + " minggu (Utang: " + _world.UnpaidRentDebtMon.ToString() + " mon | Jalur Kelompok Terputus: " + (_world.GroupSupplyLineCut ? "Ya" : "Tidak") + ")\r\n"
                    + "Sumber Event  : Jadwal=" + _rumorSys.EventsFromScheduleTransition.ToString()
                    + ", Interaksi=" + _rumorSys.EventsFromEntityInteraction.ToString()
                    + ", Soma=" + _rumorSys.EventsFromSoumaAction.ToString()
                    + ", Dunia=" + _rumorSys.EventsFromWorldCondition.ToString();
            }
            else
            {
                NpcRuntimeState ag = _world.Agents[_selectedNpcIndex];
                string suspReasons = "";
                for (int r = 0; r < ag.WhySuspiciousReasons.Count; r++)
                {
                    suspReasons += "  ! " + ag.WhySuspiciousReasons[r] + "\r\n";
                }
                if (suspReasons.Length == 0) suspReasons = "  (Tidak menaruh curiga khusus terhadap Soma)\r\n";

                _txtNpcInspector.Text = "DIALOG DIEGETIK (" + ag.DisplayName + " — Sikap: " + ag.AttitudeTowardSouma + "):\r\n  "
                    + _lastDiegeticDialogue + "\r\n\r\n"
                    + "NPC [" + (_selectedNpcIndex + 1).ToString() + "/" + _world.Agents.Count.ToString() + "]: " + ag.DisplayName + " (" + ag.Role + ")\r\n"
                    + "Tempat Kini : " + _world.Places[ag.CurrentPlaceIdx].Name + " | Interaksi Hari Ini: " + ag.DailyInteractionsCount.ToString() + "\r\n"
                    + "MENGAPA IA DI SINI: " + ag.WhyHereReason + "\r\n"
                    + "MENGAPA IA CURIGA (" + ag.SuspicionTowardSouma.ToString() + "/100):\r\n" + suspReasons;
            }

            // 3. Papan Tinta
            string ptText = "=== KABAR DI PAPAN TINTA (" + _rumorSys.KabarUpgradedCount.ToString() + " Terverifikasi >=2 Sumber) ===\r\n";
            for (int k = 0; k < _rumorSys.Kabars.Count; k++)
            {
                DynamicKabarRecord kb = _rumorSys.Kabars[k];
                ptText += "* [" + kb.Id + "] " + kb.StatusLabel + " -> " + kb.FormattedClaimId + "\r\n";
            }
            ptText += "\r\n=== GIG SAMPINGAN (" + _world.CompletedGigIds.Count.ToString() + "/" + _world.Data.Gigs.Count.ToString() + ") ===\r\n";
            for (int g = 0; g < _world.Data.Gigs.Count; g++)
            {
                SimGigDef gig = _world.Data.Gigs[g];
                bool done = false;
                for (int c = 0; c < _world.CompletedGigIds.Count; c++) if (_world.CompletedGigIds[c] == gig.Id) done = true;
                ptText += (done ? "[SELESAI] " : "[TERSEDIA] ") + gig.Title + " (+" + gig.RewardMon.ToString() + " mon)\r\n";
            }
            _txtPapanTintaAndKabar.Text = ptText;

            // 4. Nisshi Terkurasi (Butir 5: 12-20 butir) & Rantai Sebab-Akibat Agensi (Butir 2)
            string nsText = "=== NISSHI TERKURASI (" + _rumorSys.NisshiEntries.Count.ToString() + " Butir Bermakna dari " + _rumorSys.RawNisshiCandidates.Count.ToString() + " Kandidat) ===\r\n";
            int nStart = _rumorSys.NisshiEntries.Count > 6 ? (_rumorSys.NisshiEntries.Count - 6) : 0;
            for (int n = _rumorSys.NisshiEntries.Count - 1; n >= nStart; n--)
            {
                NisshiEntry ne = _rumorSys.NisshiEntries[n];
                nsText += "[" + ne.Category + "|" + ne.SourceEventId + "] " + ne.EntryText + "\r\n";
            }
            nsText += "\r\n=== RANTAI AGENSI & SALAH PAHAM NPC (" + _rumorSys.CausalChains.Count.ToString() + " Rantai) ===\r\n";
            int cStart = _rumorSys.CausalChains.Count > 5 ? (_rumorSys.CausalChains.Count - 5) : 0;
            for (int c = _rumorSys.CausalChains.Count - 1; c >= cStart; c--)
            {
                CausalChainRecord cc = _rumorSys.CausalChains[c];
                nsText += "* [" + cc.ChainId + "] " + cc.FullTraceText + "\r\n";
            }
            _txtNisshiAndAnecdotes.Text = nsText;
        }
    }

    public static class SandboxProgram
    {
        [DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        // Butir 9.3: Mode `--selftest` menjalankan simulasi headless 3 hari dengan seed tetap, periksa invarian dasar,
        // tulis hasil ke `%LOCALAPPDATA%\KageAna\selftest.txt`, keluar dengan kode 0/1 TANPA membuka jendela.
        public static int RunHeadlessSelfTest()
        {
            string localApp = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "KageAna"
            );
            try { Directory.CreateDirectory(localApp); } catch { }
            string outFile = Path.Combine(localApp, "selftest.txt");

            try
            {
                string json3Days = HeadlessSimRunner.Run28DaySimToJson(7UL, 3, false);
                bool ok = json3Days.Contains("\"violations\":0")
                    && json3Days.Contains("\"unclassifiedEvents\":0")
                    && json3Days.Contains("\"seed\":7");

                string report = "KAGE-ANA SANDBOX SELFTEST (3 HARI, SEED 7)\r\n"
                    + "Versi       : " + SandboxMainForm.AppVersion + " [" + SandboxMainForm.BuildHash8 + "]\r\n"
                    + "Waktu UTC   : " + DateTime.UtcNow.ToString("o") + "\r\n"
                    + "Status      : " + (ok ? "LULUS (0 pelanggaran invarian)" : "GAGAL") + "\r\n"
                    + "Ringkasan   : " + SessionRecorder.RedactPersonalInfo(json3Days) + "\r\n";
                File.WriteAllText(outFile, report, Encoding.UTF8);
                return ok ? 0 : 1;
            }
            catch (Exception ex)
            {
                try
                {
                    File.WriteAllText(
                        outFile,
                        "KAGE-ANA SANDBOX SELFTEST GAGAL\r\nGalat: " + SessionRecorder.RedactPersonalInfo(ex.ToString()),
                        Encoding.UTF8
                    );
                }
                catch { }
                return 1;
            }
        }

        private static void WriteCrashLogAndShowPoliteMessage(Exception ex)
        {
            string logDir = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "KageAna",
                "Log"
            );
            string logPath = Path.Combine(logDir, "galat_" + DateTime.UtcNow.ToString("yyyyMMdd_HHmmss") + ".txt");
            try
            {
                Directory.CreateDirectory(logDir);
                string body = "KAGE-ANA LAPORAN MASALAH (OTOMATIS DISAMARKAN)\r\n"
                    + "Versi : " + SandboxMainForm.AppVersion + " [" + SandboxMainForm.BuildHash8 + "]\r\n"
                    + "Waktu : " + DateTime.UtcNow.ToString("o") + "\r\n"
                    + "Rincian:\r\n" + SessionRecorder.RedactPersonalInfo(ex != null ? ex.ToString() : "Galat tak dikenal");
                File.WriteAllText(logPath, body, Encoding.UTF8);
            }
            catch { }

            MessageBox.Show(
                "Terjadi masalah. Berkas laporan ada di:\r\n" + SessionRecorder.RedactPersonalInfo(logPath) + "\r\n\r\nKirimkan berkas itu kepada pembuatnya.",
                "Kage-Ana: Sandbox Uji Sistem",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning
            );
        }

        [STAThread]
        public static int Main(string[] args)
        {
            if (args != null)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    if (args[i] == "--selftest")
                    {
                        return RunHeadlessSelfTest();
                    }
                }
            }

            bool createdNew = true;
            using (Mutex singleInstanceMutex = new Mutex(true, "Local\\KageAna_Sandbox_Uji_Sistem_Mutex", out createdNew))
            {
                if (!createdNew)
                {
                    try
                    {
                        Process current = Process.GetCurrentProcess();
                        Process[] procs = Process.GetProcessesByName(current.ProcessName);
                        for (int i = 0; i < procs.Length; i++)
                        {
                            if (procs[i].Id != current.Id && procs[i].MainWindowHandle != IntPtr.Zero)
                            {
                                ShowWindow(procs[i].MainWindowHandle, 9);
                                SetForegroundWindow(procs[i].MainWindowHandle);
                                break;
                            }
                        }
                    }
                    catch { }
                    return 0;
                }

                Application.SetHighDpiMode(HighDpiMode.SystemAware);
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
                Application.ThreadException += delegate (object s, ThreadExceptionEventArgs e)
                {
                    WriteCrashLogAndShowPoliteMessage(e.Exception);
                };
                AppDomain.CurrentDomain.UnhandledException += delegate (object s, UnhandledExceptionEventArgs e)
                {
                    WriteCrashLogAndShowPoliteMessage(e.ExceptionObject as Exception);
                };

                Application.Run(new SandboxMainForm());
                return 0;
            }
        }
    }
}
