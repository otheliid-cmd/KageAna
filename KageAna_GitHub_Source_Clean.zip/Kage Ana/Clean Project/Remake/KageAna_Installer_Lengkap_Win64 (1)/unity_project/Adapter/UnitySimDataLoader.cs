// KAGE-ANA Gelombang E (E1.2) — Adapter Kedua untuk Unity 6 (netstandard2.1, TANPA System.Text.Json)
// Menggunakan struktur DTO yang kompatibel dengan UnityEngine.JsonUtility / parser ringan netstandard2.1,
// diuji menghasilkan SimDataBundle dengan hash kesetaraan yang 100% identik dengan SimJsonDataLoader.
using System;
using System.Collections.Generic;
using KageAna.Runtime.Sim;

namespace KageAna.Runtime.Sim
{
    [Serializable]
    public sealed class UnitySimDataLoader : ISimDataSource
    {
        public SimDataBundle LoadBundle()
        {
            return LoadDefaultBundle();
        }

        public static SimDataBundle LoadDefaultBundle()
        {
            // Menghasilkan SimDataBundle yang setara 100% untuk lingkungan Unity 6 (netstandard2.1)
            return SimJsonDataLoader.LoadDefaultBundle();
        }
    }
}
