// KAGE-ANA v3.0 — External System.Text.Json Data Loader Adapter (A2-2, A3, & Gelombang C L7-L8)
// Lives OUTSIDE Runtime/Sim/ (in unity_project/Adapter/SimJsonDataLoader.cs).
// Parses all canonical JSON files from Assets/_Project/Data/ using System.Text.Json and returns a plain SimDataBundle.
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using KageAna.Runtime.Sim;

namespace KageAna.Runtime.Sim
{
    public static class SimJsonDataLoader
    {
        public static string ResolveDataFilePath(string relativeFromDataDir)
        {
            string[] candidates = new string[]
            {
                Path.Combine("unity_project", "Assets", "_Project", "Data", relativeFromDataDir),
                Path.Combine("Assets", "_Project", "Data", relativeFromDataDir),
                Path.Combine("Data", relativeFromDataDir),
                Path.Combine("..", "unity_project", "Assets", "_Project", "Data", relativeFromDataDir),
                Path.Combine("..", "Data", relativeFromDataDir)
            };
            for (int i = 0; i < candidates.Length; i++)
            {
                if (File.Exists(candidates[i]))
                {
                    return candidates[i];
                }
            }
            return "";
        }

        public static string ReadDataFileText(string relativeFromDataDir)
        {
            string p = ResolveDataFilePath(relativeFromDataDir);
            if (p.Length > 0 && File.Exists(p))
            {
                return File.ReadAllText(p);
            }
            return "";
        }

        public static int ParseHHMMToMinutes(string hhmm)
        {
            if (hhmm == null || hhmm.Length < 5) return 0;
            int h = int.Parse(hhmm.Substring(0, 2));
            int m = int.Parse(hhmm.Substring(3, 2));
            if (h == 23 && m == 59) return 1440;
            return h * 60 + m;
        }

        public static SimWeatherConfig ParseWeatherJson(string jsonText)
        {
            SimWeatherConfig cfg = new SimWeatherConfig();
            if (string.IsNullOrWhiteSpace(jsonText)) return cfg;

            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                JsonElement root = doc.RootElement;
                if (root.TryGetProperty("transitionGameSeconds", out JsonElement tgs))
                {
                    cfg.TransitionGameSeconds = tgs.GetInt32();
                }
                if (root.TryGetProperty("seasons", out JsonElement seasonsObj))
                {
                    string[] sNames = new string[] { "Spring", "Summer", "Autumn", "Winter" };
                    string[] wNames = new string[] { "Clear", "Cloudy", "Fog", "Rain", "Storm", "Snow", "Windy" };
                    for (int s = 0; s < sNames.Length; s++)
                    {
                        if (seasonsObj.TryGetProperty(sNames[s], out JsonElement sElem))
                        {
                            for (int w = 0; w < wNames.Length; w++)
                            {
                                if (sElem.TryGetProperty(wNames[w], out JsonElement wElem))
                                {
                                    cfg.SetWeight(s, w, wElem.GetInt32());
                                }
                            }
                        }
                    }
                }
            }
            return cfg;
        }

        public static SimClockConfig ParseClockJson(string jsonText)
        {
            SimClockConfig cfg = new SimClockConfig();
            if (string.IsNullOrWhiteSpace(jsonText)) return cfg;

            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                JsonElement root = doc.RootElement;
                if (root.TryGetProperty("clock", out JsonElement cElem))
                {
                    if (cElem.TryGetProperty("tickHz", out JsonElement th)) cfg.TickHz = th.GetInt32();
                    if (cElem.TryGetProperty("daysPerSeason", out JsonElement dps)) cfg.DaysPerSeason = dps.GetInt32();
                    if (cElem.TryGetProperty("seasonsPerYear", out JsonElement spy)) cfg.SeasonsPerYear = spy.GetInt32();
                    if (cElem.TryGetProperty("daysPerYear", out JsonElement dpy)) cfg.DaysPerYear = dpy.GetInt32();
                }
                if (root.TryGetProperty("economy", out JsonElement eElem))
                {
                    if (eElem.TryGetProperty("weeklyRentMon", out JsonElement rent)) cfg.WeeklyRentMon = rent.GetInt32();
                    if (eElem.TryGetProperty("autumnTaxMon", out JsonElement tax)) cfg.AutumnTaxMon = tax.GetInt32();
                }
            }
            return cfg;
        }

        public static List<SimPlaceDef> ParsePlacesJson(string jsonText)
        {
            List<SimPlaceDef> list = new List<SimPlaceDef>();
            if (string.IsNullOrWhiteSpace(jsonText)) return list;

            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                foreach (JsonElement elem in doc.RootElement.EnumerateArray())
                {
                    SimPlaceDef p = new SimPlaceDef();
                    p.Id = elem.GetProperty("id").GetString() ?? "";
                    p.Name = elem.GetProperty("name").GetString() ?? "";
                    p.District = elem.GetProperty("district").GetString() ?? "D1";
                    p.Type = elem.GetProperty("type").GetString() ?? "outdoor";
                    p.MapX = elem.GetProperty("mapX").GetInt32();
                    p.MapY = elem.GetProperty("mapY").GetInt32();
                    if (elem.TryGetProperty("witnessDensity", out JsonElement wd)) p.WitnessDensity = wd.GetDouble();
                    if (elem.TryGetProperty("lightProfile", out JsonElement lp)) p.LightProfile = lp.GetString() ?? "";
                    if (elem.TryGetProperty("isIndoorShelter", out JsonElement sh)) p.IsIndoorShelter = sh.GetBoolean();

                    if (elem.TryGetProperty("tags", out JsonElement tagsArr))
                    {
                        foreach (JsonElement t in tagsArr.EnumerateArray())
                        {
                            string ts = t.GetString() ?? "";
                            if (ts == "restricted" || ts == "high_security")
                            {
                                p.IsRestrictedZone = true;
                            }
                        }
                    }

                    if (elem.TryGetProperty("neighbors", out JsonElement nbArr))
                    {
                        foreach (JsonElement nb in nbArr.EnumerateArray())
                        {
                            SimNeighborEdge edge = new SimNeighborEdge();
                            edge.ToPlaceId = nb.GetProperty("to").GetString() ?? "";
                            edge.TravelMinutes = nb.GetProperty("travelMinutes").GetInt32();
                            if (nb.TryGetProperty("routeType", out JsonElement rt)) edge.RouteType = rt.GetString() ?? "jalan_utama";
                            p.Neighbors.Add(edge);
                        }
                    }
                    list.Add(p);
                }
            }
            return list;
        }

        public static List<SimNpcDef> ParseNpcsJson(string jsonText)
        {
            List<SimNpcDef> list = new List<SimNpcDef>();
            if (string.IsNullOrWhiteSpace(jsonText)) return list;

            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                foreach (JsonElement elem in doc.RootElement.EnumerateArray())
                {
                    SimNpcDef n = new SimNpcDef();
                    n.Id = elem.GetProperty("id").GetString() ?? "";
                    JsonElement dn = elem.GetProperty("displayName");
                    if (dn.ValueKind == JsonValueKind.Object && dn.TryGetProperty("id", out JsonElement dnId))
                    {
                        n.DisplayName = dnId.GetString() ?? n.Id;
                    }
                    else if (dn.ValueKind == JsonValueKind.String)
                    {
                        n.DisplayName = dn.GetString() ?? n.Id;
                    }
                    n.Role = elem.GetProperty("role").GetString() ?? "";
                    if (elem.TryGetProperty("roleCategory", out JsonElement rc)) n.RoleCategory = rc.GetString() ?? "Resident";
                    n.HomePlaceId = elem.GetProperty("home").GetString() ?? "place_nagaya";
                    n.SpeechHabit = elem.GetProperty("speechHabit").GetString() ?? "";

                    if (elem.TryGetProperty("traits", out JsonElement tr) && tr.ValueKind == JsonValueKind.Object)
                    {
                        if (tr.TryGetProperty("friendliness", out JsonElement fr)) n.Friendliness = fr.GetInt32();
                        if (tr.TryGetProperty("suspicion", out JsonElement su)) n.Suspicion = su.GetInt32();
                        if (tr.TryGetProperty("courage", out JsonElement co)) n.Courage = co.GetInt32();
                        if (tr.TryGetProperty("gossip", out JsonElement go)) n.Gossip = go.GetInt32();
                        if (tr.TryGetProperty("greed", out JsonElement gr)) n.Greed = gr.GetInt32();
                    }

                    if (elem.TryGetProperty("assignedPostPlaceId", out JsonElement apEl))
                    {
                        n.AssignedPostPlaceId = apEl.GetString() ?? n.HomePlaceId;
                    }
                    else
                    {
                        n.AssignedPostPlaceId = n.HomePlaceId;
                    }

                    if (elem.TryGetProperty("duties", out JsonElement dutArr) && dutArr.ValueKind == JsonValueKind.Array)
                    {
                        foreach (JsonElement dEl in dutArr.EnumerateArray())
                        {
                            n.Duties.Add(dEl.GetString() ?? "");
                        }
                    }

                    if (elem.TryGetProperty("socialDrives", out JsonElement sdObj) && sdObj.ValueKind == JsonValueKind.Object)
                    {
                        if (sdObj.TryGetProperty("perlu_bayar", out JsonElement d1)) n.SocialDrives.PerluBayar = d1.GetInt32();
                        if (sdObj.TryGetProperty("perlu_bicara", out JsonElement d2)) n.SocialDrives.PerluBicara = d2.GetInt32();
                        if (sdObj.TryGetProperty("perlu_dagang", out JsonElement d3)) n.SocialDrives.PerluDagang = d3.GetInt32();
                        if (sdObj.TryGetProperty("perlu_istirahat", out JsonElement d4)) n.SocialDrives.PerluIstirahat = d4.GetInt32();
                        if (sdObj.TryGetProperty("rasa_penasaran", out JsonElement d5)) n.SocialDrives.RasaPenasaran = d5.GetInt32();
                        if (sdObj.TryGetProperty("dendam", out JsonElement d6)) n.SocialDrives.Dendam = d6.GetInt32();
                        if (sdObj.TryGetProperty("kasih_sayang", out JsonElement d7)) n.SocialDrives.KasihSayang = d7.GetInt32();
                        if (sdObj.TryGetProperty("tugas_jadwal", out JsonElement d8)) n.SocialDrives.TugasJadwal = d8.GetInt32();
                    }

                    if (elem.TryGetProperty("relationships", out JsonElement relArr) && relArr.ValueKind == JsonValueKind.Array)
                    {
                        foreach (JsonElement rEl in relArr.EnumerateArray())
                        {
                            SimNpcRelationDef rDef = new SimNpcRelationDef();
                            if (rEl.TryGetProperty("targetId", out JsonElement tid)) rDef.TargetId = tid.GetString() ?? "";
                            if (rEl.TryGetProperty("type", out JsonElement rtp)) rDef.RelationType = rtp.GetString() ?? "asing";
                            if (rEl.TryGetProperty("closeness", out JsonElement clo)) rDef.Closeness = clo.GetInt32();
                            if (rEl.TryGetProperty("grudgeLevel", out JsonElement grl)) rDef.GrudgeLevel = grl.GetInt32();
                            if (rEl.TryGetProperty("debtMon", out JsonElement dbm)) rDef.DebtMon = dbm.GetInt32();
                            if (rEl.TryGetProperty("note", out JsonElement rnt)) rDef.Note = rnt.GetString() ?? "";
                            n.Relationships.Add(rDef);
                        }
                    }

                    if (elem.TryGetProperty("secrets", out JsonElement secArr) && secArr.ValueKind == JsonValueKind.Array)
                    {
                        foreach (JsonElement s in secArr.EnumerateArray())
                        {
                            n.SecretId = s.GetString() ?? "";
                            break;
                        }
                    }

                    if (elem.TryGetProperty("schedule", out JsonElement schArr))
                    {
                        foreach (JsonElement blk in schArr.EnumerateArray())
                        {
                            SimScheduleBlockDef b = new SimScheduleBlockDef();
                            b.FromMinutes = ParseHHMMToMinutes(blk.GetProperty("from").GetString() ?? "00:00");
                            b.ToMinutes = ParseHHMMToMinutes(blk.GetProperty("to").GetString() ?? "23:59");
                            b.Activity = blk.GetProperty("activity").GetString() ?? "";
                            b.PlaceId = blk.GetProperty("place").GetString() ?? n.HomePlaceId;
                            b.Interruptible = blk.GetProperty("interruptible").GetBoolean();
                            n.Schedule.Add(b);
                        }
                    }
                    list.Add(n);
                }
            }
            return list;
        }

        public static void ParseClaimTemplatesAndMotivesJson(string jsonText, SimDataBundle bundle)
        {
            if (string.IsNullOrWhiteSpace(jsonText)) return;
            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                JsonElement root = doc.RootElement;
                if (root.TryGetProperty("templates", out JsonElement tArr))
                {
                    foreach (JsonElement el in tArr.EnumerateArray())
                    {
                        SimClaimTemplateDef ct = new SimClaimTemplateDef();
                        ct.Action = el.GetProperty("action").GetString() ?? "";
                        ct.Category = el.GetProperty("category").GetString() ?? "general";
                        ct.BaseReliability = el.GetProperty("baseReliability").GetDouble();
                        ct.Sensitivity = el.GetProperty("sensitivity").GetDouble();
                        ct.TemplateId = el.GetProperty("templateId").GetString() ?? "";
                        ct.TemplateEn = el.GetProperty("templateEn").GetString() ?? "";
                        bundle.ClaimTemplates.Add(ct);
                    }
                }
                if (root.TryGetProperty("motives", out JsonElement mArr))
                {
                    foreach (JsonElement el in mArr.EnumerateArray())
                    {
                        SimMotiveDef m = new SimMotiveDef();
                        m.Id = el.GetProperty("id").GetString() ?? "motive_none";
                        m.TextId = el.GetProperty("textId").GetString() ?? "";
                        m.TextEn = el.GetProperty("textEn").GetString() ?? "";
                        bundle.Motives.Add(m);
                    }
                }
            }
        }

        public static void ParseWaresJson(string jsonText, SimDataBundle bundle)
        {
            if (string.IsNullOrWhiteSpace(jsonText)) return;
            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                if (doc.RootElement.TryGetProperty("wares", out JsonElement wArr))
                {
                    foreach (JsonElement el in wArr.EnumerateArray())
                    {
                        SimWareDef w = new SimWareDef();
                        w.Id = el.GetProperty("id").GetString() ?? "";
                        w.CategoryName = el.GetProperty("categoryName").GetString() ?? "";
                        w.BonusProfile = el.GetProperty("bonusProfile").GetString() ?? "";
                        w.CharacteristicRisk = el.GetProperty("characteristicRisk").GetString() ?? "";
                        w.BaseCapitalMon = el.GetProperty("baseCapitalMon").GetInt32();
                        w.MaxCarryUnits = el.GetProperty("maxCarryUnits").GetInt32();
                        w.SpeedMultiplier = el.GetProperty("speedMultiplier").GetDouble();
                        w.NoiseMultiplier = el.GetProperty("noiseMultiplier").GetDouble();
                        w.CanConcealWeapon = el.GetProperty("canConcealWeapon").GetBoolean();
                        w.RequiresZaLicense = el.GetProperty("requiresZaLicense").GetBoolean();
                        w.SeasonalOnly = el.GetProperty("seasonalOnly").GetBoolean();
                        if (w.Id == "ware_obat_ramuan") w.OdorTag = "Medicine";
                        else if (w.Id == "ware_ikan_garam") w.OdorTag = "FishSalt";
                        else w.OdorTag = "None";

                        foreach (JsonElement ap in el.GetProperty("accessPlaces").EnumerateArray())
                        {
                            w.AccessPlaces.Add(ap.GetString() ?? "");
                        }
                        foreach (JsonElement sp in el.GetProperty("sourcePlaces").EnumerateArray())
                        {
                            w.SourcePlaces.Add(sp.GetString() ?? "");
                        }
                        bundle.Wares.Add(w);
                    }
                }
            }
        }

        public static void ParseGarmentsJson(string jsonText, SimDataBundle bundle)
        {
            if (string.IsNullOrWhiteSpace(jsonText)) return;
            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                if (doc.RootElement.TryGetProperty("garments", out JsonElement gArr))
                {
                    foreach (JsonElement el in gArr.EnumerateArray())
                    {
                        SimGarmentDef g = new SimGarmentDef();
                        g.Id = el.GetProperty("id").GetString() ?? "";
                        g.Name = el.GetProperty("name").GetString() ?? "";
                        g.RoleCategory = el.GetProperty("roleCategory").GetString() ?? "";
                        g.PrimaryHex = el.GetProperty("primaryHex").GetString() ?? "#1F3A60";
                        g.SecondaryHex = el.GetProperty("secondaryHex").GetString() ?? "#3A342C";
                        g.DaySuspicionMod = el.GetProperty("daySuspicionMod").GetInt32();
                        g.NightSuspicionMod = el.GetProperty("nightSuspicionMod").GetInt32();
                        g.CanCarryWaresBox = el.GetProperty("canCarryWaresBox").GetBoolean();
                        bundle.Garments.Add(g);
                    }
                }
            }
        }

        public static void ParseGroupOrdersJson(string jsonText, SimDataBundle bundle)
        {
            if (string.IsNullOrWhiteSpace(jsonText)) return;
            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                if (doc.RootElement.TryGetProperty("orders", out JsonElement oArr))
                {
                    foreach (JsonElement el in oArr.EnumerateArray())
                    {
                        SimGroupOrderDef o = new SimGroupOrderDef();
                        o.Id = el.GetProperty("id").GetString() ?? "";
                        o.WeekNumber = el.GetProperty("weekNumber").GetInt32();
                        o.Title = el.GetProperty("title").GetString() ?? "";
                        o.RecommendedWareId = el.GetProperty("recommendedWareId").GetString() ?? "";
                        o.DeadlineDay = el.GetProperty("deadlineDay").GetInt32();
                        o.DeadDropPlaceId = el.GetProperty("deadDropPlaceId").GetString() ?? "place_titik_serah_hutan";
                        o.ContactNpcId = el.GetProperty("contactNpcId").GetString() ?? "sabu";
                        o.RewardCapitalMon = el.GetProperty("rewardCapitalMon").GetInt32();
                        o.TrustGainOnSuccess = el.GetProperty("trustGainOnSuccess").GetInt32();
                        o.TrustPenaltyOnFailure = el.GetProperty("trustPenaltyOnFailure").GetInt32();
                        foreach (JsonElement rk in el.GetProperty("requiredKabarIds").EnumerateArray())
                        {
                            o.RequiredKabarIds.Add(rk.GetString() ?? "");
                        }
                        bundle.GroupOrders.Add(o);
                    }
                }
            }
        }

        public static void ParseTrueFaceJson(string jsonText, SimDataBundle bundle)
        {
            if (string.IsNullOrWhiteSpace(jsonText)) return;
            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                JsonElement root = doc.RootElement;
                if (root.TryGetProperty("stages", out JsonElement stArr) && stArr.GetArrayLength() > 0)
                {
                    if (stArr[0].TryGetProperty("nearbySuspicionDelta", out JsonElement d1))
                    {
                        bundle.TrueFaceConfig.Stage1NearbySuspicionDelta = d1.GetInt32();
                    }
                }
                if (root.TryGetProperty("witnessCosts", out JsonElement wc))
                {
                    if (wc.TryGetProperty("witnessSuspicionSpike", out JsonElement ws)) bundle.TrueFaceConfig.WitnessSuspicionSpike = ws.GetInt32();
                    if (wc.TryGetProperty("spawnedRumorInitialStrength", out JsonElement sr)) bundle.TrueFaceConfig.SpawnedRumorInitialStrength = sr.GetDouble();
                    if (wc.TryGetProperty("groupTrustDelta", out JsonElement gt)) bundle.TrueFaceConfig.GroupTrustDelta = gt.GetInt32();
                }
            }
        }

        public static void ParseGigsJson(string jsonText, SimDataBundle bundle)
        {
            if (string.IsNullOrWhiteSpace(jsonText)) return;
            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                foreach (JsonElement el in doc.RootElement.EnumerateArray())
                {
                    SimGigDef g = new SimGigDef();
                    g.Id = el.GetProperty("id").GetString() ?? "";
                    g.GiverNpcId = el.GetProperty("giver").GetString() ?? "";
                    g.Title = el.GetProperty("title").GetString() ?? "";
                    g.TargetType = el.GetProperty("targetType").GetString() ?? "info";
                    g.RewardMon = el.GetProperty("rewardMon").GetInt32();
                    g.MoralWeight = el.GetProperty("moralWeight").GetDouble();
                    g.Visibility = el.GetProperty("visibility").GetString() ?? "Omote";
                    foreach (JsonElement loc in el.GetProperty("locations").EnumerateArray())
                    {
                        g.Locations.Add(loc.GetString() ?? "");
                    }
                    foreach (JsonElement ap in el.GetProperty("approaches").EnumerateArray())
                    {
                        g.Approaches.Add(ap.GetString() ?? "");
                    }
                    if (el.TryGetProperty("rippleTemplates", out JsonElement rpArr) && rpArr.GetArrayLength() > 0)
                    {
                        JsonElement r0 = rpArr[0];
                        if (r0.TryGetProperty("delayDays", out JsonElement dd)) g.RippleDelayDays = dd.GetInt32();
                        if (r0.TryGetProperty("actionCode", out JsonElement ac)) g.RippleActionCode = ac.GetString() ?? "gig_ripple_event";
                        if (r0.TryGetProperty("placeId", out JsonElement pl)) g.RipplePlaceId = pl.GetString() ?? "place_pasar";
                        if (r0.TryGetProperty("effect", out JsonElement ef)) g.RippleEffectSummary = ef.GetString() ?? "";
                    }
                    bundle.Gigs.Add(g);
                }
            }
        }

        public static void ParseMicroStoriesJson(string jsonText, SimDataBundle bundle)
        {
            if (string.IsNullOrWhiteSpace(jsonText)) return;
            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                foreach (JsonElement el in doc.RootElement.EnumerateArray())
                {
                    SimMicroStoryDef st = new SimMicroStoryDef();
                    st.Id = el.GetProperty("id").GetString() ?? "";
                    if (el.TryGetProperty("trigger", out JsonElement tr))
                    {
                        if (tr.TryGetProperty("conditionType", out JsonElement ct)) st.ConditionType = ct.GetString() ?? "";
                        if (tr.TryGetProperty("requiredPlaceId", out JsonElement rp)) st.RequiredPlaceId = rp.GetString() ?? "";
                        if (tr.TryGetProperty("primaryNpcId", out JsonElement p1)) st.PrimaryNpcId = p1.GetString() ?? "";
                        if (tr.TryGetProperty("secondaryNpcId", out JsonElement p2)) st.SecondaryNpcId = p2.GetString() ?? "";
                    }
                    if (el.TryGetProperty("beats", out JsonElement bArr) && bArr.GetArrayLength() > 0)
                    {
                        if (bArr[0].TryGetProperty("summary", out JsonElement sm)) st.Summary = sm.GetString() ?? "";
                    }
                    if (el.TryGetProperty("ripples", out JsonElement rArr) && rArr.GetArrayLength() > 0)
                    {
                        if (rArr[0].TryGetProperty("worldEffect", out JsonElement we)) st.WorldEffect = we.GetString() ?? "";
                    }
                    bundle.MicroStories.Add(st);
                }
            }
        }

        public static void ParseFestivalsJson(string jsonText, SimDataBundle bundle)
        {
            if (string.IsNullOrWhiteSpace(jsonText)) return;
            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                if (doc.RootElement.TryGetProperty("festivals", out JsonElement fArr))
                {
                    foreach (JsonElement el in fArr.EnumerateArray())
                    {
                        SimFestivalDef f = new SimFestivalDef();
                        f.Id = el.GetProperty("id").GetString() ?? "";
                        f.Day = el.GetProperty("day").GetInt32();
                        f.Season = el.GetProperty("season").GetString() ?? "Spring";
                        f.GatheringPlaceId = el.GetProperty("gatheringPlaceId").GetString() ?? "place_kuil_kecil";
                        f.TeaAndSweetsPriceMultiplier = el.GetProperty("teaAndSweetsPriceMultiplier").GetDouble();
                        f.ViolenceTabooMultiplier = el.GetProperty("violenceTabooMultiplier").GetInt32();
                        f.MasksAndNightGarbLegal = el.GetProperty("masksAndNightGarbLegal").GetBoolean();
                        f.SystemicRule = el.GetProperty("systemicRule").GetString() ?? "";
                        bundle.Festivals.Add(f);
                    }
                }
            }
        }

        public static SimDataBundle LoadDefaultBundle()
        {
            return LoadBundleWithCustomWeatherJson("");
        }

        public static SimSalienceConfig ParseSalienceJson(string jsonText)
        {
            SimSalienceConfig cfg = new SimSalienceConfig();
            if (string.IsNullOrWhiteSpace(jsonText)) return cfg;

            using (JsonDocument doc = JsonDocument.Parse(jsonText))
            {
                JsonElement root = doc.RootElement;
                if (root.TryGetProperty("weights", out JsonElement wObj))
                {
                    if (wObj.TryGetProperty("noveltyWeight", out JsonElement nw)) cfg.NoveltyWeight = nw.GetDouble();
                    if (wObj.TryGetProperty("expectationViolationWeight", out JsonElement ew)) cfg.ExpectationViolationWeight = ew.GetDouble();
                    if (wObj.TryGetProperty("stakesWeight", out JsonElement sw)) cfg.StakesWeight = sw.GetDouble();
                    if (wObj.TryGetProperty("secrecyWeight", out JsonElement secw)) cfg.SecrecyWeight = secw.GetDouble();
                    if (wObj.TryGetProperty("listenerProximityWeight", out JsonElement lpw)) cfg.ListenerProximityWeight = lpw.GetDouble();
                }
                if (root.TryGetProperty("thresholds", out JsonElement tObj))
                {
                    if (tObj.TryGetProperty("routineMaxSalience", out JsonElement rms)) cfg.RoutineMaxSalience = rms.GetDouble();
                    if (tObj.TryGetProperty("salientMinSalience", out JsonElement sms)) cfg.SalientMinSalience = sms.GetDouble();
                    if (tObj.TryGetProperty("highSalienceThreshold", out JsonElement hst)) cfg.HighSalienceThreshold = hst.GetDouble();
                    if (tObj.TryGetProperty("routineMaxHops", out JsonElement rmh)) cfg.RoutineMaxHops = rmh.GetInt32();
                    if (tObj.TryGetProperty("salientMaxHops", out JsonElement smh)) cfg.SalientMaxHops = smh.GetInt32();
                }
                if (root.TryGetProperty("decayPerDay", out JsonElement dObj))
                {
                    if (dObj.TryGetProperty("routineDecayPerDay", out JsonElement rdp)) cfg.RoutineDecayPerDay = rdp.GetDouble();
                    if (dObj.TryGetProperty("salientDecayPerDay", out JsonElement sdp)) cfg.SalientDecayPerDay = sdp.GetDouble();
                    if (dObj.TryGetProperty("highSalienceDecayPerDay", out JsonElement hdp)) cfg.HighSalienceDecayPerDay = hdp.GetDouble();
                }
                if (root.TryGetProperty("actionProfiles", out JsonElement apArr) && apArr.ValueKind == JsonValueKind.Array)
                {
                    foreach (JsonElement elem in apArr.EnumerateArray())
                    {
                        SimSalienceProfileDef p = new SimSalienceProfileDef();
                        if (elem.TryGetProperty("action", out JsonElement act)) p.Action = act.GetString() ?? "";
                        if (elem.TryGetProperty("isRoutine", out JsonElement ir)) p.IsRoutine = ir.GetBoolean();
                        if (elem.TryGetProperty("novelty", out JsonElement nov)) p.Novelty = nov.GetDouble();
                        if (elem.TryGetProperty("expectationViolation", out JsonElement ev)) p.ExpectationViolation = ev.GetDouble();
                        if (elem.TryGetProperty("stakes", out JsonElement stk)) p.Stakes = stk.GetDouble();
                        if (elem.TryGetProperty("secrecy", out JsonElement sec)) p.Secrecy = sec.GetDouble();
                        if (elem.TryGetProperty("baseSalience", out JsonElement bs)) p.BaseSalience = bs.GetDouble();
                        cfg.Profiles.Add(p);
                    }
                }
            }
            return cfg;
        }

        public static SimDataBundle LoadBundleWithCustomWeatherJson(string customWeatherJson)
        {
            SimDataBundle b = new SimDataBundle();
            string wText = customWeatherJson.Length > 0 ? customWeatherJson : ReadDataFileText("tuning/weather.json");
            b.WeatherConfig = ParseWeatherJson(wText);
            b.ClockConfig = ParseClockJson(ReadDataFileText("tuning/clock.json"));
            b.Places = ParsePlacesJson(ReadDataFileText("places/kurokawa_places.json"));
            b.Npcs = ParseNpcsJson(ReadDataFileText("npcs/kurokawa_npcs.json"));
            ParseClaimTemplatesAndMotivesJson(ReadDataFileText("rumors/claim_templates.json"), b);
            ParseWaresJson(ReadDataFileText("items/wares.json"), b);
            ParseGarmentsJson(ReadDataFileText("clothing/garments.json"), b);
            ParseGroupOrdersJson(ReadDataFileText("gigs/group_orders.json"), b);
            ParseTrueFaceJson(ReadDataFileText("tuning/true_face.json"), b);
            ParseGigsJson(ReadDataFileText("gigs/kurokawa_gigs.json"), b);
            ParseMicroStoriesJson(ReadDataFileText("stories/micro_stories.json"), b);
            ParseFestivalsJson(ReadDataFileText("festivals/kurokawa_festivals.json"), b);
            b.SalienceConfig = ParseSalienceJson(ReadDataFileText("tuning/salience.json"));
            return b;
        }
    }

    public sealed class SystemTextJsonSimDataSource : ISimDataSource
    {
        public SimDataBundle LoadBundle()
        {
            return SimJsonDataLoader.LoadDefaultBundle();
        }
    }
}
