// KAGE-ANA v3.0 Gelombang D (Butir 8) — Modul 8: Evaluasi Kecurigaan Sosial, Pakaian, Noda Darah/Bau, & Zona Terbatas
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimSuspicionSystem
    {
        public static void EvaluateHourlySocialSuspicion(
            SimEventBus bus,
            int day,
            int hour,
            string segment,
            SimPlaceGraphSystem world)
        {
            if (world.SoumaIsInTransit) return;

            int sPlace = world.SoumaCurrentPlaceIdx;
            SimPlaceDef place = world.Places[sPlace];
            SimGarmentDef garm = world.Data.Garments.Count > 0 ? world.Data.Garments[world.ActiveGarmentIdx] : new SimGarmentDef();
            SimWareDef ware = world.Data.Wares.Count > 0 ? world.Data.Wares[world.ActiveWareIdx] : new SimWareDef();

            bool isNight = (segment == "Night" || segment == "LateNight" || hour < 5 || hour >= 20);
            bool masksLegalToday = SimFestivalSystem.IsCurrentFestivalMasksAndNightGarbLegal(bus, day);

            bool wareMatchesAccess = false;
            for (int a = 0; a < ware.AccessPlaces.Count; a++)
            {
                if (ware.AccessPlaces[a] == place.Id)
                {
                    wareMatchesAccess = true;
                    break;
                }
            }

            for (int n = 0; n < world.Agents.Count; n++)
            {
                NpcRuntimeState ag = world.Agents[n];
                if (ag.IsDead || ag.IsSleeping || ag.IsInTransit) continue;
                if (ag.CurrentPlaceIdx != sPlace) continue;

                if (world.BloodStainLevel > 15 && world.ActiveOdor != "FishSalt")
                {
                    world.AddSuspicionReason(n, 18, "Melihat noda darah pada pakaian Soma (" + world.BloodStainLevel.ToString() + "%) di " + place.Name);
                }

                if (place.IsRestrictedZone && !wareMatchesAccess && !world.GrantedRestrictedAccessToday)
                {
                    world.AddSuspicionReason(n, 16, "Soma berada di area terbatas (" + place.Name + ") tanpa dagangan yang dibutuhkan");
                }

                if (isNight && garm.NightSuspicionMod > 0 && ag.RoleCategory == "Guard" && !masksLegalToday)
                {
                    world.AddSuspicionReason(n, garm.NightSuspicionMod, "Berjalan malam hari memakai " + garm.Name + " di dekat penjaga " + ag.DisplayName);
                }
            }
        }
    }
}
