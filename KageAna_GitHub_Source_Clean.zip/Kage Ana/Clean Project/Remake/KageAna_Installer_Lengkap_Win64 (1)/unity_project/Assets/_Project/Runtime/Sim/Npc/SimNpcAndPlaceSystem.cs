// KAGE-ANA v3.0 — Data-Driven Place Graph, 26 Canonical NPCs, ISoumaPolicy, L4-L8 World State (A2, A3, Gelombang B & C)
// Pure C# in Runtime/Sim (Decision C-07). Zero hardcoded NPC arrays or NpcCount constants.
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public sealed class NpcRuntimeState
    {
        public string Id;
        public string DisplayName;
        public string Role;
        public string RoleCategory;
        public int HomePlaceIdx;

        public int Friendliness;
        public int SuspicionTrait;
        public int Courage;
        public int GossipTrait;
        public int Greed;
        public string SpeechHabit;
        public string SecretId;

        public int ActiveBlockIdx;
        public int PreviousBlockIdx;
        public bool ScheduleTransitionedThisHour;
        public int TransitionFromPlaceIdx;
        public int CurrentPlaceIdx;
        public int TargetPlaceIdx;
        public int TransitFromPlaceIdx;
        public int TransitToPlaceIdx;
        public bool IsInTransit;
        public int TransitElapsedMinutes;
        public int TransitTotalMinutes;
        public string TransitRouteType;
        public double PosX;
        public double PosY;

        public string CurrentActivity;
        public bool IsSleeping;
        public bool IsInterrupted;
        public string InterruptType;
        public string WhyHereReason;

        public string AwarenessState; // Tenang, Penasaran, Curiga, Waspada, Panik
        public int SuspicionTowardSouma; // 0..100
        public int FamiliarityWithSouma; // 0..100
        public List<string> WhySuspiciousReasons;

        public string LodLevel; // L0_Full, L1_Light, L2_Abstract
        public double DistanceToSouma;
        public bool IsDead;
        public int NpcMon;
        public int LastInteractionDay;
        public int LastInteractionHour;
        public int DailyInteractionsCount;
        public int TotalInteractionsCount;
        public int LastAgencyActionDay;
        public string AttitudeTowardSouma;

        // Gelombang E (E2.1 & E2.2): Data-Driven Duties, Social Drives, Relationships & Anti-Filler Tracking
        public int AssignedPostPlaceIdx;
        public List<string> Duties;
        public SimSocialDrivesDef SocialDrives;
        public List<SimNpcRelationDef> Relationships;
        public int NeedPay;
        public int NeedTalk;
        public int NeedTrade;
        public int NeedRest;
        public int Curiosity;
        public int Grudge;
        public int Affection;
        public int DutyDrive;
        public List<string> InteractedPartnersToday;
        public List<string>DistinctActionsEmitted;
        public List<int> DistinctActionCounts;
        public bool HasNewTriggerSinceLastSocial;
        public string LastTriggerReason;

        public NpcRuntimeState()
        {
            Id = "";
            DisplayName = "";
            Role = "";
            RoleCategory = "Resident";
            HomePlaceIdx = 0;
            Friendliness = 5;
            SuspicionTrait = 5;
            Courage = 5;
            GossipTrait = 5;
            Greed = 5;
            SpeechHabit = "";
            SecretId = "";

            ActiveBlockIdx = 0;
            PreviousBlockIdx = 0;
            ScheduleTransitionedThisHour = false;
            TransitionFromPlaceIdx = 0;
            CurrentPlaceIdx = 0;
            TargetPlaceIdx = 0;
            TransitFromPlaceIdx = 0;
            TransitToPlaceIdx = 0;
            IsInTransit = false;
            TransitElapsedMinutes = 0;
            TransitTotalMinutes = 0;
            TransitRouteType = "jalan_utama";
            PosX = 0.0;
            PosY = 0.0;

            CurrentActivity = "Tidur";
            IsSleeping = true;
            IsInterrupted = false;
            InterruptType = "";
            WhyHereReason = "";

            AwarenessState = "Tenang";
            SuspicionTowardSouma = 0;
            FamiliarityWithSouma = 10;
            WhySuspiciousReasons = new List<string>();

            LodLevel = "L0_Full";
            DistanceToSouma = 0.0;
            IsDead = false;
            NpcMon = 100;
            LastInteractionDay = 0;
            LastInteractionHour = -1;
            DailyInteractionsCount = 0;
            TotalInteractionsCount = 0;
            LastAgencyActionDay = 0;
            AttitudeTowardSouma = "Biasa";

            AssignedPostPlaceIdx = 0;
            Duties = new List<string>();
            SocialDrives = new SimSocialDrivesDef();
            Relationships = new List<SimNpcRelationDef>();
            NeedPay = 5;
            NeedTalk = 5;
            NeedTrade = 5;
            NeedRest = 4;
            Curiosity = 5;
            Grudge = 2;
            Affection = 5;
            DutyDrive = 6;
            InteractedPartnersToday = new List<string>();
            DistinctActionsEmitted = new List<string>();
            DistinctActionCounts = new List<int>();
            HasNewTriggerSinceLastSocial = true;
            LastTriggerReason = "JadwalPagi";
        }

        public void RecordActionForEntropy(string actionCode)
        {
            for (int i = 0; i < DistinctActionsEmitted.Count; i++)
            {
                if (DistinctActionsEmitted[i] == actionCode)
                {
                    DistinctActionCounts[i] = DistinctActionCounts[i] + 1;
                    return;
                }
            }
            DistinctActionsEmitted.Add(actionCode);
            DistinctActionCounts.Add(1);
        }
    }

    public sealed class SimPlaceGraphSystem
    {
        public SimDataBundle Data;
        public List<SimPlaceDef> Places;
        public List<SimNpcDef> NpcDefs;
        public List<NpcRuntimeState> Agents;

        public int[] DirectEdgeMinutes;
        public int[] ShortestMinutes;
        public int[] NextHopIndex;
        public string[] EdgeRouteTypes;
        public bool[] GuardPostVacant; // A3-2: True when a guard post has been left vacant!

        // A3-3: Pluggable Souma Policy ("Idle", "HonestTrader", "TraderInformant", "RecklessLoud")
        public string ActiveSoumaPolicy;

        // Souma (Protagonist) State
        public int SoumaCurrentPlaceIdx;
        public int SoumaTargetPlaceIdx;
        public bool SoumaIsInTransit;
        public int SoumaTransitElapsedMinutes;
        public int SoumaTransitTotalMinutes;
        public double SoumaPosX;
        public double SoumaPosY;
        public string SoumaCurrentActivity;
        public string SoumaWhyHereReason;
        public bool SoumaManualOverride;

        // L4: Social Suspicion, Physical Traces, Garments, & Nagaya Room
        public int ActiveGarmentIdx;
        public string ActiveGarmentId;
        public int BloodStainLevel; // 0..100
        public string ActiveOdor;   // "None", "Medicine", "FishSalt", "Blood"
        public int WoundCount;
        public int FatigueLevel;    // 0..100
        public int TimesSleptInNagaya;
        public bool GrantedRestrictedAccessToday;
        public string GrantedAccessPlaceId;

        // L5 & A3-3: Economy, 8 Rotating Wares, Honest Unfiltered Yield Tracking, Group Orders & Group Trust
        public int SoumaMon;
        public int InitialCapitalLoanMon;
        public int TotalRevenueMon;
        public int TotalExpensesMon;
        public int TotalRentPaidToOhanaMon;
        public int UnpaidRentDebtMon;
        public int UnpaidRentWeeks;
        public int MissedGroupOrderCount;
        public bool GroupSupplyLineCut;
        // Gelombang E (E2.3): Group Trust Recovery State Machine
        public string GroupContactState; // "Aktif", "KontakTerputus", "UjianKesetiaan", "DipercayaKembali"
        public int LoyaltyTrialCompletedCount;
        public bool ReTrustedWithCautionFlag;
        public string AvailableRecoveryAction;
        public int RoutineTradeHeartGainsThisWeek;
        public bool HasZaLicense;
        public int ActiveWareIdx;
        public int CarryUnits;
        public int[] WareCategoryTradesCount;
        public int[] WareCategoryYieldsCount;
        public int TotalTradesExecuted;
        public int TradesYieldingKabarOrAccess;
        public int TradesYieldingKabarCount;
        public int TradesYieldingAccessCount;
        public int GroupTrust; // 0..100
        public List<string> CompletedGroupOrderIds;
        public int DeadDropReportsDelivered;
        public int MinMonObserved;
        public int MaxMonObserved;

        // L6: Heart (Warm<->Cold), Violence Mode, Corpses, Crackdown (Razia), True Face (Wajah Asli 3 Stages)
        public int HeartWarmCold; // -100 (Dingin) .. +100 (Hangat)
        public string ViolenceMode; // "Off", "Low", "High"
        public int TrueFaceStage; // 0=Omote, 1=Retak, 2=Terbuka, 3=Menghilang
        public int TrueFaceActivationsCount;
        public bool DistrictCrackdownActive;
        public int CrackdownHoursRemaining;
        public List<CorpseRecord> Corpses;

        // L7 & L8: Gigs, Pending Gig Ripples, Conditional Micro-Stories, Aspirations, Systemic Festivals
        public List<string> CompletedGigIds;
        public List<PendingGigRipple> PendingGigRipples;
        public List<string> TriggeredMicroStoryIds;
        public string ActiveAspirationId;
        public int AspirationProgressScore; // 0..100
        public double MarketPriceMultiplier;

        public SimPlaceGraphSystem(SimDataBundle bundle)
        {
            Data = bundle;
            Places = bundle.Places;
            NpcDefs = bundle.Npcs;
            Agents = new List<NpcRuntimeState>();
            ActiveSoumaPolicy = "TraderInformant";

            int pCount = Places.Count;
            int matSize = pCount * pCount;
            DirectEdgeMinutes = new int[matSize];
            ShortestMinutes = new int[matSize];
            NextHopIndex = new int[matSize];
            EdgeRouteTypes = new string[matSize];
            GuardPostVacant = new bool[pCount > 0 ? pCount : 12];

            BuildPlaceGraphMatrices();
            BuildNpcRuntimeAgents();

            int wCount = bundle.Wares.Count > 0 ? bundle.Wares.Count : 8;
            WareCategoryTradesCount = new int[wCount];
            WareCategoryYieldsCount = new int[wCount];
            CompletedGroupOrderIds = new List<string>();
            Corpses = new List<CorpseRecord>();
            CompletedGigIds = new List<string>();
            PendingGigRipples = new List<PendingGigRipple>();
            TriggeredMicroStoryIds = new List<string>();
            ActiveAspirationId = "Aspirasi_Pedagang_Dan_Pengumpul_Kabar";
            AspirationProgressScore = 20;
            MarketPriceMultiplier = 1.0;

            ResetPositionsAtHour(5, 0);
        }

        private void BuildPlaceGraphMatrices()
        {
            int n = Places.Count;
            for (int i = 0; i < n * n; i++)
            {
                DirectEdgeMinutes[i] = 9999;
                ShortestMinutes[i] = 9999;
                NextHopIndex[i] = -1;
                EdgeRouteTypes[i] = "jalan_utama";
            }

            for (int i = 0; i < n; i++)
            {
                SimPlaceDef p = Places[i];
                for (int e = 0; e < p.Neighbors.Count; e++)
                {
                    SimNeighborEdge nb = p.Neighbors[e];
                    int j = FindPlaceIndexById(nb.ToPlaceId);
                    if (j >= 0)
                    {
                        DirectEdgeMinutes[i * n + j] = nb.TravelMinutes;
                        EdgeRouteTypes[i * n + j] = nb.RouteType;
                        if (DirectEdgeMinutes[j * n + i] >= 9999)
                        {
                            DirectEdgeMinutes[j * n + i] = nb.TravelMinutes;
                            EdgeRouteTypes[j * n + i] = nb.RouteType;
                        }
                    }
                }
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    int idx = i * n + j;
                    if (i == j)
                    {
                        ShortestMinutes[idx] = 0;
                        NextHopIndex[idx] = i;
                    }
                    else if (DirectEdgeMinutes[idx] < 9999)
                    {
                        ShortestMinutes[idx] = DirectEdgeMinutes[idx];
                        NextHopIndex[idx] = j;
                    }
                }
            }

            for (int k = 0; k < n; k++)
            {
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        int ik = ShortestMinutes[i * n + k];
                        int kj = ShortestMinutes[k * n + j];
                        int ij = ShortestMinutes[i * n + j];
                        if (ik + kj < ij)
                        {
                            ShortestMinutes[i * n + j] = ik + kj;
                            NextHopIndex[i * n + j] = NextHopIndex[i * n + k];
                        }
                    }
                }
            }
        }

        private void BuildNpcRuntimeAgents()
        {
            Agents.Clear();
            for (int i = 0; i < NpcDefs.Count; i++)
            {
                SimNpcDef def = NpcDefs[i];
                NpcRuntimeState st = new NpcRuntimeState();
                st.Id = def.Id;
                st.DisplayName = def.DisplayName;
                st.Role = def.Role;
                st.RoleCategory = def.RoleCategory;
                st.HomePlaceIdx = FindPlaceIndexById(def.HomePlaceId);
                if (st.HomePlaceIdx < 0) st.HomePlaceIdx = 0;
                st.Friendliness = def.Friendliness;
                st.SuspicionTrait = def.Suspicion;
                st.Courage = def.Courage;
                st.GossipTrait = def.Gossip;
                st.Greed = def.Greed;
                st.SpeechHabit = def.SpeechHabit;
                st.SecretId = def.SecretId;
                st.NpcMon = 100 + def.Greed * 15;
                st.AssignedPostPlaceIdx = FindPlaceIndexById(def.AssignedPostPlaceId);
                if (st.AssignedPostPlaceIdx < 0) st.AssignedPostPlaceIdx = st.HomePlaceIdx;
                st.Duties = def.Duties;
                st.SocialDrives = def.SocialDrives;
                st.Relationships = def.Relationships;
                st.NeedPay = def.SocialDrives.PerluBayar;
                st.NeedTalk = def.SocialDrives.PerluBicara;
                st.NeedTrade = def.SocialDrives.PerluDagang;
                st.NeedRest = def.SocialDrives.PerluIstirahat;
                st.Curiosity = def.SocialDrives.RasaPenasaran;
                st.Grudge = def.SocialDrives.Dendam;
                st.Affection = def.SocialDrives.KasihSayang;
                st.DutyDrive = def.SocialDrives.TugasJadwal;
                Agents.Add(st);
            }
        }

        public int FindPlaceIndexById(string placeId)
        {
            for (int i = 0; i < Places.Count; i++)
            {
                if (Places[i].Id == placeId) return i;
            }
            return -1;
        }

        public int FindNpcIndexById(string npcId)
        {
            for (int i = 0; i < Agents.Count; i++)
            {
                if (Agents[i].Id == npcId) return i;
                if (npcId.Length > 4 && npcId[0] == 'n' && npcId[3] == '_' && ("npc_" + Agents[i].Id) == npcId) return i;
            }
            return -1;
        }

        public bool NpcHasDuty(int npcIdx, string dutyCode)
        {
            if (npcIdx < 0 || npcIdx >= Agents.Count) return false;
            List<string> dList = Agents[npcIdx].Duties;
            for (int i = 0; i < dList.Count; i++)
            {
                if (dList[i] == dutyCode) return true;
            }
            return false;
        }

        public int FindNpcIndexByDuty(string dutyCode)
        {
            for (int i = 0; i < Agents.Count; i++)
            {
                if (!Agents[i].IsDead && NpcHasDuty(i, dutyCode)) return i;
            }
            return -1;
        }

        public int FindActiveNpcIndexByRoleCategory(string roleCat)
        {
            for (int i = 0; i < Agents.Count; i++)
            {
                if (!Agents[i].IsDead && !Agents[i].IsSleeping && Agents[i].RoleCategory == roleCat) return i;
            }
            for (int i = 0; i < Agents.Count; i++)
            {
                if (!Agents[i].IsDead && Agents[i].RoleCategory == roleCat) return i;
            }
            return -1;
        }

        public SimNpcRelationDef FindRelationBetween(int fromIdx, int toIdx)
        {
            if (fromIdx >= 0 && fromIdx < Agents.Count && toIdx >= 0 && toIdx < Agents.Count)
            {
                string targetId = Agents[toIdx].Id;
                List<SimNpcRelationDef> rels = Agents[fromIdx].Relationships;
                for (int i = 0; i < rels.Count; i++)
                {
                    if (rels[i].TargetId == targetId) return rels[i];
                }
            }
            SimNpcRelationDef stranger = new SimNpcRelationDef();
            if (toIdx >= 0 && toIdx < Agents.Count) stranger.TargetId = Agents[toIdx].Id;
            stranger.RelationType = "asing";
            stranger.Closeness = 2;
            stranger.GrudgeLevel = 0;
            stranger.DebtMon = 0;
            stranger.Note = "Kenalan luar / orang asing di tempat umum";
            return stranger;
        }

        public static string FormatMinutesAsHHMM(int totalMin)
        {
            int h = (totalMin / 60) % 24;
            int m = totalMin % 60;
            string hs = h < 10 ? ("0" + h.ToString()) : h.ToString();
            string ms = m < 10 ? ("0" + m.ToString()) : m.ToString();
            return hs + ":" + ms;
        }

        public int FindScheduleBlockForMinute(int npcIdx, int minuteOfDay)
        {
            List<SimScheduleBlockDef> sched = NpcDefs[npcIdx].Schedule;
            for (int b = 0; b < sched.Count; b++)
            {
                if (minuteOfDay >= sched[b].FromMinutes && minuteOfDay < sched[b].ToMinutes)
                {
                    return b;
                }
            }
            return sched.Count > 0 ? (sched.Count - 1) : 0;
        }

        private string FormatScheduledWhyHere(int npcIdx, int blkIdx, int placeIdx)
        {
            SimScheduleBlockDef blk = NpcDefs[npcIdx].Schedule[blkIdx];
            string fromStr = FormatMinutesAsHHMM(blk.FromMinutes);
            string toStr = FormatMinutesAsHHMM(blk.ToMinutes);
            return "Jadwal " + fromStr + "-" + toStr + ": " + blk.Activity + " di " + Places[placeIdx].Name;
        }

        public void ResetPositionsAtHour(int hour, int minute)
        {
            int dayMinutes = hour * 60 + minute;
            int nagayaIdx = FindPlaceIndexById("place_nagaya");
            if (nagayaIdx < 0) nagayaIdx = 0;

            SoumaCurrentPlaceIdx = nagayaIdx;
            SoumaTargetPlaceIdx = nagayaIdx;
            SoumaIsInTransit = false;
            SoumaTransitElapsedMinutes = 0;
            SoumaTransitTotalMinutes = 0;
            SoumaPosX = (double)Places[nagayaIdx].MapX;
            SoumaPosY = (double)Places[nagayaIdx].MapY;
            SoumaCurrentActivity = "SiapkanKotakPikulDagang";
            SoumaWhyHereReason = "Bangun fajar di Kamar Sewa Nagaya milik O-Hana dan menyiapkan kotak pikul dagangan.";
            SoumaManualOverride = false;

            ActiveGarmentIdx = 0;
            ActiveGarmentId = Data.Garments.Count > 0 ? Data.Garments[0].Id : "garment_pedagang_caping";
            BloodStainLevel = 0;
            ActiveOdor = "None";
            WoundCount = 0;
            FatigueLevel = 0;
            TimesSleptInNagaya = 0;
            GrantedRestrictedAccessToday = false;
            GrantedAccessPlaceId = "";

            SoumaMon = 240;
            InitialCapitalLoanMon = 240;
            TotalRevenueMon = 0;
            TotalExpensesMon = 0;
            TotalRentPaidToOhanaMon = 0;
            UnpaidRentDebtMon = 0;
            UnpaidRentWeeks = 0;
            MissedGroupOrderCount = 0;
            GroupSupplyLineCut = false;
            GroupContactState = "Aktif";
            LoyaltyTrialCompletedCount = 0;
            ReTrustedWithCautionFlag = false;
            AvailableRecoveryAction = "Jalur aktif: antarkan laporan Kabar mingguan ke titik serah hutan.";
            RoutineTradeHeartGainsThisWeek = 0;
            HasZaLicense = false;
            ActiveWareIdx = 0;
            CarryUnits = 6;
            for (int w = 0; w < WareCategoryTradesCount.Length; w++)
            {
                WareCategoryTradesCount[w] = 0;
                WareCategoryYieldsCount[w] = 0;
            }
            TotalTradesExecuted = 0;
            TradesYieldingKabarOrAccess = 0;
            TradesYieldingKabarCount = 0;
            TradesYieldingAccessCount = 0;
            GroupTrust = 65;
            CompletedGroupOrderIds.Clear();
            DeadDropReportsDelivered = 0;
            MinMonObserved = SoumaMon;
            MaxMonObserved = SoumaMon;

            HeartWarmCold = 10;
            ViolenceMode = "Low";
            TrueFaceStage = 0;
            TrueFaceActivationsCount = 0;
            DistrictCrackdownActive = false;
            CrackdownHoursRemaining = 0;
            Corpses.Clear();
            CompletedGigIds.Clear();
            PendingGigRipples.Clear();
            TriggeredMicroStoryIds.Clear();
            ActiveAspirationId = "Aspirasi_Pedagang_Dan_Pengumpul_Kabar";
            AspirationProgressScore = 20;
            MarketPriceMultiplier = 1.0;

            for (int p = 0; p < GuardPostVacant.Length; p++)
            {
                GuardPostVacant[p] = false;
            }

            for (int i = 0; i < Agents.Count; i++)
            {
                NpcRuntimeState ag = Agents[i];
                int blkIdx = FindScheduleBlockForMinute(i, dayMinutes);
                int pIdx = FindPlaceIndexById(NpcDefs[i].Schedule[blkIdx].PlaceId);
                if (pIdx < 0) pIdx = ag.HomePlaceIdx;

                ag.ActiveBlockIdx = blkIdx;
                ag.PreviousBlockIdx = blkIdx;
                ag.ScheduleTransitionedThisHour = false;
                ag.TransitionFromPlaceIdx = pIdx;
                ag.CurrentPlaceIdx = pIdx;
                ag.TargetPlaceIdx = pIdx;
                ag.TransitFromPlaceIdx = pIdx;
                ag.TransitToPlaceIdx = pIdx;
                ag.IsInTransit = false;
                ag.TransitElapsedMinutes = 0;
                ag.TransitTotalMinutes = 0;
                ag.TransitRouteType = "jalan_utama";
                ag.PosX = (double)Places[pIdx].MapX;
                ag.PosY = (double)Places[pIdx].MapY;
                ag.CurrentActivity = NpcDefs[i].Schedule[blkIdx].Activity;
                ag.IsSleeping = (hour < 5 || hour >= 23);
                ag.IsInterrupted = false;
                ag.InterruptType = "";
                ag.WhyHereReason = FormatScheduledWhyHere(i, blkIdx, pIdx);
                ag.AwarenessState = "Tenang";
                ag.SuspicionTowardSouma = 0;
                ag.FamiliarityWithSouma = 12;
                ag.WhySuspiciousReasons.Clear();
                ag.LodLevel = "L0_Full";
                ag.DistanceToSouma = 0.0;
                ag.IsDead = false;
                ag.NpcMon = 100 + NpcDefs[i].Greed * 15;
                ag.LastInteractionDay = 0;
                ag.LastInteractionHour = -1;
                ag.NeedPay = NpcDefs[i].SocialDrives.PerluBayar;
                ag.NeedTalk = NpcDefs[i].SocialDrives.PerluBicara;
                ag.NeedTrade = NpcDefs[i].SocialDrives.PerluDagang;
                ag.NeedRest = NpcDefs[i].SocialDrives.PerluIstirahat;
                ag.Curiosity = NpcDefs[i].SocialDrives.RasaPenasaran;
                ag.Grudge = NpcDefs[i].SocialDrives.Dendam;
                ag.Affection = NpcDefs[i].SocialDrives.KasihSayang;
                ag.DutyDrive = NpcDefs[i].SocialDrives.TugasJadwal;
                ag.InteractedPartnersToday.Clear();
                ag.DistinctActionsEmitted.Clear();
                ag.DistinctActionCounts.Clear();
                ag.HasNewTriggerSinceLastSocial = true;
                ag.LastTriggerReason = "JadwalPagi";
            }
            UpdateAllNpcLodLevels();
        }

        public void AddSuspicionReason(int npcIdx, int delta, string reason)
        {
            if (npcIdx < 0 || npcIdx >= Agents.Count) return;
            NpcRuntimeState ag = Agents[npcIdx];
            if (ag.IsDead) return;

            int nextVal = ag.SuspicionTowardSouma + delta;
            if (nextVal < 0) nextVal = 0;
            if (nextVal > 100) nextVal = 100;
            ag.SuspicionTowardSouma = nextVal;

            if (delta > 0 && reason.Length > 0)
            {
                bool exists = false;
                for (int i = 0; i < ag.WhySuspiciousReasons.Count; i++)
                {
                    if (ag.WhySuspiciousReasons[i] == reason)
                    {
                        exists = true;
                        break;
                    }
                }
                if (!exists)
                {
                    ag.WhySuspiciousReasons.Add(reason);
                }
            }

            if (ag.SuspicionTowardSouma >= 70) ag.AwarenessState = "Waspada";
            else if (ag.SuspicionTowardSouma >= 35) ag.AwarenessState = "Curiga";
            else if (ag.SuspicionTowardSouma >= 15) ag.AwarenessState = "Penasaran";
            else ag.AwarenessState = "Tenang";
        }

        public void UpdateMonBounds()
        {
            if (SoumaMon < MinMonObserved) MinMonObserved = SoumaMon;
            if (SoumaMon > MaxMonObserved) MaxMonObserved = SoumaMon;
        }

        public void MoveSoumaByWasdDelta(double dx, double dy)
        {
            SoumaManualOverride = true;
            SoumaPosX += dx;
            SoumaPosY += dy;
            if (SoumaPosX < -240.0) SoumaPosX = -240.0;
            if (SoumaPosX > 240.0) SoumaPosX = 240.0;
            if (SoumaPosY < -240.0) SoumaPosY = -240.0;
            if (SoumaPosY > 240.0) SoumaPosY = 240.0;

            int nearestIdx = SoumaCurrentPlaceIdx;
            double bestDist = 999999.0;
            for (int i = 0; i < Places.Count; i++)
            {
                double pdx = (double)Places[i].MapX - SoumaPosX;
                double pdy = (double)Places[i].MapY - SoumaPosY;
                double d = Math.Sqrt(pdx * pdx + pdy * pdy);
                if (d < bestDist)
                {
                    bestDist = d;
                    nearestIdx = i;
                }
            }
            if (bestDist <= 38.0)
            {
                SoumaCurrentPlaceIdx = nearestIdx;
                SoumaTargetPlaceIdx = nearestIdx;
                SoumaIsInTransit = false;
                SoumaCurrentActivity = "BergerakWASD_Di_" + Places[nearestIdx].Id;
                SoumaWhyHereReason = "Digerakkan pemain (WASD) di sekitar " + Places[nearestIdx].Name + ".";
            }
            else
            {
                SoumaIsInTransit = true;
                SoumaCurrentActivity = "BerjalanWASD";
                SoumaWhyHereReason = "Digerakkan pemain (WASD) melintasi jalur lembah menuju " + Places[nearestIdx].Name + ".";
            }
            UpdateAllNpcLodLevels();
        }

        public void CommandSoumaMoveToPlace(int targetPlaceIdx, string reason)
        {
            if (targetPlaceIdx < 0 || targetPlaceIdx >= Places.Count) return;
            SoumaManualOverride = true;
            SoumaTargetPlaceIdx = targetPlaceIdx;
            int pCount = Places.Count;
            if (SoumaCurrentPlaceIdx != targetPlaceIdx)
            {
                int hop = NextHopIndex[SoumaCurrentPlaceIdx * pCount + targetPlaceIdx];
                if (hop < 0) hop = targetPlaceIdx;
                int mins = DirectEdgeMinutes[SoumaCurrentPlaceIdx * pCount + hop];
                if (mins >= 9999) mins = 10;
                SoumaIsInTransit = true;
                SoumaTransitElapsedMinutes = 0;
                SoumaTransitTotalMinutes = mins;
                SoumaCurrentActivity = "BerjalanKe_" + Places[targetPlaceIdx].Id;
                SoumaWhyHereReason = reason;
            }
            else
            {
                SoumaIsInTransit = false;
                SoumaPosX = (double)Places[targetPlaceIdx].MapX;
                SoumaPosY = (double)Places[targetPlaceIdx].MapY;
                SoumaCurrentActivity = "MengamatiDanBerdagang";
                SoumaWhyHereReason = reason;
            }
            UpdateAllNpcLodLevels();
        }

        public void SelectWareCategory(int wareIdx)
        {
            if (Data.Wares.Count == 0) return;
            int idx = wareIdx % Data.Wares.Count;
            if (idx < 0) idx = 0;
            ActiveWareIdx = idx;
            SimWareDef w = Data.Wares[idx];
            if (w.OdorTag == "FishSalt")
            {
                ActiveOdor = "FishSalt";
            }
            else if (w.OdorTag == "Medicine")
            {
                ActiveOdor = "Medicine";
            }
            else if (BloodStainLevel > 20)
            {
                ActiveOdor = "Blood";
            }
            else
            {
                ActiveOdor = "None";
            }
        }

        public void SelectGarment(int garmentIdx)
        {
            if (Data.Garments.Count == 0) return;
            int idx = garmentIdx % Data.Garments.Count;
            if (idx < 0) idx = 0;
            ActiveGarmentIdx = idx;
            ActiveGarmentId = Data.Garments[idx].Id;
        }

        // A3-2: Real state effect when a guard leaves their post early!
        public void LeaveGuardPostEarly(int guardNpcIdx, int postPlaceIdx, int destPlaceIdx, string reason)
        {
            if (postPlaceIdx >= 0 && postPlaceIdx < GuardPostVacant.Length)
            {
                GuardPostVacant[postPlaceIdx] = true;
            }
            if (guardNpcIdx >= 0 && guardNpcIdx < Agents.Count && destPlaceIdx >= 0 && destPlaceIdx < Places.Count)
            {
                NpcRuntimeState ag = Agents[guardNpcIdx];
                ag.CurrentPlaceIdx = destPlaceIdx;
                ag.TargetPlaceIdx = destPlaceIdx;
                ag.IsInTransit = false;
                ag.PosX = (double)Places[destPlaceIdx].MapX;
                ag.PosY = (double)Places[destPlaceIdx].MapY;
                ag.CurrentActivity = "TinggalkanPosKe_" + Places[destPlaceIdx].Id;
                ag.WhyHereReason = reason;
            }
        }

        public void UpdateAllNpcLodLevels()
        {
            for (int i = 0; i < Agents.Count; i++)
            {
                NpcRuntimeState ag = Agents[i];
                double dx = ag.PosX - SoumaPosX;
                double dy = ag.PosY - SoumaPosY;
                double dist = Math.Sqrt(dx * dx + dy * dy);
                ag.DistanceToSouma = dist;

                if (dist <= 40.0) ag.LodLevel = "L0_Full";
                else if (dist <= 120.0) ag.LodLevel = "L1_Light";
                else ag.LodLevel = "L2_Abstract";
            }
        }

        // A3-3: Pluggable Souma Policy Movement & Daily Preparation
        private void UpdateSoumaPolicyMovement(ulong seed, int day, int hour, int minute, string weather)
        {
            if (SoumaManualOverride) return;
            int pCount = Places.Count;
            if (pCount == 0) return;

            // Policy 1: Idle (Souma stays at Nagaya room all day)
            if (ActiveSoumaPolicy == "Idle")
            {
                int nagIdx = FindPlaceIndexById("place_nagaya");
                if (nagIdx < 0) nagIdx = 0;
                SoumaCurrentPlaceIdx = nagIdx;
                SoumaTargetPlaceIdx = nagIdx;
                SoumaIsInTransit = false;
                SoumaPosX = (double)Places[nagIdx].MapX;
                SoumaPosY = (double)Places[nagIdx].MapY;
                SoumaCurrentActivity = "DiamDiKamarNagaya";
                SoumaWhyHereReason = "Kebijakan Idle: Soma tetap berdiam di kamar sewa Nagaya sepanjang hari.";
                return;
            }

            if (hour == 6 && minute == 0 && Data.Wares.Count > 0)
            {
                int chosenWare = (day - 1) % Data.Wares.Count;
                if (!HasZaLicense && Data.Wares[chosenWare].RequiresZaLicense && ActiveSoumaPolicy == "HonestTrader")
                {
                    chosenWare = 0; // HonestTrader waits until Za license is bought before trading Za-restricted wares at Market
                }
                SelectWareCategory(chosenWare);

                SimWareDef w = Data.Wares[ActiveWareIdx];
                if (CarryUnits < 4 && SoumaMon >= w.BaseCapitalMon + 50)
                {
                    SoumaMon -= w.BaseCapitalMon;
                    TotalExpensesMon += w.BaseCapitalMon;
                    CarryUnits = w.MaxCarryUnits;
                    UpdateMonBounds();
                }

                if (!HasZaLicense && SoumaMon >= 360)
                {
                    HasZaLicense = true;
                    SoumaMon -= 120;
                    TotalExpensesMon += 120;
                    UpdateMonBounds();
                }
            }

            if (ActiveSoumaPolicy == "HonestTrader") SelectGarment(0);
            else if (hour >= 6 && hour < 20) SelectGarment(0);
            else SelectGarment(1);

            SimWareDef curWare = Data.Wares.Count > 0 ? Data.Wares[ActiveWareIdx] : new SimWareDef();
            int desiredPlace = FindPlaceIndexById("place_nagaya");
            string act = "IstirahatKamarSewa";
            string why = "Menginap di Kamar Sewa Nagaya dan menyusun Papan Tinta.";

            if (ActiveSoumaPolicy == "RecklessLoud")
            {
                if (hour >= 8 && hour < 14)
                {
                    desiredPlace = FindPlaceIndexById("place_pasar");
                    act = "AksiGegabahPasar";
                    why = "Kebijakan Gegabah/Gaduh: Mencari celah curian dan pertikaian terbuka di Pasar.";
                }
                else if (hour >= 14 && hour < 20)
                {
                    desiredPlace = FindPlaceIndexById("place_dermaga");
                    act = "AksiGegabahDermaga";
                    why = "Kebijakan Gegabah/Gaduh: Membuat kegaduhan di Dermaga.";
                }
            }
            else
            {
                // HonestTrader & TraderInformant
                if (hour >= 6 && hour < 10)
                {
                    string pId = curWare.SourcePlaces.Count > 0 ? curWare.SourcePlaces[0] : "place_pasar";
                    desiredPlace = FindPlaceIndexById(pId);
                    act = "Kulakan_" + curWare.Id;
                    why = "Kulakan dan menjajakan " + curWare.CategoryName + " di " + Places[desiredPlace].Name + ".";
                }
                else if (hour >= 10 && hour < 15)
                {
                    string pId = curWare.AccessPlaces.Count > 0 ? curWare.AccessPlaces[day % curWare.AccessPlaces.Count] : "place_pasar";
                    desiredPlace = FindPlaceIndexById(pId);
                    act = "Dagang_" + curWare.Id;
                    why = "Menjual " + curWare.CategoryName + " di " + Places[desiredPlace].Name + ".";
                }
                else if (hour >= 15 && hour < 18)
                {
                    bool goTeahouse = (ActiveSoumaPolicy == "TraderInformant")
                        || (ActiveSoumaPolicy == "Pemulih" && day >= 14)
                        || (ActiveSoumaPolicy == "HonestTrader" && GroupContactState != "Aktif");
                    desiredPlace = FindPlaceIndexById(goTeahouse ? "place_kedai_teh" : "place_nagaya");
                    act = goTeahouse ? "VerifikasiRumorKedaiOkiku" : "PulangSoreKeNagaya";
                    why = goTeahouse
                        ? "Singgah di Kedai Teh untuk mencocokkan rumor dari dua saksi independen."
                        : "Pedagang jujur kembali ke Nagaya sebelum jam malam penjaga.";
                }
                else if (hour >= 20 && hour < 22 && (
                    ((day % 7 == 0) && ActiveSoumaPolicy == "TraderInformant")
                    || (ActiveSoumaPolicy == "Pemulih" && day >= 16 && (day % 2 == 0))
                    || (ActiveSoumaPolicy == "HonestTrader" && day >= 22 && GroupContactState != "Aktif" && (day % 2 == 1))))
                {
                    desiredPlace = FindPlaceIndexById("place_titik_serah_hutan");
                    act = "LaporPesananAtauPemulihanKelompok";
                    why = "Menuju titik serah hutan untuk menyerahkan Kabar bernilai atau menjalani Ujian Kesetiaan pemulihan kelompok.";
                }
            }

            if (desiredPlace < 0) desiredPlace = 0;
            if (weather == "Storm" && !Places[desiredPlace].IsIndoorShelter)
            {
                int shelter = FindPlaceIndexById("place_kedai_teh");
                if (shelter >= 0) desiredPlace = shelter;
                act = "BerteduhDariBadai";
                why = "Berteduh dari badai di " + Places[desiredPlace].Name + " sambil mengamati tamu.";
            }

            SoumaTargetPlaceIdx = desiredPlace;
            if (!SoumaIsInTransit && SoumaCurrentPlaceIdx != desiredPlace)
            {
                int hop = NextHopIndex[SoumaCurrentPlaceIdx * pCount + desiredPlace];
                if (hop < 0) hop = desiredPlace;
                int mins = DirectEdgeMinutes[SoumaCurrentPlaceIdx * pCount + hop];
                if (mins >= 9999) mins = 10;
                SoumaIsInTransit = true;
                SoumaTransitElapsedMinutes = 0;
                SoumaTransitTotalMinutes = mins;
                SoumaCurrentActivity = "PerjalananKe_" + Places[hop].Id;
                SoumaWhyHereReason = "Berjalan dari " + Places[SoumaCurrentPlaceIdx].Name + " menuju " + Places[desiredPlace].Name + " (" + act + ").";
            }
            else if (SoumaIsInTransit)
            {
                SoumaTransitElapsedMinutes += 1;
                int hop = NextHopIndex[SoumaCurrentPlaceIdx * pCount + SoumaTargetPlaceIdx];
                if (hop < 0) hop = SoumaTargetPlaceIdx;
                int tot = SoumaTransitTotalMinutes > 0 ? SoumaTransitTotalMinutes : 1;
                double t = (double)SoumaTransitElapsedMinutes / (double)tot;
                if (t > 1.0) t = 1.0;
                SoumaPosX = (double)Places[SoumaCurrentPlaceIdx].MapX + ((double)Places[hop].MapX - (double)Places[SoumaCurrentPlaceIdx].MapX) * t;
                SoumaPosY = (double)Places[SoumaCurrentPlaceIdx].MapY + ((double)Places[hop].MapY - (double)Places[SoumaCurrentPlaceIdx].MapY) * t;

                if (SoumaTransitElapsedMinutes >= SoumaTransitTotalMinutes)
                {
                    SoumaCurrentPlaceIdx = hop;
                    SoumaPosX = (double)Places[hop].MapX;
                    SoumaPosY = (double)Places[hop].MapY;
                    SoumaIsInTransit = false;
                    SoumaCurrentActivity = act;
                    SoumaWhyHereReason = why;
                }
            }
            else
            {
                SoumaPosX = (double)Places[SoumaCurrentPlaceIdx].MapX;
                SoumaPosY = (double)Places[SoumaCurrentPlaceIdx].MapY;
                SoumaCurrentActivity = act;
                SoumaWhyHereReason = why;
            }
        }

        public void StepOneGameMinute(ulong seed, int day, int hour, int minute, string weather, string festival)
        {
            if (minute % 5 != 0 && !SoumaIsInTransit)
            {
                bool anyInTransit = false;
                for (int k = 0; k < Agents.Count; k++)
                {
                    if (Agents[k].IsInTransit) { anyInTransit = true; break; }
                }
                if (!anyInTransit) return;
            }
            if (minute % 5 == 0 || SoumaIsInTransit)
            {
                UpdateSoumaPolicyMovement(seed, day, hour, minute, weather);
            }

            int minuteOfDay = hour * 60 + minute;
            int pCount = Places.Count;

            for (int i = 0; i < Agents.Count; i++)
            {
                NpcRuntimeState ag = Agents[i];
                if (ag.IsDead) continue;
                if (minute % 15 != 0 && !ag.IsInTransit) continue;

                int blkIdx = FindScheduleBlockForMinute(i, minuteOfDay);
                if (blkIdx != ag.ActiveBlockIdx)
                {
                    ag.PreviousBlockIdx = ag.ActiveBlockIdx;
                    ag.ActiveBlockIdx = blkIdx;
                    ag.ScheduleTransitionedThisHour = true;
                    ag.TransitionFromPlaceIdx = ag.CurrentPlaceIdx;
                    ag.HasNewTriggerSinceLastSocial = true;
                    ag.LastTriggerReason = "PindahJadwal:" + NpcDefs[i].Schedule[blkIdx].Activity;
                }

                SimScheduleBlockDef blk = NpcDefs[i].Schedule[blkIdx];
                int scheduledPlace = FindPlaceIndexById(blk.PlaceId);
                if (scheduledPlace < 0) scheduledPlace = ag.HomePlaceIdx;
                string scheduledAct = blk.Activity;
                bool interruptible = blk.Interruptible;

                ag.IsSleeping = (scheduledAct.Length >= 5 && scheduledAct[0] == 'T' && scheduledAct[1] == 'i' && scheduledAct[2] == 'd' && scheduledAct[3] == 'u' && scheduledAct[4] == 'r');

                int desiredPlace = scheduledPlace;
                string activeAct = scheduledAct;
                bool interrupted = false;
                string intType = "";
                string whyReason = FormatScheduledWhyHere(i, blkIdx, scheduledPlace);

                if (DistrictCrackdownActive && ag.RoleCategory == "Guard")
                {
                    interrupted = true;
                    intType = "RaziaKuzuryu";
                    int pasarIdx = FindPlaceIndexById("place_pasar");
                    if (pasarIdx >= 0) desiredPlace = pasarIdx;
                    activeAct = "RaziaDaruratKuzuryu";
                    whyReason = "Interupsi Razia Darurat: Memeriksa seluruh pedagang dan warga akibat penemuan jejak kekerasan/Wajah Asli!";
                }
                else if (interruptible && (weather == "Storm" || (weather == "Rain" && hour >= 14 && hour < 19)) && !Places[scheduledPlace].IsIndoorShelter)
                {
                    interrupted = true;
                    intType = "Weather_" + weather;
                    int teahouseIdx = FindPlaceIndexById("place_kedai_teh");
                    desiredPlace = Places[ag.HomePlaceIdx].IsIndoorShelter ? ag.HomePlaceIdx : (teahouseIdx >= 0 ? teahouseIdx : 0);
                    activeAct = "BerteduhCuaca_" + weather;
                    whyReason = "Interupsi Cuaca (" + weather + "): Berteduh di " + Places[desiredPlace].Name + " (jadwal asli: " + scheduledAct + ")";
                }
                else if (interruptible && festival.Length > 0 && (festival == "Hanami" || festival == "Obon" || festival == "AkiMatsuri_TaxAndHarvest" || festival == "Setsubun") && hour >= 15 && hour < 20)
                {
                    interrupted = true;
                    intType = "Festival_" + festival;
                    int kuilIdx = FindPlaceIndexById("place_kuil_kecil");
                    int pasarIdx = FindPlaceIndexById("place_pasar");
                    desiredPlace = (festival == "Hanami" || festival == "Obon") ? (kuilIdx >= 0 ? kuilIdx : 0) : (pasarIdx >= 0 ? pasarIdx : 0);
                    activeAct = "RayakanFestival_" + festival;
                    whyReason = "Interupsi Festival (" + festival + "): Berkumpul di " + Places[desiredPlace].Name + " (jadwal asli: " + scheduledAct + ")";
                }

                ag.IsInterrupted = interrupted;
                ag.InterruptType = intType;
                ag.TargetPlaceIdx = desiredPlace;

                if (!ag.IsInTransit && ag.CurrentPlaceIdx != desiredPlace)
                {
                    int nextHop = NextHopIndex[ag.CurrentPlaceIdx * pCount + desiredPlace];
                    if (nextHop < 0) nextHop = desiredPlace;
                    int legMins = DirectEdgeMinutes[ag.CurrentPlaceIdx * pCount + nextHop];
                    if (legMins >= 9999) legMins = 8;
                    string rType = EdgeRouteTypes[ag.CurrentPlaceIdx * pCount + nextHop];

                    ag.IsInTransit = true;
                    ag.TransitFromPlaceIdx = ag.CurrentPlaceIdx;
                    ag.TransitToPlaceIdx = nextHop;
                    ag.TransitElapsedMinutes = 0;
                    ag.TransitTotalMinutes = legMins;
                    ag.TransitRouteType = rType;
                    ag.CurrentActivity = "JalanKe_" + Places[nextHop].Id;
                    ag.WhyHereReason = "Dalam perjalanan (0/" + legMins.ToString() + " mnt via " + rType + ") dari " + Places[ag.CurrentPlaceIdx].Name + " ke " + Places[desiredPlace].Name + " untuk " + activeAct;
                }
                else if (ag.IsInTransit)
                {
                    ag.TransitElapsedMinutes += 1;
                    int fromP = ag.TransitFromPlaceIdx;
                    int toP = ag.TransitToPlaceIdx;
                    int totM = ag.TransitTotalMinutes > 0 ? ag.TransitTotalMinutes : 1;
                    double ratio = (double)ag.TransitElapsedMinutes / (double)totM;
                    if (ratio > 1.0) ratio = 1.0;

                    ag.PosX = (double)Places[fromP].MapX + ((double)Places[toP].MapX - (double)Places[fromP].MapX) * ratio;
                    ag.PosY = (double)Places[fromP].MapY + ((double)Places[toP].MapY - (double)Places[fromP].MapY) * ratio;

                    if (ag.TransitElapsedMinutes >= ag.TransitTotalMinutes)
                    {
                        ag.CurrentPlaceIdx = toP;
                        ag.PosX = (double)Places[toP].MapX;
                        ag.PosY = (double)Places[toP].MapY;
                        ag.IsInTransit = false;
                        if (ag.CurrentPlaceIdx == desiredPlace)
                        {
                            ag.CurrentActivity = activeAct;
                            ag.WhyHereReason = whyReason;
                            if (ag.RoleCategory == "Guard" && toP >= 0 && toP < GuardPostVacant.Length)
                            {
                                GuardPostVacant[toP] = false;
                            }
                        }
                        else
                        {
                            ag.CurrentActivity = "TransitDi_" + Places[toP].Id;
                            ag.WhyHereReason = "Singgah transit di " + Places[toP].Name + " menuju " + Places[desiredPlace].Name + " untuk " + activeAct;
                        }
                    }
                }
                else
                {
                    double angle = (double)(i * 14) * 0.01745329;
                    ag.PosX = (double)Places[ag.CurrentPlaceIdx].MapX + Math.Cos(angle) * 13.0;
                    ag.PosY = (double)Places[ag.CurrentPlaceIdx].MapY + Math.Sin(angle) * 13.0;
                    ag.CurrentActivity = activeAct;
                    ag.WhyHereReason = whyReason;
                }

                if (!ag.IsInTransit && !SoumaIsInTransit && ag.CurrentPlaceIdx == SoumaCurrentPlaceIdx)
                {
                    ag.FamiliarityWithSouma += 1;
                }
            }

            UpdateAllNpcLodLevels();
        }
    }
}
