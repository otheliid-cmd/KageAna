// STATUS VERIFIKASI (E9.2): BELUM DIBUKA DI UNITY/WINDOWS ASLI — dijalankan oleh BUAT_APK.bat di PC pengguna.
using System;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace KageAna.Editor
{
    /// <summary>
    /// E9.2: Skrip bangun APK Debug otomatis untuk dipanggil lewat baris perintah Unity:
    /// Unity.exe -batchmode -nographics -quit -projectPath ... -executeMethod KageAna.Editor.AndroidBuild.BuildDebugApk -logFile build_android.log
    /// </summary>
    public static class AndroidBuild
    {
        public static void BuildDebugApk()
        {
            string outputDir = Path.Combine(Directory.GetCurrentDirectory(), "..", "Build", "Android");
            Directory.CreateDirectory(outputDir);
            string apkPath = Path.Combine(outputDir, "KageAna_Debug_IrisanVertikal.apk");

            EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            // Unity 6 (6000.0 LTS) Minimum API Level = 23 (Android 6.0 Marshmallow)
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel23;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;

            string[] scenes = new string[]
            {
                "Assets/_Project/Scenes/VerticalSlice_Blockout.unity"
            };

            var buildOptions = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = apkPath,
                target = BuildTarget.Android,
                options = BuildOptions.Development
            };

            BuildReport report = BuildPipeline.BuildPlayer(buildOptions);
            if (report.summary.result != BuildResult.Succeeded)
            {
                throw new Exception("AndroidDebugBuild gagal: " + report.summary.result);
            }
            Debug.Log("[AndroidBuild] BERHASIL membangun APK: " + apkPath + " (" + report.summary.totalSize + " byte)");
        }
    }
}
