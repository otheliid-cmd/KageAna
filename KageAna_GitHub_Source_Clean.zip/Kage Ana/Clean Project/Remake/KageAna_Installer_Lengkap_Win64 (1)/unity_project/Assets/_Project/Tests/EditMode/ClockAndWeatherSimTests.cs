// KAGE-ANA v3.0 — EditMode & Pure C# Unit Tests (L1, L1.95, L2-L8, A2, A3, & Gelombang D Butir 1-8)
// 30 unit tests covering Clock, Weather, Data-Driven 26 NPCs, 12 Modular Rumor/Agency Systems,
// Salience, Multi-Order Agency & Misunderstandings, Living Density >= 8/NPC/day, Life Pressure, Curated Nisshi (12-20),
// and Negative Guard Tests for every new validator.
using System;
using System.Collections.Generic;
using KageAna.Runtime.Sim;

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
using NUnit.Framework;
#endif

namespace KageAna.Tests.EditMode
{
    public static class ClockAndWeatherSimTests
    {
        private static void Require(bool condition, string message)
        {
            if (!condition)
            {
                throw new Exception("UnitTest Assertion Failed: " + message);
            }
        }

        private static bool ContainsSubstring(string haystack, string needle)
        {
            int n = haystack.Length;
            int m = needle.Length;
            if (m == 0) return true;
            for (int i = 0; i <= n - m; i++)
            {
                bool ok = true;
                for (int j = 0; j < m; j++)
                {
                    if (haystack[i + j] != needle[j])
                    {
                        ok = false;
                        break;
                    }
                }
                if (ok) return true;
            }
            return false;
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_Clock_10Hz_18RealMinutesPerDay_And_28DayEventCounts()
        {
            Require(WorldClock.TicksPerGameDay == 10800, "18 real minutes at 10 Hz must equal 10,800 ticks per game day");

            WorldClock clock = new WorldClock();
            for (int d = 1; d <= 28; d++)
            {
                for (int h = 0; h < 24; h++)
                {
                    for (int m = 0; m < 60; m++)
                    {
                        clock.AdvanceTicks((m % 2 == 0) ? 7 : 8);
                    }
                }
            }

            Require(clock.TotalTicks == 302400, "28 days must equal 302,400 ticks");
            Require(clock.OnHourFiredCount == 672, "28 days must fire 672 OnHour events");
            Require(clock.OnDayStartFiredCount == 28, "28 days must fire 28 OnDayStart events");
            Require(clock.OnSeasonChangeFiredCount == 4, "28 days must fire 4 OnSeasonChange events");
            Require(clock.TempleBellRingsCount == 112, "4 temple bells per day * 28 days = 112");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_DaySegments_Transitions()
        {
            Require(WorldClock.ComputeSegmentForHour(5) == "Dawn", "05:00 is Dawn");
            Require(WorldClock.ComputeSegmentForHour(8) == "Morning", "08:00 is Morning");
            Require(WorldClock.ComputeSegmentForHour(12) == "Noon", "12:00 is Noon");
            Require(WorldClock.ComputeSegmentForHour(15) == "Afternoon", "15:00 is Afternoon");
            Require(WorldClock.ComputeSegmentForHour(18) == "Dusk", "18:00 is Dusk");
            Require(WorldClock.ComputeSegmentForHour(21) == "Night", "21:00 is Night");
            Require(WorldClock.ComputeSegmentForHour(2) == "LateNight", "02:00 is LateNight");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_Calendar28Days_FourSeasons_And_Festivals()
        {
            Require(WorldClock.ComputeSeasonForDay(1) == "Spring", "Day 1 is Spring");
            Require(WorldClock.ComputeSeasonForDay(7) == "Spring", "Day 7 is Spring");
            Require(WorldClock.ComputeSeasonForDay(8) == "Summer", "Day 8 is Summer");
            Require(WorldClock.ComputeSeasonForDay(15) == "Autumn", "Day 15 is Autumn");
            Require(WorldClock.ComputeSeasonForDay(22) == "Winter", "Day 22 is Winter");
            Require(WorldClock.GetScheduledEventForDay(3) == "Hanami", "Day 3 is Hanami");
            Require(WorldClock.GetScheduledEventForDay(11) == "Obon", "Day 11 is Obon");
            Require(WorldClock.GetScheduledEventForDay(19) == "AkiMatsuri_TaxAndHarvest", "Day 19 is AkiMatsuri_TaxAndHarvest");
            Require(WorldClock.GetScheduledEventForDay(26) == "Setsubun", "Day 26 is Setsubun");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_Weather_And_LightingPreset_Determinism()
        {
            string j1 = HeadlessSimRunner.Run28DaySimToJson(7UL, 28, false);
            string j2 = HeadlessSimRunner.Run28DaySimToJson(7UL, 28, false);
            Require(j1 == j2, "Same seed must produce identical 28-day simulation output");

            LightingPresetData lp = WeatherSystem.ResolveLightingPreset("Dusk", "Fog");
            Require(lp.Id == "LP_Dusk_Fog", "Dusk+Fog must resolve to LP_Dusk_Fog");
            Require(lp.FogDensity > 0.04, "Fog preset must have elevated fog density");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_Weather_MaxStreak_AtMost3Days_UnlessWeightsForceSingleWeather()
        {
            for (ulong s = 1UL; s <= 10UL; s++)
            {
                WeatherSystem ws = new WeatherSystem();
                for (int d = 1; d <= 28; d++)
                {
                    string season = WorldClock.ComputeSeasonForDay(d);
                    ws.DrawDailyWeather(s, d, season);
                }
                Require(ws.MaxStreakObserved <= 3, "Natural weather streak must not exceed 3 consecutive days");
            }
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_NoFreeKnowledgeGuard()
        {
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            bool ok = guard.ValidateAndRecordKnowledge("ohana", "kabar_1", 0, true);
            Require(ok && guard.Violations == 0, "Valid witnessed knowledge must pass with 0 violations");

            bool bad = guard.ValidateAndRecordKnowledge("ryota", "kabar_secret", 0, false);
            Require(!bad && guard.Violations == 1, "Unwitnessed knowledge must increment Violations to 1");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_L195_JsonDataAdapter_ModifyingJsonChangesOutcome()
        {
            string defaultRun = HeadlessSimRunner.Run28DaySimWithCustomWeatherJson(7UL, 7, false, "");
            string customRainySpringJson = "{\"transitionGameSeconds\":60,\"seasons\":{\"Spring\":{\"Clear\":0,\"Cloudy\":5,\"Fog\":5,\"Rain\":85,\"Storm\":5,\"Snow\":0,\"Windy\":0}}}";
            string modifiedRun = HeadlessSimRunner.Run28DaySimWithCustomWeatherJson(7UL, 7, false, customRainySpringJson);
            Require(defaultRun != modifiedRun, "Changing weather.json weights via SimJsonDataLoader must alter simulation output without recompiling C#");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_A2_1a_EventEmitterDisabled_ProducesZeroMemoriesAndZeroRumors()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            string disabledJson = HeadlessSimRunner.Run28DaySimWithBundle(7UL, 7, false, bundle, false);
            Require(ContainsSubstring(disabledJson, "\"worldEventsEmitted\":0"), "Disabling EventEmitter must produce 0 WorldEvents");
            Require(ContainsSubstring(disabledJson, "\"totalMemoriesRecorded\":0"), "Disabling EventEmitter must produce 0 Memories");
            Require(ContainsSubstring(disabledJson, "\"rumorPropagationEdges\":0"), "Disabling EventEmitter must produce 0 RumorEdges");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_A2_1b_InjectMemoryWithoutSourceEventId_TriggersViolation()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

            MemoryEntry memWithoutEventId = new MemoryEntry();
            memWithoutEventId.Id = "mem_illegal_no_event";
            memWithoutEventId.OwnerNpcId = "okiku";
            memWithoutEventId.SourceType = 0;
            memWithoutEventId.SourceEventId = "";

            bool valid = guard.ValidateMemoryAgainstEventLog(memWithoutEventId, rumorSys.EventLog, rumorSys.Memories, "place_kedai_teh", "");
            Require(!valid && guard.Violations == 1, "Injecting a MemoryEntry without SourceEventId must fail and increment Violations to 1");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_A2_1c_RumorAboutNonexistentEvent_TriggersViolation()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

            MemoryEntry fakeSaw = new MemoryEntry();
            fakeSaw.Id = "mem_fake_saw";
            fakeSaw.OwnerNpcId = "haruki";
            fakeSaw.SourceType = 0;
            fakeSaw.SourceEventId = "evt_never_happened_in_world_999";

            bool validSaw = guard.ValidateMemoryAgainstEventLog(fakeSaw, rumorSys.EventLog, rumorSys.Memories, "place_pasar", "");
            Require(!validSaw && guard.Violations == 1, "Memory of an event that never occurred in EventLog must trigger a violation");

            MemoryEntry fakeTold = new MemoryEntry();
            fakeTold.Id = "mem_fake_told";
            fakeTold.OwnerNpcId = "okiku";
            fakeTold.SourceType = 2;
            fakeTold.SourceEventId = "evt_never_happened_in_world_999";
            fakeTold.SourceMemoryId = "mem_nonexistent_parent";
            fakeTold.TellerNpcId = "haruki";

            bool validTold = guard.ValidateMemoryAgainstEventLog(fakeTold, rumorSys.EventLog, rumorSys.Memories, "place_kedai_teh", "place_kedai_teh");
            Require(!validTold && guard.Violations == 2, "Rumor (Told) about an event that never occurred must trigger a violation");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_A2_1_SeedDiversity_And_FiveAlgorithmicDistortionOperators()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            List<string> seedSignatures = new List<string>();
            int totalMagnify = 0;
            int totalWrongPerson = 0;
            int totalWrongPlace = 0;
            int totalDropDetail = 0;
            int totalAddMotive = 0;

            for (ulong seed = 1UL; seed <= 20UL; seed++)
            {
                WorldClock clock = new WorldClock();
                WeatherSystem weather = new WeatherSystem();
                weather.SetConfig(bundle.WeatherConfig);
                NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
                SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
                SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

                for (int d = 1; d <= 5; d++)
                {
                    string season = WorldClock.ComputeSeasonForDay(d);
                    string w = weather.DrawDailyWeather(seed, d, season);
                    string fest = WorldClock.GetScheduledEventForDay(d);
                    for (int h = 0; h < 24; h++)
                    {
                        for (int m = 0; m < 60; m++)
                        {
                            int ticksThisMin = (m % 2 == 0) ? 7 : 8;
                            clock.AdvanceTicks(ticksThisMin);
                            world.StepOneGameMinute(seed, d, clock.CurrentHour, m, w, fest);
                        }
                        rumorSys.EvaluateHourlyWorldEventsAndRumors(seed, clock.TotalTicks, d, clock.CurrentHour, clock.CurrentSegment, w, world, guard);
                    }
                }

                Require(guard.Violations == 0, "Zero violations required on seed=" + seed.ToString());
                Require(rumorSys.EventLog.Count > 10, "Dynamic WorldEvents must be emitted on seed=" + seed.ToString());
                Require(rumorSys.RumorEdges.Count >= 3, "Dynamic rumors must propagate on seed=" + seed.ToString());
                Require(rumorSys.KabarUpgradedCount >= 1, "At least 1 dynamic Kabar must be verified by >=2 independent sources on seed=" + seed.ToString());

                totalMagnify += rumorSys.OpCountMagnify;
                totalWrongPerson += rumorSys.OpCountWrongPerson;
                totalWrongPlace += rumorSys.OpCountWrongPlace;
                totalDropDetail += rumorSys.OpCountDropDetail;
                totalAddMotive += rumorSys.OpCountAddMotive;

                int evC = rumorSys.EventLog.Count; int memC = rumorSys.Memories.Count; int edgC = rumorSys.RumorEdges.Count;
                string sig = evC.ToString() + ":" + memC.ToString() + ":" + edgC.ToString()
                    + ":" + rumorSys.OpCountMagnify.ToString() + ":" + rumorSys.OpCountWrongPerson.ToString()
                    + ":" + rumorSys.OpCountWrongPlace.ToString() + ":" + rumorSys.OpCountDropDetail.ToString()
                    + ":" + rumorSys.OpCountAddMotive.ToString();
                if (rumorSys.RumorEdges.Count > 0)
                {
                    sig += ":" + rumorSys.RumorEdges[0].FromNpcId + "->" + rumorSys.RumorEdges[0].ToNpcId + ":" + rumorSys.RumorEdges[0].ClaimTextId;
                }

                bool alreadySeen = false;
                for (int s = 0; s < seedSignatures.Count; s++)
                {
                    if (seedSignatures[s] == sig) { alreadySeen = true; break; }
                }
                if (!alreadySeen)
                {
                    seedSignatures.Add(sig);
                }
            }

            int sigCnt = seedSignatures.Count;
            Require(sigCnt >= 15, "Seeds 1..20 must produce diverse rumor sets and operator counts (found " + sigCnt.ToString() + " distinct signatures)");
            Require(totalMagnify > 0 && totalWrongPerson > 0 && totalWrongPlace > 0 && totalDropDetail > 0 && totalAddMotive > 0, "All 5 algorithmic distortion operators must be exercised across seeds 1..20");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_A2_2_DataDriven20CanonicalNpcs_And_OhanaOkikuCanonRoles()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);

            Require(world.Places.Count == 12, "Must load 12 places dynamically from JSON");
            Require(world.Agents.Count == 26, "Must load 26 canonical NPCs dynamically from JSON for Gelombang C (Kitab 7.1)");

            int ohanaIdx = world.FindNpcIndexById("ohana");
            int okikuIdx = world.FindNpcIndexById("okiku");
            Require(ohanaIdx >= 0 && okikuIdx >= 0, "Both ohana and okiku must exist");

            Require(world.Places[world.Agents[ohanaIdx].HomePlaceIdx].Id == "place_nagaya", "Canon: ohana home must be place_nagaya");
            Require(ContainsSubstring(world.Agents[ohanaIdx].Role, "Nagaya") && ContainsSubstring(world.Agents[ohanaIdx].Role, "Sewa"), "Canon: ohana role must be Pemilik Rumah Sewa Nagaya & Penagih Sewa");
            Require(world.Places[world.Agents[okikuIdx].HomePlaceIdx].Id == "place_kedai_teh", "Canon: okiku home must be place_kedai_teh");
            Require(ContainsSubstring(world.Agents[okikuIdx].Role, "Kedai Teh"), "Canon: okiku role must be Pemilik Kedai Teh & Izakaya Pasar");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_L4_SocialSuspicionReasons_GarmentsWithoutPureBlack_And_FishOdorMasksBlood()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            Require(bundle.Garments.Count >= 4, "Must load >= 4 garments from JSON");
            for (int g = 0; g < bundle.Garments.Count; g++)
            {
                Require(bundle.Garments[g].PrimaryHex != "#000000" && bundle.Garments[g].SecondaryHex != "#000000", "Lampiran A.4.4 prohibits pure black (#000000) garments");
            }

            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

            int nagayaIdx = world.FindPlaceIndexById("place_nagaya");
            world.SoumaCurrentPlaceIdx = nagayaIdx;
            world.SoumaIsInTransit = false;
            world.BloodStainLevel = 60;
            world.SelectWareCategory(0);
            rumorSys.EvaluateHourlySocialSuspicion(1, 10, "Morning", world);

            int ohanaIdx = world.FindNpcIndexById("ohana");
            Require(world.Agents[ohanaIdx].SuspicionTowardSouma > 0, "Visible bloodstain without fish odor must raise suspicion");
            Require(world.Agents[ohanaIdx].WhySuspiciousReasons.Count > 0, "NPC must record 'mengapa NPC ini curiga padaku' reason");

            SimPlaceGraphSystem worldFish = new SimPlaceGraphSystem(bundle);
            worldFish.SoumaCurrentPlaceIdx = nagayaIdx;
            worldFish.SoumaIsInTransit = false;
            worldFish.BloodStainLevel = 60;
            worldFish.SelectWareCategory(2);
            rumorSys.EvaluateHourlySocialSuspicion(1, 10, "Morning", worldFish);
            Require(worldFish.Agents[ohanaIdx].SuspicionTowardSouma == 0, "Fish & salt ware odor must mask blood odor per Lampiran A.4.1");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_L5_Economy28Days_NoRunaway_And_EveryTradeYieldsKabarOrAccess()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            for (ulong seed = 1UL; seed <= 3UL; seed++)
            {
                WorldClock clock = new WorldClock();
                WeatherSystem weather = new WeatherSystem();
                weather.SetConfig(bundle.WeatherConfig);
                NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
                SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
                SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

                for (int d = 1; d <= 28; d++)
                {
                    string season = WorldClock.ComputeSeasonForDay(d);
                    string w = weather.DrawDailyWeather(seed, d, season);
                    string fest = WorldClock.GetScheduledEventForDay(d);
                    for (int h = 0; h < 24; h++)
                    {
                        for (int m = 0; m < 60; m++)
                        {
                            int ticksThisMin = (m % 2 == 0) ? 7 : 8;
                            clock.AdvanceTicks(ticksThisMin);
                            world.StepOneGameMinute(seed, d, clock.CurrentHour, m, w, fest);
                        }
                        rumorSys.EvaluateHourlyWorldEventsAndRumors(seed, clock.TotalTicks, d, clock.CurrentHour, clock.CurrentSegment, w, world, guard);
                    }
                }

                Require(world.TotalTradesExecuted > 20, "Souma must execute regular trades over 28 days");
                Require(world.TradesYieldingKabarOrAccess > 0 && world.TradesYieldingKabarOrAccess <= world.TotalTradesExecuted, "A3-3: Trade yield must be measured honestly without 100% fallback");
                Require(world.SoumaMon >= 40 && world.SoumaMon <= 3500 && world.MaxMonObserved <= 3500, "28-day economy must not runaway or collapse");
                Require(world.TotalRentPaidToOhanaMon >= 700, "Souma must pay weekly rent to O-Hana at Nagaya");
            }
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_L6_ThreeScriptedScenarios_Quiet_LoudCorpseDiscovery_And_TrueFaceMarket()
        {
            string json = HeadlessSimRunner.RunThreeL6ScenariosToJson();
            Require(ContainsSubstring(json, "\"corpseHidden\":true,\"maxSuspicion\":0"), "Scenario 1 (Senyap) must have 0 suspicion and hidden corpse");
            Require(ContainsSubstring(json, "\"corpseDiscovered\":true"), "Scenario 2 (Gaduh) must trigger corpse discovery by co-located NPC");
            Require(ContainsSubstring(json, "\"groupTrustBefore\":65,\"groupTrustAfter\":55"), "Scenario 3 (Wajah Asli di Pasar) must apply automatic -10 GroupTrust cost (65 -> 55)");
            Require(ContainsSubstring(json, "\"waresCarryUnitsAfter\":0"), "Scenario 3 (Wajah Asli di Pasar) must drop carried wares (CarryUnits -> 0)");
            Require(ContainsSubstring(json, "\"directWitnessMotiveId\":\"motive_none\""), "A3-1: Direct witness at Market must have MotiveId=motive_none (never TrueMotive)");
            Require(ContainsSubstring(json, "\"hop1RumorOperators\":\"AddMotive\""), "A3-1: Hop 1 rumor must introduce motive_spy via AddMotive inference operator");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_A3_1_MotiveLeakageGuard_DirectWitnessCannotKnowTrueMotiveWithoutOperator()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

            int pasarIdx = world.FindPlaceIndexById("place_pasar");
            world.SoumaCurrentPlaceIdx = pasarIdx;
            world.SoumaIsInTransit = false;

            WorldEvent evt = rumorSys.ExecuteSoumaTrueFace(2, 1000, 1, 12, "Noon", "Clear", world, guard);
            Require(evt.TrueMotive == "motive_spy", "Debug TrueMotive on event is motive_spy");
            Require(guard.Violations == 0, "Legitimate witness perception must have 0 violations");
            Require(rumorSys.Memories.Count > 0, "Co-located NPCs at market must form direct witness memories");

            for (int m = 0; m < rumorSys.Memories.Count; m++)
            {
                MemoryEntry wm = rumorSys.Memories[m];
                Require(wm.HopCount == 0, "Initial memories are Hop 0 direct witnesses");
                Require(wm.Claim.MotiveId == "motive_none", "A3-1: Direct witness MUST NOT copy TrueMotive into Claim.MotiveId");
                Require(!ContainsSubstring(wm.FormattedTextId, "mata-mata jaringan Iga"), "A3-1: Direct witness claim text must not mention Iga spy motive");
            }

            MemoryEntry leakedWitnessMem = new MemoryEntry();
            leakedWitnessMem.Id = "mem_leaked_motive_witness";
            leakedWitnessMem.OwnerNpcId = "ohana";
            leakedWitnessMem.SourceType = 0;
            leakedWitnessMem.SourceEventId = evt.Id;
            leakedWitnessMem.HopCount = 0;
            leakedWitnessMem.AppliedDistortionOperators = "None";
            leakedWitnessMem.Claim.SubjectId = "souma";
            leakedWitnessMem.Claim.ActionCode = "true_face_exposed";
            leakedWitnessMem.Claim.PlaceId = "place_pasar";
            leakedWitnessMem.Claim.Quantity = evt.Quantity;
            leakedWitnessMem.Claim.MotiveId = "motive_spy";

            bool okLeak1 = guard.ValidateMemoryAgainstEventLog(leakedWitnessMem, rumorSys.EventLog, rumorSys.Memories, "place_pasar", "");
            Require(!okLeak1 && guard.Violations == 1, "A3-1 Negative Test: Direct witness claiming TrueMotive without operator MUST trigger violation");

            MemoryEntry parentWitness = rumorSys.Memories[0];
            MemoryEntry leakedToldMem = new MemoryEntry();
            leakedToldMem.Id = "mem_leaked_motive_told";
            leakedToldMem.OwnerNpcId = "tome";
            leakedToldMem.SourceType = 2;
            leakedToldMem.SourceEventId = evt.Id;
            leakedToldMem.SourceMemoryId = parentWitness.Id;
            leakedToldMem.TellerNpcId = parentWitness.OwnerNpcId;
            leakedToldMem.HopCount = 1;
            leakedToldMem.AppliedDistortionOperators = "None";
            leakedToldMem.Claim = parentWitness.Claim.Clone();
            leakedToldMem.Claim.MotiveId = "motive_spy";

            bool okLeak2 = guard.ValidateMemoryAgainstEventLog(leakedToldMem, rumorSys.EventLog, rumorSys.Memories, "place_pasar", "place_pasar");
            Require(!okLeak2 && guard.Violations == 2, "A3-1 Negative Test: Told memory adding motive without AddMotive operator MUST trigger violation");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_A3_2_StateDrivenEventEmitter_FourCategories_ZeroUnclassified_And_GuardPostVacancy()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

            int gerbangIdx = world.FindPlaceIndexById("place_barak_gerbang");
            int kedaiIdx = world.FindPlaceIndexById("place_kedai_teh");
            int ryotaIdx = world.FindNpcIndexById("ryota");
            Require(!world.GuardPostVacant[gerbangIdx], "Guard post starts occupied");

            world.LeaveGuardPostEarly(ryotaIdx, gerbangIdx, kedaiIdx, "Hujan sore memaksa Ryota berteduh");
            Require(world.GuardPostVacant[gerbangIdx], "A3-2: leave_post_early must set GuardPostVacant=true");
            Require(world.Agents[ryotaIdx].CurrentPlaceIdx == kedaiIdx, "A3-2: leave_post_early must move guard to destination place");

            WorldEvent badSrcEvt = new WorldEvent();
            badSrcEvt.Id = "evt_bad_source";
            badSrcEvt.EventSourceCategory = "RandomRoleRoll";
            badSrcEvt.StateEffectSummary = "None";
            bool okSrc = guard.ValidateWorldEventSource(badSrcEvt);
            Require(!okSrc && guard.Violations == 1, "A3-2 Negative Test: Unclassified WorldEvent source category MUST trigger violation");

            WorldEvent emptyEffectEvt = new WorldEvent();
            emptyEffectEvt.Id = "evt_empty_effect";
            emptyEffectEvt.EventSourceCategory = "ScheduleTransition";
            emptyEffectEvt.IsFlavorOnly = false;
            emptyEffectEvt.StateEffectSummary = "";
            bool okEff = guard.ValidateWorldEventSource(emptyEffectEvt);
            Require(!okEff && guard.Violations == 2, "A3-2 Negative Test: Non-flavor WorldEvent without StateEffectSummary MUST trigger violation");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_A3_3_A3_4_And_L8_FourPolicies_CausalChains_And_NisshiDistinctness()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            Require(bundle.Npcs.Count == 26, "L7: Must have 26 canonical NPCs");
            Require(bundle.Gigs.Count >= 6, "L7: Must have >= 6 Gigs");
            Require(bundle.MicroStories.Count == 24, "L7+L8: Must have 24 conditional Micro-Stories");
            Require(bundle.Festivals.Count == 4, "L8: Must have 4 systemic Festivals");

            string jsonIdle = HeadlessSimRunner.Run28DaySimWithPolicyAndBundle(7UL, 7, false, "Idle", bundle, true);
            string jsonHonest = HeadlessSimRunner.Run28DaySimWithPolicyAndBundle(7UL, 7, false, "HonestTrader", bundle, true);
            string jsonInformant = HeadlessSimRunner.Run28DaySimWithPolicyAndBundle(7UL, 7, false, "TraderInformant", bundle, true);
            string jsonReckless = HeadlessSimRunner.Run28DaySimWithPolicyAndBundle(7UL, 7, false, "RecklessLoud", bundle, true);

            Require(jsonIdle != jsonHonest && jsonHonest != jsonInformant && jsonInformant != jsonReckless, "A3-3 & L8: Different Souma policies must produce distinct simulation outcomes and Nisshi logs");
            Require(ContainsSubstring(jsonIdle, "\"totalTrades\":0"), "Idle policy must execute 0 trades");
            Require(ContainsSubstring(jsonReckless, "\"crackdownActive\":true"), "RecklessLoud policy must trigger district crackdown");
        }

        // --- GELOMBANG D NEW MODULE & NEGATIVE GUARD TESTS (Tests 19..30) ---

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_1_SalienceScoring_And_NegativeRoutineSpreadGuard()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            Require(bundle.SalienceConfig.Profiles.Count >= 20, "Must load Salience profiles from Data/tuning/salience.json");
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();

            double routineSal = rumorSys.ComputeEventSalience("trade_wares", "okiku", 2);
            double salientSal = rumorSys.ComputeEventSalience("hide_za_ledger", "haruki", 2);
            double lethalSal = rumorSys.ComputeEventSalience("corpse_discovered", "yasu", 1);

            Require(routineSal <= bundle.SalienceConfig.RoutineMaxSalience, "Routine trade_wares must score <= routineMaxSalience");
            Require(salientSal >= bundle.SalienceConfig.SalientMinSalience, "hide_za_ledger must score >= salientMinSalience");
            Require(lethalSal >= bundle.SalienceConfig.HighSalienceThreshold, "corpse_discovered must score >= highSalienceThreshold");

            MemoryEntry routineParent = new MemoryEntry();
            routineParent.Id = "mem_routine_1";
            routineParent.PlaceId = "place_pasar";
            routineParent.IsRoutineMemory = true;
            routineParent.SalienceScore = 0.18;

            MemoryEntry illegalHop2 = new MemoryEntry();
            illegalHop2.Id = "mem_routine_hop2";
            illegalHop2.PlaceId = "place_pasar";
            illegalHop2.HopCount = 2;
            bool okHop = guard.ValidateRumorSalienceSpread(routineParent, illegalHop2, bundle.SalienceConfig);
            Require(!okHop && guard.Violations == 1, "Wave D Negative Test: Routine memory spreading beyond routineMaxHops MUST trigger violation");

            MemoryEntry illegalCrossPlace = new MemoryEntry();
            illegalCrossPlace.Id = "mem_routine_cross";
            illegalCrossPlace.PlaceId = "place_kuil_kecil";
            illegalCrossPlace.HopCount = 1;
            bool okPlace = guard.ValidateRumorSalienceSpread(routineParent, illegalCrossPlace, bundle.SalienceConfig);
            Require(!okPlace && guard.Violations == 2, "Wave D Negative Test: Routine memory spreading across places MUST trigger violation");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_2_AgencyBeliefToAction_Order2And3_And_NegativeAgencyGuard()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

            bool okFake = guard.ValidateAgencyActionAgainstBelief("ohana", "mem_nonexistent_999", rumorSys.Memories, 0.39);
            Require(!okFake && guard.Violations == 1, "Wave D Negative Test: Agency action on nonexistent belief memory MUST trigger violation");

            MemoryEntry trivialMem = new MemoryEntry();
            trivialMem.Id = "mem_1";
            trivialMem.OwnerNpcId = "ohana";
            trivialMem.SalienceScore = 0.15;
            trivialMem.IsRoutineMemory = true;
            rumorSys.Memories.Add(trivialMem);
            bool okTrivial = guard.ValidateAgencyActionAgainstBelief("ohana", "mem_1", rumorSys.Memories, 0.39);
            Require(!okTrivial && guard.Violations == 2, "Wave D Negative Test: Agency action on trivial routine memory MUST trigger violation");

            MemoryEntry otherMem = new MemoryEntry();
            otherMem.Id = "mem_2";
            otherMem.OwnerNpcId = "haruki";
            otherMem.SalienceScore = 0.80;
            rumorSys.Memories.Add(otherMem);
            bool okWrongOwner = guard.ValidateAgencyActionAgainstBelief("ohana", "mem_2", rumorSys.Memories, 0.39);
            Require(!okWrongOwner && guard.Violations == 3, "Wave D Negative Test: Agency action on another NPC's memory MUST trigger violation");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveE_1_SocialIntent_AntiFillerMetrics_And_NegativeModulusRejection()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);
            WorldClock clock = new WorldClock();
            WeatherSystem weather = new WeatherSystem();
            weather.SetConfig(bundle.WeatherConfig);

            for (int d = 1; d <= 3; d++)
            {
                string season = WorldClock.ComputeSeasonForDay(d);
                string w = weather.DrawDailyWeather(7UL, d, season);
                for (int h = 0; h < 24; h++)
                {
                    for (int m = 0; m < 60; m++)
                    {
                        clock.AdvanceTicks((m % 2 == 0) ? 7 : 8);
                        world.StepOneGameMinute(7UL, d, clock.CurrentHour, m, w, "");
                    }
                    rumorSys.EvaluateHourlyWorldEventsAndRumors(7UL, clock.TotalTicks, d, clock.CurrentHour, clock.CurrentSegment, w, world, guard);
                }
            }

            Require(rumorSys.EventsFromEntityInteraction > 0, "E2.1: Must emit meaningful needs-driven EntityInteraction events");
            Require(rumorSys.WhyLinkedInteractionEventsCount == rumorSys.EventsFromEntityInteraction, "E2.1 Metric 1: 100% of EntityInteraction events must have WhyNeedAndRelationTag");
            Require(rumorSys.CrossLocationInteractionsCount == 0, "E2.1 Rule: 0 cross-location NPC interactions allowed");
            int repPct = (rumorSys.RepeatedPairWithoutTriggerCount * 100) / rumorSys.EventsFromEntityInteraction;
            Require(repPct < 30, "E2.1 Metric 2: Repeated pair without new trigger ratio must be < 30%");
            Require(rumorSys.UnpredictableCausalEventsCount >= 10, "E2.1 Metric 4: Must emit unpredictable causal events");
            Require(guard.Violations == 0, "E2.1 3-day social intent run must have 0 guard violations");

            // Negative tests: fake modulus filler (cross-location, <100% why-linked, >=30% repeated pair, low entropy) MUST be rejected!
            NoFreeKnowledgeGuard negGuard = new NoFreeKnowledgeGuard();
            bool okCross = negGuard.ValidateAntiFillerMetrics(100, 100, 5, 2, 1.80, 20, 3);
            Require(!okCross && negGuard.Violations == 1, "E2.1 Negative Test: Cross-location interactions MUST be rejected");
            bool okUnlinked = negGuard.ValidateAntiFillerMetrics(100, 85, 5, 0, 1.80, 20, 3);
            Require(!okUnlinked && negGuard.Violations == 2, "E2.1 Negative Test: <100% why-linked interactions MUST be rejected");
            bool okRepeat = negGuard.ValidateAntiFillerMetrics(100, 100, 35, 0, 1.80, 20, 3);
            Require(!okRepeat && negGuard.Violations == 3, "E2.1 Negative Test: >=30% repeated pair without trigger MUST be rejected");
            bool okLowEnt = negGuard.ValidateAntiFillerMetrics(100, 100, 5, 0, 0.80, 20, 3);
            Require(!okLowEnt && negGuard.Violations == 4, "E2.1 Negative Test: Low interaction entropy (<1.25 bits) MUST be rejected");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_4_IdlePolicyLifePressure_RentArrears_And_DiminishingReturnsHeart()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem worldIdle = new SimPlaceGraphSystem(bundle);
            worldIdle.ActiveSoumaPolicy = "Idle";
            SimPerceptionMemoryRumorSystem rumorIdle = new SimPerceptionMemoryRumorSystem(bundle);
            WorldClock clock = new WorldClock();
            WeatherSystem weather = new WeatherSystem();
            weather.SetConfig(bundle.WeatherConfig);

            for (int d = 1; d <= 28; d++)
            {
                string season = WorldClock.ComputeSeasonForDay(d);
                string w = weather.DrawDailyWeather(7UL, d, season);
                for (int h = 0; h < 24; h++)
                {
                    for (int m = 0; m < 60; m++)
                    {
                        clock.AdvanceTicks((m % 2 == 0) ? 7 : 8);
                        worldIdle.StepOneGameMinute(7UL, d, clock.CurrentHour, m, w, "");
                    }
                    rumorIdle.EvaluateHourlyWorldEventsAndRumors(7UL, clock.TotalTicks, d, clock.CurrentHour, clock.CurrentSegment, w, worldIdle, guard);
                }
            }

            Require(worldIdle.SoumaMon == 0 && worldIdle.UnpaidRentDebtMon > 400, "Butir 4: Idle Soma must exhaust cash and accumulate rent/food debt");
            Require(worldIdle.UnpaidRentWeeks >= 4, "Butir 4: Idle Soma must accumulate 4 weeks of rent arrears with O-Hana");
            Require(worldIdle.GroupTrust <= 10 && worldIdle.GroupSupplyLineCut, "Butir 4: Idle Soma missing group orders must drop GroupTrust and cut supply line");
            int ohanaIdx = worldIdle.FindNpcIndexById("ohana");
            Require(worldIdle.Agents[ohanaIdx].SuspicionTowardSouma >= 35, "Butir 4: O-Hana suspicion toward Idle rent-delinquent Soma must rise significantly");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_5_CuratedNisshiBounds_12To20_And_NegativeBoundsGuard()
        {
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();

            List<NisshiEntry> tooFew = new List<NisshiEntry>();
            for (int i = 0; i < 5; i++) tooFew.Add(new NisshiEntry());
            bool okFew = guard.ValidateCuratedNisshiBounds(tooFew, 12, 20);
            Require(!okFew && guard.Violations == 1, "Wave D Negative Test: < 12 Nisshi entries MUST trigger violation");

            List<NisshiEntry> tooMany = new List<NisshiEntry>();
            for (int i = 0; i < 25; i++) tooMany.Add(new NisshiEntry());
            bool okMany = guard.ValidateCuratedNisshiBounds(tooMany, 12, 20);
            Require(!okMany && guard.Violations == 2, "Wave D Negative Test: > 20 Nisshi entries MUST trigger violation");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_6_DiegeticNpcInquiryDialogue_ContainsSourceAndCertainty()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

            int pasarIdx = world.FindPlaceIndexById("place_pasar");
            world.SoumaCurrentPlaceIdx = pasarIdx;
            world.SoumaIsInTransit = false;
            rumorSys.EmitWorldEvent(100, 1, 10, "Morning", "Clear", "EntityInteraction", "EntityInteraction", "haruki", "mio", "place_pasar", "haruki", "hide_za_ledger", 2, "motive_greed", 1.0, 20.0, true, false, "ZaLedger", "ZaLedger", world, guard);

            string dlg = rumorSys.GenerateDiegeticNpcDialogue("haruki", world);
            Require(ContainsSubstring(dlg, "Haruki") && ContainsSubstring(dlg, "keyakinan") && ContainsSubstring(dlg, "evt_"), "Butir 6b: Diegetic NPC dialogue must state what they know, certainty level, and source event");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_7_ModuleFestivalSystem_ObonAndSetsubunRules()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            SimEventBus bus = new SimEventBus(bundle);
            Require(SimFestivalSystem.GetCurrentFestivalViolenceTabooMultiplier(bus, 12) == 3, "Module SimFestivalSystem: Day 12 Obon must have taboo multiplier 3");
            Require(SimFestivalSystem.IsCurrentFestivalMasksAndNightGarbLegal(bus, 26), "Module SimFestivalSystem: Day 26 Setsubun must make masks and night garb legal");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_8_ModuleGigSystem_SchedulesAndFiresRippleEvent()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            SimEventBus bus = new SimEventBus(bundle);
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);

            WorldEvent gEvt = SimGigSystem.ExecuteSoumaCompleteGig(bus, 0, "Merciful", 200, 2, 14, "Afternoon", "Clear", world, guard);
            Require(gEvt.ActionCode == "complete_gig" && world.PendingGigRipples.Count == 1, "Module SimGigSystem: Completing Gig must schedule PendingGigRipple");
            int rippleDay = world.PendingGigRipples[0].TriggerDay;
            SimGigSystem.EvaluateHourlyGigRipples(bus, 900, rippleDay, 10, "Morning", "Clear", world, guard);
            Require(world.PendingGigRipples[0].Fired, "Module SimGigSystem: PendingGigRipple must fire on TriggerDay at 10:00");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_9_ModuleMicroStorySystem_TriggersOnWorldCondition()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            SimEventBus bus = new SimEventBus(bundle);
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);

            SimMicroStorySystem.EvaluateConditionalMicroStories(bus, 300, 1, 11, "Morning", "Storm", world, guard);
            Require(world.TriggeredMicroStoryIds.Count >= 1, "Module SimMicroStorySystem: Storm condition must trigger shelter micro-story");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_10_ModuleMemoryDecay_FadesRoutineMemoriesNextDay()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            SimEventBus bus = new SimEventBus(bundle);

            MemoryEntry rMem = new MemoryEntry();
            rMem.Id = "mem_1";
            rMem.Day = 1;
            rMem.IsRoutineMemory = true;
            rMem.SalienceScore = 0.18;
            rMem.Reliability = 0.88;
            rMem.Tellable = true;
            bus.Memories.Add(rMem);

            MemoryEntry sMem = new MemoryEntry();
            sMem.Id = "mem_2";
            sMem.Day = 1;
            sMem.IsRoutineMemory = false;
            sMem.SalienceScore = 0.82;
            sMem.Reliability = 0.90;
            sMem.Tellable = true;
            bus.Memories.Add(sMem);

            SimMemoryStore.DecayMemoriesAtDayStart(bus, 2);
            Require(!bus.Memories[0].Tellable, "Module SimMemoryStore: Routine memory must stop being tellable after 1 day decay");
            Require(bus.Memories[1].Tellable && bus.Memories[1].Reliability >= 0.80, "Module SimMemoryStore: High-salience memory must persist across days");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_11_ModuleEventBus_FastEventLookupAndTemplateFormatting()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            SimEventBus bus = new SimEventBus(bundle);
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);

            WorldEvent e1 = SimPerceptionSystem.EmitWorldEvent(bus, 10, 1, 8, "Morning", "Clear", "ScheduleTransition", "ScheduleTransition", "ryota", "", "place_barak_gerbang", "ryota", "inspect_newcomers", 3, "motive_spy", 1.0, 20.0, true, false, "Inspect", "Inspect", world, guard);
            WorldEvent found = bus.FindEventById(e1.Id);
            Require(found.Id == e1.Id && found.ActionCode == "inspect_newcomers", "Module SimEventBus: O(1) FindEventById must resolve emitted WorldEvent");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
#endif
        public static void Test_WaveD_12_ModuleEconomyDiminishingReturns_HeartDoesNotSaturateOnRoutineTrades()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            SimEventBus bus = new SimEventBus(bundle);
            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);

            world.HeartWarmCold = 10;
            for (int t = 0; t < 25; t++)
            {
                world.CarryUnits = 10;
                SimEconomyAndPressureSystem.ExecuteSoumaTrade(bus, 7UL, 100 + t, 1, 9, "Morning", "Clear", world, guard);
            }
            Require(world.HeartWarmCold <= 22, "Module SimEconomyAndPressureSystem: Routine trades must respect diminishing returns cap (<= 22) and never saturate Heart to +86");
        }

#if NUNIT_TESTS || UNITY_INCLUDE_TESTS
        [Test]
        public static void Test_Print_Deterministic_Hash_For_User_Dotnet_Verification()
        {
            string runA = HeadlessSimRunner.Run28DaySimToJson(7UL, 28, false);
            string runB = HeadlessSimRunner.Run28DaySimToJson(7UL, 28, false);
            Require(runA == runB, "Two runs of seed=7 (28 days) must produce identical JSON and hash");
            Console.WriteLine("[DOTNET_VERIFY] SEED_7_28DAY_SIM_JSON=" + runA);
        }
#endif

        public static void Test_WaveE_2_DualAdapterBundleEquivalenceHash()
        {
            SimDataBundle b1 = SimJsonDataLoader.LoadDefaultBundle();
            SimDataBundle b2 = UnitySimDataLoader.LoadDefaultBundle();
            string h1 = b1.ComputeBundleEquivalenceHashHex();
            string h2 = b2.ComputeBundleEquivalenceHashHex();
            Require(h1.Length == 16 && h1 == h2, "E1.2: SimJsonDataLoader and UnitySimDataLoader must produce identical SimDataBundle equivalence hash");
        }

        public static void Test_WaveE_3_ZeroHardcodedNpcIds_DataDrivenDutiesAndRelationships()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
            int landladyIdx = world.FindNpcIndexByDuty("collect_nagaya_rent");
            int hostIdx = world.FindNpcIndexByDuty("food_stall_host");
            int courierIdx = world.FindNpcIndexByDuty("group_courier");
            int guardIdx = world.FindNpcIndexByDuty("receive_citizen_reports");
            Require(landladyIdx >= 0 && hostIdx >= 0 && courierIdx >= 0 && guardIdx >= 0, "E2.2: All key village duties must resolve from JSON data");
            Require(world.Agents[landladyIdx].Relationships.Count >= 3, "E2.1: NPCs must load typed relationships from JSON");
        }

        public static void Test_WaveE_4_GroupTrustRecovery_KontakTerputus_UjianKesetiaan_DipercayaKembali_And_PemulihPolicy()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            string pemulihJson = HeadlessSimRunner.Run28DaySimWithPolicyAndBundle(7UL, 28, false, "Pemulih", bundle, true);
            Require(pemulihJson.Contains("\"groupContactState\":\"DipercayaKembali\""), "E2.3: Pemulih policy must recover GroupContactState to DipercayaKembali");
            Require(pemulihJson.Contains("\"reTrustedWithCaution\":true"), "E2.3: Pemulih policy must set reTrustedWithCaution=true");
        }

        public static void Test_WaveE_5_SoumaMisunderstandingIntervention_Success_Fail_Backfire()
        {
            string intJson = HeadlessSimRunner.RunThreeInterventionScenariosToJson();
            Require(intJson.Contains("Outcome=BERHASIL"), "E2.4: Intervention Scenario A must succeed with 2-source evidence");
            Require(intJson.Contains("Outcome=GAGAL"), "E2.4: Intervention Scenario B must fail when testifying under suspicion without proof");
            Require(intJson.Contains("Outcome=BERBALIK"), "E2.4: Intervention Scenario C must backfire when bribing an alert guard");
        }

        public static void Test_WaveE_6_StepCostBudget_Under2MsPerGameMinute()
        {
            string runJson = HeadlessSimRunner.Run28DaySimToJson(7UL, 1, false);
            Require(runJson.Contains("\"withinAndroidMidrangeBudget\":true"), "E1.2: Per-minute step cost must stay within < 2.0 ms mid-range Android budget");
        }

        public static int RunAllUnitTests()
        {
            Test_Clock_10Hz_18RealMinutesPerDay_And_28DayEventCounts();
            Test_DaySegments_Transitions();
            Test_Calendar28Days_FourSeasons_And_Festivals();
            Test_Weather_And_LightingPreset_Determinism();
            Test_Weather_MaxStreak_AtMost3Days_UnlessWeightsForceSingleWeather();
            Test_NoFreeKnowledgeGuard();
            Test_L195_JsonDataAdapter_ModifyingJsonChangesOutcome();
            Test_A2_1a_EventEmitterDisabled_ProducesZeroMemoriesAndZeroRumors();
            Test_A2_1b_InjectMemoryWithoutSourceEventId_TriggersViolation();
            Test_A2_1c_RumorAboutNonexistentEvent_TriggersViolation();
            Test_A2_1_SeedDiversity_And_FiveAlgorithmicDistortionOperators();
            Test_A2_2_DataDriven20CanonicalNpcs_And_OhanaOkikuCanonRoles();
            Test_L4_SocialSuspicionReasons_GarmentsWithoutPureBlack_And_FishOdorMasksBlood();
            Test_L5_Economy28Days_NoRunaway_And_EveryTradeYieldsKabarOrAccess();
            Test_L6_ThreeScriptedScenarios_Quiet_LoudCorpseDiscovery_And_TrueFaceMarket();
            Test_A3_1_MotiveLeakageGuard_DirectWitnessCannotKnowTrueMotiveWithoutOperator();
            Test_A3_2_StateDrivenEventEmitter_FourCategories_ZeroUnclassified_And_GuardPostVacancy();
            Test_A3_3_A3_4_And_L8_FourPolicies_CausalChains_And_NisshiDistinctness();
            Test_WaveD_1_SalienceScoring_And_NegativeRoutineSpreadGuard();
            Test_WaveD_2_AgencyBeliefToAction_Order2And3_And_NegativeAgencyGuard();
            Test_WaveE_1_SocialIntent_AntiFillerMetrics_And_NegativeModulusRejection();
            Test_WaveD_4_IdlePolicyLifePressure_RentArrears_And_DiminishingReturnsHeart();
            Test_WaveD_5_CuratedNisshiBounds_12To20_And_NegativeBoundsGuard();
            Test_WaveD_6_DiegeticNpcInquiryDialogue_ContainsSourceAndCertainty();
            Test_WaveD_7_ModuleFestivalSystem_ObonAndSetsubunRules();
            Test_WaveD_8_ModuleGigSystem_SchedulesAndFiresRippleEvent();
            Test_WaveD_9_ModuleMicroStorySystem_TriggersOnWorldCondition();
            Test_WaveD_10_ModuleMemoryDecay_FadesRoutineMemoriesNextDay();
            Test_WaveD_11_ModuleEventBus_FastEventLookupAndTemplateFormatting();
            Test_WaveD_12_ModuleEconomyDiminishingReturns_HeartDoesNotSaturateOnRoutineTrades();
            Test_WaveE_2_DualAdapterBundleEquivalenceHash();
            Test_WaveE_3_ZeroHardcodedNpcIds_DataDrivenDutiesAndRelationships();
            Test_WaveE_4_GroupTrustRecovery_KontakTerputus_UjianKesetiaan_DipercayaKembali_And_PemulihPolicy();
            Test_WaveE_5_SoumaMisunderstandingIntervention_Success_Fail_Backfire();
            Test_WaveE_6_StepCostBudget_Under2MsPerGameMinute();
            return 35;
        }
    }
}
