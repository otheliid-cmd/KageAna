// KAGE-ANA v3.0 Gelombang D (Butir 8) — Koordinator Ringkas Sistem Persepsi, Ingatan, Rumor, Agensi & Nisshi
// Dipecah dari 1.884 baris menjadi 12 modul terpisah di Runtime/Sim/Rumor/ (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public sealed class SimPerceptionMemoryRumorSystem : SimEventBus
    {
        public SimPerceptionMemoryRumorSystem(SimDataBundle bundle) : base(bundle)
        {
        }

        public void RecordKisahEvent(int day, int hour, string category, string placeId, string summary)
        {
            SimNisshiCurator.RecordKisahEvent(this, day, hour, category, placeId, summary);
        }

        public void RecordNisshiEntry(int day, string category, string sourceEventId, string text)
        {
            SimNisshiCurator.RecordNisshiEntry(this, day, category, sourceEventId, text);
        }

        public void CurateYearlyNisshi(SimPlaceGraphSystem world)
        {
            SimNisshiCurator.CurateYearlyNisshi(this, world);
        }

        public string GenerateDiegeticNpcDialogue(string targetNpcId, SimPlaceGraphSystem world)
        {
            return SimSoumaActionSystem.GenerateDiegeticNpcDialogue(this, targetNpcId, world);
        }

        public int GetCurrentFestivalViolenceTabooMultiplier(int day)
        {
            return SimFestivalSystem.GetCurrentFestivalViolenceTabooMultiplier(this, day);
        }

        public bool IsCurrentFestivalMasksAndNightGarbLegal(int day)
        {
            return SimFestivalSystem.IsCurrentFestivalMasksAndNightGarbLegal(this, day);
        }

        public double GetCurrentFestivalTeaSweetsMultiplier(int day)
        {
            return SimFestivalSystem.GetCurrentFestivalTeaSweetsMultiplier(this, day);
        }

        public WorldEvent EmitWorldEvent(
            int tick, int day, int hour, string segment, string weather,
            string evtType, string eventSourceCategory, string actorId, string secondaryEntityId,
            string placeId, string subjectId, string actionCode, int quantity,
            string trueMotiveForDebugOnly, double visibility, double noiseDb,
            bool tellable, bool isFlavorOnly, string stateEffectSummary, string payload,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimPerceptionSystem.EmitWorldEvent(
                this, tick, day, hour, segment, weather, evtType, eventSourceCategory,
                actorId, secondaryEntityId, placeId, subjectId, actionCode, quantity,
                trueMotiveForDebugOnly, visibility, noiseDb, tellable, isFlavorOnly,
                stateEffectSummary, payload, world, guard
            );
        }

        public void EvaluatePerceptionForWorldEvent(
            WorldEvent evt, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            SimPerceptionSystem.EvaluatePerceptionForWorldEvent(this, evt, segment, weather, world, guard);
        }

        public void RegisterSoumaKabarObservation(
            string sourceEventId, string rootWitnessId, string sourceTypeLabel,
            StructuredClaim claim, int day, int hour, SimPlaceGraphSystem world)
        {
            SimMemoryStore.RegisterSoumaKabarObservation(this, sourceEventId, rootWitnessId, sourceTypeLabel, claim, day, hour, world);
        }

        public void EvaluateConditionalMicroStories(
            int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            SimMicroStorySystem.EvaluateConditionalMicroStories(this, tick, day, hour, segment, weather, world, guard);
        }

        public void EvaluateHourlySocialSuspicion(int day, int hour, string segment, SimPlaceGraphSystem world)
        {
            SimSuspicionSystem.EvaluateHourlySocialSuspicion(this, day, hour, segment, world);
        }

        public WorldEvent ExecuteSoumaTrade(
            ulong seed, int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimEconomyAndPressureSystem.ExecuteSoumaTrade(this, seed, tick, day, hour, segment, weather, world, guard);
        }

        public WorldEvent ExecuteSoumaCompleteGig(
            int gigIdx, string chosenApproach, int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimGigSystem.ExecuteSoumaCompleteGig(this, gigIdx, chosenApproach, tick, day, hour, segment, weather, world, guard);
        }

        public WorldEvent ExecuteSoumaInquireNpc(
            int tick, int day, int hour, string segment, string weather, string targetNpcId,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimSoumaActionSystem.ExecuteSoumaInquireNpc(this, tick, day, hour, segment, weather, targetNpcId, world, guard);
        }

        public WorldEvent ExecuteSoumaSteal(
            int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimSoumaActionSystem.ExecuteSoumaSteal(this, tick, day, hour, segment, weather, world, guard);
        }

        public WorldEvent ExecuteSoumaPayRentToOhana(
            int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimEconomyAndPressureSystem.ExecuteSoumaPayRentToOhana(this, tick, day, hour, segment, weather, world, guard);
        }

        public WorldEvent ExecuteSoumaDeadDropReport(
            int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimEconomyAndPressureSystem.ExecuteSoumaDeadDropReport(this, tick, day, hour, segment, weather, world, guard);
        }

        public WorldEvent ExecuteSoumaSleepAndCleanInNagaya(
            int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimSoumaActionSystem.ExecuteSoumaSleepAndCleanInNagaya(this, tick, day, hour, segment, weather, world, guard);
        }

        public WorldEvent ExecuteSoumaElimination(
            int tick, int day, int hour, string segment, string weather,
            string victimNpcId, bool isLoud, bool hideCorpse,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimSoumaActionSystem.ExecuteSoumaElimination(this, tick, day, hour, segment, weather, victimNpcId, isLoud, hideCorpse, world, guard);
        }

        public WorldEvent ExecuteSoumaTrueFace(
            int stage, int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimSoumaActionSystem.ExecuteSoumaTrueFace(this, stage, tick, day, hour, segment, weather, world, guard);
        }

        public WorldEvent ExecuteSoumaInterveneMisunderstanding(
            string interventionType, string targetChainId, int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            return SimSoumaActionSystem.ExecuteSoumaInterveneMisunderstanding(this, interventionType, targetChainId, tick, day, hour, segment, weather, world, guard);
        }

        public void EvaluateHourlyWorldEventsAndRumors(
            ulong seed, int tick, int day, int hour, string segment, string weather,
            SimPlaceGraphSystem world, NoFreeKnowledgeGuard guard)
        {
            world.MarketPriceMultiplier = GetCurrentFestivalTeaSweetsMultiplier(day);

            if (world.CrackdownHoursRemaining > 0)
            {
                world.CrackdownHoursRemaining -= 1;
                if (world.CrackdownHoursRemaining <= 0)
                {
                    world.DistrictCrackdownActive = false;
                }
            }

            for (int c = 0; c < world.Corpses.Count; c++)
            {
                CorpseRecord corp = world.Corpses[c];
                if (corp.IsHidden || corp.IsDiscovered) continue;
                int cpIdx = world.FindPlaceIndexById(corp.PlaceId);
                for (int n = 0; n < world.Agents.Count; n++)
                {
                    NpcRuntimeState ag = world.Agents[n];
                    if (ag.IsDead || ag.IsSleeping || ag.IsInTransit) continue;
                    if (ag.CurrentPlaceIdx == cpIdx)
                    {
                        corp.IsDiscovered = true;
                        corp.DiscoveredByNpcId = ag.Id;
                        WorldEvent cEvt = EmitWorldEvent(
                            tick, day, hour, segment, weather,
                            "CorpseDiscovered", "WorldCondition",
                            ag.Id, corp.VictimNpcId, corp.PlaceId, corp.VictimNpcId,
                            "corpse_discovered", 1, "motive_fear", 1.2, 48.0, true, false,
                            "CorpseDiscoveredBy:" + ag.Id + ";CrackdownActivated=true",
                            "Corpse of " + corp.VictimNpcId + " discovered by " + ag.Id,
                            world, guard
                        );
                        RecordKisahEvent(day, hour, "MayatDitemukan", corp.PlaceId, ag.DisplayName + " menemukan jenazah " + corp.VictimNpcId + " di " + world.Places[cpIdx].Name + "! Razia darurat diaktifkan!");
                        RecordNisshiEntry(day, "JejakBayangan", cEvt.Id, "Hari " + day.ToString() + " — Jenazah " + corp.VictimNpcId + " ditemukan oleh " + ag.DisplayName + " di " + world.Places[cpIdx].Name + "; Razia Kuzuryu dikerahkan.");
                        break;
                    }
                }
            }

            SimGigSystem.EvaluateHourlyGigRipples(this, tick, day, hour, segment, weather, world, guard);

            SimEconomyAndPressureSystem.EvaluateHourlyScheduleAndEntityInteractions(this, seed, tick, day, hour, segment, weather, world, guard);

            SimSoumaActionSystem.EvaluateHourlyAutomatedSoumaPolicy(this, seed, tick, day, hour, segment, weather, world, guard);

            if (EventEmitterEnabled && (hour == 11 || hour == 16 || hour == 20))
            {
                SimMicroStorySystem.EvaluateConditionalMicroStories(this, tick, day, hour, segment, weather, world, guard);
            }

            SimSuspicionSystem.EvaluateHourlySocialSuspicion(this, day, hour, segment, world);

            SimRumorPropagator.PropagateHourlyRumors(this, seed, day, hour, world, guard);

            SimNpcAgencySystem.EvaluateHourlyNpcAgency(this, seed, tick, day, hour, segment, weather, world, guard);

            if (day == 28 && hour == 23)
            {
                SimNisshiCurator.CurateYearlyNisshi(this, world);
            }
        }
    }
}
