// STATUS VERIFIKASI (E3.1 & E8): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using System;
using UnityEngine;
using KageAna.Input;

namespace KageAna.Tests.EditMode
{
    /// <summary>
    /// E8: Uji otomatis simulasi input untuk ke-14 aksi pada ketiga skema kontrol (KeyboardMouse, Gamepad, Touch).
    /// </summary>
    public static class InputAndBridgeEditModeTests
    {
        public static bool RunAllFourteenActionsAcrossThreeSchemes()
        {
            var go = new GameObject("InputTestHost");
            var ctrl = go.AddComponent<UnifiedInputController>();
            ControlSchemeType[] schemes = new ControlSchemeType[]
            {
                ControlSchemeType.KeyboardMouse,
                ControlSchemeType.Gamepad,
                ControlSchemeType.Touch
            };

            for (int s = 0; s < schemes.Length; s++)
            {
                for (int i = 0; i < UnifiedInputController.RequiredFourteenActions.Length; i++)
                {
                    string act = UnifiedInputController.RequiredFourteenActions[i];
                    ctrl.SimulateSchemeInput(schemes[s], new Vector2(0.5f, 0.5f), new Vector2(0.1f, 0.0f), act);
                    if (!ctrl.WasActionTriggered(act))
                    {
                        UnityEngine.Object.DestroyImmediate(go);
                        return false;
                    }
                }
            }
            UnityEngine.Object.DestroyImmediate(go);
            return true;
        }
    }
}
