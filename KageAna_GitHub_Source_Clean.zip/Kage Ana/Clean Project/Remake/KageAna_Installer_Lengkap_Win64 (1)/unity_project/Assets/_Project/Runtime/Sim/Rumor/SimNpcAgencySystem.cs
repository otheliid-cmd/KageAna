// KAGE-ANA v3.0 Gelombang D (Butir 2 & 8) — Modul 7: Agensi NPC (Keyakinan -> Niat -> Tindakan Orde Ke-2 & Ke-3 + Salah Paham)
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimNpcAgencySystem
    {
        private static bool ContainsOp(string ops, string tok)
        {
            int n = ops.Length;
            int m = tok.Length;
            for (int i = 0; i <= n - m; i++)
            {
                bool ok = true;
                for (int j = 0; j < m; j++)
                {
                    if (ops[i + j] != tok[j]) { ok = false; break; }
                }
                if (ok) return true;
            }
            return false;
        }

        public static void EvaluateHourlyNpcAgency(
            SimEventBus bus,
            ulong seed,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (!bus.EventEmitterEnabled || !(hour == 10 || hour == 14 || hour == 18))
            {
                return;
            }

            double minSalience = bus.Data.SalienceConfig.SalientMinSalience;
            int memCount = bus.Memories.Count;
            int minMemIdx = memCount > 90 ? memCount - 90 : 0;
            int agencyFiredThisHour = 0;

            for (int mIdx = memCount - 1; mIdx >= minMemIdx; mIdx--)
            {
                if (agencyFiredThisHour >= 2) break;
                MemoryEntry beliefMem = bus.Memories[mIdx];
                if (beliefMem.AgencyActedOn) continue;
                if (beliefMem.IsRoutineMemory || beliefMem.SalienceScore < minSalience) continue;
                if (beliefMem.HopCount < 1) continue;

                string bAct = beliefMem.Claim.ActionCode;
                if (bAct == "agency_confront_accused" || bAct == "agency_price_sanction" || bAct == "agency_avoid_or_boycott" || bAct == "agency_cover_up_ally")
                {
                    continue;
                }

                int actorIdx = world.FindNpcIndexById(beliefMem.OwnerNpcId);
                if (actorIdx < 0) continue;
                NpcRuntimeState actor = world.Agents[actorIdx];
                if (actor.IsDead || actor.IsSleeping || actor.IsInTransit) continue;
                if (actor.LastAgencyActionDay == day) continue;

                if (!guard.ValidateAgencyActionAgainstBelief(actor.Id, beliefMem.Id, bus.Memories, minSalience))
                {
                    continue;
                }

                WorldEvent rootEvt = bus.FindEventById(beliefMem.SourceEventId);
                if (rootEvt.Id.Length == 0) continue;

                string accusedId = beliefMem.Claim.SubjectId;
                string believedPlaceId = beliefMem.Claim.PlaceId;
                string actorPlaceId = world.Places[actor.CurrentPlaceIdx].Id;

                bool isMisunderstanding = (accusedId != rootEvt.SubjectId)
                    || (believedPlaceId != rootEvt.PlaceId)
                    || ContainsOp(beliefMem.AppliedDistortionOperators, "WrongPerson")
                    || ContainsOp(beliefMem.AppliedDistortionOperators, "WrongPlace")
                    || ContainsOp(beliefMem.AppliedDistortionOperators, "Magnify")
                    || ContainsOp(beliefMem.AppliedDistortionOperators, "AddMotive");

                string accusedName = bus.LookupSubjectDisplayName(accusedId, world);
                string rootSubjectName = bus.LookupSubjectDisplayName(rootEvt.SubjectId, world);

                // KASUS 1: Melapor ke Penjaga (Orde Ke-2) -> Penjaga Mengonfrontasi Tertuduh (Orde Ke-3)
                if (actor.RoleCategory != "Guard" && actor.SuspicionTrait >= 6 && (bAct == "hide_za_ledger" || bAct == "leave_post_early" || bAct == "steal_item" || bAct == "npc_heated_argument" || bAct == "npc_debt_demand" || bAct == "rent_arrears_warning"))
                {
                    int guardIdx = world.FindActiveNpcIndexByRoleCategory("Guard");
                    if (guardIdx < 0) guardIdx = world.FindNpcIndexByDuty("receive_citizen_reports");
                    if (guardIdx >= 0)
                    {
                        NpcRuntimeState guardNpc = world.Agents[guardIdx];
                        beliefMem.AgencyActedOn = true;
                        actor.LastAgencyActionDay = day;
                        agencyFiredThisHour += 1;
                        bus.AgencyActionsEmittedCount += 1;

                        WorldEvent evtOrder2 = SimPerceptionSystem.EmitWorldEvent(
                            bus,
                            tick, day, hour, segment, weather,
                            "AgencyAction", "EntityInteraction",
                            actor.Id, guardNpc.Id, actorPlaceId, actor.Id,
                            "agency_report_to_guard", 1, "motive_fear", 1.0, 20.0, true, false,
                            "AgencyReportToGuard:" + actor.Id + "->" + guardNpc.Id + ";Accused=" + accusedId,
                            actor.DisplayName + " melaporkan " + accusedName + " kepada penjaga " + guardNpc.DisplayName,
                            world, guard
                        );
                        evtOrder2.ParentEventId = rootEvt.Id;
                        evtOrder2.WhyNeedAndRelationTag = "Drive=tugas_jadwal;Rel=atasan_bawahan;Trigger=Belief_" + beliefMem.Id;
                        evtOrder2.IsUnpredictableFromSchedule = true;
                        bus.WhyLinkedInteractionEventsCount += 1;
                        bus.UnpredictableCausalEventsCount += 1;
                        actor.RecordActionForEntropy("agency_report_to_guard");

                        int fineMon = 35;
                        int accIdx = world.FindNpcIndexById(accusedId);
                        if (accIdx >= 0)
                        {
                            world.Agents[accIdx].NpcMon = Math.Max(0, world.Agents[accIdx].NpcMon - fineMon);
                            world.Agents[accIdx].DailyInteractionsCount += 1;
                            world.Agents[accIdx].TotalInteractionsCount += 1;
                        }
                        else if (accusedId == "souma")
                        {
                            world.SoumaMon = Math.Max(0, world.SoumaMon - fineMon);
                            world.TotalExpensesMon += fineMon;
                            world.UpdateMonBounds();
                            world.AddSuspicionReason(guardIdx, 16, "Menindaklanjuti aduan " + actor.DisplayName + " atas rumor '" + bAct + "'");
                        }
                        guardNpc.NpcMon += fineMon;
                        guardNpc.DailyInteractionsCount += 1;
                        guardNpc.TotalInteractionsCount += 1;
                        bus.AgencyActionsEmittedCount += 1;

                        WorldEvent evtOrder3 = SimPerceptionSystem.EmitWorldEvent(
                            bus,
                            tick + 2, day, hour, segment, weather,
                            "AgencyAction", "EntityInteraction",
                            guardNpc.Id, accusedId, believedPlaceId, guardNpc.Id,
                            "agency_confront_accused", fineMon, "motive_spy", 1.1, 26.0, true, false,
                            "AgencyGuardConfront:" + guardNpc.Id + "->" + accusedId + ";Fine=" + fineMon.ToString() + "mon;Misunderstanding=" + (isMisunderstanding ? "true" : "false"),
                            guardNpc.DisplayName + " menginterogasi dan mendenda " + accusedName + " sebesar " + fineMon.ToString() + " mon",
                            world, guard
                        );
                        evtOrder3.ParentEventId = evtOrder2.Id;
                        evtOrder3.WhyNeedAndRelationTag = "Drive=tugas_jadwal;Rel=atasan_bawahan;Trigger=Report_" + evtOrder2.Id;
                        evtOrder3.IsUnpredictableFromSchedule = true;
                        bus.WhyLinkedInteractionEventsCount += 1;
                        bus.UnpredictableCausalEventsCount += 1;
                        guardNpc.RecordActionForEntropy("agency_confront_accused");

                        if (isMisunderstanding) bus.MisunderstandingChainsCount += 1;

                        string conseqDesc = isMisunderstanding
                            ? ((accusedId != rootEvt.SubjectId ? ("SALAH PAHAM ORANG (WrongPerson): Karena rumor terdistorsi (" + beliefMem.AppliedDistortionOperators + "), " + actor.DisplayName + " salah mengira " + accusedName + " pelaku '" + bAct + "' (padahal pelaku sebenarnya di " + rootEvt.Id + " adalah " + rootSubjectName + ") lalu melapor ke " + guardNpc.DisplayName + " (" + evtOrder2.Id + "), sehingga " + guardNpc.DisplayName + " menginterogasi & mendenda " + accusedName + " sebesar " + fineMon.ToString() + " mon (" + evtOrder3.Id + ")!") : ("SALAH PAHAM MOTIF/TEMPAT (" + beliefMem.AppliedDistortionOperators + "): " + actor.DisplayName + " termakan bumbu desas-desus tentang " + accusedName + " (sumber: " + rootEvt.Id + ") lalu melapor ke " + guardNpc.DisplayName + " (" + evtOrder2.Id + "), sehingga " + guardNpc.DisplayName + " menginterogasi & mendenda " + accusedName + " sebesar " + fineMon.ToString() + " mon (" + evtOrder3.Id + ")!")))
                            : (actor.DisplayName + " mempercayai kabar '" + bAct + "' lalu melapor ke penjaga " + guardNpc.DisplayName + " (" + evtOrder2.Id + "), yang kemudian mengonfrontasi & mendenda " + accusedName + " sebesar " + fineMon.ToString() + " mon (" + evtOrder3.Id + ").");

                        SimMemoryStore.TryRecordMultiOrderCausalChain(
                            bus, world.ActiveSoumaPolicy, day, rootEvt,
                            beliefMem.RootWitnessNpcId, beliefMem.SourceMemoryId,
                            beliefMem.TellerNpcId, actor.Id, beliefMem.Id,
                            beliefMem.AppliedDistortionOperators,
                            isMisunderstanding ? "AgencyMisunderstandingConfront" : "AgencyReportAndConfront",
                            conseqDesc,
                            evtOrder2.Id, evtOrder3.Id, isMisunderstanding
                        );
                        continue;
                    }
                }

                // KASUS 2: Penjaga/Pejabat langsung mengonfrontasi
                if (actor.RoleCategory == "Guard" || actor.RoleCategory == "Official")
                {
                    beliefMem.AgencyActedOn = true;
                    actor.LastAgencyActionDay = day;
                    agencyFiredThisHour += 1;
                    bus.AgencyActionsEmittedCount += 1;

                    int fineMon = 30;
                    int accIdx = world.FindNpcIndexById(accusedId);
                    if (accIdx >= 0)
                    {
                        world.Agents[accIdx].NpcMon = Math.Max(0, world.Agents[accIdx].NpcMon - fineMon);
                        world.Agents[accIdx].DailyInteractionsCount += 1;
                    }
                    else if (accusedId == "souma")
                    {
                        world.AddSuspicionReason(actorIdx, 18, "Mengonfrontasi Soma atas keyakinan rumor '" + bAct + "'");
                    }

                    WorldEvent evtOrder2 = SimPerceptionSystem.EmitWorldEvent(
                        bus,
                        tick, day, hour, segment, weather,
                        "AgencyAction", "EntityInteraction",
                        actor.Id, accusedId, actorPlaceId, actor.Id,
                        "agency_confront_accused", fineMon, "motive_spy", 1.1, 24.0, true, false,
                        "AgencyDirectConfront:" + actor.Id + "->" + accusedId + ";Fine=" + fineMon.ToString() + "mon",
                        actor.DisplayName + " mengonfrontasi " + accusedName + " atas tuduhan " + bAct,
                        world, guard
                    );
                    evtOrder2.ParentEventId = rootEvt.Id;
                        evtOrder2.WhyNeedAndRelationTag = "Drive=tugas_jadwal;Rel=atasan_bawahan;Trigger=Belief_" + beliefMem.Id;
                        evtOrder2.IsUnpredictableFromSchedule = true;
                        bus.WhyLinkedInteractionEventsCount += 1;
                        bus.UnpredictableCausalEventsCount += 1;
                        actor.RecordActionForEntropy("agency_report_to_guard");
                    if (isMisunderstanding) bus.MisunderstandingChainsCount += 1;

                    string conseqDesc = isMisunderstanding
                        ? ((accusedId != rootEvt.SubjectId ? ("SALAH PAHAM PENJAGA (WrongPerson): " + actor.DisplayName + " termakan kabar salah orang (" + beliefMem.AppliedDistortionOperators + ") dan menegur keras serta mendenda " + accusedName + " 30 mon (" + evtOrder2.Id + "), padahal kejadian sumber " + rootEvt.Id + " dilakukan oleh " + rootSubjectName + "!") : ("SALAH PAHAM PENJAGA (" + beliefMem.AppliedDistortionOperators + "): " + actor.DisplayName + " termakan kabar yang dibumbui tentang " + accusedName + " (sumber: " + rootEvt.Id + ") lalu menjatuhkan denda 30 mon (" + evtOrder2.Id + ")!")))
                        : (actor.DisplayName + " bertindak atas keyakinan rumor '" + bAct + "' dengan menginterogasi dan mendenda " + accusedName + " sebesar 30 mon (" + evtOrder2.Id + ").");

                    SimMemoryStore.TryRecordMultiOrderCausalChain(
                        bus, world.ActiveSoumaPolicy, day, rootEvt,
                        beliefMem.RootWitnessNpcId, beliefMem.SourceMemoryId,
                        beliefMem.TellerNpcId, actor.Id, beliefMem.Id,
                        beliefMem.AppliedDistortionOperators,
                        isMisunderstanding ? "AgencyMisunderstandingConfront" : "AgencyGuardConfront",
                        conseqDesc,
                        evtOrder2.Id, "", isMisunderstanding
                    );
                    continue;
                }

                // KASUS 3: Pedagang / Pemilik Sewa menaikkan harga / membatasi layanan
                if (actor.RoleCategory == "Merchant" || actor.RoleCategory == "Landlady" || actor.Greed >= 6)
                {
                    beliefMem.AgencyActedOn = true;
                    actor.LastAgencyActionDay = day;
                    agencyFiredThisHour += 1;
                    bus.AgencyActionsEmittedCount += 1;

                    int surchargeMon = 25;
                    world.MarketPriceMultiplier = Math.Min(1.45, world.MarketPriceMultiplier + 0.08);
                    actor.AttitudeTowardSouma = "Curiga";

                    WorldEvent evtOrder2 = SimPerceptionSystem.EmitWorldEvent(
                        bus,
                        tick, day, hour, segment, weather,
                        "AgencyAction", "EntityInteraction",
                        actor.Id, accusedId, actorPlaceId, actor.Id,
                        "agency_price_sanction", surchargeMon, "motive_greed", 1.0, 19.0, true, false,
                        "AgencyPriceSanction:" + actor.Id + "->" + accusedId + ";Surcharge=+" + surchargeMon.ToString() + "mon",
                        actor.DisplayName + " menaikkan harga +" + surchargeMon.ToString() + " mon dan membatasi layanan karena curiga pada " + accusedName,
                        world, guard
                    );
                    evtOrder2.ParentEventId = rootEvt.Id;
                    evtOrder2.WhyNeedAndRelationTag = "Drive=perlu_dagang;Rel=saingan;Trigger=Belief_" + beliefMem.Id;
                    evtOrder2.IsUnpredictableFromSchedule = true;
                    bus.WhyLinkedInteractionEventsCount += 1;
                    bus.UnpredictableCausalEventsCount += 1;
                    actor.RecordActionForEntropy("agency_price_sanction");
                    if (isMisunderstanding) bus.MisunderstandingChainsCount += 1;

                    string conseqDesc = isMisunderstanding
                        ? ((accusedId != rootEvt.SubjectId ? ("SALAH PAHAM DAGANG (WrongPerson): Karena kabar salah orang (" + beliefMem.AppliedDistortionOperators + "), " + actor.DisplayName + " menyangka " + accusedName + " pelaku '" + bAct + "' (padahal pelakunya " + rootSubjectName + " di " + rootEvt.Id + ") lalu menaikkan harga lapak +" + surchargeMon.ToString() + " mon dan menolak utang (" + evtOrder2.Id + ")!") : ("SALAH PAHAM DAGANG (" + beliefMem.AppliedDistortionOperators + "): Karena desas-desus yang dibesar-besarkan dari " + rootEvt.Id + ", " + actor.DisplayName + " mencurigai " + accusedName + " lalu menaikkan harga lapak +" + surchargeMon.ToString() + " mon dan menolak utang (" + evtOrder2.Id + ")!")))
                        : (actor.DisplayName + " bereaksi atas kabar '" + bAct + "' dengan menaikkan harga +" + surchargeMon.ToString() + " mon dan memperketat transaksi terhadap " + accusedName + " (" + evtOrder2.Id + ").");

                    SimMemoryStore.TryRecordMultiOrderCausalChain(
                        bus, world.ActiveSoumaPolicy, day, rootEvt,
                        beliefMem.RootWitnessNpcId, beliefMem.SourceMemoryId,
                        beliefMem.TellerNpcId, actor.Id, beliefMem.Id,
                        beliefMem.AppliedDistortionOperators,
                        isMisunderstanding ? "AgencyMisunderstandingSanction" : "AgencyPriceSanction",
                        conseqDesc,
                        evtOrder2.Id, "", isMisunderstanding
                    );
                    continue;
                }

                // KASUS 4: Warga ramah membantu / menutupi alibi vs Warga penakut menghindar
                beliefMem.AgencyActedOn = true;
                actor.LastAgencyActionDay = day;
                agencyFiredThisHour += 1;
                bus.AgencyActionsEmittedCount += 1;

                if (actor.Friendliness >= 7 && actor.Courage >= 5)
                {
                    int helpMon = 20;
                    actor.NpcMon = Math.Max(0, actor.NpcMon - helpMon);
                    int accIdx = world.FindNpcIndexById(accusedId);
                    if (accIdx >= 0) world.Agents[accIdx].NpcMon += helpMon;

                    WorldEvent evtOrder2 = SimPerceptionSystem.EmitWorldEvent(
                        bus,
                        tick, day, hour, segment, weather,
                        "AgencyAction", "EntityInteraction",
                        actor.Id, accusedId, actorPlaceId, actor.Id,
                        "agency_cover_up_ally", helpMon, "motive_bribe", 0.90, 17.0, true, false,
                        "AgencyCoverUpAlly:" + actor.Id + "->" + accusedId + ";HelpMon=" + helpMon.ToString(),
                        actor.DisplayName + " pasang badan memberi alibi dan bantuan " + helpMon.ToString() + " mon untuk " + accusedName,
                        world, guard
                    );
                    evtOrder2.ParentEventId = rootEvt.Id;
                    evtOrder2.WhyNeedAndRelationTag = "Drive=kasih_sayang;Rel=rekan;Trigger=Belief_" + beliefMem.Id;
                    evtOrder2.IsUnpredictableFromSchedule = true;
                    bus.WhyLinkedInteractionEventsCount += 1;
                    bus.UnpredictableCausalEventsCount += 1;
                    actor.RecordActionForEntropy("agency_cover_up_ally");
                    if (isMisunderstanding) bus.MisunderstandingChainsCount += 1;

                    string conseqDesc = actor.DisplayName + " mendengar desas-desus (" + beliefMem.AppliedDistortionOperators + ") yang menyudutkan " + accusedName + " dan memutuskan pasang badan memberi alibi serta bantuan " + helpMon.ToString() + " mon (" + evtOrder2.Id + ").";
                    SimMemoryStore.TryRecordMultiOrderCausalChain(
                        bus, world.ActiveSoumaPolicy, day, rootEvt,
                        beliefMem.RootWitnessNpcId, beliefMem.SourceMemoryId,
                        beliefMem.TellerNpcId, actor.Id, beliefMem.Id,
                        beliefMem.AppliedDistortionOperators,
                        "AgencyCoverUpAlly",
                        conseqDesc,
                        evtOrder2.Id, "", isMisunderstanding
                    );
                }
                else
                {
                    actor.AttitudeTowardSouma = "Menghindar";
                    int shrineIdx = world.FindPlaceIndexById("place_kuil_kecil");
                    if (shrineIdx >= 0) actor.TargetPlaceIdx = shrineIdx;

                    WorldEvent evtOrder2 = SimPerceptionSystem.EmitWorldEvent(
                        bus,
                        tick, day, hour, segment, weather,
                        "AgencyAction", "EntityInteraction",
                        actor.Id, accusedId, actorPlaceId, actor.Id,
                        "agency_avoid_or_boycott", 2, "motive_fear", 0.95, 18.0, true, false,
                        "AgencyAvoidPlace:" + actor.Id + "->Avoid:" + believedPlaceId,
                        actor.DisplayName + " mengajak warga menjauhi " + bus.LookupPlaceDisplayName(believedPlaceId, world) + " dan menghindari " + accusedName,
                        world, guard
                    );
                    evtOrder2.ParentEventId = rootEvt.Id;
                    evtOrder2.WhyNeedAndRelationTag = "Drive=perlu_istirahat;Rel=rekan;Trigger=Belief_" + beliefMem.Id;
                    evtOrder2.IsUnpredictableFromSchedule = true;
                    bus.WhyLinkedInteractionEventsCount += 1;
                    bus.UnpredictableCausalEventsCount += 1;
                    actor.RecordActionForEntropy("agency_avoid_or_boycott");
                    if (isMisunderstanding) bus.MisunderstandingChainsCount += 1;

                    string conseqDesc = isMisunderstanding
                        ? ("SALAH PAHAM BOIKOT: Termakan kabar keliru (" + beliefMem.AppliedDistortionOperators + "), " + actor.DisplayName + " ketakutan dan mengajak warga menjauhi " + bus.LookupPlaceDisplayName(believedPlaceId, world) + " serta menghindari " + accusedName + " (" + evtOrder2.Id + "), padahal kejadian " + rootEvt.Id + " terjadi di " + bus.LookupPlaceDisplayName(rootEvt.PlaceId, world) + "!")
                        : (actor.DisplayName + " cemas atas kabar '" + bAct + "' lalu mengajak warga menghindari " + accusedName + " dan menyingkir ke kuil (" + evtOrder2.Id + ").");

                    SimMemoryStore.TryRecordMultiOrderCausalChain(
                        bus, world.ActiveSoumaPolicy, day, rootEvt,
                        beliefMem.RootWitnessNpcId, beliefMem.SourceMemoryId,
                        beliefMem.TellerNpcId, actor.Id, beliefMem.Id,
                        beliefMem.AppliedDistortionOperators,
                        isMisunderstanding ? "AgencyMisunderstandingBoycott" : "AgencyAvoidAndBoycott",
                        conseqDesc,
                        evtOrder2.Id, "", isMisunderstanding
                    );
                }
            }
        }
    }
}
