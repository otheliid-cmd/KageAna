// STATUS VERIFIKASI (E1.1 & E3.1): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis di atas sim-freeze-E.
using System;
using System.Collections.Generic;
using UnityEngine;
using KageAna.Sim;

namespace KageAna.Game
{
    /// <summary>
    /// E3.1 & E3.2: Satu sumber kebenaran (Single Source of Truth) Sim <-> Unity 3D.
    /// Unity hanya menampilkan keadaan Sim dan mengirim perintah ke HeadlessSimRunner.
    /// Tidak ada logika dunia di MonoBehaviour.
    /// Irisan vertikal pertama ("Satu Malam di Kaki Kastil"):
    /// - 1 Distrik (Pasar Kaki Kastil + Nagaya + Gang Belakang: place_pasar, place_nagaya, place_kedai_teh, place_gerbang_selatan)
    /// - 10 NPC dari 26 yang aktif di distrik kaki kastil
    /// - Siklus siang->malam 24 menit dipercepat, cuaca dari Sim
    /// - Minimal 2 rantai salah paham terlihat di dunia + intervensi Souma (E2.4)
    /// </summary>
    public sealed class SimUnityBridge : MonoBehaviour
    {
        public string VerificationLabel = "BELUM DIBUKA DI UNITY/WINDOWS ASLI";
        public int Seed = 7;
        public string Policy = "TraderInformant";
        public bool IsUraNightGarbActive;

        public static readonly string[] VerticalSliceDistrictPlaces = new string[]
        {
            "place_pasar",
            "place_nagaya",
            "place_kedai_teh",
            "place_gerbang_selatan"
        };

        public static readonly string[] VerticalSliceTenNpcs = new string[]
        {
            "ohana", "okiku", "ryota", "haruki", "sabu",
            "matsubei", "kanta", "suzu", "chiyo", "daigo"
        };

        private SimDataBundle _bundle;
        private HeadlessSimReport _latestReport;

        public HeadlessSimReport LatestReport { get { return _latestReport; } }

        public void InitializeFromDataSource(ISimDataSource dataSource, string dataRootPath)
        {
            if (dataSource == null) throw new ArgumentNullException(nameof(dataSource));
            _bundle = dataSource.LoadBundle(dataRootPath);
        }

        public HeadlessSimReport RunDeterministicStepVerification(int days)
        {
            var runner = new HeadlessSimRunner(_bundle, Seed);
            _latestReport = runner.Run(days, false, Policy);
            return _latestReport;
        }

        public static bool VerifyDeterministicBridgeHashEquality(SimDataBundle bundle, int seed, int days)
        {
            var bridgeRunner = new HeadlessSimRunner(bundle, seed);
            var headlessRunner = new HeadlessSimRunner(bundle, seed);
            HeadlessSimReport rBridge = bridgeRunner.Run(days, false, "TraderInformant");
            HeadlessSimReport rHeadless = headlessRunner.Run(days, false, "TraderInformant");
            return rBridge.DeterministicHashHex == rHeadless.DeterministicHashHex
                && rBridge.WaveBDeterministicHashHex == rHeadless.WaveBDeterministicHashHex;
        }
    }
}
