// KAGE-ANA v3.0 Gelombang D (Butir 5, 6a, & 8) — Modul 3: Kurator Nisshi (12-20 Butir Bermakna) & Umpan "Kisah Hari Ini"
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimNisshiCurator
    {
        public static void RecordKisahEvent(SimEventBus bus, int day, int hour, string category, string placeId, string summary)
        {
            RecordKisahEventWithWhy(bus, day, hour, category, placeId, summary, "", "", "Terjadi di sekitar " + placeId);
        }

        public static void RecordKisahEventWithWhy(
            SimEventBus bus,
            int day,
            int hour,
            string category,
            string placeId,
            string summary,
            string sourceEventId,
            string witnessNpcId,
            string whyLinkText)
        {
            KisahEventEntry k = new KisahEventEntry();
            k.Day = day;
            k.Hour = hour;
            k.Category = category;
            k.PlaceId = placeId;
            k.Summary = summary;
            k.SourceEventId = sourceEventId;
            k.WitnessNpcId = witnessNpcId;
            k.WhyLinkText = whyLinkText;
            bus.KisahEvents.Add(k);
        }

        public static void RecordNisshiEntry(SimEventBus bus, int day, string category, string sourceEventId, string text)
        {
            double impact = 0.65;
            double sal = 0.65;
            if (category == "TekananHidup" || category == "JejakBayangan" || category == "AgensiWarga" || category == "Gig")
            {
                impact = 0.92;
                sal = 0.85;
            }
            else if (category == "Festival" || category == "Dagang")
            {
                impact = 0.78;
                sal = 0.72;
            }
            else if (category == "RantaiAnekdot")
            {
                impact = 0.75;
                sal = 0.80;
            }
            RecordNisshiCandidate(bus, day, category, sourceEventId, text, impact, sal);
        }

        public static void RecordNisshiCandidate(
            SimEventBus bus,
            int day,
            string category,
            string sourceEventId,
            string text,
            double impactScore,
            double salienceScore)
        {
            for (int i = 0; i < bus.RawNisshiCandidates.Count; i++)
            {
                if (bus.RawNisshiCandidates[i].Category == category && bus.RawNisshiCandidates[i].EntryText == text)
                {
                    return;
                }
            }
            NisshiEntry ne = new NisshiEntry();
            ne.Day = day;
            ne.Season = WorldClock.ComputeSeasonForDay(day);
            ne.Category = category;
            ne.SourceEventId = sourceEventId;
            ne.EntryText = text;
            ne.ImpactScore = impactScore;
            ne.SalienceScore = salienceScore;
            bus.RawNisshiCandidates.Add(ne);
            bus.NisshiEntries.Add(ne);
        }

        public static void CurateYearlyNisshi(SimEventBus bus, SimPlaceGraphSystem world)
        {
            List<NisshiEntry> pool = new List<NisshiEntry>();
            bool isIdle = (world.ActiveSoumaPolicy == "Idle");

            for (int i = 0; i < bus.RawNisshiCandidates.Count; i++)
            {
                NisshiEntry cand = bus.RawNisshiCandidates[i];
                if (isIdle)
                {
                    // Butir 5: Kebijakan Idle harus menghasilkan Nisshi yang mencerminkan tunggakan/penurunan Sōma, bukan trivia NPC
                    if (cand.Category == "Kabar" || cand.Category == "RantaiAnekdot" || cand.Category == "KisahKecil")
                    {
                        continue;
                    }
                }
                pool.Add(cand);
            }

            List<int> selectedIndices = new List<int>();
            bool[] used = new bool[pool.Count];
            int targetCount = 16;

            int lastPickedDay = -1;
            for (int step = 0; step < targetCount; step++)
            {
                int bestIdx = -1;
                double bestScore = -1.0;

                for (int i = 0; i < pool.Count; i++)
                {
                    if (used[i]) continue;
                    NisshiEntry c = pool[i];

                    int sameDayCount = 0;
                    int sameCatCount = 0;
                    int sameSeasonCount = 0;
                    for (int s = 0; s < selectedIndices.Count; s++)
                    {
                        NisshiEntry picked = pool[selectedIndices[s]];
                        if (picked.Day == c.Day) sameDayCount += 1;
                        if (picked.Category == c.Category) sameCatCount += 1;
                        if (picked.Season == c.Season) sameSeasonCount += 1;
                    }

                    if (sameDayCount >= (isIdle ? 2 : 1) && step < 12) continue;

                    double diversityBonus = 0.0;
                    if (sameCatCount == 0) diversityBonus += 0.35;
                    else if (sameCatCount == 1) diversityBonus += 0.15;
                    else if (sameCatCount >= 4 && !isIdle) diversityBonus -= 0.25;

                    if (sameSeasonCount < 3) diversityBonus += 0.20;
                    if (c.Day != lastPickedDay) diversityBonus += 0.08;

                    if (isIdle && (c.Category == "TekananHidup" || c.Category == "Festival")) diversityBonus += 0.65;
                    double totalScore = (c.ImpactScore * 0.55) + (c.SalienceScore * 0.45) + diversityBonus;
                    if (totalScore > bestScore)
                    {
                        bestScore = totalScore;
                        bestIdx = i;
                    }
                }

                if (bestIdx >= 0)
                {
                    used[bestIdx] = true;
                    selectedIndices.Add(bestIdx);
                    lastPickedDay = pool[bestIdx].Day;
                }
                else
                {
                    break;
                }
            }

            for (int i = 0; i < pool.Count && selectedIndices.Count < 14; i++)
            {
                if (!used[i])
                {
                    used[i] = true;
                    selectedIndices.Add(i);
                }
            }

            for (int i = 0; i < selectedIndices.Count; i++)
            {
                for (int j = i + 1; j < selectedIndices.Count; j++)
                {
                    if (pool[selectedIndices[j]].Day < pool[selectedIndices[i]].Day)
                    {
                        int tmpIdx = selectedIndices[i];
                        selectedIndices[i] = selectedIndices[j];
                        selectedIndices[j] = tmpIdx;
                    }
                }
            }

            bus.NisshiEntries.Clear();
            int limit = selectedIndices.Count > 20 ? 20 : selectedIndices.Count;
            for (int i = 0; i < limit; i++)
            {
                bus.NisshiEntries.Add(pool[selectedIndices[i]]);
            }
        }
    }
}
