// STATUS VERIFIKASI (E0.3 & E4.4): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using UnityEngine;

namespace KageAna.Presentation
{
    /// <summary>
    /// E0.3 & E4.4: Kamera orang ketiga membuntuti bahu Souma dengan jarak adaptif
    /// (menarik mendekat di gang sempit) + mode kamera dekat 2-bidikan untuk dialog
    /// (kedalaman bidang / DoF ringan hanya di PC).
    /// </summary>
    public sealed class ThirdPersonShoulderCamera : MonoBehaviour
    {
        public Transform FollowTarget;
        public Transform DialogPartnerTarget;
        public bool IsInDialogTwoShotMode;
        public bool IsPcPlatform;

        public float OpenStreetDistance = 3.2f;
        public float NarrowAlleyDistance = 1.65f;
        public Vector3 ShoulderOffset = new Vector3(0.48f, 1.52f, 0.0f);
        public float CurrentDistance { get; private set; } = 3.2f;
        public bool EnableDialogDepthOfField { get { return IsInDialogTwoShotMode && IsPcPlatform; } }

        public void UpdateCameraFraming(bool isInNarrowAlley, float deltaTime)
        {
            float targetDist = isInNarrowAlley ? NarrowAlleyDistance : OpenStreetDistance;
            if (IsInDialogTwoShotMode)
            {
                targetDist = 1.35f;
            }
            CurrentDistance = Mathf.Lerp(CurrentDistance, targetDist, Mathf.Clamp01(deltaTime * 6.0f));
        }
    }
}
