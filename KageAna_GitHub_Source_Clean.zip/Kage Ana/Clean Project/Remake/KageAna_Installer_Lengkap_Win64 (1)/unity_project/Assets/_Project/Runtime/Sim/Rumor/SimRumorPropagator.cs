// KAGE-ANA v3.0 Gelombang D (Butir 1 & 8) — Modul 6: Penyebaran Rumor Berbasis Kebermaknaan (Salience), 5 Operator Distorsi, & Inferensi Motif
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimRumorPropagator
    {
        public static string InferMotiveFromBeliefsAndRelation(
            NpcRuntimeState speaker,
            NpcRuntimeState listener,
            StructuredClaim claim,
            SimPlaceGraphSystem world)
        {
            if (claim.ActionCode == "true_face_exposed" || (claim.SubjectId == "souma" && (listener.RoleCategory == "Guard" || listener.SuspicionTowardSouma >= 20)))
            {
                return "motive_spy";
            }
            if (claim.ActionCode == "leave_post_early" || claim.ActionCode == "agency_cover_up_ally")
            {
                return "motive_bribe";
            }
            if (claim.ActionCode == "hide_za_ledger" || claim.ActionCode == "agency_price_sanction" || speaker.Greed >= 6)
            {
                return "motive_greed";
            }
            if (claim.ActionCode == "collect_nagaya_rent" || claim.ActionCode == "rent_arrears_warning" || claim.ActionCode == "npc_debt_demand")
            {
                return "motive_debt";
            }
            if (claim.ActionCode == "corpse_discovered" || claim.ActionCode == "agency_avoid_or_boycott" || world.DistrictCrackdownActive)
            {
                return "motive_fear";
            }
            return "motive_greed";
        }

        public static string ApplyAlgorithmicDistortion(
            SimEventBus bus,
            ulong seed,
            int day,
            int hour,
            NpcRuntimeState speaker,
            NpcRuntimeState listener,
            StructuredClaim claim,
            SimPlaceGraphSystem world)
        {
            string stream = "distort_d" + day.ToString() + "_h" + hour.ToString() + "_" + speaker.Id + "_" + listener.Id + "_" + claim.ActionCode;
            SimRandom rng = new SimRandom(seed, stream);

            if (claim.ActionCode == "true_face_exposed" && claim.MotiveId == "motive_none")
            {
                claim.MotiveId = InferMotiveFromBeliefsAndRelation(speaker, listener, claim, world);
                bus.OpCountAddMotive += 1;
                return "AddMotive";
            }

            double distortProb = 0.34 + ((double)speaker.GossipTrait * 0.05) + ((double)(10 - listener.SuspicionTrait) * 0.02);
            if (rng.NextDouble() > distortProb)
            {
                return "None";
            }

            int opChoice = rng.NextInt(0, 5);
            string opApplied = "None";

            if (opChoice == 0)
            {
                claim.Quantity = (claim.Quantity * 2) + rng.NextInt(1, 4);
                opApplied = "Magnify";
                bus.OpCountMagnify += 1;
            }
            else if (opChoice == 1)
            {
                int subjIdx = world.FindNpcIndexById(claim.SubjectId);
                string targetCat = (subjIdx >= 0) ? world.Agents[subjIdx].RoleCategory : "Guard";
                List<string> candidates = new List<string>();
                for (int i = 0; i < world.Agents.Count; i++)
                {
                    if (world.Agents[i].Id != claim.SubjectId && world.Agents[i].RoleCategory == targetCat)
                    {
                        candidates.Add(world.Agents[i].Id);
                    }
                }
                if (candidates.Count > 0)
                {
                    int pick = rng.NextInt(0, candidates.Count);
                    claim.SubjectId = candidates[pick];
                }
                opApplied = "WrongPerson";
                bus.OpCountWrongPerson += 1;
            }
            else if (opChoice == 2)
            {
                int pIdx = world.FindPlaceIndexById(claim.PlaceId);
                if (pIdx >= 0 && world.Places[pIdx].Neighbors.Count > 0)
                {
                    int nbPick = rng.NextInt(0, world.Places[pIdx].Neighbors.Count);
                    claim.PlaceId = world.Places[pIdx].Neighbors[nbPick].ToPlaceId;
                }
                opApplied = "WrongPlace";
                bus.OpCountWrongPlace += 1;
            }
            else if (opChoice == 3)
            {
                claim.TimeLabel = "waktu yang simpang-siur";
                opApplied = "DropDetail";
                bus.OpCountDropDetail += 1;
            }
            else
            {
                claim.MotiveId = InferMotiveFromBeliefsAndRelation(speaker, listener, claim, world);
                opApplied = "AddMotive";
                bus.OpCountAddMotive += 1;
            }

            if ((speaker.GossipTrait >= 7 || listener.SuspicionTrait >= 7) && rng.NextDouble() < 0.45 && opApplied != "AddMotive")
            {
                claim.MotiveId = InferMotiveFromBeliefsAndRelation(speaker, listener, claim, world);
                opApplied = opApplied + "+AddMotive";
                bus.OpCountAddMotive += 1;
            }

            return opApplied;
        }

        public static void PropagateHourlyRumors(
            SimEventBus bus,
            ulong seed,
            int day,
            int hour,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (!bus.EventEmitterEnabled || !(hour == 9 || hour == 13 || hour == 17 || hour == 20))
            {
                return;
            }

            SimSalienceConfig salCfg = bus.Data.SalienceConfig;
            int currentMemCount = bus.Memories.Count;
            int startMemIdx = currentMemCount > 110 ? currentMemCount - 110 : 0;
            int hopsThisHour = 0;

            for (int mIdx = startMemIdx; mIdx < currentMemCount; mIdx++)
            {
                if (hopsThisHour >= 6) break;
                MemoryEntry spkMem = bus.Memories[mIdx];
                if (!spkMem.Tellable) continue;

                bool isRoutine = spkMem.IsRoutineMemory || (spkMem.SalienceScore <= salCfg.RoutineMaxSalience);
                int maxAllowedHops = isRoutine ? salCfg.RoutineMaxHops : salCfg.SalientMaxHops;
                if (spkMem.HopCount >= maxAllowedHops) continue;

                int maxAgeDays = isRoutine ? 0 : (spkMem.SalienceScore >= salCfg.HighSalienceThreshold ? 6 : 3);
                if (day - spkMem.Day > maxAgeDays) continue;

                int spkIdx = world.FindNpcIndexById(spkMem.OwnerNpcId);
                if (spkIdx < 0) continue;
                NpcRuntimeState spk = world.Agents[spkIdx];
                if (spk.IsDead || spk.IsSleeping || spk.IsInTransit) continue;

                string pIdNow = world.Places[spk.CurrentPlaceIdx].Id;
                if (isRoutine && pIdNow != spkMem.PlaceId) continue;
                if (isRoutine && (spk.GossipTrait < 6 || (hour != 13 && hour != 17))) continue;

                for (int lstIdx = 0; lstIdx < world.Agents.Count; lstIdx++)
                {
                    if (spkIdx == lstIdx) continue;
                    NpcRuntimeState lst = world.Agents[lstIdx];
                    if (lst.IsDead || lst.IsSleeping || lst.IsInTransit) continue;
                    if (spk.CurrentPlaceIdx != lst.CurrentPlaceIdx) continue;
                    if (SimMemoryStore.HasNpcAlreadyLearnedRootEvent(bus, lst.Id, spkMem.SourceEventId)) continue;

                    string talkStream = "talk_d" + day.ToString() + "_h" + hour.ToString() + "_" + spk.Id + "_" + lst.Id + "_" + spkMem.Id;
                    SimRandom talkRng = new SimRandom(seed, talkStream);

                    double baseProb = isRoutine ? 0.08 : (0.28 + (spkMem.SalienceScore * 0.38));
                    double talkProb = baseProb + ((double)spk.GossipTrait * 0.04);
                    if (talkRng.NextDouble() > talkProb) continue;

                    StructuredClaim nextClaim = spkMem.Claim.Clone();
                    string opsUsed = ApplyAlgorithmicDistortion(bus, seed, day, hour, spk, lst, nextClaim, world);
                    int nextHop = spkMem.HopCount + 1;
                    double nextRel = spkMem.Reliability * (opsUsed == "None" ? 0.92 : 0.76);
                    if (nextRel < 0.25) nextRel = 0.25;

                    WorldEvent rEvt = bus.FindEventById(spkMem.SourceEventId);
                    double lstSalience = SimMemoryStore.ComputeMemorySalienceForListener(bus, rEvt, lst, world);
                    if (!isRoutine && opsUsed != "None")
                    {
                        lstSalience = Math.Min(1.0, lstSalience + 0.06);
                    }

                    MemoryEntry newMem = new MemoryEntry();
                    int nextId = bus.Memories.Count + 1;
                    newMem.Id = "mem_" + nextId.ToString();
                    newMem.OwnerNpcId = lst.Id;
                    newMem.Day = day;
                    newMem.Hour = hour;
                    newMem.PlaceId = pIdNow;
                    newMem.SourceType = 2; // Told
                    newMem.SourceEventId = spkMem.SourceEventId;
                    newMem.SourceMemoryId = spkMem.Id;
                    newMem.TellerNpcId = spk.Id;
                    newMem.RootWitnessNpcId = spkMem.RootWitnessNpcId;
                    newMem.HopCount = nextHop;
                    newMem.Reliability = nextRel;
                    newMem.Tellable = !isRoutine;
                    newMem.AppliedDistortionOperators = opsUsed;
                    newMem.Claim = nextClaim;
                    newMem.SalienceScore = lstSalience;
                    newMem.IsRoutineMemory = isRoutine;
                    newMem.FormattedTextId = bus.FormatClaimFromTemplate(nextClaim, world, false);
                    newMem.FormattedTextEn = bus.FormatClaimFromTemplate(nextClaim, world, true);

                    if (guard.ValidateMemoryAgainstEventLog(newMem, bus.EventLog, bus.Memories, pIdNow, world.Places[spk.CurrentPlaceIdx].Id)
                        && guard.ValidateRumorSalienceSpread(spkMem, newMem, salCfg))
                    {
                        bus.Memories.Add(newMem);

                        RumorPropagationHop edge = new RumorPropagationHop();
                        edge.SourceEventId = newMem.SourceEventId;
                        edge.FromMemoryId = spkMem.Id;
                        edge.NewMemoryId = newMem.Id;
                        edge.FromNpcId = spk.Id;
                        edge.ToNpcId = lst.Id;
                        edge.PlaceId = pIdNow;
                        edge.Day = day;
                        edge.Hour = hour;
                        edge.HopNumber = nextHop;
                        edge.AppliedOperators = opsUsed;
                        edge.Reliability = nextRel;
                        edge.ClaimTextId = newMem.FormattedTextId;
                        edge.ClaimTextEn = newMem.FormattedTextEn;
                        bus.RumorEdges.Add(edge);
                        hopsThisHour += 1;

                        if (nextClaim.SubjectId == "souma" && (nextClaim.ActionCode == "true_face_exposed" || nextClaim.ActionCode == "loud_violence" || nextClaim.ActionCode == "steal_item" || nextClaim.ActionCode == "rent_arrears_warning"))
                        {
                            world.AddSuspicionReason(lstIdx, 14, "Mendengar rumor dari " + spk.DisplayName + ": \"" + newMem.FormattedTextId + "\"");
                            SimMemoryStore.TryRecordCausalChain(
                                bus,
                                world.ActiveSoumaPolicy,
                                day,
                                rEvt,
                                spkMem.RootWitnessNpcId,
                                spkMem.Id,
                                spk.Id,
                                lst.Id,
                                newMem.Id,
                                opsUsed,
                                "SuspicionSpike",
                                lst.DisplayName + " naik kecurigaannya (+14) setelah mendengar rumor dari " + spk.DisplayName
                            );
                        }
                    }
                }

                if (!world.SoumaIsInTransit && spk.CurrentPlaceIdx == world.SoumaCurrentPlaceIdx && spkMem.Claim.SubjectId != "souma" && !isRoutine)
                {
                    SimMemoryStore.RegisterSoumaKabarObservation(bus, spkMem.SourceEventId, spkMem.RootWitnessNpcId, "Told", spkMem.Claim, day, hour, world);
                }
            }
        }
    }
}
