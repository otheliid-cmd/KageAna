// STATUS VERIFIKASI (E6.4): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using UnityEngine;

namespace KageAna.Presentation
{
    /// <summary>
    /// E6.4: Sinkronisasi bibir VRM 5 visem wajib (aa, ih, ou, ee, oh) dari klip suara,
    /// dengan mode ringan berbasis amplop RMS untuk Android menengah.
    /// </summary>
    public sealed class LipSyncFromAudio : MonoBehaviour
    {
        public bool LightweightAndroidEnvelopeMode = true;
        public float WeightAa { get; private set; }
        public float WeightIh { get; private set; }
        public float WeightOu { get; private set; }
        public float WeightEe { get; private set; }
        public float WeightOh { get; private set; }

        public void EvaluateVisemesFromRms(float rmsAmplitude, float pitchCyclePhase)
        {
            float clamped = Mathf.Clamp01(rmsAmplitude * 3.2f);
            if (clamped < 0.04f)
            {
                WeightAa = WeightIh = WeightOu = WeightEe = WeightOh = 0.0f;
                return;
            }
            if (LightweightAndroidEnvelopeMode)
            {
                int slot = Mathf.Abs(Mathf.FloorToInt(pitchCyclePhase * 5.0f)) % 5;
                WeightAa = slot == 0 ? clamped : clamped * 0.25f;
                WeightIh = slot == 1 ? clamped * 0.8f : 0.0f;
                WeightOu = slot == 2 ? clamped * 0.85f : 0.0f;
                WeightEe = slot == 3 ? clamped * 0.75f : 0.0f;
                WeightOh = slot == 4 ? clamped * 0.9f : 0.0f;
            }
            else
            {
                WeightAa = clamped;
                WeightOh = clamped * 0.45f;
            }
        }
    }
}
