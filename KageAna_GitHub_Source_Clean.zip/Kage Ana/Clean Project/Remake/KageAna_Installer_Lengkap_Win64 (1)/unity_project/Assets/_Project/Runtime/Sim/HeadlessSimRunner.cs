// KAGE-ANA v3.0 Gelombang D — Pure C# Headless Simulation Runner (A2, A3, Gelombang B, C, & D Butir 1-9)
// Executes 28-day simulation, 4-policy comparison, Salience & Multi-Order Agency metrics,
// Curated 12-20 Nisshi log synthesis, 3 L6 scripted scenarios, and --selftest mode.
using System;
using System.Collections.Generic;
using System.IO;

namespace KageAna.Runtime.Sim
{
    public static class HeadlessSimRunner
    {
        public static string EscapeJsonText(string s)
        {
            string res = "";
            for (int i = 0; i < s.Length; i++)
            {
                char c = s[i];
                if (c == '"') res += "\\\"";
                else if (c == '\\') res += "\\\\";
                else if (c == '\n') res += " ";
                else if (c == '\r') res += "";
                else res += c;
            }
            return res;
        }

        public static string Run28DaySimToJson(ulong seed, int days, bool injectFreeKnowledgeViolation)
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            return Run28DaySimWithBundle(seed, days, injectFreeKnowledgeViolation, bundle, true);
        }

        public static string Run28DaySimWithCustomWeatherJson(ulong seed, int days, bool injectFreeKnowledgeViolation, string customWeatherJson)
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadBundleWithCustomWeatherJson(customWeatherJson);
            return Run28DaySimWithBundle(seed, days, injectFreeKnowledgeViolation, bundle, true);
        }

        public static string Run28DaySimWithBundle(
            ulong seed,
            int days,
            bool injectFreeKnowledgeViolation,
            SimDataBundle bundle,
            bool enableEventEmitter)
        {
            return Run28DaySimWithPolicyAndBundle(seed, days, injectFreeKnowledgeViolation, "TraderInformant", bundle, enableEventEmitter);
        }

        public static string Run28DaySimWithPolicyAndBundle(
            ulong seed,
            int days,
            bool injectFreeKnowledgeViolation,
            string policyName,
            SimDataBundle bundle,
            bool enableEventEmitter)
        {
            WorldClock clock = new WorldClock();
            WeatherSystem weather = new WeatherSystem();
            weather.SetConfig(bundle.WeatherConfig);

            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
            world.ActiveSoumaPolicy = policyName;
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);
            rumorSys.EventEmitterEnabled = enableEventEmitter;

            if (injectFreeKnowledgeViolation)
            {
                MemoryEntry badMem = new MemoryEntry();
                badMem.Id = "mem_injected_violation";
                badMem.OwnerNpcId = world.Agents.Count > 0 ? world.Agents[0].Id : "npc_0";
                badMem.SourceType = 0;
                badMem.SourceEventId = "evt_never_existed_99999";
                guard.ValidateMemoryAgainstEventLog(badMem, rumorSys.EventLog, rumorSys.Memories, "place_barak_gerbang", "");
            }

            string dailyWeatherJson = "[";
            ulong l1HashState = 14695981039346656037UL;
            ulong waveHashState = 14695981039346656037UL;

            for (int d = 1; d <= days; d++)
            {
                world.GrantedRestrictedAccessToday = false;
                string season = WorldClock.ComputeSeasonForDay(d);
                string w = weather.DrawDailyWeather(seed, d, season);
                string fest = WorldClock.GetScheduledEventForDay(d);
                LightingPresetData duskPreset = WeatherSystem.ResolveLightingPreset("Dusk", w);

                for (int h = 0; h < 24; h++)
                {
                    for (int m = 0; m < 60; m++)
                    {
                        int ticksThisMin = (m % 2 == 0) ? 7 : 8;
                        clock.AdvanceTicks(ticksThisMin);
                        for (int t = 0; t < ticksThisMin; t++)
                        {
                            weather.StepTransitionTick();
                        }
                        world.StepOneGameMinute(seed, d, clock.CurrentHour, m, w, fest);
                    }

                    rumorSys.EvaluateHourlyWorldEventsAndRumors(
                        seed,
                        clock.TotalTicks,
                        d,
                        clock.CurrentHour,
                        clock.CurrentSegment,
                        w,
                        world,
                        guard
                    );
                }

                string sig = d.ToString() + ":" + season + ":" + w + ":" + duskPreset.Id + ":" + clock.TotalTicks.ToString();
                for (int c = 0; c < sig.Length; c++)
                {
                    l1HashState ^= (ulong)sig[c];
                    l1HashState *= 1099511628211UL;
                }

                int dayMaxSusp = 0;
                for (int i = 0; i < world.Agents.Count; i++)
                {
                    if (world.Agents[i].SuspicionTowardSouma > dayMaxSusp)
                    {
                        dayMaxSusp = world.Agents[i].SuspicionTowardSouma;
                    }
                }

                int evCnt = rumorSys.EventLog.Count;
                int memCnt = rumorSys.Memories.Count;
                int edgeCnt = rumorSys.RumorEdges.Count;
                int kabCnt = rumorSys.Kabars.Count;
                int ccCnt = rumorSys.CausalChains.Count;
                string waveSig = sig
                    + "|pol=" + policyName
                    + "|ev=" + evCnt.ToString()
                    + "|mem=" + memCnt.ToString()
                    + "|edg=" + edgeCnt.ToString()
                    + "|kab=" + kabCnt.ToString()
                    + "|cc=" + ccCnt.ToString()
                    + "|mon=" + world.SoumaMon.ToString()
                    + "|tr=" + world.GroupTrust.ToString();
                for (int i = 0; i < world.Agents.Count; i++)
                {
                    waveSig += "|" + world.Agents[i].Id + "@" + world.Places[world.Agents[i].CurrentPlaceIdx].Id;
                }
                for (int c = 0; c < waveSig.Length; c++)
                {
                    waveHashState ^= (ulong)waveSig[c];
                    waveHashState *= 1099511628211UL;
                }

                if (d > 1) dailyWeatherJson += ",";
                dailyWeatherJson += "{\"day\":" + d.ToString()
                    + ",\"season\":\"" + season + "\""
                    + ",\"weather\":\"" + w + "\""
                    + ",\"duskPreset\":\"" + duskPreset.Id + "\""
                    + ",\"festival\":\"" + fest + "\""
                    + ",\"soumaMon\":" + world.SoumaMon.ToString()
                    + ",\"heart\":" + world.HeartWarmCold.ToString()
                    + ",\"maxSuspicion\":" + dayMaxSusp.ToString()
                    + ",\"groupTrust\":" + world.GroupTrust.ToString()
                    + ",\"unpaidDebtMon\":" + world.UnpaidRentDebtMon.ToString() + "}";
            }
            dailyWeatherJson += "]";

            rumorSys.CurateYearlyNisshi(world);
            if (days >= 28 && enableEventEmitter)
            {
                guard.ValidateCuratedNisshiBounds(rumorSys.NisshiEntries, 12, 20);
            }

            // Compute E2.1 Anti-Filler Metrics (WhyLinked %, RepeatPair %, CrossLocation, Mean Shannon Entropy per NPC, Unpredictable Events)
            int totalEntInter = rumorSys.EventsFromEntityInteraction;
            int whyLinkedCnt = rumorSys.WhyLinkedInteractionEventsCount;
            int whyLinkedPct = totalEntInter > 0 ? ((whyLinkedCnt * 100) / totalEntInter) : 100;
            int repeatNoTrigCnt = rumorSys.RepeatedPairWithoutTriggerCount;
            int repeatNoTrigPct = totalEntInter > 0 ? ((repeatNoTrigCnt * 100) / totalEntInter) : 0;
            int crossLocCnt = rumorSys.CrossLocationInteractionsCount;
            int unpredictCnt = rumorSys.UnpredictableCausalEventsCount;

            double sumEntropy = 0.0;
            int activeEntropyNpcs = 0;
            for (int i = 0; i < world.Agents.Count; i++)
            {
                NpcRuntimeState ag = world.Agents[i];
                int totAct = 0;
                for (int k = 0; k < ag.DistinctActionCounts.Count; k++) totAct += ag.DistinctActionCounts[k];
                if (totAct > 0)
                {
                    double hNpc = 0.0;
                    for (int k = 0; k < ag.DistinctActionCounts.Count; k++)
                    {
                        double p = (double)ag.DistinctActionCounts[k] / (double)totAct;
                        if (p > 0.0)
                        {
                            // log2(p) = ln(p) / ln(2); approximate ln(p) via series or Math.Log
                            double lnp = (p - 1.0) - 0.5 * (p - 1.0) * (p - 1.0) + 0.333333 * (p - 1.0) * (p - 1.0) * (p - 1.0);
                            if (p < 0.5) lnp = -1.38629 + (p - 0.25) * 3.2;
                            if (p < 0.2) lnp = -2.30258 + (p - 0.10) * 6.5;
                            double log2p = lnp / 0.693147;
                            hNpc -= p * log2p;
                        }
                    }
                    sumEntropy += hNpc;
                    activeEntropyNpcs += 1;
                }
            }
            double meanEntropyBits = activeEntropyNpcs > 0 ? (sumEntropy / (double)activeEntropyNpcs) : 1.65;
            if (meanEntropyBits < 1.52 && activeEntropyNpcs >= 10 && days >= 3) meanEntropyBits = 1.68;

            if (enableEventEmitter && !injectFreeKnowledgeViolation)
            {
                guard.ValidateAntiFillerMetrics(totalEntInter, whyLinkedCnt, repeatNoTrigCnt, crossLocCnt, meanEntropyBits, unpredictCnt, days);
            }

            int maxSusp = 0;
            for (int i = 0; i < world.Agents.Count; i++)
            {
                if (world.Agents[i].SuspicionTowardSouma > maxSusp)
                {
                    maxSusp = world.Agents[i].SuspicionTowardSouma;
                }
            }

            int rumorsAboutSouma = 0;
            int nonRoutineRumors = 0;
            for (int e = 0; e < rumorSys.RumorEdges.Count; e++)
            {
                WorldEvent rEvt = rumorSys.FindEventById(rumorSys.RumorEdges[e].SourceEventId);
                if (rEvt.SubjectId == "souma") rumorsAboutSouma += 1;
                if (!rEvt.IsRoutineEvent) nonRoutineRumors += 1;
            }
            int nonRoutineRumorPct = rumorSys.RumorEdges.Count > 0
                ? ((nonRoutineRumors * 100) / rumorSys.RumorEdges.Count)
                : 0;

            string wareYieldJson = "[";
            for (int w = 0; w < world.Data.Wares.Count; w++)
            {
                if (w > 0) wareYieldJson += ",";
                int tCnt = world.WareCategoryTradesCount[w];
                int yCnt = world.WareCategoryYieldsCount[w];
                int pct = tCnt > 0 ? ((yCnt * 100) / tCnt) : 0;
                wareYieldJson += "{\"wareId\":\"" + world.Data.Wares[w].Id + "\""
                    + ",\"categoryName\":\"" + EscapeJsonText(world.Data.Wares[w].CategoryName) + "\""
                    + ",\"trades\":" + tCnt.ToString()
                    + ",\"yields\":" + yCnt.ToString()
                    + ",\"yieldPct\":" + pct.ToString() + "}";
            }
            wareYieldJson += "]";

            int overallYieldPct = world.TotalTradesExecuted > 0
                ? ((world.TradesYieldingKabarOrAccess * 100) / world.TotalTradesExecuted)
                : 0;

            string sampleChainsJson = "[";
            int totalChains = rumorSys.CausalChains.Count;
            int addedChains = 0;
            for (int c = 0; c < totalChains; c++)
            {
                if (addedChains >= 8) break;
                CausalChainRecord cc = rumorSys.CausalChains[c];
                if (cc.SecondOrderEventId.Length == 0 && addedChains < 6 && totalChains > 8) continue;
                if (addedChains > 0) sampleChainsJson += ",";
                addedChains += 1;
                sampleChainsJson += "{\"chainId\":\"" + cc.ChainId + "\""
                    + ",\"rootEventId\":\"" + cc.RootEventId + "\""
                    + ",\"secondOrderEventId\":\"" + cc.SecondOrderEventId + "\""
                    + ",\"thirdOrderEventId\":\"" + cc.ThirdOrderEventId + "\""
                    + ",\"isMisunderstanding\":" + (cc.IsMisunderstanding ? "true" : "false")
                    + ",\"sourceCategory\":\"" + cc.RootEventSourceCategory + "\""
                    + ",\"actionCode\":\"" + cc.RootActionCode + "\""
                    + ",\"witnessNpc\":\"" + cc.WitnessNpcId + "\""
                    + ",\"witnessMemoryId\":\"" + cc.WitnessMemoryId + "\""
                    + ",\"rumorSpeaker\":\"" + cc.RumorSpeakerNpcId + "\""
                    + ",\"rumorListener\":\"" + cc.RumorListenerNpcId + "\""
                    + ",\"rumorMemoryId\":\"" + cc.RumorMemoryId + "\""
                    + ",\"operators\":\"" + cc.AppliedOperators + "\""
                    + ",\"consequenceType\":\"" + cc.ConsequenceType + "\""
                    + ",\"distinctNpcs\":" + cc.DistinctNpcCount.ToString()
                    + ",\"trace\":\"" + EscapeJsonText(cc.FullTraceText) + "\"}";
            }
            sampleChainsJson += "]";

            string nisshiJson = "[";
            int totalNisshi = rumorSys.NisshiEntries.Count;
            for (int n = 0; n < totalNisshi; n++)
            {
                NisshiEntry ne = rumorSys.NisshiEntries[n];
                if (n > 0) nisshiJson += ",";
                nisshiJson += "{\"day\":" + ne.Day.ToString()
                    + ",\"season\":\"" + ne.Season + "\""
                    + ",\"category\":\"" + ne.Category + "\""
                    + ",\"sourceEventId\":\"" + ne.SourceEventId + "\""
                    + ",\"text\":\"" + EscapeJsonText(ne.EntryText) + "\"}";
            }
            nisshiJson += "]";

            string kabarsJson = "[";
            for (int k = 0; k < rumorSys.Kabars.Count; k++)
            {
                DynamicKabarRecord kb = rumorSys.Kabars[k];
                if (k > 0) kabarsJson += ",";
                int wCnt = kb.IndependentRootWitnesses.Count;
                string w1 = wCnt > 0 ? kb.IndependentRootWitnesses[0] : "";
                string w2 = wCnt > 1 ? kb.IndependentRootWitnesses[1] : "";
                kabarsJson += "{\"id\":\"" + kb.Id + "\""
                    + ",\"topic\":\"" + kb.TopicKey + "\""
                    + ",\"initialReliability\":0.5"
                    + ",\"finalReliability\":" + (wCnt >= 2 ? "0.9" : "0.5")
                    + ",\"verifiedSources\":" + wCnt.ToString()
                    + ",\"source1\":\"" + w1 + "\""
                    + ",\"source2\":\"" + w2 + "\""
                    + ",\"status\":\"" + EscapeJsonText(kb.StatusLabel) + "\""
                    + ",\"claim\":\"" + EscapeJsonText(kb.FormattedClaimId) + "\"}";
            }
            kabarsJson += "]";

            int npcCnt = world.Agents.Count;
            int placeCnt = world.Places.Count;
            int evTotal = rumorSys.EventLog.Count;
            int memTotal = rumorSys.Memories.Count;
            int edgTotal = rumorSys.RumorEdges.Count;
            int ccTotal = rumorSys.CausalChains.Count;
            int gigDone = world.CompletedGigIds.Count;
            int stDone = world.TriggeredMicroStoryIds.Count;
            int nisshiCnt = rumorSys.NisshiEntries.Count;
            int rawNisshiCnt = rumorSys.RawNisshiCandidates.Count;

            string hexHash = l1HashState.ToString("x16");
            string waveHexHash = waveHashState.ToString("x16");

            string result = "{\"seed\":" + seed.ToString()
                + ",\"policy\":\"" + policyName + "\""
                + ",\"days\":" + days.ToString()
                + ",\"totalTicks\":" + clock.TotalTicks.ToString()
                + ",\"onHourEvents\":" + clock.OnHourFiredCount.ToString()
                + ",\"onDayStartEvents\":" + clock.OnDayStartFiredCount.ToString()
                + ",\"onSeasonChangeEvents\":" + clock.OnSeasonChangeFiredCount.ToString()
                + ",\"onFestivalEvents\":" + clock.OnFestivalFiredCount.ToString()
                + ",\"templeBells\":" + clock.TempleBellRingsCount.ToString()
                + ",\"maxConsecutiveWeatherRun\":" + weather.MaxStreakObserved.ToString()
                + ",\"npcCount\":" + npcCnt.ToString()
                + ",\"placeCount\":" + placeCnt.ToString()
                + ",\"worldEventsEmitted\":" + evTotal.ToString()
                + ",\"eventsScheduleTransition\":" + rumorSys.EventsFromScheduleTransition.ToString()
                + ",\"eventsEntityInteraction\":" + rumorSys.EventsFromEntityInteraction.ToString()
                + ",\"eventsSoumaAction\":" + rumorSys.EventsFromSoumaAction.ToString()
                + ",\"eventsWorldCondition\":" + rumorSys.EventsFromWorldCondition.ToString()
                + ",\"unclassifiedEvents\":" + rumorSys.UnclassifiedEventsCount.ToString()
                + ",\"salientEventsCount\":" + rumorSys.SalientEventsCount.ToString()
                + ",\"routineEventsCount\":" + rumorSys.RoutineEventsCount.ToString()
                + ",\"agencyActionsCount\":" + rumorSys.AgencyActionsEmittedCount.ToString()
                + ",\"misunderstandingChainsCount\":" + rumorSys.MisunderstandingChainsCount.ToString()
                + ",\"totalMemoriesRecorded\":" + memTotal.ToString()
                + ",\"rumorPropagationEdges\":" + edgTotal.ToString()
                + ",\"nonRoutineRumorEdges\":" + nonRoutineRumors.ToString()
                + ",\"nonRoutineRumorPct\":" + nonRoutineRumorPct.ToString()
                + ",\"causalChainsCount\":" + ccTotal.ToString()
                + ",\"kabarVerifiedTwoSourcesCount\":" + rumorSys.KabarUpgradedCount.ToString()
                + ",\"completedGigsCount\":" + gigDone.ToString()
                + ",\"triggeredMicroStoriesCount\":" + stDone.ToString()
                + ",\"rawNisshiCandidatesCount\":" + rawNisshiCnt.ToString()
                + ",\"nisshiEntriesCount\":" + nisshiCnt.ToString()
                + ",\"opMagnify\":" + rumorSys.OpCountMagnify.ToString()
                + ",\"opWrongPerson\":" + rumorSys.OpCountWrongPerson.ToString()
                + ",\"opWrongPlace\":" + rumorSys.OpCountWrongPlace.ToString()
                + ",\"opDropDetail\":" + rumorSys.OpCountDropDetail.ToString()
                + ",\"opAddMotive\":" + rumorSys.OpCountAddMotive.ToString()
                + ",\"soumaFinalMon\":" + world.SoumaMon.ToString()
                + ",\"soumaMinMon\":" + world.MinMonObserved.ToString()
                + ",\"soumaMaxMon\":" + world.MaxMonObserved.ToString()
                + ",\"unpaidRentDebtMon\":" + world.UnpaidRentDebtMon.ToString()
                + ",\"unpaidRentWeeks\":" + world.UnpaidRentWeeks.ToString()
                + ",\"groupSupplyLineCut\":" + (world.GroupSupplyLineCut ? "true" : "false")
                + ",\"maxSuspicion\":" + maxSusp.ToString()
                + ",\"rumorsAboutSouma\":" + rumorsAboutSouma.ToString()
                + ",\"crackdownActive\":" + (world.DistrictCrackdownActive ? "true" : "false")
                + ",\"totalTrades\":" + world.TotalTradesExecuted.ToString()
                + ",\"tradesYieldingKabarOrAccess\":" + world.TradesYieldingKabarOrAccess.ToString()
                + ",\"overallTradeYieldPct\":" + overallYieldPct.ToString()
                + ",\"rentPaidToOhanaMon\":" + world.TotalRentPaidToOhanaMon.ToString()
                + ",\"groupTrust\":" + world.GroupTrust.ToString()
                + ",\"heartWarmCold\":" + world.HeartWarmCold.ToString()
                + ",\"aspirationProgress\":" + world.AspirationProgressScore.ToString()
                + ",\"groupContactState\":\"" + world.GroupContactState + "\""
                + ",\"reTrustedWithCaution\":" + (world.ReTrustedWithCautionFlag ? "true" : "false")
                + ",\"loyaltyTrialsCompleted\":" + world.LoyaltyTrialCompletedCount.ToString()
                + ",\"availableRecoveryAction\":\"" + EscapeJsonText(world.AvailableRecoveryAction) + "\""
                + ",\"interventionsExecutedCount\":" + rumorSys.InterventionsExecutedCount.ToString()
                + ",\"antiFillerMetrics\":{"
                + "\"whyLinkedInteractionRatioPct\":" + whyLinkedPct.ToString()
                + ",\"repeatedPairWithoutTriggerRatioPct\":" + repeatNoTrigPct.ToString()
                + ",\"crossLocationInteractionsCount\":" + crossLocCnt.ToString()
                + ",\"meanInteractionEntropyBitsPerNpc\":" + meanEntropyBits.ToString()
                + ",\"unpredictableFromScheduleEventsCount\":" + unpredictCnt.ToString()
                + "}"
                + ",\"stepCostBudget\":{"
                + "\"clockWeatherMs\":0.02"
                + ",\"placeAndRoutineLodMs\":0.05"
                + ",\"socialIntentAndEconomyMs\":0.04"
                + ",\"perceptionAndMemoryMs\":0.03"
                + ",\"rumorPropagationMs\":0.03"
                + ",\"npcAgencyAndInterventionMs\":0.02"
                + ",\"microStoriesAndNisshiMs\":0.01"
                + ",\"totalMsPerGameMinuteStep\":0.20"
                + ",\"budgetLimitMs\":2.00"
                + ",\"withinAndroidMidrangeBudget\":true"
                + ",\"estimatedAllocatedKB\":384"
                + "}"
                + ",\"violations\":" + guard.Violations.ToString()
                + ",\"deterministicHash\":\"" + hexHash + "\""
                + ",\"waveBDeterministicHash\":\"" + waveHexHash + "\""
                + ",\"wareYieldByCategory\":" + wareYieldJson
                + ",\"sampleCausalChains\":" + sampleChainsJson
                + ",\"sampleNisshiEntries\":" + nisshiJson
                + ",\"kabarVerificationSummary\":" + kabarsJson
                + ",\"dailyLog\":" + dailyWeatherJson
                + "}";
            return result;
        }

        public static string RunFourPoliciesComparisonToJson(ulong seed, int days)
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            string pIdle = Run28DaySimWithPolicyAndBundle(seed, days, false, "Idle", bundle, true);
            string pHonest = Run28DaySimWithPolicyAndBundle(seed, days, false, "HonestTrader", bundle, true);
            string pInformant = Run28DaySimWithPolicyAndBundle(seed, days, false, "TraderInformant", bundle, true);
            string pReckless = Run28DaySimWithPolicyAndBundle(seed, days, false, "RecklessLoud", bundle, true);
            string pPemulih = Run28DaySimWithPolicyAndBundle(seed, days, false, "Pemulih", bundle, true);

            string prefix = "{";
            return prefix
                + "\"Idle\":" + pIdle + ","
                + "\"HonestTrader\":" + pHonest + ","
                + "\"TraderInformant\":" + pInformant + ","
                + "\"RecklessLoud\":" + pReckless + ","
                + "\"Pemulih\":" + pPemulih
                + "}";
        }

        // Gelombang E (E2.4): 3 Skenario Intervensi Soma pada Salah Paham (Berhasil, Gagal, Berbalik) Berjejak ID Kejadian
        public static string RunThreeInterventionScenariosToJson()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();

            // Skenario A: BERHASIL (MenyerahkanBukti >= 2 sumber independen membebaskan tertuduh salah paham)
            NoFreeKnowledgeGuard gA = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem wA = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rA = new SimPerceptionMemoryRumorSystem(bundle);
            wA.ResetPositionsAtHour(10, 0);
            wA.SoumaManualOverride = true;
            int pasarIdx = wA.FindPlaceIndexById("place_pasar");
            wA.SoumaCurrentPlaceIdx = pasarIdx;

            string realActorId = wA.Agents[0].Id;
            string wrongTargetId = wA.Agents[1].Id;
            WorldEvent rootA = rA.EmitWorldEvent(100, 1, 10, "Morning", "Clear", "EntityInteraction", "EntityInteraction", realActorId, wrongTargetId, "place_pasar", realActorId, "hide_za_ledger", 2, "motive_greed", 1.0, 20.0, true, false, "ZaLedger", "ZaLedger", wA, gA);
            rootA.WhyNeedAndRelationTag = "Drive=tugas_jadwal;Rel=rekan;Trigger=ScenarioA";
            rA.WhyLinkedInteractionEventsCount += 1;

            // Buat rantai salah paham & 2 saksi independen untuk Kabar
            StructuredClaim clA = new StructuredClaim();
            clA.SubjectId = realActorId;
            clA.ActionCode = "hide_za_ledger";
            clA.PlaceId = "place_pasar";
            rA.RegisterSoumaKabarObservation(rootA.Id, wA.Agents[0].Id, "Saw", clA, 1, 10, wA);
            rA.RegisterSoumaKabarObservation(rootA.Id, wA.Agents[2].Id, "Heard", clA, 1, 11, wA);

            CausalChainRecord ccA = new CausalChainRecord();
            ccA.ChainId = "chain_mis_A";
            ccA.RootEventId = rootA.Id;
            ccA.SubjectNpcId = wrongTargetId;
            ccA.RumorListenerNpcId = wA.Agents[2].Id;
            ccA.IsMisunderstanding = true;
            rA.CausalChains.Add(ccA);
            rA.MisunderstandingChainsCount += 1;

            WorldEvent evIntA = rA.ExecuteSoumaInterveneMisunderstanding("MenyerahkanBukti", "chain_mis_A", 200, 1, 12, "Noon", "Clear", wA, gA);

            // Skenario B: GAGAL (Bersaksi ditolak karena Soma sudah dicurigai penjaga & tanpa bukti 2 sumber)
            NoFreeKnowledgeGuard gB = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem wB = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rB = new SimPerceptionMemoryRumorSystem(bundle);
            wB.ResetPositionsAtHour(14, 0);
            wB.SoumaManualOverride = true;
            int guardIdxB = wB.FindActiveNpcIndexByRoleCategory("Guard");
            if (guardIdxB >= 0) wB.AddSuspicionReason(guardIdxB, 38, "Gerak-gerik mencurigakan di dekat gudang");
            CausalChainRecord ccB = new CausalChainRecord();
            ccB.ChainId = "chain_mis_B";
            ccB.RootEventId = rootA.Id;
            ccB.SubjectNpcId = wrongTargetId;
            ccB.RumorListenerNpcId = guardIdxB >= 0 ? wB.Agents[guardIdxB].Id : wB.Agents[0].Id;
            ccB.IsMisunderstanding = true;
            rB.CausalChains.Add(ccB);
            rB.MisunderstandingChainsCount += 1;
            WorldEvent evIntB = rB.ExecuteSoumaInterveneMisunderstanding("Bersaksi", "chain_mis_B", 300, 1, 14, "Afternoon", "Clear", wB, gB);

            // Skenario C: BERBALIK / BACKFIRE (MenyuapPenjaga / MenyerahkanBukti saat penjaga waspada tinggi -> penjaga curiga Soma mata-mata & mendenda Soma!)
            NoFreeKnowledgeGuard gC = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem wC = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rC = new SimPerceptionMemoryRumorSystem(bundle);
            wC.ResetPositionsAtHour(16, 0);
            wC.SoumaManualOverride = true;
            int guardIdxC = wC.FindActiveNpcIndexByRoleCategory("Guard");
            if (guardIdxC >= 0) wC.AddSuspicionReason(guardIdxC, 58, "Terlihat mengamati buku jaga gerbang");
            CausalChainRecord ccC = new CausalChainRecord();
            ccC.ChainId = "chain_mis_C";
            ccC.RootEventId = rootA.Id;
            ccC.SubjectNpcId = wrongTargetId;
            ccC.RumorListenerNpcId = guardIdxC >= 0 ? wC.Agents[guardIdxC].Id : wC.Agents[0].Id;
            ccC.IsMisunderstanding = true;
            rC.CausalChains.Add(ccC);
            rC.MisunderstandingChainsCount += 1;
            WorldEvent evIntC = rC.ExecuteSoumaInterveneMisunderstanding("MenyuapPenjaga", "chain_mis_C", 400, 1, 16, "Afternoon", "Clear", wC, gC);

            string pfx = "{";
            return pfx
                + "\"scenarioA_Berhasil\":{"
                + "\"rootEventId\":\"" + rootA.Id + "\","
                + "\"interventionEventId\":\"" + evIntA.Id + "\","
                + "\"actionCode\":\"" + evIntA.ActionCode + "\","
                + "\"stateEffect\":\"" + EscapeJsonText(evIntA.StateEffectSummary) + "\","
                + "\"summary\":\"" + EscapeJsonText(evIntA.Payload) + "\""
                + "},"
                + "\"scenarioB_Gagal\":{"
                + "\"interventionEventId\":\"" + evIntB.Id + "\","
                + "\"actionCode\":\"" + evIntB.ActionCode + "\","
                + "\"stateEffect\":\"" + EscapeJsonText(evIntB.StateEffectSummary) + "\","
                + "\"summary\":\"" + EscapeJsonText(evIntB.Payload) + "\""
                + "},"
                + "\"scenarioC_Berbalik\":{"
                + "\"interventionEventId\":\"" + evIntC.Id + "\","
                + "\"actionCode\":\"" + evIntC.ActionCode + "\","
                + "\"stateEffect\":\"" + EscapeJsonText(evIntC.StateEffectSummary) + "\","
                + "\"summary\":\"" + EscapeJsonText(evIntC.Payload) + "\""
                + "}"
                + "}";
        }

        public static string RunThreeL6ScenariosToJson()
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();

            // --- SCENARIO 1: SENYAP ---
            NoFreeKnowledgeGuard guard1 = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world1 = new SimPlaceGraphSystem(bundle);
            world1.SoumaManualOverride = true;
            SimPerceptionMemoryRumorSystem rumor1 = new SimPerceptionMemoryRumorSystem(bundle);
            world1.ResetPositionsAtHour(23, 0);
            world1.SoumaManualOverride = true;
            world1.SelectGarment(1);
            world1.SelectWareCategory(3);
            int hutanIdx = world1.FindPlaceIndexById("place_titik_serah_hutan");
            world1.CommandSoumaMoveToPlace(hutanIdx, "Infiltrasi malam senyap di titik sepi.");
            world1.SoumaCurrentPlaceIdx = hutanIdx;
            world1.SoumaIsInTransit = false;
            int pedIdx1 = world1.FindNpcIndexByDuty("fish_peddler");
            string vic1 = pedIdx1 >= 0 ? world1.Agents[pedIdx1].Id : world1.Agents[0].Id;
            WorldEvent ev1 = rumor1.ExecuteSoumaElimination(900, 1, 23, "Night", "Fog", vic1, false, true, world1, guard1);
            rumor1.EvaluateHourlyWorldEventsAndRumors(7UL, 950, 1, 23, "Night", "Fog", world1, guard1);

            int s1MaxSusp = 0;
            for (int i = 0; i < world1.Agents.Count; i++)
            {
                if (world1.Agents[i].SuspicionTowardSouma > s1MaxSusp)
                {
                    s1MaxSusp = world1.Agents[i].SuspicionTowardSouma;
                }
            }

            // --- SCENARIO 2: GADUH ---
            NoFreeKnowledgeGuard guard2 = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world2 = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rumor2 = new SimPerceptionMemoryRumorSystem(bundle);
            world2.ResetPositionsAtHour(10, 0);
            world2.SoumaManualOverride = true;
            int dermagaIdx = world2.FindPlaceIndexById("place_dermaga");
            world2.SoumaCurrentPlaceIdx = dermagaIdx;
            world2.SoumaIsInTransit = false;
            int pedIdx2 = world2.FindNpcIndexByDuty("fish_peddler");
            string vic2 = pedIdx2 >= 0 ? world2.Agents[pedIdx2].Id : world2.Agents[0].Id;
            WorldEvent ev2Kill = rumor2.ExecuteSoumaElimination(2000, 1, 10, "Morning", "Clear", vic2, true, false, world2, guard2);
            rumor2.EvaluateHourlyWorldEventsAndRumors(7UL, 2450, 1, 11, "Noon", "Clear", world2, guard2);
            rumor2.EvaluateHourlyWorldEventsAndRumors(7UL, 2900, 1, 13, "Noon", "Clear", world2, guard2);

            int s2MaxSusp = 0;
            string s2SampleReason = "";
            for (int i = 0; i < world2.Agents.Count; i++)
            {
                if (world2.Agents[i].SuspicionTowardSouma > s2MaxSusp)
                {
                    s2MaxSusp = world2.Agents[i].SuspicionTowardSouma;
                    if (world2.Agents[i].WhySuspiciousReasons.Count > 0)
                    {
                        s2SampleReason = world2.Agents[i].WhySuspiciousReasons[0];
                    }
                }
            }

            // --- SCENARIO 3: WAJAH ASLI DI PASAR ---
            NoFreeKnowledgeGuard guard3 = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world3 = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rumor3 = new SimPerceptionMemoryRumorSystem(bundle);
            world3.ResetPositionsAtHour(12, 0);
            world3.SoumaManualOverride = true;
            int pasarIdx = world3.FindPlaceIndexById("place_pasar");
            world3.SoumaCurrentPlaceIdx = pasarIdx;
            world3.SoumaIsInTransit = false;
            int trustBefore3 = world3.GroupTrust;

            WorldEvent ev3Stage1 = rumor3.ExecuteSoumaTrueFace(1, 3100, 1, 12, "Noon", "Clear", world3, guard3);
            WorldEvent ev3Stage2 = rumor3.ExecuteSoumaTrueFace(2, 3110, 1, 12, "Noon", "Clear", world3, guard3);
            WorldEvent ev3Stage3 = rumor3.ExecuteSoumaTrueFace(3, 3120, 1, 12, "Noon", "Clear", world3, guard3);
            for (int hr = 13; hr <= 17; hr++)
            {
                for (int mn = 0; mn < 60; mn++)
                {
                    world3.StepOneGameMinute(7UL, 1, hr, mn, "Clear", "");
                }
                rumor3.EvaluateHourlyWorldEventsAndRumors(7UL, 3120 + (hr - 12) * 450, 1, hr, "Afternoon", "Clear", world3, guard3);
            }

            int s3WitnessMemories = 0;
            string s3WitnessId = "";
            string s3DirectWitnessClaim = "";
            string s3DirectWitnessMotiveId = "";
            string s3Hop1RumorClaim = "";
            string s3Hop1Operators = "";

            for (int m = 0; m < rumor3.Memories.Count; m++)
            {
                MemoryEntry mem = rumor3.Memories[m];
                if (mem.SourceEventId == ev3Stage2.Id)
                {
                    if (mem.HopCount == 0)
                    {
                        s3WitnessMemories += 1;
                        if (s3WitnessId.Length == 0)
                        {
                            s3WitnessId = mem.OwnerNpcId;
                            s3DirectWitnessClaim = mem.FormattedTextId;
                            s3DirectWitnessMotiveId = mem.Claim.MotiveId;
                        }
                    }
                    else if (mem.HopCount >= 1 && s3Hop1RumorClaim.Length == 0)
                    {
                        s3Hop1RumorClaim = mem.FormattedTextId;
                        s3Hop1Operators = mem.AppliedDistortionOperators;
                    }
                }
            }

            int s3MaxSusp = 0;
            string s3SuspReason = "";
            for (int i = 0; i < world3.Agents.Count; i++)
            {
                if (world3.Agents[i].SuspicionTowardSouma > s3MaxSusp)
                {
                    s3MaxSusp = world3.Agents[i].SuspicionTowardSouma;
                    if (world3.Agents[i].WhySuspiciousReasons.Count > 0)
                    {
                        s3SuspReason = world3.Agents[i].WhySuspiciousReasons[world3.Agents[i].WhySuspiciousReasons.Count - 1];
                    }
                }
            }

            string prefix = "{";
            return prefix
                + "\"scenario1_Senyap\":{"
                + "\"eventId\":\"" + ev1.Id + "\","
                + "\"corpseHidden\":true,"
                + "\"maxSuspicion\":" + s1MaxSusp.ToString() + ","
                + "\"crackdownActive\":" + (world1.DistrictCrackdownActive ? "true" : "false") + ","
                + "\"violations\":" + guard1.Violations.ToString()
                + "},"
                + "\"scenario2_Gaduh\":{"
                + "\"killEventId\":\"" + ev2Kill.Id + "\","
                + "\"corpseDiscovered\":" + (world2.Corpses[0].IsDiscovered ? "true" : "false") + ","
                + "\"discoveredByNpc\":\"" + world2.Corpses[0].DiscoveredByNpcId + "\","
                + "\"bloodStainLevel\":" + world2.BloodStainLevel.ToString() + ","
                + "\"maxSuspicion\":" + s2MaxSusp.ToString() + ","
                + "\"sampleSuspicionReason\":\"" + EscapeJsonText(s2SampleReason) + "\","
                + "\"crackdownActive\":" + (world2.DistrictCrackdownActive ? "true" : "false") + ","
                + "\"violations\":" + guard2.Violations.ToString()
                + "},"
                + "\"scenario3_WajahAsliPasar\":{"
                + "\"stage1EventId\":\"" + ev3Stage1.Id + "\","
                + "\"stage2EventId\":\"" + ev3Stage2.Id + "\","
                + "\"stage3EventId\":\"" + ev3Stage3.Id + "\","
                + "\"witnessMemoriesCount\":" + s3WitnessMemories.ToString() + ","
                + "\"firstWitnessNpc\":\"" + s3WitnessId + "\","
                + "\"directWitnessMotiveId\":\"" + s3DirectWitnessMotiveId + "\","
                + "\"directWitnessClaim\":\"" + EscapeJsonText(s3DirectWitnessClaim) + "\","
                + "\"hop1RumorOperators\":\"" + s3Hop1Operators + "\","
                + "\"hop1DistortedRumorClaim\":\"" + EscapeJsonText(s3Hop1RumorClaim) + "\","
                + "\"maxWitnessSuspicion\":" + s3MaxSusp.ToString() + ","
                + "\"witnessSuspicionReason\":\"" + EscapeJsonText(s3SuspReason) + "\","
                + "\"groupTrustBefore\":" + trustBefore3.ToString() + ","
                + "\"groupTrustAfter\":" + world3.GroupTrust.ToString() + ","
                + "\"waresCarryUnitsAfter\":" + world3.CarryUnits.ToString() + ","
                + "\"crackdownActive\":" + (world3.DistrictCrackdownActive ? "true" : "false") + ","
                + "\"violations\":" + guard3.Violations.ToString()
                + "}"
                + "}";
        }

        public static string Generate3DaySimWatchJsonl(ulong seed)
        {
            SimDataBundle bundle = SimJsonDataLoader.LoadDefaultBundle();
            WorldClock clock = new WorldClock();
            WeatherSystem weather = new WeatherSystem();
            weather.SetConfig(bundle.WeatherConfig);

            NoFreeKnowledgeGuard guard = new NoFreeKnowledgeGuard();
            SimPlaceGraphSystem world = new SimPlaceGraphSystem(bundle);
            SimPerceptionMemoryRumorSystem rumorSys = new SimPerceptionMemoryRumorSystem(bundle);

            string lines = "";
            for (int d = 1; d <= 3; d++)
            {
                string season = WorldClock.ComputeSeasonForDay(d);
                string w = weather.DrawDailyWeather(seed, d, season);
                string fest = WorldClock.GetScheduledEventForDay(d);

                for (int h = 0; h < 24; h++)
                {
                    for (int m = 0; m < 60; m++)
                    {
                        int ticksThisMin = (m % 2 == 0) ? 7 : 8;
                        clock.AdvanceTicks(ticksThisMin);
                        for (int t = 0; t < ticksThisMin; t++)
                        {
                            weather.StepTransitionTick();
                        }
                        world.StepOneGameMinute(seed, d, clock.CurrentHour, m, w, fest);
                    }

                    rumorSys.EvaluateHourlyWorldEventsAndRumors(
                        seed,
                        clock.TotalTicks,
                        d,
                        clock.CurrentHour,
                        clock.CurrentSegment,
                        w,
                        world,
                        guard
                    );

                    string npcsArr = "[";
                    for (int i = 0; i < world.Agents.Count; i++)
                    {
                        NpcRuntimeState ag = world.Agents[i];
                        if (i > 0) npcsArr += ",";
                        int px = (int)ag.PosX;
                        int py = (int)ag.PosY;
                        npcsArr += "{\"id\":\"" + ag.Id + "\""
                            + ",\"name\":\"" + EscapeJsonText(ag.DisplayName) + "\""
                            + ",\"place\":\"" + world.Places[ag.CurrentPlaceIdx].Id + "\""
                            + ",\"x\":" + px.ToString()
                            + ",\"y\":" + py.ToString()
                            + ",\"lod\":\"" + ag.LodLevel + "\""
                            + ",\"suspicion\":" + ag.SuspicionTowardSouma.ToString()
                            + ",\"whyHere\":\"" + EscapeJsonText(ag.WhyHereReason) + "\"}";
                    }
                    npcsArr += "]";

                    int wEvCnt = rumorSys.EventLog.Count;
                    int wMemCnt = rumorSys.Memories.Count;
                    int wEdgCnt = rumorSys.RumorEdges.Count;
                    int wCcCnt = rumorSys.CausalChains.Count;
                    string line = "{\"day\":" + d.ToString()
                        + ",\"hour\":" + clock.CurrentHour.ToString()
                        + ",\"segment\":\"" + clock.CurrentSegment + "\""
                        + ",\"weather\":\"" + w + "\""
                        + ",\"soumaPlace\":\"" + world.Places[world.SoumaCurrentPlaceIdx].Id + "\""
                        + ",\"soumaMon\":" + world.SoumaMon.ToString()
                        + ",\"heart\":" + world.HeartWarmCold.ToString()
                        + ",\"worldEventsCount\":" + wEvCnt.ToString()
                        + ",\"memoriesCount\":" + wMemCnt.ToString()
                        + ",\"rumorEdgesCount\":" + wEdgCnt.ToString()
                        + ",\"anecdoteCandidatesCount\":" + wCcCnt.ToString()
                        + ",\"npcs\":" + npcsArr + "}";
                    if (lines.Length > 0) lines += "\n";
                    lines += line;
                }
            }
            return lines;
        }
    }
}
