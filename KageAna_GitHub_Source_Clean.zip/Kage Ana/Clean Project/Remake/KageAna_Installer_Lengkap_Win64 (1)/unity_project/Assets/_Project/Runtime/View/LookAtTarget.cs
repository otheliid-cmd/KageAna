// STATUS VERIFIKASI (E6.4): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using UnityEngine;

namespace KageAna.Presentation
{
    /// <summary>
    /// E6.4: Mengarahkan tulang mata & kepala VRM secara halus ke titik minat (Souma, lentera, atau lawan bicara).
    /// </summary>
    public sealed class LookAtTarget : MonoBehaviour
    {
        public Transform EyeCenter;
        public Transform CurrentPointOfInterest;
        public float MaxYawDegrees = 42.0f;
        public float MaxPitchDegrees = 24.0f;
        public Vector2 CurrentEyeAngles { get; private set; }

        public void UpdateLookDirection(Vector3 targetWorldPos, float deltaTime)
        {
            if (EyeCenter == null) return;
            Vector3 localDir = EyeCenter.InverseTransformPoint(targetWorldPos).normalized;
            float yaw = Mathf.Clamp(Mathf.Atan2(localDir.x, localDir.z) * Mathf.Rad2Deg, -MaxYawDegrees, MaxYawDegrees);
            float pitch = Mathf.Clamp(-Mathf.Asin(Mathf.Clamp(localDir.y, -1f, 1f)) * Mathf.Rad2Deg, -MaxPitchDegrees, MaxPitchDegrees);
            CurrentEyeAngles = Vector2.Lerp(CurrentEyeAngles, new Vector2(yaw, pitch), Mathf.Clamp01(deltaTime * 7.5f));
        }
    }
}
