// KAGE-ANA v3.0 Gelombang D (Butir 8) — Modul 2: Aturan Sistemik 4 Festival (Hanami, Obon x3, Aki Matsuri, Setsubun)
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimFestivalSystem
    {
        public static int GetCurrentFestivalViolenceTabooMultiplier(SimEventBus bus, int day)
        {
            for (int i = 0; i < bus.Data.Festivals.Count; i++)
            {
                if (bus.Data.Festivals[i].Day == day)
                {
                    return bus.Data.Festivals[i].ViolenceTabooMultiplier;
                }
            }
            return 1;
        }

        public static bool IsCurrentFestivalMasksAndNightGarbLegal(SimEventBus bus, int day)
        {
            for (int i = 0; i < bus.Data.Festivals.Count; i++)
            {
                if (bus.Data.Festivals[i].Day == day)
                {
                    return bus.Data.Festivals[i].MasksAndNightGarbLegal;
                }
            }
            return false;
        }

        public static double GetCurrentFestivalTeaSweetsMultiplier(SimEventBus bus, int day)
        {
            for (int i = 0; i < bus.Data.Festivals.Count; i++)
            {
                if (bus.Data.Festivals[i].Day == day)
                {
                    return bus.Data.Festivals[i].TeaAndSweetsPriceMultiplier;
                }
            }
            return 1.0;
        }
    }
}
