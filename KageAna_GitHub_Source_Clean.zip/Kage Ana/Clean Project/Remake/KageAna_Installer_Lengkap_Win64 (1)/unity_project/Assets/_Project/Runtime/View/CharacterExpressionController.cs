// STATUS VERIFIKASI (E6.4): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using System;
using UnityEngine;

namespace KageAna.Presentation
{
    public enum VrmEmotionPreset
    {
        Neutral = 0,
        Happy = 1,
        Angry = 2,
        Sad = 3,
        Surprised = 4,
        Relaxed = 5,
        SuspiciousCustom = 6,
        EmbarrassedCustom = 7
    }

    /// <summary>
    /// E6.4: Menerjemahkan keadaan emosi Sim (sikap NPC terhadap Souma, keyakinan, kecurigaan)
    /// ke ekspresi blendshape VRM + mikro-gerak berlapis (kedipan acak, napas, goyangan kepala, reaksi sesaat)
    /// agar wajah tidak pernah beku saat bicara.
    /// </summary>
    public sealed class CharacterExpressionController : MonoBehaviour
    {
        public VrmEmotionPreset BaseEmotion = VrmEmotionPreset.Neutral;
        public float BlinkLeftWeight;
        public float BlinkRightWeight;
        public float BreathPhase;
        public float HeadMicroSwayAngleDeg;
        public float TransientReactionWeight;

        private float _nextBlinkTimer = 2.8f;
        private float _blinkProgress = -1.0f;

        public void ApplySimStateToExpression(string attitudeToSouma, int suspicionLevel, bool justHeardShockingRumor, float deltaTime)
        {
            if (justHeardShockingRumor)
            {
                BaseEmotion = VrmEmotionPreset.Surprised;
                TransientReactionWeight = 1.0f;
            }
            else if (suspicionLevel >= 55 || attitudeToSouma == "Hostile")
            {
                BaseEmotion = VrmEmotionPreset.SuspiciousCustom;
            }
            else if (attitudeToSouma == "Warm" || attitudeToSouma == "Trusted")
            {
                BaseEmotion = VrmEmotionPreset.Happy;
            }
            else if (attitudeToSouma == "Fearful" || attitudeToSouma == "indebted")
            {
                BaseEmotion = VrmEmotionPreset.Sad;
            }
            else
            {
                BaseEmotion = VrmEmotionPreset.Neutral;
            }

            BreathPhase += deltaTime * 1.65f;
            HeadMicroSwayAngleDeg = Mathf.Sin(BreathPhase * 0.7f) * 1.4f;
            TransientReactionWeight = Mathf.MoveTowards(TransientReactionWeight, 0.0f, deltaTime * 1.5f);

            _nextBlinkTimer -= deltaTime;
            if (_nextBlinkTimer <= 0.0f && _blinkProgress < 0.0f)
            {
                _blinkProgress = 0.0f;
                _nextBlinkTimer = 2.2f + Mathf.Abs(Mathf.Sin(BreathPhase * 3.1f)) * 2.4f;
            }

            if (_blinkProgress >= 0.0f)
            {
                _blinkProgress += deltaTime * 9.0f;
                float w = _blinkProgress <= 1.0f ? _blinkProgress : Mathf.Max(0.0f, 2.0f - _blinkProgress);
                BlinkLeftWeight = w;
                BlinkRightWeight = w;
                if (_blinkProgress >= 2.0f)
                {
                    _blinkProgress = -1.0f;
                    BlinkLeftWeight = 0.0f;
                    BlinkRightWeight = 0.0f;
                }
            }
        }
    }
}
