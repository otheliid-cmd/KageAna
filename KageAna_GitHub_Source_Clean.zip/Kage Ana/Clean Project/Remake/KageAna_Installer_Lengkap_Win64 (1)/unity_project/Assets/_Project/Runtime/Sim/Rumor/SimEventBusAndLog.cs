// KAGE-ANA v3.0 Gelombang D (Butir 1 & 8) — Modul 1: EventBus, Log Kejadian, Skor Kebermaknaan (Salience), & Pemformat Klaim
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public sealed class KisahEventEntry
    {
        public int Day;
        public int Hour;
        public string Category;
        public string PlaceId;
        public string Summary;
        public string SourceEventId;
        public string WitnessNpcId;
        public string WhyLinkText;

        public KisahEventEntry()
        {
            Day = 1;
            Hour = 6;
            Category = "";
            PlaceId = "";
            Summary = "";
            SourceEventId = "";
            WitnessNpcId = "";
            WhyLinkText = "";
        }
    }

    public class SimEventBus
    {
        public SimDataBundle Data;
        public bool EventEmitterEnabled;

        public List<WorldEvent> EventLog;
        public List<MemoryEntry> Memories;
        public List<RumorPropagationHop> RumorEdges;
        public List<DynamicKabarRecord> Kabars;
        public List<KisahEventEntry> KisahEvents;
        public List<CausalChainRecord> CausalChains;
        public List<NisshiEntry> RawNisshiCandidates;
        public List<NisshiEntry> NisshiEntries;

        public int KabarUpgradedCount;

        // Algorithmic Distortion Operator Counters (A2-1 & A3-1)
        public int OpCountMagnify;
        public int OpCountWrongPerson;
        public int OpCountWrongPlace;
        public int OpCountDropDetail;
        public int OpCountAddMotive;

        // A3-2 WorldEvent Source Category Counters
        public int EventsFromScheduleTransition;
        public int EventsFromEntityInteraction;
        public int EventsFromSoumaAction;
        public int EventsFromWorldCondition;
        public int UnclassifiedEventsCount;

        // Gelombang D Counters (Salience & Agency)
        public int AgencyActionsEmittedCount;
        public int MisunderstandingChainsCount;
        public int SalientEventsCount;
        public int RoutineEventsCount;

        // Gelombang E Counters (E1.2 Step Cost & E2.1-E2.4 Anti-Filler / Intervention)
        public int WhyLinkedInteractionEventsCount;
        public int RepeatedPairWithoutTriggerCount;
        public int CrossLocationInteractionsCount;
        public int UnpredictableCausalEventsCount;
        public int InterventionsExecutedCount;
        public int StepCostClockWeatherOps;
        public int StepCostPlaceRoutineOps;
        public int StepCostSocialEconomyOps;
        public int StepCostPerceptionMemoryOps;
        public int StepCostRumorPropOps;
        public int StepCostAgencyOps;
        public int StepCostMicroNisshiOps;

        public SimEventBus(SimDataBundle bundle)
        {
            Data = bundle;
            EventEmitterEnabled = true;

            EventLog = new List<WorldEvent>();
            Memories = new List<MemoryEntry>();
            RumorEdges = new List<RumorPropagationHop>();
            Kabars = new List<DynamicKabarRecord>();
            KisahEvents = new List<KisahEventEntry>();
            CausalChains = new List<CausalChainRecord>();
            RawNisshiCandidates = new List<NisshiEntry>();
            NisshiEntries = new List<NisshiEntry>();

            KabarUpgradedCount = 0;
            OpCountMagnify = 0;
            OpCountWrongPerson = 0;
            OpCountWrongPlace = 0;
            OpCountDropDetail = 0;
            OpCountAddMotive = 0;

            EventsFromScheduleTransition = 0;
            EventsFromEntityInteraction = 0;
            EventsFromSoumaAction = 0;
            EventsFromWorldCondition = 0;
            UnclassifiedEventsCount = 0;

            AgencyActionsEmittedCount = 0;
            MisunderstandingChainsCount = 0;
            SalientEventsCount = 0;
            RoutineEventsCount = 0;

            WhyLinkedInteractionEventsCount = 0;
            RepeatedPairWithoutTriggerCount = 0;
            CrossLocationInteractionsCount = 0;
            UnpredictableCausalEventsCount = 0;
            InterventionsExecutedCount = 0;
            StepCostClockWeatherOps = 0;
            StepCostPlaceRoutineOps = 0;
            StepCostSocialEconomyOps = 0;
            StepCostPerceptionMemoryOps = 0;
            StepCostRumorPropOps = 0;
            StepCostAgencyOps = 0;
            StepCostMicroNisshiOps = 0;
        }

        public SimSalienceProfileDef FindSalienceProfile(string actionCode)
        {
            for (int i = 0; i < Data.SalienceConfig.Profiles.Count; i++)
            {
                if (Data.SalienceConfig.Profiles[i].Action == actionCode)
                {
                    return Data.SalienceConfig.Profiles[i];
                }
            }
            SimSalienceProfileDef defProf = new SimSalienceProfileDef();
            defProf.Action = actionCode;
            defProf.IsRoutine = (actionCode == "trade_wares" || actionCode == "visit_temple_bell" || actionCode == "collect_nagaya_rent" || actionCode == "inspect_newcomers" || actionCode == "npc_daily_chat" || actionCode == "npc_help_neighbor");
            defProf.BaseSalience = defProf.IsRoutine ? 0.22 : 0.68;
            return defProf;
        }

        public double ComputeEventSalience(string actionCode, string subjectId, int quantity)
        {
            SimSalienceProfileDef p = FindSalienceProfile(actionCode);
            SimSalienceConfig cfg = Data.SalienceConfig;
            double weighted = (p.Novelty * cfg.NoveltyWeight)
                + (p.ExpectationViolation * cfg.ExpectationViolationWeight)
                + (p.Stakes * cfg.StakesWeight)
                + (p.Secrecy * cfg.SecrecyWeight);
            double score = (p.BaseSalience * 0.55) + (weighted * 0.45);
            if (!p.IsRoutine && quantity >= 3) score += 0.04;
            if (subjectId == "souma" && !p.IsRoutine) score += 0.06;
            if (score > 1.0) score = 1.0;
            if (score < 0.05) score = 0.05;
            return score;
        }

        public string ReplaceSlot(string templateStr, string slot, string value)
        {
            string res = "";
            int n = templateStr.Length;
            int m = slot.Length;
            int i = 0;
            while (i < n)
            {
                bool match = false;
                if (i + m <= n)
                {
                    match = true;
                    for (int j = 0; j < m; j++)
                    {
                        if (templateStr[i + j] != slot[j])
                        {
                            match = false;
                            break;
                        }
                    }
                }
                if (match)
                {
                    res += value;
                    i += m;
                }
                else
                {
                    res += templateStr[i];
                    i += 1;
                }
            }
            return res;
        }

        public string LookupSubjectDisplayName(string subjectId, SimPlaceGraphSystem world)
        {
            if (subjectId == "souma") return "Shinonome Soma";
            int nIdx = world.FindNpcIndexById(subjectId);
            if (nIdx >= 0) return world.Agents[nIdx].DisplayName;
            return subjectId;
        }

        public string LookupPlaceDisplayName(string placeId, SimPlaceGraphSystem world)
        {
            int pIdx = world.FindPlaceIndexById(placeId);
            if (pIdx >= 0) return world.Places[pIdx].Name;
            return placeId;
        }

        public string LookupMotiveText(string motiveId, bool inEnglish)
        {
            for (int i = 0; i < Data.Motives.Count; i++)
            {
                if (Data.Motives[i].Id == motiveId)
                {
                    return inEnglish ? Data.Motives[i].TextEn : Data.Motives[i].TextId;
                }
            }
            return inEnglish ? "(with no stated motive)" : "(tanpa motif yang terucap)";
        }

        public SimClaimTemplateDef FindTemplateForAction(string actionCode)
        {
            for (int i = 0; i < Data.ClaimTemplates.Count; i++)
            {
                if (Data.ClaimTemplates[i].Action == actionCode)
                {
                    return Data.ClaimTemplates[i];
                }
            }
            SimClaimTemplateDef fallback = new SimClaimTemplateDef();
            fallback.Action = actionCode;
            return fallback;
        }

        public string FormatClaimFromTemplate(StructuredClaim claim, SimPlaceGraphSystem world, bool inEnglish)
        {
            SimClaimTemplateDef tpl = FindTemplateForAction(claim.ActionCode);
            string raw = inEnglish ? tpl.TemplateEn : tpl.TemplateId;
            string subjName = LookupSubjectDisplayName(claim.SubjectId, world);
            string placeName = LookupPlaceDisplayName(claim.PlaceId, world);
            string motiveText = LookupMotiveText(claim.MotiveId, inEnglish);

            string s = ReplaceSlot(raw, "{subject}", subjName);
            s = ReplaceSlot(s, "{action}", claim.ActionCode);
            s = ReplaceSlot(s, "{place}", placeName);
            s = ReplaceSlot(s, "{time}", claim.TimeLabel);
            s = ReplaceSlot(s, "{quantity}", claim.Quantity.ToString());
            s = ReplaceSlot(s, "{motive}", motiveText);
            return s;
        }

        public WorldEvent FindEventById(string eventId)
        {
            if (eventId.Length > 4 && eventId[0] == 'e' && eventId[1] == 'v' && eventId[2] == 't' && eventId[3] == '_')
            {
                int val = 0;
                bool ok = true;
                for (int k = 4; k < eventId.Length; k++)
                {
                    char c = eventId[k];
                    if (c < '0' || c > '9') { ok = false; break; }
                    val = (val * 10) + (int)(c - '0');
                }
                int idx = val - 1;
                if (ok && idx >= 0 && idx < EventLog.Count && EventLog[idx].Id == eventId)
                {
                    return EventLog[idx];
                }
            }
            for (int i = EventLog.Count - 1; i >= 0; i--)
            {
                if (EventLog[i].Id == eventId)
                {
                    return EventLog[i];
                }
            }
            return new WorldEvent();
        }
    }
}
