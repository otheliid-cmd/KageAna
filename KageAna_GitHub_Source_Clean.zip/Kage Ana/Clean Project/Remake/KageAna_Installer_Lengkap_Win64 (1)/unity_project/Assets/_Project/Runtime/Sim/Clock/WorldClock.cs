// KAGE-ANA v3.0 — World.Clock (10 Hz, 18 Real Minutes/Day, 7 Segments, 28-Day 4-Season Calendar)
// Pure C# implementation in Runtime/Sim/Clock (Decision C-07).
using System;

namespace KageAna.Runtime.Sim
{
    public sealed class WorldClock
    {
        public const int TicksPerRealSecond = 10;
        public const int RealSecondsPerGameHour = 45;
        public const int TicksPerGameHour = TicksPerRealSecond * RealSecondsPerGameHour; // 450 ticks
        public const int HoursPerDay = 24;
        public const int TicksPerGameDay = TicksPerGameHour * HoursPerDay; // 10,800 ticks = 1080s = 18.0 real min
        public const int DaysPerSeason = 7;
        public const int SeasonsPerYear = 4;
        public const int DaysPerYear = DaysPerSeason * SeasonsPerYear; // 28 days

        public int TotalTicks;
        public int CurrentDay;       // 1..28
        public int CurrentYear;      // 1..N
        public int CurrentHour;      // 0..23
        public int CurrentMinute;    // 0..59
        public string CurrentSegment;
        public string CurrentSeason;

        public int OnHourFiredCount;
        public int OnDayStartFiredCount;
        public int OnSeasonChangeFiredCount;
        public int OnFestivalFiredCount;
        public int TempleBellRingsCount;
        public string LastFestivalId;

        public WorldClock()
        {
            ResetToDayOneDawn();
        }

        public void ResetToDayOneDawn()
        {
            TotalTicks = 0;
            CurrentDay = 1;
            CurrentYear = 1;
            CurrentHour = 5; // Day 1 begins at 05:00 Dawn (Fajar)
            CurrentMinute = 0;
            CurrentSegment = ComputeSegmentForHour(CurrentHour);
            CurrentSeason = ComputeSeasonForDay(CurrentDay);

            // Event counters start at 0 before tick 0 is processed so that a 28-day simulation
            // [0, 302400) fires DayStart 28 times (Days 1..28) and SeasonChange 4 times (4 seasons),
            // avoiding the closed-interval [0, 302400] fencepost double-count at the end of Day 28.
            OnHourFiredCount = 0;
            OnDayStartFiredCount = 0;
            OnSeasonChangeFiredCount = 0;
            OnFestivalFiredCount = 0;
            TempleBellRingsCount = 0;
            LastFestivalId = GetScheduledEventForDay(CurrentDay);
        }

        public static string ComputeSegmentForHour(int hour)
        {
            // Section 6.1 & 10.6:
            // Fajar (Dawn) 05-07, Pagi (Morning) 07-11, Siang (Noon) 11-15,
            // Sore (Afternoon) 15-18, Senja (Dusk) 18-20, Malam (Night) 20-01, Dini (LateNight) 01-05
            if (hour >= 5 && hour < 7) return "Dawn";
            if (hour >= 7 && hour < 11) return "Morning";
            if (hour >= 11 && hour < 15) return "Noon";
            if (hour >= 15 && hour < 18) return "Afternoon";
            if (hour >= 18 && hour < 20) return "Dusk";
            if (hour >= 20 || hour < 1) return "Night";
            return "LateNight";
        }

        public static string ComputeSeasonForDay(int day)
        {
            // Section 6.2: Semi (Spring) 1-7, Panas (Summer) 8-14, Gugur (Autumn) 15-21, Dingin (Winter) 22-28
            int zeroBased = (day - 1) % DaysPerYear;
            if (zeroBased < 0) zeroBased += DaysPerYear;
            int seasonIdx = zeroBased / DaysPerSeason;
            if (seasonIdx == 0) return "Spring";
            if (seasonIdx == 1) return "Summer";
            if (seasonIdx == 2) return "Autumn";
            return "Winter";
        }

        public static bool IsTempleBellHour(int hour)
        {
            // Section 6.1: Temple bell rings at 06:00, 12:00, 18:00, 22:00
            return hour == 6 || hour == 12 || hour == 18 || hour == 22;
        }

        public static string GetScheduledEventForDay(int day)
        {
            int dayInYear = ((day - 1) % DaysPerYear) + 1;
            // Section 6.3 Scheduled Year-1 Events
            if (dayInYear == 3) return "Hanami";
            if (dayInYear == 7) return "RentDue_Week1";
            if (dayInYear == 11) return "Obon";
            if (dayInYear == 14) return "ShirahaneCaravan_And_RentDue";
            if (dayInYear == 19) return "AkiMatsuri_TaxAndHarvest";
            if (dayInYear == 21) return "RentDue_Week3";
            if (dayInYear == 22) return "KuzuryuInspection";
            if (dayInYear == 26) return "Setsubun";
            if (dayInYear == 28) return "YearEnd_Nisshi_And_RentDue";
            return "";
        }

        public void StepOneTick()
        {
            int tickStarting = TotalTicks;

            // Fire DayStart / SeasonChange / Festival at the opening tick of each day (0, 10800, ..., 291600)
            if (tickStarting % TicksPerGameDay == 0)
            {
                int dayIndexOneBased = 1 + (tickStarting / TicksPerGameDay);
                int dayOfCycle = ((dayIndexOneBased - 1) % DaysPerYear) + 1;
                string seasonAtDayStart = ComputeSeasonForDay(dayOfCycle);

                OnDayStartFiredCount += 1;
                if (dayIndexOneBased == 1 || seasonAtDayStart != ComputeSeasonForDay(dayIndexOneBased - 1))
                {
                    OnSeasonChangeFiredCount += 1;
                }

                string fest = GetScheduledEventForDay(dayOfCycle);
                LastFestivalId = fest;
                if (fest.Length > 0)
                {
                    OnFestivalFiredCount += 1;
                }
            }

            TotalTicks += 1;
            int ticksSinceStart = TotalTicks;
            // Offset by 5 hours so Day 1 starts at 05:00
            int absoluteTicks = ticksSinceStart + (5 * TicksPerGameHour);
            int totalDaysElapsed = absoluteTicks / TicksPerGameDay;
            int newYear = 1 + (totalDaysElapsed / DaysPerYear);
            int newDay = 1 + (totalDaysElapsed % DaysPerYear);
            int remDayTicks = absoluteTicks % TicksPerGameDay;
            int newHour = remDayTicks / TicksPerGameHour;
            int remHourTicks = remDayTicks % TicksPerGameHour;
            int newMinute = (remHourTicks * 60) / TicksPerGameHour;

            bool hourChanged = (newHour != CurrentHour) || (newDay != CurrentDay) || (newYear != CurrentYear);

            CurrentYear = newYear;
            CurrentDay = newDay;
            CurrentSeason = ComputeSeasonForDay(CurrentDay);
            CurrentMinute = newMinute;

            if (hourChanged)
            {
                CurrentHour = newHour;
                CurrentSegment = ComputeSegmentForHour(CurrentHour);
                OnHourFiredCount += 1;
                if (IsTempleBellHour(CurrentHour))
                {
                    TempleBellRingsCount += 1;
                }
            }
        }

        public void AdvanceTicks(int count)
        {
            for (int i = 0; i < count; i++)
            {
                StepOneTick();
            }
        }
    }
}
