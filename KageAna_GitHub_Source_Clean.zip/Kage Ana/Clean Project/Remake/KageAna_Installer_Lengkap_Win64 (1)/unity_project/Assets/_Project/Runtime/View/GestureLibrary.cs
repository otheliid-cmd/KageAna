// STATUS VERIFIKASI (E6.4): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using System.Collections.Generic;
using UnityEngine;

namespace KageAna.Presentation
{
    /// <summary>
    /// E6.4: Daftar 19 gerakan wajib Humanoid + kebiasaan mikro khas karakter dari SpeechHabit/Attitude Sim.
    /// </summary>
    public sealed class GestureLibrary : MonoBehaviour
    {
        public static readonly string[] MandatoryHumanoidClips = new string[]
        {
            "Walk",
            "Run",
            "Sneak",
            "Climb",
            "IdleBreathing",
            "TalkGesture_01_Calm",
            "TalkGesture_02_Explain",
            "TalkGesture_03_Whisper",
            "TalkGesture_04_Point",
            "TalkGesture_05_Accuse",
            "TalkGesture_06_Laugh",
            "TradeOffer",
            "BaggleCountMon",
            "RefuseWaveHand",
            "StartledStepBack",
            "RaiseHandsSurrender",
            "BowRespectful",
            "SaluteGuard",
            "PeekCorner",
            "AmbushCrouch",
            "CollapseFall"
        };

        public string SelectGestureForSimEvent(string actionType, string speechHabit)
        {
            if (actionType == "AccuseWrongPerson" || actionType == "FineIssued") return "TalkGesture_05_Accuse";
            if (actionType == "SpreadRumor" || actionType == "TradeAndGossip") return "TalkGesture_03_Whisper";
            if (actionType == "MarketHaggle" || actionType == "TradeFair") return "BaggleCountMon";
            if (actionType == "CollectRent" || actionType == "LedgerMismatch") return "TalkGesture_04_Point";
            if (speechHabit != null && speechHabit.Contains("batuk")) return "IdleBreathing";
            return "TalkGesture_01_Calm";
        }
    }
}
