// KAGE-ANA v3.0 Gelombang D (Butir 1, 3, & 8) — Modul 5: Persepsi Indra (Kitab 8.2), LOD Ingatan, & Pemancar Kejadian
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimPerceptionSystem
    {
        public static void EvaluatePerceptionForWorldEvent(
            SimEventBus bus,
            WorldEvent evt,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (evt.Id.Length == 0 || evt.IsFlavorOnly) return;

            int evtPlaceIdx = world.FindPlaceIndexById(evt.PlaceId);
            if (evtPlaceIdx < 0) return;

            double baseSightMeters = 22.0;
            if (segment == "Dusk") baseSightMeters = 15.0;
            else if (segment == "Night" || segment == "LateNight")
            {
                baseSightMeters = (world.Places[evtPlaceIdx].LightProfile == "DeepMoonShadow") ? 8.0 : 14.0;
            }
            double weatherSightMult = 1.0;
            if (weather == "Fog") weatherSightMult = 0.50;
            else if (weather == "Storm") weatherSightMult = 0.60;
            else if (weather == "Rain") weatherSightMult = 0.80;

            double effectiveSightRange = baseSightMeters * weatherSightMult * evt.VisibilityIntensity;
            int tabooMult = SimFestivalSystem.GetCurrentFestivalViolenceTabooMultiplier(bus, evt.Day);

            bool isSoumaPlace = (!world.SoumaIsInTransit && world.SoumaCurrentPlaceIdx == evtPlaceIdx);
            if (evt.IsRoutineEvent && !isSoumaPlace && evt.Hour != 13 && evt.ActionCode != "inspect_newcomers")
            {
                return;
            }
            int maxWitnessMemories = (evt.IsRoutineEvent && !isSoumaPlace) ? 1 : 26;
            int recordedWitnesses = 0;

            for (int n = 0; n < world.Agents.Count; n++)
            {
                if (recordedWitnesses >= maxWitnessMemories) break;
                NpcRuntimeState ag = world.Agents[n];
                if (ag.IsDead || ag.IsSleeping || ag.IsInTransit) continue;
                if (ag.CurrentPlaceIdx != evtPlaceIdx) continue;
                if (SimMemoryStore.HasNpcAlreadyWitnessedEvent(bus, ag.Id, evt.Id)) continue;

                bool canSee = (effectiveSightRange >= 6.0) && (ag.FamiliarityWithSouma >= 5 || evt.SubjectId != "souma");
                bool canHear = (evt.NoiseDecibels >= 16.0);
                if (!canSee && !canHear) continue;

                int srcType = canSee ? 0 : 1; // 0=Saw, 1=Heard

                MemoryEntry mem = new MemoryEntry();
                int nextMemId = bus.Memories.Count + 1;
                mem.Id = "mem_" + nextMemId.ToString();
                mem.OwnerNpcId = ag.Id;
                mem.Day = evt.Day;
                mem.Hour = evt.Hour;
                mem.PlaceId = evt.PlaceId;
                mem.SourceType = srcType;
                mem.SourceEventId = evt.Id;
                mem.SourceMemoryId = "";
                mem.TellerNpcId = "";
                mem.RootWitnessNpcId = ag.Id;
                mem.HopCount = 0;
                SimClaimTemplateDef tpl = bus.FindTemplateForAction(evt.ActionCode);
                mem.Reliability = tpl.BaseReliability;
                mem.Tellable = evt.Tellable;
                mem.AppliedDistortionOperators = "None";

                mem.Claim.SubjectId = evt.SubjectId;
                mem.Claim.ActionCode = evt.ActionCode;
                mem.Claim.PlaceId = evt.PlaceId;
                mem.Claim.TimeLabel = segment + " (H" + evt.Day.ToString() + " " + evt.Hour.ToString() + ":00)";
                mem.Claim.Quantity = evt.Quantity;
                mem.Claim.MotiveId = "motive_none";

                mem.SalienceScore = SimMemoryStore.ComputeMemorySalienceForListener(bus, evt, ag, world);
                mem.IsRoutineMemory = evt.IsRoutineEvent && (mem.SalienceScore <= bus.Data.SalienceConfig.RoutineMaxSalience);

                mem.FormattedTextId = bus.FormatClaimFromTemplate(mem.Claim, world, false);
                mem.FormattedTextEn = bus.FormatClaimFromTemplate(mem.Claim, world, true);

                if (guard.ValidateMemoryAgainstEventLog(mem, bus.EventLog, bus.Memories, world.Places[ag.CurrentPlaceIdx].Id, ""))
                {
                    bus.Memories.Add(mem);
                    recordedWitnesses += 1;

                    if (evt.SubjectId == "souma")
                    {
                        if (evt.Type == "TrueFaceStage1_Retak")
                        {
                            world.AddSuspicionReason(n, bus.Data.TrueFaceConfig.Stage1NearbySuspicionDelta, "Merasakan perubahan postur Wajah Asli Tahap 1 (Retak) di " + world.Places[evtPlaceIdx].Name);
                        }
                        else if (evt.Type == "TrueFaceStage2_Terbuka")
                        {
                            int tfSpike = bus.Data.TrueFaceConfig.WitnessSuspicionSpike * tabooMult;
                            world.AddSuspicionReason(n, tfSpike, "Menyaksikan langsung Wajah Asli Tahap 2 (Terbuka) dengan gerak mematikan di " + world.Places[evtPlaceIdx].Name + " (+" + tfSpike.ToString() + ")");
                        }
                        else if (evt.ActionCode == "steal_item")
                        {
                            world.AddSuspicionReason(n, 25 * tabooMult, "Melihat Soma mengambil barang secara mencurigakan di " + world.Places[evtPlaceIdx].Name);
                        }
                        else if (evt.ActionCode == "loud_violence")
                        {
                            world.AddSuspicionReason(n, 45 * tabooMult, "Menyaksikan Soma bertarung gaduh di " + world.Places[evtPlaceIdx].Name);
                        }
                    }
                    else if (evt.ActionCode == "corpse_discovered")
                    {
                        world.AddSuspicionReason(n, 20 * tabooMult, "Menemukan jenazah korban tebasan di " + world.Places[evtPlaceIdx].Name);
                        world.DistrictCrackdownActive = true;
                        world.CrackdownHoursRemaining = 12;
                    }
                }
            }

            if (isSoumaPlace && evt.Tellable && !evt.IsFlavorOnly && evt.ActorId != "souma" && (!evt.IsRoutineEvent || evt.ActionCode == "trade_wares" || evt.ActionCode == "collect_nagaya_rent"))
            {
                StructuredClaim sClaim = new StructuredClaim();
                sClaim.SubjectId = evt.SubjectId;
                sClaim.ActionCode = evt.ActionCode;
                sClaim.PlaceId = evt.PlaceId;
                sClaim.TimeLabel = segment + " (H" + evt.Day.ToString() + ")";
                sClaim.Quantity = evt.Quantity;
                sClaim.MotiveId = "motive_none";
                SimMemoryStore.RegisterSoumaKabarObservation(bus, evt.Id, "souma_direct_" + evt.ActorId, "Saw", sClaim, evt.Day, evt.Hour, world);
            }
        }

        public static WorldEvent EmitWorldEvent(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            string evtType,
            string eventSourceCategory,
            string actorId,
            string secondaryEntityId,
            string placeId,
            string subjectId,
            string actionCode,
            int quantity,
            string trueMotiveForDebugOnly,
            double visibility,
            double noiseDb,
            bool tellable,
            bool isFlavorOnly,
            string stateEffectSummary,
            string payload,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (!bus.EventEmitterEnabled)
            {
                return new WorldEvent();
            }

            WorldEvent evt = new WorldEvent();
            int nextNum = bus.EventLog.Count + 1;
            evt.Id = "evt_" + nextNum.ToString();
            evt.Tick = tick;
            evt.Day = day;
            evt.Hour = hour;
            evt.Type = evtType;
            evt.EventSourceCategory = eventSourceCategory;
            evt.ActorId = actorId;
            evt.SecondaryEntityId = secondaryEntityId;
            evt.PlaceId = placeId;
            evt.SubjectId = subjectId;
            evt.ActionCode = actionCode;
            evt.Quantity = quantity;
            evt.AppearanceNote = (subjectId == "souma") ? world.ActiveGarmentId : "warga_kurokawa";
            evt.TrueMotive = trueMotiveForDebugOnly;
            evt.VisibilityIntensity = visibility;
            evt.NoiseDecibels = noiseDb;
            evt.Tellable = tellable;
            evt.IsFlavorOnly = isFlavorOnly;
            evt.StateEffectSummary = stateEffectSummary;
            evt.Payload = payload;

            SimSalienceProfileDef prof = bus.FindSalienceProfile(actionCode);
            evt.IsRoutineEvent = prof.IsRoutine;
            evt.SalienceScore = bus.ComputeEventSalience(actionCode, subjectId, quantity);
            if (evt.IsRoutineEvent) bus.RoutineEventsCount += 1;
            else bus.SalientEventsCount += 1;

            if (!guard.ValidateWorldEventSource(evt))
            {
                bus.UnclassifiedEventsCount += 1;
                return evt;
            }

            if (eventSourceCategory == "ScheduleTransition") bus.EventsFromScheduleTransition += 1;
            else if (eventSourceCategory == "EntityInteraction") bus.EventsFromEntityInteraction += 1;
            else if (eventSourceCategory == "SoumaAction") bus.EventsFromSoumaAction += 1;
            else if (eventSourceCategory == "WorldCondition") bus.EventsFromWorldCondition += 1;
            else bus.UnclassifiedEventsCount += 1;

            bus.EventLog.Add(evt);
            EvaluatePerceptionForWorldEvent(bus, evt, segment, weather, world, guard);
            return evt;
        }
    }
}
