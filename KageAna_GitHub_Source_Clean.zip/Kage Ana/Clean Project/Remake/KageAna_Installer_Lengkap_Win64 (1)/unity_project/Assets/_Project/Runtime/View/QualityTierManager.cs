// STATUS VERIFIKASI (E1.1 & E3.3): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using System;
using UnityEngine;

namespace KageAna.Presentation
{
    public enum QualityTier
    {
        PC_Desktop_60Fps = 0,
        Android_MidRange_30Fps = 1,
        Android_High_60Fps = 2,
        Android_BatterySaver_30Fps = 3
    }

    /// <summary>
    /// E3.3 & E9.3: Kontrak anggaran performa keras untuk PC dan Android menengah (Snapdragon 7-series / Mali sejenis).
    /// Menyediakan pengukur performa (FPS, draw call, memori) di menu pengembang dan mode hemat baterai/panas.
    /// </summary>
    public sealed class QualityTierManager : MonoBehaviour
    {
        public QualityTier CurrentTier = QualityTier.Android_MidRange_30Fps;
        public bool ShowDeveloperOverlay;

        public int TargetFps { get; private set; } = 30;
        public int MaxMainCharacterTriangles { get; private set; } = 20000;
        public int MaxBackgroundNpcTriangles { get; private set; } = 8000;
        public int MaxDrawCallsPerFrame { get; private set; } = 150;
        public int ShadowCascades { get; private set; } = 1;
        public int MaxCharacterTextureResolution { get; private set; } = 1024;
        public int MaxMemoryBudgetMB { get; private set; } = 1500;
        public bool EnableBloomAndGrain { get; private set; }
        public bool UseInvertedHullOutline { get; private set; } = true;

        public void ApplyTier(QualityTier tier)
        {
            CurrentTier = tier;
            if (tier == QualityTier.PC_Desktop_60Fps)
            {
                TargetFps = 60;
                MaxMainCharacterTriangles = 40000;
                MaxBackgroundNpcTriangles = 15000;
                MaxDrawCallsPerFrame = 400;
                ShadowCascades = 3;
                MaxCharacterTextureResolution = 2048;
                MaxMemoryBudgetMB = 4096;
                EnableBloomAndGrain = true;
                UseInvertedHullOutline = false;
            }
            else if (tier == QualityTier.Android_High_60Fps)
            {
                TargetFps = 60;
                MaxMainCharacterTriangles = 20000;
                MaxBackgroundNpcTriangles = 8000;
                MaxDrawCallsPerFrame = 150;
                ShadowCascades = 1;
                MaxCharacterTextureResolution = 1024;
                MaxMemoryBudgetMB = 1500;
                EnableBloomAndGrain = false;
                UseInvertedHullOutline = true;
            }
            else
            {
                // Android_MidRange_30Fps & Android_BatterySaver_30Fps (Kontrak E3.3)
                TargetFps = 30;
                MaxMainCharacterTriangles = 20000;
                MaxBackgroundNpcTriangles = 8000;
                MaxDrawCallsPerFrame = 150;
                ShadowCascades = tier == QualityTier.Android_BatterySaver_30Fps ? 0 : 1;
                MaxCharacterTextureResolution = 1024;
                MaxMemoryBudgetMB = 1500;
                EnableBloomAndGrain = false;
                UseInvertedHullOutline = true;
            }
            Application.targetFrameRate = TargetFps;
        }
    }
}
