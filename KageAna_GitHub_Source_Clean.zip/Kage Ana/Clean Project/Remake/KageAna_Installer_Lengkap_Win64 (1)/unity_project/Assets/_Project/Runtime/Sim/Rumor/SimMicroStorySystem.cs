// KAGE-ANA v3.0 Gelombang E (E2.2) — Modul 10: 24 Kisah Kecil Bersyarat Keadaan Dunia (100% Data-Driven, 0 ID NPC Keras)
// Pure C# in Runtime/Sim (netstandard2.1, tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimMicroStorySystem
    {
        public static void EvaluateConditionalMicroStories(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            bus.StepCostMicroNisshiOps += 1;
            for (int s = 0; s < bus.Data.MicroStories.Count; s++)
            {
                SimMicroStoryDef st = bus.Data.MicroStories[s];
                bool alreadyTriggered = false;
                for (int t = 0; t < world.TriggeredMicroStoryIds.Count; t++)
                {
                    if (world.TriggeredMicroStoryIds[t] == st.Id) { alreadyTriggered = true; break; }
                }
                if (alreadyTriggered) continue;

                string cond = st.ConditionType;
                bool matched = false;
                int pIdx = world.FindPlaceIndexById(st.RequiredPlaceId);
                int p1Idx = world.FindNpcIndexById(st.PrimaryNpcId);
                int p2Idx = world.FindNpcIndexById(st.SecondaryNpcId);

                if (cond == "guard_post_vacant" && pIdx >= 0 && pIdx < world.Places.Count && world.GuardPostVacant[pIdx])
                {
                    matched = true;
                }
                else if (cond == "nagaya_rent_due_co_located" && (day % 7 == 0))
                {
                    if (p1Idx >= 0 && p2Idx >= 0 && world.Agents[p1Idx].CurrentPlaceIdx == world.Agents[p2Idx].CurrentPlaceIdx) matched = true;
                }
                else if (cond == "weather_storm_crowded_shelter" && weather == "Storm")
                {
                    matched = true;
                }
                else if (cond == "souma_carrying_medicine_at_apothecary" && world.ActiveOdor == "Medicine" && world.Places[world.SoumaCurrentPlaceIdx].Id == st.RequiredPlaceId)
                {
                    matched = true;
                }
                else if (cond == "souma_obtained_za_license" && world.HasZaLicense)
                {
                    matched = true;
                }
                else if (cond == "high_suspicion_at_bridge")
                {
                    if (p1Idx >= 0 && world.Agents[p1Idx].SuspicionTowardSouma >= 25) matched = true;
                }
                else if (cond == "souma_high_trust_at_workshop" && world.GroupTrust >= 75)
                {
                    matched = true;
                }
                else if (cond == "night_fog_at_docks" && weather == "Fog" && (segment == "Dusk" || segment == "Night"))
                {
                    matched = true;
                }
                else if (cond == "district_crackdown_active" && world.DistrictCrackdownActive)
                {
                    matched = true;
                }
                else if (cond == "corpse_discovered_panic")
                {
                    for (int c = 0; c < world.Corpses.Count; c++) if (world.Corpses[c].IsDiscovered) matched = true;
                }
                else if (cond == "low_heart_cold_at_shrine" && world.HeartWarmCold <= -10)
                {
                    matched = true;
                }
                else if (cond == "rain_at_farmland" && weather == "Rain")
                {
                    matched = true;
                }
                else if (cond == "festival_hanami_active" && day == 5) matched = true;
                else if (cond == "festival_obon_active" && day == 12) matched = true;
                else if (cond == "violence_during_obon" && day == 12 && world.BloodStainLevel > 0) matched = true;
                else if (cond == "festival_akimatsuri_active" && day == 19) matched = true;
                else if (cond == "festival_setsubun_active" && day == 26) matched = true;
                else if (cond == "unpaid_rent_debt_high" && world.UnpaidRentDebtMon >= 350) matched = true;
                else if (cond == "kaede_meets_soan_afternoon")
                {
                    if (p1Idx >= 0 && p2Idx >= 0 && world.Agents[p1Idx].CurrentPlaceIdx == world.Agents[p2Idx].CurrentPlaceIdx) matched = true;
                }
                else if (cond == "weekly_dead_drop_delivered" && world.DeadDropReportsDelivered >= 1) matched = true;
                else if (cond == "craftsman_coal_delivery")
                {
                    if (p1Idx >= 0 && p2Idx >= 0 && world.Agents[p1Idx].CurrentPlaceIdx == world.Agents[p2Idx].CurrentPlaceIdx) matched = true;
                }
                else if (cond == "high_rumor_density_teahouse" && bus.RumorEdges.Count >= 25) matched = true;
                else if (cond == "true_face_witnessed_recently" && world.TrueFaceActivationsCount > 0) matched = true;
                else if (cond == "high_warm_heart_and_rich" && world.HeartWarmCold >= 40 && world.SoumaMon >= 400) matched = true;

                if (matched)
                {
                    world.TriggeredMicroStoryIds.Add(st.Id);
                    WorldEvent stEvt = SimPerceptionSystem.EmitWorldEvent(
                        bus,
                        tick, day, hour, segment, weather,
                        "MicroStory", "WorldCondition",
                        st.PrimaryNpcId, st.SecondaryNpcId, st.RequiredPlaceId, st.PrimaryNpcId,
                        "micro_story_event", 2, "motive_none", 1.0, 20.0, true, false,
                        "MicroStoryTriggered:" + st.Id + "->" + st.WorldEffect,
                        st.Summary,
                        world, guard
                    );
                    stEvt.IsUnpredictableFromSchedule = true;
                    bus.UnpredictableCausalEventsCount += 1;
                    SimNisshiCurator.RecordKisahEventWithWhy(bus, day, hour, "KisahKecil", st.RequiredPlaceId, "KISAH KECIL [" + st.Id + "]: " + st.Summary + " (Efek: " + st.WorldEffect + ")", stEvt.Id, st.PrimaryNpcId, "Dipicu kondisi dunia: " + cond + " di " + st.RequiredPlaceId);
                    double imp = (cond == "unpaid_rent_debt_high" || cond == "souma_carrying_medicine_at_apothecary" || cond == "souma_obtained_za_license" || cond == "weekly_dead_drop_delivered") ? 0.88 : 0.68;
                    SimNisshiCurator.RecordNisshiCandidate(bus, day, "KisahKecil", stEvt.Id, "Hari " + day.ToString() + " — " + st.Summary + ".", imp, 0.72);
                    break;
                }
            }
        }
    }
}
