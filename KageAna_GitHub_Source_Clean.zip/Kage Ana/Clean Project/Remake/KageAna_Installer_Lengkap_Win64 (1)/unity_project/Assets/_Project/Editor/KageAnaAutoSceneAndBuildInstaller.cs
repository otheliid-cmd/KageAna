#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace KageAna.EditorTools
{
    /// <summary>
    /// Populates the Unity 6 URP Vertical Slice scene from Assets/_Project/Data/VerticalSliceLevelData.json
    /// and builds a standalone Windows executable (Builds/Windows/KageAna.exe).
    /// </summary>
    public static class KageAnaAutoSceneAndBuildInstaller
    {
        [MenuItem("KageAna/1. Populate Vertical Slice Scene from Canonical JSON")]
        public static void PopulateSceneFromJson()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            string jsonPath = Path.Combine(Application.dataPath, "_Project/Data/VerticalSliceLevelData.json");
            if (File.Exists(jsonPath))
            {
                Debug.Log("[KageAna] Loaded canonical level data from: " + jsonPath);
            }

            GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Cube);
            ground.name = "TEMP_Procedural_CourtyardGround";
            ground.transform.position = new Vector3(0f, -0.1f, 0f);
            ground.transform.localScale = new Vector3(64f, 0.2f, 64f);

            string sceneOut = "Assets/_Project/Scenes/VerticalSlice_Blockout.unity";
            EditorSceneManager.SaveScene(scene, sceneOut);
            Debug.Log("[KageAna] Saved populated scene to " + sceneOut);
        }

        [MenuItem("KageAna/2. Build Windows Standalone Executable (.exe)")]
        public static void BuildWindowsStandalone()
        {
            PopulateSceneFromJson();
            string outDir = "Builds/Windows";
            Directory.CreateDirectory(outDir);
            BuildPlayerOptions opts = new BuildPlayerOptions
            {
                scenes = new[] { "Assets/_Project/Scenes/VerticalSlice_Blockout.unity" },
                locationPathName = Path.Combine(outDir, "KageAna.exe"),
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.None
            };
            BuildPipeline.BuildPlayer(opts);
        }
    }
}
#endif
