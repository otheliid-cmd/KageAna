// STATUS VERIFIKASI (E6.5): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using System;
using System.Collections.Generic;
using UnityEngine;

namespace KageAna.Audio
{
    [Serializable]
    public sealed class VoiceBarkEntry
    {
        public string BarkId;
        public string CharacterId;
        public string Situation;
        public string EmotionTag;
        public string JapaneseText;
        public string Romaji;
        public string IndonesianSubtitle;
        public float CooldownSeconds = 8.0f;
    }

    /// <summary>
    /// E6.5: Memilih bark suara Jepang menurut emosi + keyakinan + hubungan dengan cooldown agar tak berulang,
    /// serta mendukung tabel id -> klip yang dapat diganti tanpa membangun ulang.
    /// </summary>
    public sealed class VoiceBarkPlayer : MonoBehaviour
    {
        private readonly Dictionary<string, VoiceBarkEntry> _barkTable = new Dictionary<string, VoiceBarkEntry>();
        private readonly Dictionary<string, float> _lastPlayedTimeByBarkId = new Dictionary<string, float>();

        public void RegisterBark(VoiceBarkEntry entry)
        {
            if (entry != null && !string.IsNullOrEmpty(entry.BarkId))
            {
                _barkTable[entry.BarkId] = entry;
            }
        }

        public VoiceBarkEntry TrySelectBark(string characterId, string situation, string emotionTag, float currentTimeSeconds)
        {
            foreach (var kv in _barkTable)
            {
                VoiceBarkEntry b = kv.Value;
                if (b.CharacterId == characterId && b.Situation == situation && b.EmotionTag == emotionTag)
                {
                    float lastTime;
                    if (_lastPlayedTimeByBarkId.TryGetValue(b.BarkId, out lastTime))
                    {
                        if (currentTimeSeconds - lastTime < b.CooldownSeconds) continue;
                    }
                    _lastPlayedTimeByBarkId[b.BarkId] = currentTimeSeconds;
                    return b;
                }
            }
            return null;
        }
    }
}
