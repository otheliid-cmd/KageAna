// KAGE-ANA v3.0 Gelombang E (E2.1, E2.2, E2.3) — Modul 11: Niat Sosial Berbasis Kebutuhan & Hubungan (0 Pengisi Kuota, 0 ID Keras) + Pemulihan Kepercayaan Kelompok
// Pure C# in Runtime/Sim (netstandard2.1, tanpa UnityEngine, tanpa System.Text.Json).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimEconomyAndPressureSystem
    {
        public static void EvaluateDailyLifePressure(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (!bus.EventEmitterEnabled) return;

            if (hour == 5)
            {
                for (int i = 0; i < world.Agents.Count; i++)
                {
                    NpcRuntimeState ag = world.Agents[i];
                    ag.DailyInteractionsCount = 0;
                    ag.InteractedPartnersToday.Clear();
                    ag.HasNewTriggerSinceLastSocial = true;
                    ag.LastTriggerReason = "FajarHariBaru_H" + day.ToString();
                    ag.NeedPay = Math.Min(10, ag.SocialDrives.PerluBayar + (day % 3 == 0 ? 1 : 0));
                    ag.NeedTalk = Math.Min(10, ag.SocialDrives.PerluBicara);
                    ag.NeedTrade = Math.Min(10, ag.SocialDrives.PerluDagang);
                    ag.NeedRest = Math.Max(2, ag.SocialDrives.PerluIstirahat - 1);
                    ag.Curiosity = Math.Min(10, ag.SocialDrives.RasaPenasaran);
                    ag.Grudge = ag.SocialDrives.Dendam;
                    ag.Affection = ag.SocialDrives.KasihSayang;
                    ag.DutyDrive = ag.SocialDrives.TugasJadwal;
                }
                if (day % 7 == 1)
                {
                    world.RoutineTradeHeartGainsThisWeek = 0;
                }
                SimMemoryStore.DecayMemoriesAtDayStart(bus, day);
            }

            // 1. Biaya makan harian (15 mon setiap pagi pukul 07:00)
            if (hour == 7)
            {
                int foodCost = 15;
                if (world.SoumaMon >= foodCost)
                {
                    world.SoumaMon -= foodCost;
                    world.TotalExpensesMon += foodCost;
                    world.UpdateMonBounds();

                    if (world.ActiveSoumaPolicy == "Idle" && (day == 1 || day == 5))
                    {
                        int evIdx = bus.EventLog.Count;
                        SimNisshiCurator.RecordNisshiCandidate(
                            bus, day, "TekananHidup", "evt_" + evIdx.ToString(),
                            "Hari " + day.ToString() + " — Mengurung diri di kamar sewa Nagaya tanpa membuka kotak pikul; bekal uang menyusut menjadi " + world.SoumaMon.ToString() + " mon untuk membeli bubur pagi.",
                            0.85, 0.72
                        );
                    }
                }
                else
                {
                    int deficit = foodCost - world.SoumaMon;
                    world.TotalExpensesMon += world.SoumaMon;
                    world.SoumaMon = 0;
                    world.UnpaidRentDebtMon += deficit;
                    world.FatigueLevel = Math.Min(100, world.FatigueLevel + 10);
                    world.HeartWarmCold = Math.Max(-100, world.HeartWarmCold - 2);
                    world.UpdateMonBounds();

                    if (day % 3 == 0)
                    {
                        int hostIdx = world.FindNpcIndexByDuty("food_stall_host");
                        string hostId = hostIdx >= 0 ? world.Agents[hostIdx].Id : (world.Agents.Count > 0 ? world.Agents[0].Id : "npc_host");
                        string hostName = hostIdx >= 0 ? world.Agents[hostIdx].DisplayName : "Pemilik Kedai";

                        WorldEvent debtEvt = SimPerceptionSystem.EmitWorldEvent(
                            bus, tick, day, hour, segment, weather,
                            "LifePressure", "EntityInteraction",
                            hostId, "souma", "place_nagaya", hostId,
                            "npc_debt_demand", world.UnpaidRentDebtMon, "motive_debt", 1.0, 20.0, true, false,
                            "FoodDebtDemand:" + hostId + "->souma;TotalDebt=" + world.UnpaidRentDebtMon.ToString(),
                            hostName + " menagih utang makan harian Soma",
                            world, guard
                        );
                        debtEvt.WhyNeedAndRelationTag = "Drive=perlu_bayar;Rel=utang;Trigger=UtangMakanHarian";
                        debtEvt.IsUnpredictableFromSchedule = true;
                        bus.WhyLinkedInteractionEventsCount += 1;
                        bus.UnpredictableCausalEventsCount += 1;

                        SimNisshiCurator.RecordKisahEventWithWhy(
                            bus, day, hour, "TekananHidup_UtangMakan", "place_nagaya",
                            "Kantong Soma kosong (0 mon); " + hostName + " mencatat utang makan harian (total tunggakan " + world.UnpaidRentDebtMon.ToString() + " mon) dan menatap dingin.",
                            debtEvt.Id, hostId, "Biaya makan harian 15 mon tak terbayar tunai karena Soma tidak berdagang."
                        );
                        SimNisshiCurator.RecordNisshiCandidate(
                            bus, day, "TekananHidup", debtEvt.Id,
                            "Hari " + day.ToString() + " — Kantong uang keping benar-benar kosong (0 mon); terpaksa berutang jatah makan pagi di Nagaya hingga total tunggakan membengkak menjadi " + world.UnpaidRentDebtMon.ToString() + " mon.",
                            0.92, 0.84
                        );
                    }
                }
            }

            // 2. Tagihan Sewa Mingguan Pemilik Nagaya (setiap Hari 7, 14, 21, 28 pukul 19:00)
            if (day % 7 == 0 && hour == 19)
            {
                if (world.ActiveSoumaPolicy == "HonestTrader" || world.ActiveSoumaPolicy == "TraderInformant" || world.ActiveSoumaPolicy == "Pemulih")
                {
                    ExecuteSoumaPayRentToOhana(bus, tick, day, hour, segment, weather, world, guard);
                }
                else
                {
                    int rent = world.Data.ClockConfig.WeeklyRentMon;
                    int landladyIdx = world.FindNpcIndexByDuty("collect_nagaya_rent");
                    string landladyId = landladyIdx >= 0 ? world.Agents[landladyIdx].Id : (world.Agents.Count > 0 ? world.Agents[0].Id : "npc_landlady");
                    string landladyName = landladyIdx >= 0 ? world.Agents[landladyIdx].DisplayName : "Pemilik Nagaya";

                    if (world.ActiveSoumaPolicy == "Idle")
                    {
                        int partialPaid = world.SoumaMon;
                        world.SoumaMon = 0;
                        world.TotalExpensesMon += partialPaid;
                        world.TotalRentPaidToOhanaMon += partialPaid;
                        int unpaidThisWeek = rent - partialPaid;
                        world.UnpaidRentDebtMon += unpaidThisWeek;
                        world.UnpaidRentWeeks += 1;
                        world.HeartWarmCold = Math.Max(-100, world.HeartWarmCold - 4);
                        world.UpdateMonBounds();

                        if (landladyIdx >= 0)
                        {
                            world.Agents[landladyIdx].AttitudeTowardSouma = "Kesal_Tunggakan";
                            world.AddSuspicionReason(landladyIdx, 18, "Menunggak sewa kamar Nagaya minggu ke-" + world.UnpaidRentWeeks.ToString() + " (utang " + world.UnpaidRentDebtMon.ToString() + " mon)");
                        }

                        string conseqNote = "";
                        if (world.UnpaidRentWeeks == 1)
                        {
                            conseqNote = landladyName + " menegur keras Soma di serambi Nagaya karena hanya sanggup menyerahkan sisa " + partialPaid.ToString() + " mon dari sewa 350 mon.";
                        }
                        else if (world.UnpaidRentWeeks == 2)
                        {
                            world.CarryUnits = Math.Max(2, world.CarryUnits / 2);
                            conseqNote = "Tunggakan minggu ke-2: " + landladyName + " menahan separuh isi kotak pikul Soma sebagai jaminan sewa tetapi masih mengizinkan Soma berjualan untuk menebusnya.";
                        }
                        else
                        {
                            world.UnpaidRentDebtMon = Math.Max(0, world.UnpaidRentDebtMon - 90);
                            world.FatigueLevel = Math.Min(100, world.FatigueLevel + 25);
                            conseqNote = "Ancaman pengusiran minggu ke-" + world.UnpaidRentWeeks.ToString() + ": Demi tidak diusir ke jalan, Soma diwajibkan " + landladyName + " menimba air sumur dan membelah kayu bakar Nagaya untuk memotong utang 90 mon.";
                        }

                        WorldEvent arrEvt = SimPerceptionSystem.EmitWorldEvent(
                            bus, tick, day, hour, segment, weather,
                            "RentArrears", "EntityInteraction",
                            landladyId, "souma", "place_nagaya", landladyId,
                            "rent_arrears_warning", world.UnpaidRentDebtMon, "motive_debt", 1.1, 24.0, true, false,
                            "RentArrearsWeek=" + world.UnpaidRentWeeks.ToString() + ";Debt=" + world.UnpaidRentDebtMon.ToString() + ";CarryUnits=" + world.CarryUnits.ToString(),
                            conseqNote,
                            world, guard
                        );
                        arrEvt.WhyNeedAndRelationTag = "Drive=perlu_bayar;Rel=utang;Trigger=TunggakanSewaMingguan";
                        arrEvt.IsUnpredictableFromSchedule = true;
                        bus.WhyLinkedInteractionEventsCount += 1;
                        bus.UnpredictableCausalEventsCount += 1;

                        SimNisshiCurator.RecordKisahEventWithWhy(
                            bus, day, hour, "TunggakanSewaOhana", "place_nagaya",
                            conseqNote, arrEvt.Id, landladyId,
                            "Jatuh tempo sewa mingguan (350 mon) pada Hari " + day.ToString() + " saat uang Soma tidak mencukupi."
                        );
                        SimNisshiCurator.RecordNisshiCandidate(
                            bus, day, "TekananHidup", arrEvt.Id,
                            "Hari " + day.ToString() + " — " + conseqNote + " (Total tunggakan: " + world.UnpaidRentDebtMon.ToString() + " mon).",
                            0.96, 0.88
                        );
                    }
                }
            }

            // 3. Pajak Panen Aki Matsuri (Hari 19 pukul 12:00)
            if (day == 19 && hour == 12)
            {
                int tax = world.Data.ClockConfig.AutumnTaxMon;
                int evIdx = bus.EventLog.Count;
                if (world.SoumaMon >= tax && world.ActiveSoumaPolicy != "Idle")
                {
                    world.SoumaMon -= tax;
                    world.TotalExpensesMon += tax;
                    world.UpdateMonBounds();
                    SimNisshiCurator.RecordNisshiCandidate(
                        bus, day, "Festival", "evt_" + evIdx.ToString(),
                        "Hari 19 (Aki Matsuri) — Membayar pungutan pajak panen musim gugur sebesar " + tax.ToString() + " mon kepada juru tulis lembah.",
                        0.84, 0.78
                    );
                }
                else if (world.ActiveSoumaPolicy == "Idle")
                {
                    world.UnpaidRentDebtMon += 200;
                    int magIdx = world.FindNpcIndexByDuty("enforce_tax_and_seizure");
                    if (magIdx >= 0)
                    {
                        world.AddSuspicionReason(magIdx, 20, "Mangkir dari iuran panen Aki Matsuri saat pendataan warga Nagaya");
                    }
                    SimNisshiCurator.RecordNisshiCandidate(
                        bus, day, "Festival", "evt_" + evIdx.ToString(),
                        "Hari 19 (Aki Matsuri) — Tidak sanggup membayar iuran panen lembah; Magistrat mencatat nama penghuni kamar Nagaya dalam daftar pengawasan (+20 kecurigaan).",
                        0.93, 0.85
                    );
                }
            }

            // 4. Evaluasi Jatuh Tempo Pesanan Kelompok Mingguan & Jalur Pemulihan (E2.3)
            if (day % 7 == 0 && hour == 21)
            {
                bool autoDeliver = (world.ActiveSoumaPolicy == "TraderInformant")
                    || (world.ActiveSoumaPolicy == "Pemulih" && day >= 21)
                    || (world.ActiveSoumaPolicy == "HonestTrader" && day == 28 && world.GroupContactState != "Aktif");
                if (autoDeliver)
                {
                    ExecuteSoumaDeadDropReport(bus, tick, day, hour, segment, weather, world, guard);
                }
                else
                {
                    int weekNum = ((day - 1) / 7) + 1;
                    int penalty = 22;
                    string orderTitle = "Pesanan Mingguan #" + weekNum.ToString();
                    for (int o = 0; o < world.Data.GroupOrders.Count; o++)
                    {
                        if (world.Data.GroupOrders[o].WeekNumber == weekNum)
                        {
                            penalty = world.Data.GroupOrders[o].TrustPenaltyOnFailure;
                            orderTitle = world.Data.GroupOrders[o].Title;
                            break;
                        }
                    }
                    if (penalty < 20) penalty = 22;
                    world.MissedGroupOrderCount += 1;
                    world.GroupTrust = Math.Max(0, world.GroupTrust - penalty);

                    if (world.GroupTrust <= 25 && !world.GroupSupplyLineCut)
                    {
                        world.GroupSupplyLineCut = true;
                        world.GroupContactState = "KontakTerputus";
                        world.AvailableRecoveryAction = "Antarkan minimal 1 Kabar terverifikasi (>=2 saksi) ke Titik Serah Hutan untuk memulai Ujian Kesetiaan.";

                        int courierIdx = world.FindNpcIndexByDuty("group_courier");
                        string courierId = courierIdx >= 0 ? world.Agents[courierIdx].Id : (world.Agents.Count > 0 ? world.Agents[0].Id : "npc_courier");
                        string courierName = courierIdx >= 0 ? world.Agents[courierIdx].DisplayName : "Kurir Kelompok";

                        WorldEvent cutEvt = SimPerceptionSystem.EmitWorldEvent(
                            bus, tick, day, hour, segment, weather,
                            "GroupSupplyCut", "EntityInteraction",
                            courierId, "souma", "place_titik_serah_hutan", courierId,
                            "group_supply_cut", world.MissedGroupOrderCount, "motive_spy", 0.70, 16.0, true, false,
                            "GroupSupplyCut=true;GroupContactState=KontakTerputus;GroupTrust=" + world.GroupTrust.ToString(),
                            "Kurir " + courierName + " memutus sementara kiriman modal kelompok dan membuka jalur Ujian Kesetiaan",
                            world, guard
                        );
                        cutEvt.WhyNeedAndRelationTag = "Drive=tugas_jadwal;Rel=atasan_bawahan;Trigger=PesananKelompokTerlewat";
                        cutEvt.IsUnpredictableFromSchedule = true;
                        bus.WhyLinkedInteractionEventsCount += 1;
                        bus.UnpredictableCausalEventsCount += 1;

                        SimNisshiCurator.RecordKisahEventWithWhy(
                            bus, day, hour, "JalurKelompokTerputus", "place_titik_serah_hutan",
                            "Kepercayaan Kelompok jatuh ke " + world.GroupTrust.ToString() + "/100 (Status: KontakTerputus). Jalan lanjut terbuka: bawa 1 Kabar bernilai ke Pohon Aras Tua untuk menempuh Ujian Kesetiaan!",
                            cutEvt.Id, courierId,
                            "Tidak ada laporan Papan Tinta yang diserahkan pada tenggat Minggu ke-" + weekNum.ToString()
                        );
                        SimNisshiCurator.RecordNisshiCandidate(
                            bus, day, "TekananHidup", cutEvt.Id,
                            "Hari " + day.ToString() + " — Karena terus mengabaikan '" + orderTitle + "', kontak kelompok terputus (" + world.GroupTrust.ToString() + "/100). Kau mengirim kabar yang jujur sebagai pedagang, namun kelompok menuntut bukti kesetiaan bila ingin dipercaya kembali.",
                            0.95, 0.89
                        );
                    }
                    else if (world.ActiveSoumaPolicy == "Idle")
                    {
                        int evIdx = bus.EventLog.Count;
                        SimNisshiCurator.RecordNisshiCandidate(
                            bus, day, "TekananHidup", "evt_" + evIdx.ToString(),
                            "Hari " + day.ToString() + " — Melewatkan tenggat '" + orderTitle + "' tanpa satu pun kabar terverifikasi; Kepercayaan Kelompok turun menjadi " + world.GroupTrust.ToString() + "/100.",
                            0.88, 0.78
                        );
                    }
                }
            }

            // E2.3: Jika kebijakan Pemulih atau HonestTrader berada pada status KontakTerputus / UjianKesetiaan dan punya Kabar terverifikasi
            if (hour == 20 && (world.GroupContactState == "KontakTerputus" || world.GroupContactState == "UjianKesetiaan"))
            {
                if ((world.ActiveSoumaPolicy == "Pemulih" && day >= 16) || (world.ActiveSoumaPolicy == "HonestTrader" && day >= 23))
                {
                    ExecuteSoumaDeadDropReport(bus, tick, day, hour, segment, weather, world, guard);
                }
            }
        }

        public static void EvaluateHourlyScheduleAndEntityInteractions(
            SimEventBus bus,
            ulong seed,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            EvaluateDailyLifePressure(bus, tick, day, hour, segment, weather, world, guard);

            if (!bus.EventEmitterEnabled || hour < 6 || hour > 21)
            {
                return;
            }

            // (a) ScheduleTransition Events: Real state effects (Guard post vacancy, Market inspection, Temple bell)
            int schedEmitted = 0;
            for (int i = 0; i < world.Agents.Count; i++)
            {
                NpcRuntimeState ag = world.Agents[i];
                if (ag.IsDead || ag.IsSleeping) continue;
                string pId = world.Places[ag.CurrentPlaceIdx].Id;

                if (ag.RoleCategory == "Guard" && (hour == 12 || hour == 19) && ((day + i) % 3 == 0))
                {
                    int postIdx = ag.AssignedPostPlaceIdx;
                    int teaIdx = world.FindPlaceIndexById("place_kedai_teh");
                    if (postIdx >= 0 && teaIdx >= 0 && !world.GuardPostVacant[postIdx])
                    {
                        world.LeaveGuardPostEarly(i, postIdx, teaIdx, "Meninggalkan pos " + world.Places[postIdx].Name + " lebih awal menuju Kedai Teh.");
                        schedEmitted += 1;
                        SimPerceptionSystem.EmitWorldEvent(
                            bus,
                            tick, day, hour, segment, weather,
                            "ScheduleTransition", "ScheduleTransition",
                            ag.Id, "", world.Places[postIdx].Id, ag.Id,
                            "leave_post_early", 1, "motive_bribe", 1.0, 18.0, true, false,
                            "GuardPostVacant:" + world.Places[postIdx].Id + "=true;MovedTo=place_kedai_teh",
                            ag.CurrentActivity,
                            world, guard
                        );
                        continue;
                    }
                }

                if (!ag.ScheduleTransitionedThisHour && schedEmitted >= 2) continue;
                ag.ScheduleTransitionedThisHour = false;

                if (ag.RoleCategory == "Guard" && (hour == 8 || hour == 15) && schedEmitted < 2)
                {
                    if (ag.CurrentPlaceIdx >= 0 && ag.CurrentPlaceIdx < world.Places.Count)
                    {
                        world.GuardPostVacant[ag.CurrentPlaceIdx] = false;
                    }
                    schedEmitted += 1;
                    SimPerceptionSystem.EmitWorldEvent(
                        bus,
                        tick, day, hour, segment, weather,
                        "ScheduleTransition", "ScheduleTransition",
                        ag.Id, "", pId, ag.Id,
                        "inspect_newcomers", 2 + (day % 4), "motive_spy", 1.0, 20.0, true, false,
                        "GuardPostOccupied:" + pId + "=true;Inspector=" + ag.Id,
                        ag.CurrentActivity,
                        world, guard
                    );
                }
                else if (world.NpcHasDuty(i, "ring_temple_bell") && (pId == "place_kuil_kecil" || pId == "place_apotek_soan") && (hour == 6 || hour == 11 || hour == 18))
                {
                    schedEmitted += 1;
                    SimPerceptionSystem.EmitWorldEvent(
                        bus,
                        tick, day, hour, segment, weather,
                        "ScheduleTransition", "ScheduleTransition",
                        ag.Id, "", pId, ag.Id,
                        "visit_temple_bell", 1, "motive_none", 1.0, 24.0, true, false,
                        "RitualShiftStarted:" + ag.Id + "@" + pId,
                        ag.CurrentActivity,
                        world, guard
                    );
                }
            }

            // (b) E2.1 Needs & Relationship Driven Social Intent (ZERO quota filler, ZERO cross-location pairing)
            int agentCount = world.Agents.Count;
            int maxSocialIntentsThisHour = 7;
            int intentsFired = 0;

            for (int i = 0; i < agentCount; i++)
            {
                if (intentsFired >= maxSocialIntentsThisHour) break;
                NpcRuntimeState a1 = world.Agents[i];
                if (a1.IsDead || a1.IsSleeping || a1.IsInTransit) continue;
                if (a1.LastInteractionDay == day && (hour - a1.LastInteractionHour) < 2) continue;

                // Evolve needs over the day
                if (hour == 9 || hour == 14 || hour == 18) a1.NeedTalk = Math.Min(10, a1.NeedTalk + 1);
                if (hour == 10 || hour == 15) a1.NeedTrade = Math.Min(10, a1.NeedTrade + 1);
                if (hour >= 17) a1.NeedRest = Math.Min(10, a1.NeedRest + 1);

                // Find best co-located partner ONLY at the exact same place (a2.CurrentPlaceIdx == a1.CurrentPlaceIdx)
                int bestPartnerIdx = -1;
                string bestDrive = "";
                int bestScore = -1;
                SimNpcRelationDef bestRel = new SimNpcRelationDef();

                for (int j = 0; j < agentCount; j++)
                {
                    if (j == i) continue;
                    NpcRuntimeState cand = world.Agents[j];
                    if (cand.IsDead || cand.IsSleeping || cand.IsInTransit) continue;
                    // HARD RULE E2.1: Strictly same location only! Never pair across locations.
                    if (cand.CurrentPlaceIdx != a1.CurrentPlaceIdx) continue;

                    SimNpcRelationDef rel = world.FindRelationBetween(i, j);
                    bool alreadyPairedToday = false;
                    for (int p = 0; p < a1.InteractedPartnersToday.Count; p++)
                    {
                        if (a1.InteractedPartnersToday[p] == cand.Id)
                        {
                            alreadyPairedToday = true;
                            break;
                        }
                    }

                    // Skip repeated pair unless there is a genuine new trigger today
                    if (alreadyPairedToday && !a1.HasNewTriggerSinceLastSocial) continue;

                    int opportunity = alreadyPairedToday ? 1 : 3;
                    int closeWeight = Math.Max(2, rel.Closeness);

                    // Score each of the 8 social drives based on relationship type & need state
                    // 1. perlu_bayar / utang / sewa
                    if (rel.RelationType == "utang" || (world.NpcHasDuty(i, "collect_nagaya_rent") && cand.HomePlaceIdx == a1.HomePlaceIdx))
                    {
                        int sc = a1.NeedPay * (closeWeight + 2) * opportunity;
                        if (sc > bestScore) { bestScore = sc; bestPartnerIdx = j; bestDrive = "perlu_bayar"; bestRel = rel; }
                    }
                    // 2. dendam / saingan (heated argument only when grudge + drive crosses threshold)
                    if ((rel.RelationType == "dendam" || rel.RelationType == "saingan" || rel.RelationType == "utang") && (rel.GrudgeLevel + a1.Grudge >= 11))
                    {
                        int sc = (a1.Grudge + rel.GrudgeLevel) * closeWeight * opportunity;
                        if (sc > bestScore) { bestScore = sc; bestPartnerIdx = j; bestDrive = "dendam"; bestRel = rel; }
                    }
                    // 3. kasih_sayang (kerabat / kekasih / rekan dekat)
                    if (rel.RelationType == "kerabat" || rel.RelationType == "kekasih" || (rel.RelationType == "rekan" && rel.Closeness >= 8))
                    {
                        int sc = a1.Affection * closeWeight * opportunity;
                        if (sc > bestScore) { bestScore = sc; bestPartnerIdx = j; bestDrive = "kasih_sayang"; bestRel = rel; }
                    }
                    // 4. tugas_jadwal (atasan_bawahan / rekan / manage_za_ledger)
                    if (rel.RelationType == "atasan_bawahan" || world.NpcHasDuty(i, "manage_za_ledger") || world.NpcHasDuty(i, "patrol_guard"))
                    {
                        int sc = a1.DutyDrive * closeWeight * opportunity;
                        if (sc > bestScore) { bestScore = sc; bestPartnerIdx = j; bestDrive = "tugas_jadwal"; bestRel = rel; }
                    }
                    // 5. perlu_dagang
                    if (a1.RoleCategory == "Merchant" || cand.RoleCategory == "Merchant" || a1.NeedTrade >= 6)
                    {
                        int sc = a1.NeedTrade * closeWeight * opportunity;
                        if (sc > bestScore) { bestScore = sc; bestPartnerIdx = j; bestDrive = "perlu_dagang"; bestRel = rel; }
                    }
                    // 6. rasa_penasaran
                    if (a1.Curiosity >= 6 && rel.RelationType != "asing")
                    {
                        int sc = a1.Curiosity * closeWeight * opportunity;
                        if (sc > bestScore) { bestScore = sc; bestPartnerIdx = j; bestDrive = "rasa_penasaran"; bestRel = rel; }
                    }
                    // 7. perlu_istirahat (di kedai teh / nagaya / kuil)
                    if (a1.NeedRest >= 6 && world.Places[a1.CurrentPlaceIdx].IsIndoorShelter)
                    {
                        int sc = a1.NeedRest * closeWeight * opportunity;
                        if (sc > bestScore) { bestScore = sc; bestPartnerIdx = j; bestDrive = "perlu_istirahat"; bestRel = rel; }
                    }
                    // 8. perlu_bicara (termasuk sapaan orang asing)
                    {
                        int sc = a1.NeedTalk * closeWeight * opportunity;
                        if (sc > bestScore) { bestScore = sc; bestPartnerIdx = j; bestDrive = "perlu_bicara"; bestRel = rel; }
                    }
                }

                // Minimum score threshold so NPCs only interact when a meaningful drive & opportunity align
                if (bestPartnerIdx < 0 || bestScore < 42) continue;

                NpcRuntimeState a2 = world.Agents[bestPartnerIdx];
                if (a1.CurrentPlaceIdx != a2.CurrentPlaceIdx)
                {
                    bus.CrossLocationInteractionsCount += 1;
                    continue;
                }

                bool wasRepeatToday = false;
                for (int p = 0; p < a1.InteractedPartnersToday.Count; p++)
                {
                    if (a1.InteractedPartnersToday[p] == a2.Id) { wasRepeatToday = true; break; }
                }
                if (wasRepeatToday && !a1.HasNewTriggerSinceLastSocial)
                {
                    bus.RepeatedPairWithoutTriggerCount += 1;
                }

                a1.InteractedPartnersToday.Add(a2.Id);
                a2.InteractedPartnersToday.Add(a1.Id);
                string triggerUsed = a1.LastTriggerReason.Length > 0 ? a1.LastTriggerReason : ("Jadwal@" + world.Places[a1.CurrentPlaceIdx].Id);
                a1.HasNewTriggerSinceLastSocial = false;

                a1.LastInteractionDay = day;
                a1.LastInteractionHour = hour;
                a1.DailyInteractionsCount += 1;
                a1.TotalInteractionsCount += 1;
                a2.DailyInteractionsCount += 1;
                a2.TotalInteractionsCount += 1;
                intentsFired += 1;
                bus.StepCostSocialEconomyOps += 1;

                string pId = world.Places[a1.CurrentPlaceIdx].Id;
                string actionCode = "npc_daily_chat";
                string motiveCode = "motive_none";
                int qty = 1;
                double vis = 0.85;
                double noise = 16.0;
                bool unpredictable = false;
                string effectStr = "";
                string summaryStr = "";

                if (bestRel.RelationType == "asing")
                {
                    // HARD RULE E2.1: Strangers ONLY greet or bargain!
                    if (bestDrive == "perlu_dagang" || a1.RoleCategory == "Merchant" || a2.RoleCategory == "Merchant")
                    {
                        actionCode = "trade_wares";
                        qty = 2;
                        a1.NpcMon += 10;
                        a2.NpcMon = Math.Max(0, a2.NpcMon - 10);
                        a1.NeedTrade = Math.Max(2, a1.NeedTrade - 3);
                        effectStr = "StrangerTrade:" + a1.Id + "<->" + a2.Id + ":10mon";
                        summaryStr = a1.DisplayName + " menawar dan membeli dagangan dari " + a2.DisplayName;
                    }
                    else
                    {
                        actionCode = "npc_greet_stranger";
                        qty = 1;
                        a1.NeedTalk = Math.Max(2, a1.NeedTalk - 2);
                        effectStr = "StrangerGreet:" + a1.Id + "<->" + a2.Id;
                        summaryStr = a1.DisplayName + " menyapa singkat " + a2.DisplayName + " di " + world.Places[a1.CurrentPlaceIdx].Name;
                    }
                }
                else if (bestDrive == "perlu_bayar")
                {
                    if (world.NpcHasDuty(i, "collect_nagaya_rent"))
                    {
                        actionCode = "collect_nagaya_rent";
                        motiveCode = "motive_debt";
                        qty = 80;
                        a2.NpcMon = Math.Max(0, a2.NpcMon - 80);
                        a1.NpcMon += 80;
                        a1.NeedPay = Math.Max(2, a1.NeedPay - 4);
                        a2.HasNewTriggerSinceLastSocial = true;
                        a2.LastTriggerReason = "DitagihSewaOleh_" + a1.Id;
                        unpredictable = true;
                        effectStr = "RentCollected:" + a2.Id + "->" + a1.Id + ":80mon";
                        summaryStr = a1.DisplayName + " menagih cicilan sewa kamar dari " + a2.DisplayName;
                    }
                    else
                    {
                        actionCode = "npc_debt_demand";
                        motiveCode = "motive_debt";
                        qty = bestRel.DebtMon > 0 ? bestRel.DebtMon : 45;
                        int paid = Math.Min(a2.NpcMon, 20);
                        a2.NpcMon -= paid;
                        a1.NpcMon += paid;
                        bestRel.GrudgeLevel = Math.Min(10, bestRel.GrudgeLevel + 1);
                        a1.NeedPay = Math.Max(2, a1.NeedPay - 4);
                        a2.HasNewTriggerSinceLastSocial = true;
                        a2.LastTriggerReason = "DitagihUtangOleh_" + a1.Id;
                        unpredictable = true;
                        effectStr = "DebtDemand:" + a1.Id + "->" + a2.Id + ":" + paid.ToString() + "mon;Grudge=" + bestRel.GrudgeLevel.ToString();
                        summaryStr = a1.DisplayName + " menagih piutang kepada " + a2.DisplayName + " (" + bestRel.Note + ")";
                    }
                }
                else if (bestDrive == "dendam")
                {
                    // Pertengkaran HANYA lahir dari dendam/utang/saingan yang melewati ambang & meninggalkan jejak hubungan memburuk!
                    actionCode = "npc_heated_argument";
                    motiveCode = "motive_greed";
                    qty = 2;
                    vis = 1.05;
                    noise = 25.0;
                    bestRel.GrudgeLevel = Math.Min(10, bestRel.GrudgeLevel + 2);
                    bestRel.Closeness = Math.Max(1, bestRel.Closeness - 1);
                    a1.Grudge = Math.Max(2, a1.Grudge - 3);
                    a2.Grudge = Math.Min(10, a2.Grudge + 2);
                    a2.HasNewTriggerSinceLastSocial = true;
                    a2.LastTriggerReason = "PertengkaranDengan_" + a1.Id;
                    unpredictable = true;
                    effectStr = "HeatedArgument:" + a1.Id + "<->" + a2.Id + ";Closeness=" + bestRel.Closeness.ToString() + ";Grudge=" + bestRel.GrudgeLevel.ToString();
                    summaryStr = a1.DisplayName + " berselisih sengit dengan " + a2.DisplayName + " karena " + bestRel.Note;
                }
                else if (bestDrive == "tugas_jadwal" && world.NpcHasDuty(i, "manage_za_ledger") && (bestRel.RelationType == "rekan" || bestRel.RelationType == "atasan_bawahan" || bestRel.RelationType == "saingan"))
                {
                    actionCode = "hide_za_ledger";
                    motiveCode = "motive_greed";
                    qty = 2;
                    vis = 0.95;
                    noise = 18.0;
                    a1.NpcMon += 25;
                    a1.DutyDrive = Math.Max(3, a1.DutyDrive - 3);
                    a2.HasNewTriggerSinceLastSocial = true;
                    a2.LastTriggerReason = "BukuZa_" + a1.Id;
                    unpredictable = true;
                    effectStr = "ZaLedgerInteraction:" + a1.Id + "<->" + a2.Id + ":+25mon";
                    summaryStr = a1.DisplayName + " dan " + a2.DisplayName + " mencocokkan buku pungutan serikat Za";
                }
                else if (bestDrive == "kasih_sayang")
                {
                    actionCode = "npc_share_concern";
                    qty = 1;
                    bestRel.Closeness = Math.Min(10, bestRel.Closeness + 1);
                    a1.Affection = Math.Max(3, a1.Affection - 3);
                    a2.NeedRest = Math.Max(1, a2.NeedRest - 2);
                    effectStr = "ShareConcern:" + a1.Id + "->" + a2.Id + ";Closeness=" + bestRel.Closeness.ToString();
                    summaryStr = a1.DisplayName + " berbagi bekal dan perhatian kepada " + a2.DisplayName + " (" + bestRel.RelationType + ")";
                }
                else if (bestDrive == "rasa_penasaran")
                {
                    actionCode = "npc_curious_inquiry";
                    qty = 1;
                    a1.Curiosity = Math.Max(2, a1.Curiosity - 3);
                    a2.HasNewTriggerSinceLastSocial = true;
                    a2.LastTriggerReason = "DitanyaKabarOleh_" + a1.Id;
                    unpredictable = true;
                    effectStr = "CuriousInquiry:" + a1.Id + "->" + a2.Id;
                    summaryStr = a1.DisplayName + " menanyakan kabar terbaru di lembah kepada " + a2.DisplayName;
                }
                else if (bestDrive == "tugas_jadwal")
                {
                    actionCode = "npc_duty_coordination";
                    qty = 1;
                    a1.DutyDrive = Math.Max(3, a1.DutyDrive - 3);
                    effectStr = "DutyCoord:" + a1.Id + "<->" + a2.Id;
                    summaryStr = a1.DisplayName + " mengoordinasikan giliran kerja dengan " + a2.DisplayName;
                }
                else if (bestDrive == "perlu_dagang")
                {
                    actionCode = "trade_wares";
                    qty = 2;
                    a1.NpcMon += 12;
                    a2.NpcMon = Math.Max(0, a2.NpcMon - 12);
                    a1.NeedTrade = Math.Max(2, a1.NeedTrade - 3);
                    effectStr = "NpcTrade:" + a1.Id + "<->" + a2.Id + ":12mon";
                    summaryStr = a1.DisplayName + " bertransaksi dagangan dengan " + a2.DisplayName;
                }
                else if (bestDrive == "perlu_istirahat")
                {
                    actionCode = "npc_help_neighbor";
                    qty = 1;
                    a1.NeedRest = Math.Max(1, a1.NeedRest - 3);
                    a1.NpcMon += 4;
                    effectStr = "RestAndHelp:" + a1.Id + "->" + a2.Id;
                    summaryStr = a1.DisplayName + " beristirahat sejenak sambil membantu " + a2.DisplayName;
                }
                else
                {
                    actionCode = "npc_daily_chat";
                    qty = 1;
                    a1.NeedTalk = Math.Max(2, a1.NeedTalk - 3);
                    effectStr = "DailyChat:" + a1.Id + "<->" + a2.Id;
                    summaryStr = a1.DisplayName + " berbincang akrab dengan " + a2.DisplayName + " (" + bestRel.RelationType + ")";
                }

                a1.RecordActionForEntropy(actionCode);
                a2.RecordActionForEntropy(actionCode);

                WorldEvent iEvt = SimPerceptionSystem.EmitWorldEvent(
                    bus, tick, day, hour, segment, weather,
                    "EntityInteraction", "EntityInteraction",
                    a1.Id, a2.Id, pId, a1.Id,
                    actionCode, qty, motiveCode, vis, noise, true, false,
                    effectStr, summaryStr,
                    world, guard
                );
                iEvt.WhyNeedAndRelationTag = "Drive=" + bestDrive + ";Rel=" + bestRel.RelationType + ";Trigger=" + triggerUsed;
                iEvt.IsUnpredictableFromSchedule = unpredictable;
                bus.WhyLinkedInteractionEventsCount += 1;
                if (unpredictable)
                {
                    bus.UnpredictableCausalEventsCount += 1;
                }
            }
        }

        public static WorldEvent ExecuteSoumaTrade(
            SimEventBus bus,
            ulong seed,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (world.Data.Wares.Count == 0 || world.CarryUnits <= 0)
            {
                return new WorldEvent();
            }

            bus.StepCostSocialEconomyOps += 2;
            int wIdx = world.ActiveWareIdx;
            SimWareDef curWare = world.Data.Wares[wIdx];
            int pIdx = world.SoumaCurrentPlaceIdx;
            string pId = world.Places[pIdx].Id;

            if (curWare.RequiresZaLicense && !world.HasZaLicense && pId == "place_pasar")
            {
                int inspectorIdx = world.FindNpcIndexByDuty("inspect_market_license");
                if (inspectorIdx >= 0)
                {
                    world.AddSuspicionReason(inspectorIdx, 12, "Berdagang " + curWare.CategoryName + " di Pasar tanpa izin serikat Za resmi");
                }
            }

            SimRandom trng = new SimRandom(seed, "trade_d" + day.ToString() + "_h" + hour.ToString() + "_w" + wIdx.ToString());
            int unitsSold = Math.Min(world.CarryUnits, 2);
            double priceMult = (curWare.Id == "ware_teh_kue_gula") ? world.MarketPriceMultiplier : 1.0;
            int grossGain = (int)((double)(unitsSold * (18 + (curWare.BaseCapitalMon / 5) + trng.NextInt(0, 6))) * priceMult);
            if (!world.HasZaLicense && pId == "place_pasar")
            {
                grossGain = (grossGain * 75) / 100;
            }

            world.CarryUnits -= unitsSold;
            world.SoumaMon += grossGain;
            world.TotalRevenueMon += grossGain;
            world.WareCategoryTradesCount[wIdx] += 1;
            world.TotalTradesExecuted += 1;

            if (world.HeartWarmCold < 22 && world.RoutineTradeHeartGainsThisWeek < 2)
            {
                world.HeartWarmCold += 1;
                world.RoutineTradeHeartGainsThisWeek += 1;
            }

            world.AspirationProgressScore = Math.Min(100, world.AspirationProgressScore + 2);
            world.UpdateMonBounds();

            bool grantedAccess = false;
            if (world.Places[pIdx].IsRestrictedZone && !world.GrantedRestrictedAccessToday)
            {
                for (int a = 0; a < curWare.AccessPlaces.Count; a++)
                {
                    if (curWare.AccessPlaces[a] == pId)
                    {
                        world.GrantedRestrictedAccessToday = true;
                        world.GrantedAccessPlaceId = pId;
                        grantedAccess = true;
                        world.TradesYieldingAccessCount += 1;
                        break;
                    }
                }
            }

            bool heardKabar = false;
            int minMem = bus.Memories.Count > 90 ? bus.Memories.Count - 90 : 0;
            for (int m = bus.Memories.Count - 1; m >= minMem; m--)
            {
                MemoryEntry mem = bus.Memories[m];
                if (!mem.Tellable || mem.Claim.SubjectId == "souma" || mem.IsRoutineMemory) continue;
                WorldEvent srcEvt = bus.FindEventById(mem.SourceEventId);
                if (srcEvt.IsFlavorOnly) continue;

                int ownerIdx = world.FindNpcIndexById(mem.OwnerNpcId);
                if (ownerIdx >= 0 && !world.Agents[ownerIdx].IsDead && !world.Agents[ownerIdx].IsSleeping && world.Agents[ownerIdx].CurrentPlaceIdx == pIdx)
                {
                    SimMemoryStore.RegisterSoumaKabarObservation(bus, mem.SourceEventId, mem.RootWitnessNpcId, "Heard", mem.Claim, day, hour, world);
                    heardKabar = true;
                    world.TradesYieldingKabarCount += 1;
                    break;
                }
            }

            if (grantedAccess || heardKabar)
            {
                world.TradesYieldingKabarOrAccess += 1;
                world.WareCategoryYieldsCount[wIdx] += 1;
            }

            WorldEvent tEvt = SimPerceptionSystem.EmitWorldEvent(
                bus,
                tick, day, hour, segment, weather,
                "SoumaTrade", "SoumaAction",
                "souma", "", pId, "souma",
                "trade_wares", unitsSold, "motive_none", 1.0, 16.0, false, false,
                "SoumaMon:+" + grossGain.ToString() + ";CarryUnits:-" + unitsSold.ToString() + ";Yielded=" + ((grantedAccess || heardKabar) ? "true" : "false"),
                "Traded " + curWare.Id + " at " + pId + " for +" + grossGain.ToString() + " mon",
                world, guard
            );
            tEvt.IsUnpredictableFromSchedule = (grantedAccess || heardKabar);
            if (tEvt.IsUnpredictableFromSchedule) bus.UnpredictableCausalEventsCount += 1;

            if (day == 1 && world.TotalTradesExecuted == 1)
            {
                SimNisshiCurator.RecordNisshiCandidate(
                    bus, day, "Dagang", tEvt.Id,
                    "Hari 1 — Membuka kotak pikul pertama (" + curWare.CategoryName + ") di " + world.Places[pIdx].Name + " dan mengantongi +" + grossGain.ToString() + " mon.",
                    0.85, 0.72
                );
            }
            return tEvt;
        }

        public static WorldEvent ExecuteSoumaPayRentToOhana(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            int rent = world.Data.ClockConfig.WeeklyRentMon;
            string pId = "place_nagaya";
            int landladyIdx = world.FindNpcIndexByDuty("collect_nagaya_rent");
            string landladyId = landladyIdx >= 0 ? world.Agents[landladyIdx].Id : (world.Agents.Count > 0 ? world.Agents[0].Id : "npc_landlady");
            string landladyName = landladyIdx >= 0 ? world.Agents[landladyIdx].DisplayName : "Pemilik Nagaya";

            if (world.SoumaMon >= rent)
            {
                world.SoumaMon -= rent;
                world.TotalExpensesMon += rent;
                world.TotalRentPaidToOhanaMon += rent;
                if (world.HeartWarmCold < 28)
                {
                    world.HeartWarmCold = Math.Min(28, world.HeartWarmCold + 2);
                }
                world.UpdateMonBounds();

                if (landladyIdx >= 0)
                {
                    world.Agents[landladyIdx].AttitudeTowardSouma = "Ramah";
                    world.AddSuspicionReason(landladyIdx, -10, "");
                }

                SimNisshiCurator.RecordKisahEventWithWhy(
                    bus, day, hour, "SewaNagayaOhana", pId,
                    "Soma melunasi uang sewa kamar mingguan sebesar " + rent.ToString() + " mon kepada pemilik Nagaya " + landladyName + ".",
                    "", landladyId, "Jatuh tempo sewa mingguan Nagaya (350 mon)."
                );
                WorldEvent rEvt = SimPerceptionSystem.EmitWorldEvent(
                    bus,
                    tick, day, hour, segment, weather,
                    "PayNagayaRent", "SoumaAction",
                    "souma", landladyId, pId, landladyId,
                    "collect_nagaya_rent", rent, "motive_debt", 0.90, 14.0, true, false,
                    "SoumaPaidRentToLandlady:" + rent.ToString() + "mon",
                    "Soma paid weekly Nagaya rent to " + landladyName,
                    world, guard
                );
                if (day == 7 || day == 28)
                {
                    SimNisshiCurator.RecordNisshiCandidate(
                        bus, day, "Dagang", rEvt.Id,
                        "Hari " + day.ToString() + " — Melunasi uang sewa kamar Nagaya sebesar " + rent.ToString() + " mon tepat waktu kepada " + landladyName + "; pemilik rumah sewa itu mulai menaruh percaya.",
                        0.80, 0.70
                    );
                }
                return rEvt;
            }
            else
            {
                world.UnpaidRentDebtMon += rent;
                world.UnpaidRentWeeks += 1;
                if (landladyIdx >= 0)
                {
                    world.Agents[landladyIdx].AttitudeTowardSouma = "Kesal_Tunggakan";
                    world.AddSuspicionReason(landladyIdx, 18, "Menunggak pembayaran sewa kamar mingguan Nagaya (" + world.UnpaidRentDebtMon.ToString() + " mon)");
                }
                return new WorldEvent();
            }
        }

        public static WorldEvent ExecuteSoumaDeadDropReport(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            int courierIdx = world.FindNpcIndexByDuty("group_courier");
            string courierId = courierIdx >= 0 ? world.Agents[courierIdx].Id : (world.Data.GroupOrders.Count > 0 ? world.Data.GroupOrders[0].ContactNpcId : "npc_courier");
            string courierName = courierIdx >= 0 ? world.Agents[courierIdx].DisplayName : "Kurir Kelompok";
            string dropPlaceId = world.Data.GroupOrders.Count > 0 ? world.Data.GroupOrders[0].DeadDropPlaceId : "place_titik_serah_hutan";

            // E2.3: Jalur Pemulihan Kepercayaan Kelompok (KontakTerputus -> UjianKesetiaan -> DipercayaKembali)
            if (world.GroupContactState == "KontakTerputus")
            {
                world.GroupContactState = "UjianKesetiaan";
                world.AvailableRecoveryAction = "Selesaikan Ujian Kesetiaan: serahkan 1 Kabar bernilai (atau selesaikan tugas berisiko) di Titik Serah Hutan untuk kembali dipercaya.";
                WorldEvent trialEvt = SimPerceptionSystem.EmitWorldEvent(
                    bus, tick, day, hour, segment, weather,
                    "GroupLoyaltyTrial", "SoumaAction",
                    "souma", courierId, dropPlaceId, "souma",
                    "group_loyalty_trial_accepted", 1, "motive_spy", 0.50, 12.0, true, false,
                    "GroupContactState=UjianKesetiaan;GroupTrust=" + world.GroupTrust.ToString(),
                    "Soma menerima Ujian Kesetiaan dari kurir " + courierName,
                    world, guard
                );
                trialEvt.IsUnpredictableFromSchedule = true;
                bus.UnpredictableCausalEventsCount += 1;
                SimNisshiCurator.RecordKisahEventWithWhy(
                    bus, day, hour, "UjianKesetiaanKelompok", dropPlaceId,
                    "Soma mendatangi Pohon Aras Tua saat kontak terputus dan menerima Ujian Kesetiaan dari " + courierName + " untuk memulihkan jalur kelompok.",
                    trialEvt.Id, courierId, "Pemulihan dari status KontakTerputus lewat 1 Kabar bernilai."
                );

                // Jika Soma sudah memegang minimal 1 Kabar (atau telah menyelesaikan Gig), langsung tuntaskan pemulihan pada kunjungan berikutnya atau saat Kabar diserahkan
                if (bus.KabarUpgradedCount >= 1 || bus.Kabars.Count >= 1 || world.CompletedGigIds.Count >= 1)
                {
                    world.GroupContactState = "DipercayaKembali";
                    world.GroupSupplyLineCut = false;
                    world.ReTrustedWithCautionFlag = true;
                    world.LoyaltyTrialCompletedCount += 1;
                    world.GroupTrust = Math.Max(52, world.GroupTrust + 38);
                    world.SoumaMon += 90;
                    world.TotalRevenueMon += 90;
                    world.UpdateMonBounds();
                    world.AvailableRecoveryAction = "Status: DipercayaKembali (dengan tanda hati-hati). Pertahankan pengiriman Kabar bernilai.";

                    WorldEvent restEvt = SimPerceptionSystem.EmitWorldEvent(
                        bus, tick + 1, day, hour, segment, weather,
                        "GroupTrustRestored", "SoumaAction",
                        "souma", courierId, dropPlaceId, "souma",
                        "group_trust_restored_with_caution", 1, "motive_spy", 0.50, 12.0, true, false,
                        "GroupContactState=DipercayaKembali;ReTrustedWithCaution=true;GroupTrust=" + world.GroupTrust.ToString(),
                        "Kepercayaan Kelompok dipulihkan dengan tanda hati-hati lewat 1 Kabar bernilai",
                        world, guard
                    );
                    restEvt.IsUnpredictableFromSchedule = true;
                    bus.UnpredictableCausalEventsCount += 1;
                    SimNisshiCurator.RecordNisshiCandidate(
                        bus, day, "Kabar", restEvt.Id,
                        "Hari " + day.ToString() + " — Menempuh Ujian Kesetiaan di Pohon Aras Tua dengan menyerahkan satu Kabar bernilai kepada " + courierName + "; jalur kelompok pulih menjadi Dipercaya Kembali (dengan tanda hati-hati, Kepercayaan " + world.GroupTrust.ToString() + "/100). Kau membeli nyawa samaranmu dengan rahasia orang lain.",
                        0.96, 0.90
                    );
                    return restEvt;
                }
                return trialEvt;
            }
            else if (world.GroupContactState == "UjianKesetiaan")
            {
                world.GroupContactState = "DipercayaKembali";
                world.GroupSupplyLineCut = false;
                world.ReTrustedWithCautionFlag = true;
                world.LoyaltyTrialCompletedCount += 1;
                world.GroupTrust = Math.Max(52, world.GroupTrust + 38);
                world.SoumaMon += 90;
                world.TotalRevenueMon += 90;
                world.UpdateMonBounds();
                world.AvailableRecoveryAction = "Status: DipercayaKembali (dengan tanda hati-hati).";

                WorldEvent restEvt = SimPerceptionSystem.EmitWorldEvent(
                    bus, tick, day, hour, segment, weather,
                    "GroupTrustRestored", "SoumaAction",
                    "souma", courierId, dropPlaceId, "souma",
                    "group_trust_restored_with_caution", 1, "motive_spy", 0.50, 12.0, true, false,
                    "GroupContactState=DipercayaKembali;ReTrustedWithCaution=true;GroupTrust=" + world.GroupTrust.ToString(),
                    "Kepercayaan Kelompok dipulihkan dengan tanda hati-hati",
                    world, guard
                );
                restEvt.IsUnpredictableFromSchedule = true;
                bus.UnpredictableCausalEventsCount += 1;
                return restEvt;
            }

            int weekNum = ((day - 1) / 7) + 1;
            for (int o = 0; o < world.Data.GroupOrders.Count; o++)
            {
                SimGroupOrderDef ord = world.Data.GroupOrders[o];
                if (ord.WeekNumber == weekNum)
                {
                    bool alreadyDone = false;
                    for (int c = 0; c < world.CompletedGroupOrderIds.Count; c++)
                    {
                        if (world.CompletedGroupOrderIds[c] == ord.Id) { alreadyDone = true; break; }
                    }
                    if (!alreadyDone && (bus.KabarUpgradedCount >= 1 || bus.Kabars.Count >= 1))
                    {
                        world.CompletedGroupOrderIds.Add(ord.Id);
                        world.DeadDropReportsDelivered += 1;
                        world.GroupTrust = Math.Min(100, world.GroupTrust + ord.TrustGainOnSuccess);
                        world.SoumaMon += ord.RewardCapitalMon;
                        world.TotalRevenueMon += ord.RewardCapitalMon;
                        world.UpdateMonBounds();

                        WorldEvent dEvt = SimPerceptionSystem.EmitWorldEvent(
                            bus,
                            tick, day, hour, segment, weather,
                            "DeadDropReport", "SoumaAction",
                            "souma", ord.ContactNpcId, ord.DeadDropPlaceId, "souma",
                            "trade_wares", 1, "motive_none", 0.40, 10.0, false, false,
                            "DeadDropDelivered:" + ord.Id + ";GroupTrust=" + world.GroupTrust.ToString() + ";Reward=+" + ord.RewardCapitalMon.ToString(),
                            "Delivered Group Order report " + ord.Id,
                            world, guard
                        );
                        dEvt.IsUnpredictableFromSchedule = true;
                        bus.UnpredictableCausalEventsCount += 1;
                        SimNisshiCurator.RecordKisahEventWithWhy(
                            bus, day, hour, "PesananKelompokSelesai", ord.DeadDropPlaceId,
                            "Soma menyerahkan laporan Kabar terverifikasi untuk '" + ord.Title + "' di titik serah kurir " + courierName + " (+Kepercayaan Kelompok, +" + ord.RewardCapitalMon.ToString() + " mon modal).",
                            dEvt.Id, ord.ContactNpcId, "Kabar telah diverifikasi dari >= 2 saksi independen di Papan Tinta."
                        );
                        SimNisshiCurator.RecordNisshiCandidate(
                            bus, day, "Kabar", dEvt.Id,
                            "Hari " + day.ToString() + " — Menyerahkan gulungan Papan Tinta '" + ord.Title + "' di Pohon Aras Tua kepada kurir " + courierName + " (Kepercayaan Kelompok naik ke " + world.GroupTrust.ToString() + "/100, modal +" + ord.RewardCapitalMon.ToString() + " mon). Kau mengirim kabar yang benar; seseorang di lembah ini akan menanggung akibatnya.",
                            0.90, 0.82
                        );
                        return dEvt;
                    }
                }
            }
            return new WorldEvent();
        }
    }
}
