// KAGE-ANA v3.0 Gelombang D (Butir 1, 2, & 8) — Modul 4: Penyimpanan Ingatan, Peluruhan Berbasis Kebermaknaan, & Rantai Sebab-Akibat
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimMemoryStore
    {
        public static bool HasNpcAlreadyWitnessedEvent(SimEventBus bus, string npcId, string eventId)
        {
            int minIdx = bus.Memories.Count > 45 ? bus.Memories.Count - 45 : 0;
            for (int i = bus.Memories.Count - 1; i >= minIdx; i--)
            {
                if (bus.Memories[i].SourceEventId == eventId && bus.Memories[i].OwnerNpcId == npcId)
                {
                    return true;
                }
            }
            return false;
        }

        public static bool HasNpcAlreadyLearnedRootEvent(SimEventBus bus, string npcId, string rootEventId)
        {
            int minIdx = bus.Memories.Count > 90 ? bus.Memories.Count - 90 : 0;
            for (int i = bus.Memories.Count - 1; i >= minIdx; i--)
            {
                if (bus.Memories[i].SourceEventId == rootEventId && bus.Memories[i].OwnerNpcId == npcId)
                {
                    return true;
                }
            }
            return false;
        }

        public static double ComputeMemorySalienceForListener(
            SimEventBus bus,
            WorldEvent evt,
            NpcRuntimeState listener,
            SimPlaceGraphSystem world)
        {
            SimSalienceProfileDef prof = bus.FindSalienceProfile(evt.ActionCode);
            SimSalienceConfig cfg = bus.Data.SalienceConfig;

            double proximity = 0.25;
            int evtPlaceIdx = world.FindPlaceIndexById(evt.PlaceId);
            if (evtPlaceIdx == listener.HomePlaceIdx) proximity += 0.45;
            if (evt.SubjectId == listener.Id || evt.SecondaryEntityId == listener.Id) proximity = 1.0;
            else if (evt.SubjectId == "souma" && listener.FamiliarityWithSouma >= 15) proximity += 0.30;

            if (proximity > 1.0) proximity = 1.0;

            double novelty = prof.Novelty;
            if (prof.IsRoutine)
            {
                int recentSameAction = 0;
                int minM = bus.Memories.Count > 60 ? bus.Memories.Count - 60 : 0;
                for (int m = bus.Memories.Count - 1; m >= minM; m--)
                {
                    if (bus.Memories[m].OwnerNpcId == listener.Id && bus.Memories[m].Claim.ActionCode == evt.ActionCode)
                    {
                        recentSameAction += 1;
                        if (recentSameAction >= 2) break;
                    }
                }
                if (recentSameAction >= 1) novelty = Math.Max(0.02, novelty - 0.10);
            }

            double weighted = (novelty * cfg.NoveltyWeight)
                + (prof.ExpectationViolation * cfg.ExpectationViolationWeight)
                + (prof.Stakes * cfg.StakesWeight)
                + (prof.Secrecy * cfg.SecrecyWeight)
                + (proximity * cfg.ListenerProximityWeight);

            double sal = (prof.BaseSalience * 0.50) + (weighted * 0.50);
            if (prof.IsRoutine && sal > cfg.RoutineMaxSalience)
            {
                sal = cfg.RoutineMaxSalience;
            }
            else if (!prof.IsRoutine && sal < cfg.SalientMinSalience)
            {
                sal = cfg.SalientMinSalience;
            }
            if (sal > 1.0) sal = 1.0;
            return sal;
        }

        public static void DecayMemoriesAtDayStart(SimEventBus bus, int currentDay)
        {
            SimSalienceConfig cfg = bus.Data.SalienceConfig;
            int minIdx = bus.Memories.Count > 240 ? bus.Memories.Count - 240 : 0;
            for (int i = minIdx; i < bus.Memories.Count; i++)
            {
                MemoryEntry mem = bus.Memories[i];
                if (!mem.Tellable) continue;
                int ageDays = currentDay - mem.Day;
                if (ageDays <= 0) continue;

                if (mem.IsRoutineMemory || mem.SalienceScore <= cfg.RoutineMaxSalience)
                {
                    mem.Reliability -= cfg.RoutineDecayPerDay;
                    if (ageDays >= 1 || mem.Reliability < 0.35)
                    {
                        mem.Tellable = false;
                    }
                }
                else if (mem.SalienceScore >= cfg.HighSalienceThreshold)
                {
                    mem.Reliability = Math.Max(0.35, mem.Reliability - cfg.HighSalienceDecayPerDay);
                    if (ageDays > 10) mem.Tellable = false;
                }
                else
                {
                    mem.Reliability = Math.Max(0.30, mem.Reliability - cfg.SalientDecayPerDay);
                    if (ageDays > 5) mem.Tellable = false;
                }
            }
        }

        public static void TryRecordCausalChain(
            SimEventBus bus,
            string policyName,
            int day,
            WorldEvent rootEvt,
            string witnessNpcId,
            string witnessMemId,
            string speakerNpcId,
            string listenerNpcId,
            string rumorMemId,
            string opsUsed,
            string consequenceType,
            string consequenceSummary)
        {
            TryRecordMultiOrderCausalChain(
                bus, policyName, day, rootEvt, witnessNpcId, witnessMemId,
                speakerNpcId, listenerNpcId, rumorMemId, opsUsed,
                consequenceType, consequenceSummary, "", "", false
            );
        }

        public static void TryRecordMultiOrderCausalChain(
            SimEventBus bus,
            string policyName,
            int day,
            WorldEvent rootEvt,
            string witnessNpcId,
            string witnessMemId,
            string speakerNpcId,
            string listenerNpcId,
            string rumorMemId,
            string opsUsed,
            string consequenceType,
            string consequenceSummary,
            string secondOrderEventId,
            string thirdOrderEventId,
            bool isMisunderstanding)
        {
            if (rootEvt.Id.Length == 0) return;

            List<string> uniqueNpcs = new List<string>();
            if (rootEvt.SubjectId.Length > 0 && rootEvt.SubjectId != "souma") uniqueNpcs.Add(rootEvt.SubjectId);
            if (witnessNpcId.Length > 0)
            {
                bool s = false;
                for (int i = 0; i < uniqueNpcs.Count; i++) if (uniqueNpcs[i] == witnessNpcId) s = true;
                if (!s) uniqueNpcs.Add(witnessNpcId);
            }
            if (speakerNpcId.Length > 0)
            {
                bool s = false;
                for (int i = 0; i < uniqueNpcs.Count; i++) if (uniqueNpcs[i] == speakerNpcId) s = true;
                if (!s) uniqueNpcs.Add(speakerNpcId);
            }
            if (listenerNpcId.Length > 0)
            {
                bool s = false;
                for (int i = 0; i < uniqueNpcs.Count; i++) if (uniqueNpcs[i] == listenerNpcId) s = true;
                if (!s) uniqueNpcs.Add(listenerNpcId);
            }

            if (uniqueNpcs.Count < 3) return;

            for (int c = 0; c < bus.CausalChains.Count; c++)
            {
                if (bus.CausalChains[c].RootEventId == rootEvt.Id && bus.CausalChains[c].ConsequenceType == consequenceType)
                {
                    return;
                }
            }

            CausalChainRecord rec = new CausalChainRecord();
            int nextChain = bus.CausalChains.Count + 1;
            rec.ChainId = "chain_" + nextChain.ToString();
            rec.PolicyName = policyName;
            rec.DayCompleted = day;
            rec.RootEventId = rootEvt.Id;
            rec.RootEventSourceCategory = rootEvt.EventSourceCategory;
            rec.RootActionCode = rootEvt.ActionCode;
            rec.PlaceId = rootEvt.PlaceId;
            rec.SubjectNpcId = rootEvt.SubjectId;
            rec.WitnessNpcId = witnessNpcId;
            rec.WitnessMemoryId = witnessMemId;
            rec.RumorSpeakerNpcId = speakerNpcId;
            rec.RumorListenerNpcId = listenerNpcId;
            rec.RumorMemoryId = rumorMemId;
            rec.AppliedOperators = opsUsed;
            rec.ConsequenceType = consequenceType;
            rec.ConsequenceSummary = consequenceSummary;
            rec.SecondOrderEventId = secondOrderEventId;
            rec.ThirdOrderEventId = thirdOrderEventId;
            rec.IsMisunderstanding = isMisunderstanding;
            rec.ChainLength = thirdOrderEventId.Length > 0 ? 6 : (secondOrderEventId.Length > 0 ? 5 : 4);
            rec.DistinctNpcCount = uniqueNpcs.Count;

            string orderTrace = "";
            if (secondOrderEventId.Length > 0)
            {
                orderTrace = " -> Orde2:" + secondOrderEventId;
                if (thirdOrderEventId.Length > 0)
                {
                    orderTrace += " -> Orde3:" + thirdOrderEventId;
                }
            }

            rec.FullTraceText = rootEvt.Id + " (" + rootEvt.EventSourceCategory + ":" + rootEvt.ActionCode + " @" + rootEvt.PlaceId + ")"
                + " -> Saksi:" + witnessNpcId + " (" + witnessMemId + ")"
                + " -> Rumor:" + speakerNpcId + "->" + listenerNpcId + " (" + rumorMemId + ", Op=" + opsUsed + ")"
                + orderTrace
                + " -> Akibat[" + consequenceType + (isMisunderstanding ? "/SalahPaham" : "") + "]: " + consequenceSummary;
            bus.CausalChains.Add(rec);

            SimNisshiCurator.RecordKisahEventWithWhy(
                bus,
                day,
                18,
                "AnekdotRantaiSebabAkibat",
                rootEvt.PlaceId,
                "ANEKDOT [" + rec.ChainId + "]: " + consequenceSummary,
                rootEvt.Id,
                witnessNpcId,
                rec.FullTraceText
            );
            if (secondOrderEventId.Length > 0 || consequenceType == "KabarVerified" || consequenceType == "SuspicionSpike")
            {
                SimNisshiCurator.RecordNisshiCandidate(
                    bus,
                    day,
                    secondOrderEventId.Length > 0 ? "AgensiWarga" : "RantaiAnekdot",
                    secondOrderEventId.Length > 0 ? secondOrderEventId : rootEvt.Id,
                    "Hari " + day.ToString() + " — " + consequenceSummary + " (Jejak: " + rootEvt.Id + (secondOrderEventId.Length > 0 ? " -> " + secondOrderEventId : "") + (thirdOrderEventId.Length > 0 ? " -> " + thirdOrderEventId : "") + ").",
                    isMisunderstanding ? 0.94 : 0.84,
                    0.86
                );
            }
        }

        public static void RegisterSoumaKabarObservation(
            SimEventBus bus,
            string sourceEventId,
            string rootWitnessId,
            string sourceTypeLabel,
            StructuredClaim claim,
            int day,
            int hour,
            SimPlaceGraphSystem world)
        {
            WorldEvent srcEvt = bus.FindEventById(sourceEventId);
            if (srcEvt.IsFlavorOnly) return;

            if (world.ActiveSoumaPolicy == "Idle" && claim.PlaceId != "place_nagaya")
            {
                return;
            }

            string topicKey = claim.ActionCode;
            int foundIdx = -1;
            for (int i = 0; i < bus.Kabars.Count; i++)
            {
                if (bus.Kabars[i].TopicKey == topicKey)
                {
                    foundIdx = i;
                    break;
                }
            }

            if (foundIdx < 0)
            {
                DynamicKabarRecord k = new DynamicKabarRecord();
                int nextK = bus.Kabars.Count + 1;
                k.Id = "kabar_dinamis_" + nextK.ToString() + "_" + claim.ActionCode;
                k.TopicKey = topicKey;
                k.SubjectId = claim.SubjectId;
                k.PlaceId = claim.PlaceId;
                k.ActionCode = claim.ActionCode;
                k.SourceTypeLabel = sourceTypeLabel;
                k.InitialReliability = 0.50;
                k.CurrentReliability = 0.50;
                k.DiscoveredDay = day;
                k.IndependentRootWitnesses.Add(rootWitnessId);
                k.SupportingEventIds.Add(sourceEventId);
                k.FormattedClaimId = bus.FormatClaimFromTemplate(claim, world, false);
                k.StatusLabel = "Lemah (1 Sumber: " + rootWitnessId + ")";
                bus.Kabars.Add(k);

                SimNisshiCurator.RecordKisahEventWithWhy(
                    bus,
                    day,
                    hour,
                    "KabarBaru",
                    claim.PlaceId,
                    "Soma mencatat kandidat Kabar '" + k.Id + "' (Keandalan 0.50 - 1 Sumber: " + rootWitnessId + "): " + k.FormattedClaimId,
                    sourceEventId,
                    rootWitnessId,
                    "Sumber: " + rootWitnessId + " menyaksikan/menceritakan kejadian " + sourceEventId + " di " + claim.PlaceId
                );
                if (!srcEvt.IsRoutineEvent)
                {
                    SimNisshiCurator.RecordNisshiCandidate(
                        bus,
                        day,
                        "Kabar",
                        sourceEventId,
                        "Hari " + day.ToString() + " — Mencatat Kabar awal (" + k.Id + ") dari kesaksian " + rootWitnessId + ": " + k.FormattedClaimId,
                        0.72,
                        srcEvt.SalienceScore
                    );
                }
            }
            else
            {
                DynamicKabarRecord k = bus.Kabars[foundIdx];
                bool alreadyHasWitness = false;
                for (int w = 0; w < k.IndependentRootWitnesses.Count; w++)
                {
                    if (k.IndependentRootWitnesses[w] == rootWitnessId)
                    {
                        alreadyHasWitness = true;
                        break;
                    }
                }

                if (!alreadyHasWitness)
                {
                    int prevCount = k.IndependentRootWitnesses.Count;
                    k.IndependentRootWitnesses.Add(rootWitnessId);
                    k.SupportingEventIds.Add(sourceEventId);

                    if (prevCount == 1 && k.IndependentRootWitnesses.Count >= 2)
                    {
                        k.CurrentReliability = 0.90;
                        k.UpgradedDay = day;
                        k.UpgradedHour = hour;
                        int wCnt = k.IndependentRootWitnesses.Count;
                        k.StatusLabel = "Kuat (Terverifikasi " + wCnt.ToString() + " Sumber Independen: "
                            + k.IndependentRootWitnesses[0] + " & " + k.IndependentRootWitnesses[1] + ")";
                        bus.KabarUpgradedCount += 1;
                        world.AspirationProgressScore = Math.Min(100, world.AspirationProgressScore + 12);

                        SimNisshiCurator.RecordKisahEventWithWhy(
                            bus,
                            day,
                            hour,
                            "VerifikasiKabar2Sumber",
                            claim.PlaceId,
                            "VERIFIKASI 2 SUMBER INDEPENDEN: Kabar '" + k.Id + "' naik keandalannya dari 0.50 menjadi 0.90 (Kuat) setelah saksi independen kedua (" + rootWitnessId + ") terkonfirmasi!",
                            sourceEventId,
                            rootWitnessId,
                            "Saksi 1: " + k.IndependentRootWitnesses[0] + " + Saksi 2: " + k.IndependentRootWitnesses[1] + " (Kejadian " + sourceEventId + ")"
                        );
                        SimNisshiCurator.RecordNisshiCandidate(
                            bus,
                            day,
                            "Kabar",
                            sourceEventId,
                            "Hari " + day.ToString() + " — Kabar '" + k.Id + "' terverifikasi Kuat (0.90) di Papan Tinta lewat kesaksian silang " + k.IndependentRootWitnesses[0] + " dan " + k.IndependentRootWitnesses[1] + ".",
                            0.86,
                            0.82
                        );

                        TryRecordCausalChain(
                            bus,
                            world.ActiveSoumaPolicy,
                            day,
                            srcEvt,
                            k.IndependentRootWitnesses[0],
                            "mem_root_1",
                            k.IndependentRootWitnesses[1],
                            "souma",
                            "mem_root_2",
                            "CrossVerification",
                            "KabarVerified",
                            "Kabar '" + k.Id + "' diverifikasi kuat (0.90) oleh Soma dari 2 sumber independen"
                        );
                    }
                }
            }
        }
    }
}
