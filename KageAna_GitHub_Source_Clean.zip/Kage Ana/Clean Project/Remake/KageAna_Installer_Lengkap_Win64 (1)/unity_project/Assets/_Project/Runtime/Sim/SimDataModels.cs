// KAGE-ANA v3.0 — Plain Data Models & Dynamic Simulation DTOs (A2, A3, Gelombang B L4-L6, & Gelombang C L7-L8)
// Pure C# in Runtime/Sim (Decision C-07). Populated via System.Text.Json in Adapter/SimJsonDataLoader.cs.
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public sealed class SimWeatherConfig
    {
        public int TransitionGameSeconds;
        public int[] WeightsFlat;

        public SimWeatherConfig()
        {
            TransitionGameSeconds = 60;
            WeightsFlat = new int[28];
            ResetToCanonicalDefaults();
        }

        public void ResetToCanonicalDefaults()
        {
            TransitionGameSeconds = 60;
            // Spring: Clear=35, Cloudy=20, Fog=20, Rain=18, Storm=2, Snow=0, Windy=5
            SetWeight(0, 0, 35); SetWeight(0, 1, 20); SetWeight(0, 2, 20); SetWeight(0, 3, 18); SetWeight(0, 4, 2); SetWeight(0, 5, 0); SetWeight(0, 6, 5);
            // Summer: Clear=40, Cloudy=15, Fog=5, Rain=20, Storm=15, Snow=0, Windy=5
            SetWeight(1, 0, 40); SetWeight(1, 1, 15); SetWeight(1, 2, 5); SetWeight(1, 3, 20); SetWeight(1, 4, 15); SetWeight(1, 5, 0); SetWeight(1, 6, 5);
            // Autumn: Clear=30, Cloudy=22, Fog=15, Rain=13, Storm=5, Snow=0, Windy=15
            SetWeight(2, 0, 30); SetWeight(2, 1, 22); SetWeight(2, 2, 15); SetWeight(2, 3, 13); SetWeight(2, 4, 5); SetWeight(2, 5, 0); SetWeight(2, 6, 15);
            // Winter: Clear=20, Cloudy=25, Fog=10, Rain=5, Storm=5, Snow=30, Windy=5
            SetWeight(3, 0, 20); SetWeight(3, 1, 25); SetWeight(3, 2, 10); SetWeight(3, 3, 5); SetWeight(3, 4, 5); SetWeight(3, 5, 30); SetWeight(3, 6, 5);
        }

        public static int SeasonToIndex(string season)
        {
            if (season == "Spring") return 0;
            if (season == "Summer") return 1;
            if (season == "Autumn") return 2;
            return 3;
        }

        public void SetWeight(int seasonIdx, int weatherIdx, int weight)
        {
            WeightsFlat[seasonIdx * 7 + weatherIdx] = weight;
        }

        public int GetWeight(string season, int weatherIdx)
        {
            int sIdx = SeasonToIndex(season);
            return WeightsFlat[sIdx * 7 + weatherIdx];
        }
    }

    public sealed class SimClockConfig
    {
        public int TickHz;
        public int RealSecondsPerGameHour;
        public int DaysPerSeason;
        public int SeasonsPerYear;
        public int DaysPerYear;
        public int WeeklyRentMon;
        public int AutumnTaxMon;

        public SimClockConfig()
        {
            TickHz = 10;
            RealSecondsPerGameHour = 45;
            DaysPerSeason = 7;
            SeasonsPerYear = 4;
            DaysPerYear = 28;
            WeeklyRentMon = 350;
            AutumnTaxMon = 600;
        }
    }

    public sealed class SimNeighborEdge
    {
        public string ToPlaceId;
        public int TravelMinutes;
        public string RouteType;

        public SimNeighborEdge()
        {
            ToPlaceId = "";
            TravelMinutes = 10;
            RouteType = "jalan_utama";
        }
    }

    public sealed class SimPlaceDef
    {
        public string Id;
        public string Name;
        public string District;
        public string Type;
        public int MapX;
        public int MapY;
        public double WitnessDensity;
        public string LightProfile;
        public bool IsIndoorShelter;
        public bool IsRestrictedZone;
        public List<SimNeighborEdge> Neighbors;

        public SimPlaceDef()
        {
            Id = "";
            Name = "";
            District = "D1";
            Type = "outdoor";
            MapX = 0;
            MapY = 0;
            WitnessDensity = 0.5;
            LightProfile = "DayBright_NightLantern";
            IsIndoorShelter = false;
            IsRestrictedZone = false;
            Neighbors = new List<SimNeighborEdge>();
        }
    }

    public sealed class SimScheduleBlockDef
    {
        public int FromMinutes;
        public int ToMinutes;
        public string Activity;
        public string PlaceId;
        public bool Interruptible;

        public SimScheduleBlockDef()
        {
            FromMinutes = 0;
            ToMinutes = 60;
            Activity = "Istirahat";
            PlaceId = "place_nagaya";
            Interruptible = true;
        }
    }

    // Gelombang E (E2.1 & E2.2): Data-Driven Social Drives & Relationship Definitions
    public sealed class SimSocialDrivesDef
    {
        public int PerluBayar;
        public int PerluBicara;
        public int PerluDagang;
        public int PerluIstirahat;
        public int RasaPenasaran;
        public int Dendam;
        public int KasihSayang;
        public int TugasJadwal;

        public SimSocialDrivesDef()
        {
            PerluBayar = 5;
            PerluBicara = 5;
            PerluDagang = 5;
            PerluIstirahat = 5;
            RasaPenasaran = 5;
            Dendam = 2;
            KasihSayang = 5;
            TugasJadwal = 6;
        }
    }

    public sealed class SimNpcRelationDef
    {
        public string TargetId;
        public string RelationType; // kerabat, utang, saingan, kekasih, atasan_bawahan, rekan, asing
        public int Closeness;
        public int GrudgeLevel;
        public int DebtMon;
        public string Note;

        public SimNpcRelationDef()
        {
            TargetId = "";
            RelationType = "asing";
            Closeness = 2;
            GrudgeLevel = 0;
            DebtMon = 0;
            Note = "";
        }
    }

    public sealed class SimNpcDef
    {
        public string Id;
        public string DisplayName;
        public string Role;
        public string RoleCategory;
        public string HomePlaceId;
        public string AssignedPostPlaceId;
        public int Friendliness;
        public int Suspicion;
        public int Courage;
        public int Gossip;
        public int Greed;
        public string SpeechHabit;
        public string SecretId;
        public List<string> Duties;
        public SimSocialDrivesDef SocialDrives;
        public List<SimNpcRelationDef> Relationships;
        public List<SimScheduleBlockDef> Schedule;

        public SimNpcDef()
        {
            Id = "";
            DisplayName = "";
            Role = "";
            RoleCategory = "Resident";
            HomePlaceId = "place_nagaya";
            AssignedPostPlaceId = "place_nagaya";
            Friendliness = 5;
            Suspicion = 5;
            Courage = 5;
            Gossip = 5;
            Greed = 5;
            SpeechHabit = "";
            SecretId = "";
            Duties = new List<string>();
            SocialDrives = new SimSocialDrivesDef();
            Relationships = new List<SimNpcRelationDef>();
            Schedule = new List<SimScheduleBlockDef>();
        }
    }

    public sealed class SimClaimTemplateDef
    {
        public string Action;
        public string Category;
        public double BaseReliability;
        public double Sensitivity;
        public string TemplateId;
        public string TemplateEn;

        public SimClaimTemplateDef()
        {
            Action = "";
            Category = "general";
            BaseReliability = 0.88;
            Sensitivity = 0.50;
            TemplateId = "{subject} melakukan {action} di {place} pada {time} ({quantity}) {motive}.";
            TemplateEn = "{subject} did {action} at {place} at {time} ({quantity}) {motive}.";
        }
    }

    public sealed class SimMotiveDef
    {
        public string Id;
        public string TextId;
        public string TextEn;

        public SimMotiveDef()
        {
            Id = "motive_none";
            TextId = "(tanpa motif yang terucap)";
            TextEn = "(with no stated motive)";
        }
    }

    public sealed class SimWareDef
    {
        public string Id;
        public string CategoryName;
        public List<string> AccessPlaces;
        public List<string> SourcePlaces;
        public string BonusProfile;
        public string CharacteristicRisk;
        public int BaseCapitalMon;
        public int MaxCarryUnits;
        public double SpeedMultiplier;
        public double NoiseMultiplier;
        public bool CanConcealWeapon;
        public bool RequiresZaLicense;
        public bool SeasonalOnly;
        public string OdorTag;

        public SimWareDef()
        {
            Id = "";
            CategoryName = "";
            AccessPlaces = new List<string>();
            SourcePlaces = new List<string>();
            BonusProfile = "";
            CharacteristicRisk = "";
            BaseCapitalMon = 60;
            MaxCarryUnits = 10;
            SpeedMultiplier = 0.95;
            NoiseMultiplier = 1.0;
            CanConcealWeapon = true;
            RequiresZaLicense = false;
            SeasonalOnly = false;
            OdorTag = "None";
        }
    }

    public sealed class SimGarmentDef
    {
        public string Id;
        public string Name;
        public string RoleCategory;
        public string PrimaryHex;
        public string SecondaryHex;
        public int DaySuspicionMod;
        public int NightSuspicionMod;
        public bool CanCarryWaresBox;

        public SimGarmentDef()
        {
            Id = "garment_pedagang_caping";
            Name = "Kosode Pedagang & Caping Bambu";
            RoleCategory = "Pedagang";
            PrimaryHex = "#5C412C";
            SecondaryHex = "#EAE0C8";
            DaySuspicionMod = -10;
            NightSuspicionMod = 12;
            CanCarryWaresBox = true;
        }
    }

    public sealed class SimGroupOrderDef
    {
        public string Id;
        public int WeekNumber;
        public string Title;
        public List<string> RequiredKabarIds;
        public string RecommendedWareId;
        public int DeadlineDay;
        public string DeadDropPlaceId;
        public string ContactNpcId;
        public int RewardCapitalMon;
        public int TrustGainOnSuccess;
        public int TrustPenaltyOnFailure;

        public SimGroupOrderDef()
        {
            Id = "";
            WeekNumber = 1;
            Title = "";
            RequiredKabarIds = new List<string>();
            RecommendedWareId = "";
            DeadlineDay = 7;
            DeadDropPlaceId = "place_titik_serah_hutan";
            ContactNpcId = "";
            RewardCapitalMon = 120;
            TrustGainOnSuccess = 10;
            TrustPenaltyOnFailure = -8;
        }
    }

    public sealed class SimTrueFaceConfig
    {
        public int Stage1NearbySuspicionDelta;
        public int WitnessSuspicionSpike;
        public double SpawnedRumorInitialStrength;
        public int GroupTrustDelta;

        public SimTrueFaceConfig()
        {
            Stage1NearbySuspicionDelta = 8;
            WitnessSuspicionSpike = 35;
            SpawnedRumorInitialStrength = 0.70;
            GroupTrustDelta = -10;
        }
    }

    // L7: Gig Definition (Kitab 9.2) with >=3 approaches & 1-3 day ripple emitted as WorldEvent
    public sealed class SimGigDef
    {
        public string Id;
        public string GiverNpcId;
        public string Title;
        public string TargetType;
        public List<string> Locations;
        public int RewardMon;
        public List<string> Approaches;
        public int RippleDelayDays;
        public string RippleActionCode;
        public string RipplePlaceId;
        public string RippleEffectSummary;
        public double MoralWeight;
        public string Visibility;

        public SimGigDef()
        {
            Id = "";
            GiverNpcId = "";
            Title = "";
            TargetType = "info";
            Locations = new List<string>();
            RewardMon = 80;
            Approaches = new List<string>();
            RippleDelayDays = 1;
            RippleActionCode = "gig_ripple_event";
            RipplePlaceId = "place_pasar";
            RippleEffectSummary = "";
            MoralWeight = 0.0;
            Visibility = "Omote";
        }
    }

    // L7 & L8: Conditional Micro-Story Definition (Kitab 9.1, triggered by world state, never fixed clock)
    public sealed class SimMicroStoryDef
    {
        public string Id;
        public string ConditionType;
        public string RequiredPlaceId;
        public string PrimaryNpcId;
        public string SecondaryNpcId;
        public string Summary;
        public string WorldEffect;

        public SimMicroStoryDef()
        {
            Id = "";
            ConditionType = "";
            RequiredPlaceId = "";
            PrimaryNpcId = "";
            SecondaryNpcId = "";
            Summary = "";
            WorldEffect = "";
        }
    }

    // L8: Systemic Festival Definition (Kitab 9.4)
    public sealed class SimFestivalDef
    {
        public string Id;
        public int Day;
        public string Season;
        public string GatheringPlaceId;
        public double TeaAndSweetsPriceMultiplier;
        public int ViolenceTabooMultiplier;
        public bool MasksAndNightGarbLegal;
        public string SystemicRule;

        public SimFestivalDef()
        {
            Id = "";
            Day = 5;
            Season = "Spring";
            GatheringPlaceId = "place_kuil_kecil";
            TeaAndSweetsPriceMultiplier = 1.0;
            ViolenceTabooMultiplier = 1;
            MasksAndNightGarbLegal = false;
            SystemicRule = "";
        }
    }

    // Gelombang D (Butir 1): Salience & Decay Tuning Data Models (Data/tuning/salience.json)
    public sealed class SimSalienceProfileDef
    {
        public string Action;
        public bool IsRoutine;
        public double Novelty;
        public double ExpectationViolation;
        public double Stakes;
        public double Secrecy;
        public double BaseSalience;

        public SimSalienceProfileDef()
        {
            Action = "";
            IsRoutine = false;
            Novelty = 0.50;
            ExpectationViolation = 0.50;
            Stakes = 0.50;
            Secrecy = 0.50;
            BaseSalience = 0.50;
        }
    }

    public sealed class SimSalienceConfig
    {
        public double NoveltyWeight;
        public double ExpectationViolationWeight;
        public double StakesWeight;
        public double SecrecyWeight;
        public double ListenerProximityWeight;

        public double RoutineMaxSalience;
        public double SalientMinSalience;
        public double HighSalienceThreshold;
        public int RoutineMaxHops;
        public int SalientMaxHops;

        public double RoutineDecayPerDay;
        public double SalientDecayPerDay;
        public double HighSalienceDecayPerDay;

        public List<SimSalienceProfileDef> Profiles;

        public SimSalienceConfig()
        {
            NoveltyWeight = 0.25;
            ExpectationViolationWeight = 0.25;
            StakesWeight = 0.25;
            SecrecyWeight = 0.15;
            ListenerProximityWeight = 0.10;

            RoutineMaxSalience = 0.38;
            SalientMinSalience = 0.39;
            HighSalienceThreshold = 0.72;
            RoutineMaxHops = 1;
            SalientMaxHops = 4;

            RoutineDecayPerDay = 0.45;
            SalientDecayPerDay = 0.10;
            HighSalienceDecayPerDay = 0.04;

            Profiles = new List<SimSalienceProfileDef>();
        }
    }

    public sealed class SimDataBundle
    {
        public SimWeatherConfig WeatherConfig;
        public SimClockConfig ClockConfig;
        public List<SimPlaceDef> Places;
        public List<SimNpcDef> Npcs;
        public List<SimClaimTemplateDef> ClaimTemplates;
        public List<SimMotiveDef> Motives;
        public List<SimWareDef> Wares;
        public List<SimGarmentDef> Garments;
        public List<SimGroupOrderDef> GroupOrders;
        public SimTrueFaceConfig TrueFaceConfig;
        public List<SimGigDef> Gigs;
        public List<SimMicroStoryDef> MicroStories;
        public List<SimFestivalDef> Festivals;
        public SimSalienceConfig SalienceConfig;

        public SimDataBundle()
        {
            WeatherConfig = new SimWeatherConfig();
            ClockConfig = new SimClockConfig();
            Places = new List<SimPlaceDef>();
            Npcs = new List<SimNpcDef>();
            ClaimTemplates = new List<SimClaimTemplateDef>();
            Motives = new List<SimMotiveDef>();
            Wares = new List<SimWareDef>();
            Garments = new List<SimGarmentDef>();
            GroupOrders = new List<SimGroupOrderDef>();
            TrueFaceConfig = new SimTrueFaceConfig();
            Gigs = new List<SimGigDef>();
            MicroStories = new List<SimMicroStoryDef>();
            Festivals = new List<SimFestivalDef>();
            SalienceConfig = new SimSalienceConfig();
        }

        public string ComputeBundleEquivalenceHashHex()
        {
            ulong h = 14695981039346656037UL;
            int pCnt = Places.Count;
            int nCnt = Npcs.Count;
            int ctCnt = ClaimTemplates.Count;
            int wCnt = Wares.Count;
            int gCnt = Gigs.Count;
            int msCnt = MicroStories.Count;
            int fCnt = Festivals.Count;
            int sCnt = SalienceConfig.Profiles.Count;
            string sig = "W:" + WeatherConfig.TransitionGameSeconds.ToString()
                + "|C:" + ClockConfig.TickHz.ToString() + ":" + ClockConfig.WeeklyRentMon.ToString()
                + "|P:" + pCnt.ToString()
                + "|N:" + nCnt.ToString()
                + "|CT:" + ctCnt.ToString()
                + "|Wares:" + wCnt.ToString()
                + "|Gigs:" + gCnt.ToString()
                + "|MS:" + msCnt.ToString()
                + "|F:" + fCnt.ToString()
                + "|Sal:" + sCnt.ToString();
            for (int i = 0; i < Npcs.Count; i++)
            {
                SimNpcDef n = Npcs[i];
                int dCnt = n.Duties.Count;
                int rCnt = n.Relationships.Count;
                sig += "|" + n.Id + ":" + n.RoleCategory + ":" + dCnt.ToString() + ":" + rCnt.ToString();
            }
            for (int i = 0; i < Places.Count; i++)
            {
                int nbCnt = Places[i].Neighbors.Count;
                sig += "|" + Places[i].Id + ":" + nbCnt.ToString();
            }
            for (int c = 0; c < sig.Length; c++)
            {
                h ^= (ulong)sig[c];
                h *= 1099511628211UL;
            }
            return h.ToString("x16");
        }
    }

    // A2-1 & A3-1/A3-2 Typed WorldEvent:
    // Separates OBSERVED attributes (ActorId, SubjectId, PlaceId, ActionCode, Quantity, AppearanceNote)
    // from TrueMotive (strictly for log/debug; NEVER copied to direct witness MemoryEntry/Claim!).
    // Also records EventSourceCategory ("ScheduleTransition", "EntityInteraction", "SoumaAction", "WorldCondition")
    // and StateEffectSummary (concrete state change).
    public sealed class WorldEvent
    {
        public string Id;
        public int Tick;
        public int Day;
        public int Hour;
        public string Type;
        public string EventSourceCategory; // "ScheduleTransition", "EntityInteraction", "SoumaAction", "WorldCondition"
        public string ActorId;
        public string SecondaryEntityId;
        public string PlaceId;
        public string SubjectId;
        public string ActionCode;
        public int Quantity;
        public string AppearanceNote;
        public string TrueMotive; // Log/debug ONLY — forbidden in direct witness claims (A3-1)!
        public double VisibilityIntensity;
        public double NoiseDecibels;
        public bool Tellable;
        public bool IsFlavorOnly; // If true, cannot form a Kabar (A3-2)
        public string StateEffectSummary;
        public string Payload;
        public double SalienceScore;
        public bool IsRoutineEvent;
        public string ParentEventId;
        public string WhyNeedAndRelationTag;
        public bool IsUnpredictableFromSchedule;

        public WorldEvent()
        {
            Id = "";
            Tick = 0;
            Day = 1;
            Hour = 5;
            Type = "NpcAction";
            EventSourceCategory = "ScheduleTransition";
            ActorId = "";
            SecondaryEntityId = "";
            PlaceId = "";
            SubjectId = "";
            ActionCode = "";
            Quantity = 1;
            AppearanceNote = "biasa";
            TrueMotive = "motive_none";
            VisibilityIntensity = 1.0;
            NoiseDecibels = 12.0;
            Tellable = true;
            IsFlavorOnly = false;
            StateEffectSummary = "";
            Payload = "";
            SalienceScore = 0.50;
            IsRoutineEvent = false;
            ParentEventId = "";
            WhyNeedAndRelationTag = "";
            IsUnpredictableFromSchedule = false;
        }
    }

    // A2-1 & A3-1 Structured Claim {subject, action, place, time, quantity, motive}
    // Direct witnesses ALWAYS start with MotiveId = "motive_none".
    // Non-empty MotiveId only enters via AddMotive operator / listener inference on Told hops!
    public sealed class StructuredClaim
    {
        public string SubjectId;
        public string ActionCode;
        public string PlaceId;
        public string TimeLabel;
        public int Quantity;
        public string MotiveId;

        public StructuredClaim()
        {
            SubjectId = "";
            ActionCode = "";
            PlaceId = "";
            TimeLabel = "";
            Quantity = 1;
            MotiveId = "motive_none";
        }

        public StructuredClaim Clone()
        {
            StructuredClaim c = new StructuredClaim();
            c.SubjectId = this.SubjectId;
            c.ActionCode = this.ActionCode;
            c.PlaceId = this.PlaceId;
            c.TimeLabel = this.TimeLabel;
            c.Quantity = this.Quantity;
            c.MotiveId = this.MotiveId;
            return c;
        }
    }

    // A2-1 & A3-1 MemoryEntry backed by SourceEventId (Saw/Heard/Inferred) or SourceMemoryId + TellerNpcId (Told)
    public sealed class MemoryEntry
    {
        public string Id;
        public string OwnerNpcId;
        public int Day;
        public int Hour;
        public string PlaceId;
        public int SourceType; // 0=Saw, 1=Heard, 2=Told, 3=Inferred
        public string SourceEventId;
        public string SourceMemoryId;
        public string TellerNpcId;
        public string RootWitnessNpcId;
        public int HopCount;
        public double Reliability;
        public bool Tellable;
        public string AppliedDistortionOperators;
        public StructuredClaim Claim;
        public string FormattedTextId;
        public string FormattedTextEn;
        public double SalienceScore;
        public bool IsRoutineMemory;
        public bool AgencyActedOn;

        public MemoryEntry()
        {
            Id = "";
            OwnerNpcId = "";
            Day = 1;
            Hour = 5;
            PlaceId = "";
            SourceType = 0;
            SourceEventId = "";
            SourceMemoryId = "";
            TellerNpcId = "";
            RootWitnessNpcId = "";
            HopCount = 0;
            Reliability = 0.90;
            Tellable = true;
            AppliedDistortionOperators = "None";
            Claim = new StructuredClaim();
            FormattedTextId = "";
            FormattedTextEn = "";
            SalienceScore = 0.50;
            IsRoutineMemory = false;
            AgencyActedOn = false;
        }
    }

    public sealed class RumorPropagationHop
    {
        public string SourceEventId;
        public string FromMemoryId;
        public string NewMemoryId;
        public string FromNpcId;
        public string ToNpcId;
        public string PlaceId;
        public int Day;
        public int Hour;
        public int HopNumber;
        public string AppliedOperators;
        public double Reliability;
        public string ClaimTextId;
        public string ClaimTextEn;

        public RumorPropagationHop()
        {
            SourceEventId = "";
            FromMemoryId = "";
            NewMemoryId = "";
            FromNpcId = "";
            ToNpcId = "";
            PlaceId = "";
            Day = 1;
            Hour = 5;
            HopNumber = 1;
            AppliedOperators = "None";
            Reliability = 0.72;
            ClaimTextId = "";
            ClaimTextEn = "";
        }
    }

    public sealed class DynamicKabarRecord
    {
        public string Id;
        public string TopicKey;
        public string SubjectId;
        public string PlaceId;
        public string ActionCode;
        public string SourceTypeLabel;
        public double InitialReliability;
        public double CurrentReliability;
        public int DiscoveredDay;
        public int UpgradedDay;
        public int UpgradedHour;
        public List<string> IndependentRootWitnesses;
        public List<string> SupportingEventIds;
        public string FormattedClaimId;
        public string StatusLabel;

        public DynamicKabarRecord()
        {
            Id = "";
            TopicKey = "";
            SubjectId = "";
            PlaceId = "";
            ActionCode = "";
            SourceTypeLabel = "Heard";
            InitialReliability = 0.50;
            CurrentReliability = 0.50;
            DiscoveredDay = 1;
            UpgradedDay = 0;
            UpgradedHour = 0;
            IndependentRootWitnesses = new List<string>();
            SupportingEventIds = new List<string>();
            FormattedClaimId = "";
            StatusLabel = "Lemah (1 Sumber)";
        }
    }

    public sealed class CorpseRecord
    {
        public string Id;
        public string VictimNpcId;
        public string PlaceId;
        public int KilledDay;
        public int KilledHour;
        public string CauseEventId;
        public bool IsHidden;
        public bool IsDiscovered;
        public string DiscoveredByNpcId;

        public CorpseRecord()
        {
            Id = "";
            VictimNpcId = "";
            PlaceId = "";
            KilledDay = 1;
            KilledHour = 0;
            CauseEventId = "";
            IsHidden = false;
            IsDiscovered = false;
            DiscoveredByNpcId = "";
        }
    }

    // L7 Pending Gig Ripple scheduled 1..3 days after Gig completion
    public sealed class PendingGigRipple
    {
        public string GigId;
        public string ActorNpcId;
        public int TriggerDay;
        public int TriggerHour;
        public string ActionCode;
        public string PlaceId;
        public string EffectSummary;
        public bool Fired;

        public PendingGigRipple()
        {
            GigId = "";
            ActorNpcId = "";
            TriggerDay = 2;
            TriggerHour = 10;
            ActionCode = "gig_ripple_event";
            PlaceId = "place_pasar";
            EffectSummary = "";
            Fired = false;
        }
    }

    // A3-4 & Gelombang C Anecdote Detector: Causal Chain Record
    // Tracks: WorldEvent (evt_...) -> Witness (mem_...) -> Rumor Hop (mem_...) -> Consequence (Suspicion/Kabar/Behavior/Story)
    // Length >= 3 links, involving >= 3 distinct NPCs!
    public sealed class CausalChainRecord
    {
        public string ChainId;
        public string PolicyName;
        public int DayCompleted;
        public string RootEventId;
        public string RootEventSourceCategory;
        public string RootActionCode;
        public string PlaceId;
        public string SubjectNpcId;
        public string WitnessNpcId;
        public string WitnessMemoryId;
        public string RumorSpeakerNpcId;
        public string RumorListenerNpcId;
        public string RumorMemoryId;
        public string AppliedOperators;
        public string ConsequenceType;
        public string ConsequenceSummary;
        public int ChainLength;
        public int DistinctNpcCount;
        public string SecondOrderEventId;
        public string ThirdOrderEventId;
        public bool IsMisunderstanding;
        public string FullTraceText;

        public CausalChainRecord()
        {
            ChainId = "";
            PolicyName = "TraderInformant";
            DayCompleted = 1;
            RootEventId = "";
            RootEventSourceCategory = "";
            RootActionCode = "";
            PlaceId = "";
            SubjectNpcId = "";
            WitnessNpcId = "";
            WitnessMemoryId = "";
            RumorSpeakerNpcId = "";
            RumorListenerNpcId = "";
            RumorMemoryId = "";
            AppliedOperators = "None";
            ConsequenceType = "";
            ConsequenceSummary = "";
            ChainLength = 4;
            DistinctNpcCount = 3;
            SecondOrderEventId = "";
            ThirdOrderEventId = "";
            IsMisunderstanding = false;
            FullTraceText = "";
        }
    }

    // L8 Nisshi (Kitab 8.10) Entry composed strictly from real simulation log events
    public sealed class NisshiEntry
    {
        public int Day;
        public string Season;
        public string Category; // "Dagang", "Kabar", "Gig", "KisahKecil", "Festival", "RantaiAnekdot", "JejakBayangan"
        public string SourceEventId;
        public string EntryText;
        public double ImpactScore;
        public double SalienceScore;

        public NisshiEntry()
        {
            Day = 1;
            Season = "Spring";
            Category = "Dagang";
            SourceEventId = "";
            EntryText = "";
            ImpactScore = 0.50;
            SalienceScore = 0.50;
        }
    }
}
