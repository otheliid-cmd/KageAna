// KAGE-ANA v3.0 — WeatherSystem & LightingPresetTable (Section 6.2, 8.1, 10.6, A2-2 Plain Config Object)
// Pure C# implementation in Runtime/Sim/Weather (Decision C-07).
using System;

namespace KageAna.Runtime.Sim
{
    public struct LightingPresetData
    {
        public string Id;
        public string Segment;
        public string Weather;
        public string SunColor;
        public string AmbientColor;
        public string FogColor;
        public double FogDensity;
        public double LanternIntensity;
    }

    public sealed class WeatherSystem
    {
        public string CurrentWeather;
        public string PreviousWeather;
        public int ConsecutiveSameWeatherDays;
        public int MaxStreakObserved;
        public int MaxAllowedConsecutiveDays;
        public int TransitionTicksRemaining;
        public SimWeatherConfig Config;

        public const int TransitionTotalTicks = 225;
        public const int DefaultMaxConsecutiveDays = 3;

        public WeatherSystem()
        {
            CurrentWeather = "";
            PreviousWeather = "Clear";
            ConsecutiveSameWeatherDays = 0;
            MaxStreakObserved = 0;
            MaxAllowedConsecutiveDays = DefaultMaxConsecutiveDays;
            TransitionTicksRemaining = 0;
            Config = new SimWeatherConfig();
        }

        public void SetConfig(SimWeatherConfig cfg)
        {
            Config = cfg;
        }

        public static string GetWeatherNameByIndex(int idx)
        {
            if (idx == 0) return "Clear";
            if (idx == 1) return "Cloudy";
            if (idx == 2) return "Fog";
            if (idx == 3) return "Rain";
            if (idx == 4) return "Storm";
            if (idx == 5) return "Snow";
            return "Windy";
        }

        public int GetActiveSeasonWeight(string season, int weatherIndex)
        {
            return Config.GetWeight(season, weatherIndex);
        }

        public string DrawDailyWeather(ulong seed, int day, string season)
        {
            return DrawDailyWeatherInternal(seed, day, season, -1);
        }

        public string DrawDailyWeatherInternal(ulong seed, int day, string season, int forcedSingleWeatherIndex)
        {
            string streamName = "weather_day_" + day.ToString();
            SimRandom rng = new SimRandom(seed, streamName);

            int otherPositiveWeightSum = 0;
            for (int i = 0; i < 7; i++)
            {
                int w = (forcedSingleWeatherIndex >= 0)
                    ? (i == forcedSingleWeatherIndex ? 100 : 0)
                    : GetActiveSeasonWeight(season, i);
                string wName = GetWeatherNameByIndex(i);
                if (w > 0 && wName != CurrentWeather)
                {
                    otherPositiveWeightSum += w;
                }
            }

            bool suppressCurrentForStreak = (ConsecutiveSameWeatherDays >= MaxAllowedConsecutiveDays) && (otherPositiveWeightSum > 0);

            int totalWeight = 0;
            for (int i = 0; i < 7; i++)
            {
                int w = (forcedSingleWeatherIndex >= 0)
                    ? (i == forcedSingleWeatherIndex ? 100 : 0)
                    : GetActiveSeasonWeight(season, i);
                if (suppressCurrentForStreak && GetWeatherNameByIndex(i) == CurrentWeather)
                {
                    w = 0;
                }
                totalWeight += w;
            }

            double roll = rng.NextDouble() * (double)totalWeight;
            double accum = 0.0;
            string picked = "Clear";
            for (int i = 0; i < 7; i++)
            {
                int w = (forcedSingleWeatherIndex >= 0)
                    ? (i == forcedSingleWeatherIndex ? 100 : 0)
                    : GetActiveSeasonWeight(season, i);
                if (suppressCurrentForStreak && GetWeatherNameByIndex(i) == CurrentWeather)
                {
                    w = 0;
                }
                accum += (double)w;
                if (roll < accum && w > 0)
                {
                    picked = GetWeatherNameByIndex(i);
                    break;
                }
            }

            if (picked == CurrentWeather)
            {
                ConsecutiveSameWeatherDays += 1;
            }
            else
            {
                ConsecutiveSameWeatherDays = 1;
            }
            if (ConsecutiveSameWeatherDays > MaxStreakObserved)
            {
                MaxStreakObserved = ConsecutiveSameWeatherDays;
            }

            PreviousWeather = CurrentWeather.Length > 0 ? CurrentWeather : picked;
            CurrentWeather = picked;
            TransitionTicksRemaining = TransitionTotalTicks;
            return CurrentWeather;
        }

        public void StepTransitionTick()
        {
            if (TransitionTicksRemaining > 0)
            {
                TransitionTicksRemaining -= 1;
            }
        }

        public double GetSightMultiplier()
        {
            if (CurrentWeather == "Fog") return 0.50;
            if (CurrentWeather == "Storm") return 0.60;
            if (CurrentWeather == "Rain") return 0.80;
            if (CurrentWeather == "Snow") return 0.85;
            if (CurrentWeather == "Cloudy") return 0.90;
            if (CurrentWeather == "Windy") return 0.95;
            return 1.00;
        }

        public double GetRoofStepNoiseMultiplier()
        {
            if (CurrentWeather == "Rain") return 0.70;
            if (CurrentWeather == "Storm") return 0.50;
            if (CurrentWeather == "Snow") return 0.80;
            if (CurrentWeather == "Windy") return 0.80;
            return 1.00;
        }

        public static LightingPresetData ResolveLightingPreset(string segment, string weather)
        {
            LightingPresetData preset = new LightingPresetData();
            preset.Id = "LP_" + segment + "_" + weather;
            preset.Segment = segment;
            preset.Weather = weather;

            double baseFog = 0.016;
            double baseLantern = 0.0;
            if (segment == "Dawn")
            {
                preset.SunColor = "#E8A87C"; preset.AmbientColor = "#3B4D6B"; preset.FogColor = "#C8C2B4";
                baseFog = 0.032; baseLantern = 0.35;
            }
            else if (segment == "Morning")
            {
                preset.SunColor = "#EAE0C8"; preset.AmbientColor = "#D8CEB8"; preset.FogColor = "#E2D9C5";
                baseFog = 0.012; baseLantern = 0.00;
            }
            else if (segment == "Noon")
            {
                preset.SunColor = "#F4EFE6"; preset.AmbientColor = "#CFC7B4"; preset.FogColor = "#EAE0C8";
                baseFog = 0.008; baseLantern = 0.00;
            }
            else if (segment == "Afternoon")
            {
                preset.SunColor = "#F5B041"; preset.AmbientColor = "#8C7A6B"; preset.FogColor = "#D6C3A5";
                baseFog = 0.016; baseLantern = 0.45;
            }
            else if (segment == "Dusk")
            {
                preset.SunColor = "#C8232C"; preset.AmbientColor = "#2B3552"; preset.FogColor = "#4A5670";
                baseFog = 0.022; baseLantern = 1.00;
            }
            else if (segment == "Night")
            {
                preset.SunColor = "#DCE2EC"; preset.AmbientColor = "#152238"; preset.FogColor = "#1F3A60";
                baseFog = 0.025; baseLantern = 1.15;
            }
            else
            {
                preset.SunColor = "#9AA8BC"; preset.AmbientColor = "#101622"; preset.FogColor = "#101622";
                baseFog = 0.030; baseLantern = 0.65;
            }

            double fogMult = 1.0;
            double lantMult = 1.0;
            if (weather == "Cloudy") { fogMult = 1.25; lantMult = 1.00; }
            else if (weather == "Fog") { fogMult = 2.20; lantMult = 1.10; }
            else if (weather == "Rain") { fogMult = 1.55; lantMult = 0.75; }
            else if (weather == "Storm") { fogMult = 1.85; lantMult = 0.50; }
            else if (weather == "Snow") { fogMult = 1.45; lantMult = 1.20; }
            else if (weather == "Windy") { fogMult = 1.10; lantMult = 0.80; }

            double fd = baseFog * fogMult;
            if (fd > 1.0) fd = 1.0;
            preset.FogDensity = fd;
            preset.LanternIntensity = baseLantern * lantMult;
            return preset;
        }
    }
}
