// KAGE-ANA Gelombang E (E1.2) — Antarmuka Sumber Data Simulasi Lintas-Adapter (netstandard2.1 & net8.0)
// Pure C# in Runtime/Sim (tanpa System.Text.Json, tanpa UnityEngine).
using System;

namespace KageAna.Runtime.Sim
{
    public interface ISimDataSource
    {
        SimDataBundle LoadBundle();
    }
}
