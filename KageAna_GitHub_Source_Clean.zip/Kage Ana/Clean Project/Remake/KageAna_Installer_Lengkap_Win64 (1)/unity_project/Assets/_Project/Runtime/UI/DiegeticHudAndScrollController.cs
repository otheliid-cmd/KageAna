// STATUS VERIFIKASI (E4.5 & E8): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using UnityEngine;
using KageAna.Presentation;

namespace KageAna.UI
{
    /// <summary>
    /// E4.5: HUD diegetik minimal (cap Hanko untuk status, ikon Kamon sederhana,
    /// panel Nisshi seperti gulungan terbuka, Kisah Hari Ini seperti papan pengumuman Kosatsu).
    /// Ukuran sentuh >= 48 dp, skala UI 80-140%, teks >= 16 sp di ponsel, subtitle selalu tersedia,
    /// dan navigasi penuh dengan gamepad tanpa kursor wajib.
    /// </summary>
    public sealed class DiegeticHudAndScrollController : MonoBehaviour
    {
        public float MinTouchTargetDp = 48.0f;
        public float UiScalePercent = 100.0f; // 80..140%
        public float MinBodyTextSp = 16.0f;
        public bool SubtitlesAlwaysEnabled = true;
        public bool IsNightInkThemeActive;
        public int CurrentGamepadFocusIndex;

        public void SetUiScale(float scalePct)
        {
            UiScalePercent = Mathf.Clamp(scalePct, 80.0f, 140.0f);
        }

        public void NavigateGamepadFocus(int delta, int totalFocusableItems)
        {
            if (totalFocusableItems <= 0) return;
            CurrentGamepadFocusIndex = (CurrentGamepadFocusIndex + delta + totalFocusableItems) % totalFocusableItems;
        }
    }
}
