Shader "KageAna/UkiyoENoirCelOutline"
{
    Properties
    {
        _BaseMap ("Base Texture", 2D) = "white" {}
        _BaseColor ("Base Tint", Color) = (0.87, 0.83, 0.75, 1)
        _ShadowColor ("Shadow Ink Tint", Color) = (0.11, 0.13, 0.22, 1)
        _RimColor ("Rim Accent Color", Color) = (0.95, 0.66, 0.23, 1)
        _RimPower ("Rim Power", Range(1.0, 8.0)) = 4.2
        _OutlineColor ("Sumi-e Outline Color", Color) = (0.07, 0.08, 0.11, 1)
        _OutlineWidth ("Outline Width (Meters)", Range(0.0, 0.03)) = 0.008
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" }
        LOD 200

        // Pass 1: Forward Lit 3-Band Stepped Cel Shading with Real Shadow Attenuation
        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode"="UniversalForward" }
            Cull Back

            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE
            #pragma multi_compile_fog

            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS   : NORMAL;
                float2 uv         : TEXCOORD0;
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
                float3 positionWS : TEXCOORD0;
                float3 normalWS   : TEXCOORD1;
                float2 uv         : TEXCOORD2;
                float  fogFactor  : TEXCOORD3;
            };

            TEXTURE2D(_BaseMap);
            SAMPLER(sampler_BaseMap);

            CBUFFER_START(UnityPerMaterial)
                float4 _BaseColor;
                float4 _ShadowColor;
                float4 _RimColor;
                float  _RimPower;
                float4 _OutlineColor;
                float  _OutlineWidth;
            CBUFFER_END

            Varyings vert(Attributes IN)
            {
                Varyings OUT;
                VertexPositionInputs posInputs = GetVertexPositionInputs(IN.positionOS.xyz);
                VertexNormalInputs normInputs = GetVertexNormalInputs(IN.normalOS);
                OUT.positionCS = posInputs.positionCS;
                OUT.positionWS = posInputs.positionWS;
                OUT.normalWS = normInputs.normalWS;
                OUT.uv = IN.uv;
                OUT.fogFactor = ComputeFogFactor(posInputs.positionCS.z);
                return OUT;
            }

            half4 frag(Varyings IN) : SV_Target
            {
                float4 shadowCoord = TransformWorldToShadowCoord(IN.positionWS);
                Light mainLight = GetMainLight(shadowCoord);

                float3 N = normalize(IN.normalWS);
                float3 L = normalize(mainLight.direction);
                float3 V = normalize(GetWorldSpaceViewDir(IN.positionWS));

                float ndotl = dot(N, L) * mainLight.shadowAttenuation;
                // 3-Band Ukiyo-e Stepped Cel Ramp
                float celBand = ndotl > 0.55 ? 1.0 : (ndotl > 0.12 ? 0.62 : 0.0);

                float4 texCol = SAMPLE_TEXTURE2D(_BaseMap, sampler_BaseMap, IN.uv) * _BaseColor;
                float3 shaded = lerp(texCol.rgb * _ShadowColor.rgb, texCol.rgb * mainLight.color, celBand);

                // Subtle Silhouette Rim Light for Readability in Fog
                float rim = pow(1.0 - saturate(dot(N, V)), _RimPower) * step(0.1, ndotl + 0.3);
                shaded += _RimColor.rgb * rim * 0.35;

                shaded = MixFog(shaded, IN.fogFactor);
                return half4(shaded, 1.0);
            }
            ENDHLSL
        }

        // Pass 2: Inverted-Hull Sumi-e Brush Outline
        Pass
        {
            Name "SumiOutline"
            Tags { "LightMode"="SRPDefaultUnlit" }
            Cull Front

            HLSLPROGRAM
            #pragma vertex vertOutline
            #pragma fragment fragOutline
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes
            {
                float4 positionOS : POSITION;
                float3 normalOS   : NORMAL;
            };

            struct Varyings
            {
                float4 positionCS : SV_POSITION;
            };

            CBUFFER_START(UnityPerMaterial)
                float4 _BaseColor;
                float4 _ShadowColor;
                float4 _RimColor;
                float  _RimPower;
                float4 _OutlineColor;
                float  _OutlineWidth;
            CBUFFER_END

            Varyings vertOutline(Attributes IN)
            {
                Varyings OUT;
                float3 extrudedOS = IN.positionOS.xyz + normalize(IN.normalOS) * _OutlineWidth;
                OUT.positionCS = TransformObjectToHClip(extrudedOS);
                return OUT;
            }

            half4 fragOutline(Varyings IN) : SV_Target
            {
                return _OutlineColor;
            }
            ENDHLSL
        }
    }
}
