// STATUS VERIFIKASI (E8): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using System;
using System.Collections.Generic;
using UnityEngine;

namespace KageAna.Input
{
    public enum ControlSchemeType
    {
        KeyboardMouse = 0,
        Gamepad = 1,
        Touch = 2
    }

    public enum GamepadBrandPrompt
    {
        Xbox = 0,
        PlayStationDualSense = 1,
        SwitchPro = 2
    }

    /// <summary>
    /// E8: Satu abstraksi input tunggal untuk 14 aksi wajib pada 3 skema kontrol
    /// (Gamepad Xbox/PS/Switch Pro, Keyboard+Mouse, dan Sentuh Android >=48dp dengan opsi kidal),
    /// pengalihan otomatis skema + ikon tombol, serta getaran (rumble) halus yang dapat dimatikan.
    /// </summary>
    public sealed class UnifiedInputController : MonoBehaviour
    {
        public static readonly string[] RequiredFourteenActions = new string[]
        {
            "Gerak",
            "Kamera",
            "Interaksi",
            "TanyaBicara",
            "Mengendap",
            "Lari",
            "Sembunyi",
            "BukaNisshi",
            "Menu",
            "Konfirmasi",
            "Batal",
            "Fokus",
            "WajahAsli",
            "TindakanKhusus"
        };

        public ControlSchemeType ActiveScheme { get; private set; } = ControlSchemeType.KeyboardMouse;
        public GamepadBrandPrompt ActiveGamepadBrand { get; private set; } = GamepadBrandPrompt.Xbox;
        public bool LeftHandedTouchMode;
        public float TouchButtonSizeDp = 52.0f; // Kontrak E4.5 & E8: >= 48 dp
        public bool EnableSubtleRumble = true;

        public Vector2 MoveVector { get; private set; }
        public Vector2 CameraLookVector { get; private set; }
        private readonly HashSet<string> _triggeredActionsThisFrame = new HashSet<string>();

        public void SimulateSchemeInput(ControlSchemeType scheme, Vector2 move, Vector2 look, string triggeredAction = null, GamepadBrandPrompt brand = GamepadBrandPrompt.Xbox)
        {
            ActiveScheme = scheme;
            if (scheme == ControlSchemeType.Gamepad)
            {
                ActiveGamepadBrand = brand;
            }
            MoveVector = move;
            CameraLookVector = look;
            _triggeredActionsThisFrame.Clear();
            if (!string.IsNullOrEmpty(triggeredAction))
            {
                _triggeredActionsThisFrame.Add(triggeredAction);
            }
        }

        public bool WasActionTriggered(string actionName)
        {
            return _triggeredActionsThisFrame.Contains(actionName);
        }

        public string GetPromptLabelForAction(string actionName)
        {
            if (ActiveScheme == ControlSchemeType.Touch)
            {
                return "[Sentuh: " + actionName + "]";
            }
            if (ActiveScheme == ControlSchemeType.Gamepad)
            {
                if (ActiveGamepadBrand == GamepadBrandPrompt.PlayStationDualSense)
                {
                    if (actionName == "Interaksi" || actionName == "Konfirmasi") return "[Cross]";
                    if (actionName == "Batal" || actionName == "Mengendap") return "[Circle]";
                    if (actionName == "TanyaBicara") return "[Square]";
                    if (actionName == "TindakanKhusus") return "[Triangle]";
                }
                else if (ActiveGamepadBrand == GamepadBrandPrompt.SwitchPro)
                {
                    if (actionName == "Interaksi" || actionName == "Konfirmasi") return "[B]";
                    if (actionName == "Batal" || actionName == "Mengendap") return "[A]";
                    if (actionName == "TanyaBicara") return "[Y]";
                    if (actionName == "TindakanKhusus") return "[X]";
                }
                else
                {
                    if (actionName == "Interaksi" || actionName == "Konfirmasi") return "[A]";
                    if (actionName == "Batal" || actionName == "Mengendap") return "[B]";
                    if (actionName == "TanyaBicara") return "[X]";
                    if (actionName == "TindakanKhusus") return "[Y]";
                }
            }
            return "[Key: " + actionName + "]";
        }
    }
}
