#if UNITY_EDITOR
using System;
using System.IO;
using UnityEditor;
using UnityEngine;
using KageAna.Runtime.Sim;
using KageAna.Tests.EditMode;

namespace KageAna.EditorTools
{
    public static class KageAnaHeadlessBatchRunner
    {
        [MenuItem("KageAna/3. Run L1 C# Unit Tests & 28-Day Headless Sim")]
        public static void RunHeadlessCli()
        {
            int passed = ClockAndWeatherSimTests.RunAllUnitTests();
            Debug.Log("[KageAna.Sim] EditMode Unit Tests Passed: " + passed);
            string jsonReport = HeadlessSimRunner.Run28DaySimToJson(7UL, 28, false);
            File.WriteAllText("sim_report_unity.json", jsonReport);
            Debug.Log("[KageAna.Sim] 28-Day Sim JSON: " + jsonReport);
        }
    }
}
#endif
