// STATUS VERIFIKASI (E4.1–E4.3): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using UnityEngine;
using KageAna.Sim;

namespace KageAna.Presentation
{
    /// <summary>
    /// E4.1, E4.2, E4.3: Mengatur palet token ukiyo-e -> sumi-e, gradasi langit dari WorldClock & Weather,
    /// tekstur kertas washi (4-6% multiply), efek curiga, dan efek Wajah Asli (1-bingkai freeze + Shu #B8321F).
    /// </summary>
    public sealed class KageAnaPaletteAsset : ScriptableObject
    {
        public string WashiPaperDayHex = "#EFE6D2";
        public string SumiInkHex = "#1C1B1A";
        public string AiiroIndigoDayHex = "#27406B";
        public string KonIndigoNightHex = "#141B33";
        public string TsukiMoonlightHex = "#B9C7D8";
        public string AndonLanternWarmHex = "#E8A33D";
        public string KakiPersimmonAccentHex = "#D2692E";
        public string ShuVermilionDangerHex = "#B8321F";
        public string KaratDriedBloodHex = "#5E1F18";
        public string KuriEarthDarkWoodHex = "#6B5A44";
        public string SugiCedarLightWoodHex = "#A37E56";
        public string MatchaMutedFoliageHex = "#7A8B5C";
    }

    public sealed class WorldClockSkyAndAtmosphereController : MonoBehaviour
    {
        public KageAnaPaletteAsset Palette;
        public float PaperOverlayOpacity = 0.05f; // 4-6% multiply
        public float CurrentSaturation = 1.0f;
        public float SuspicionVignetteWeight;
        public bool TrueFaceMomentActive;

        public void EvaluateFromSimClock(DaySegment segment, WeatherType weather, int suspicionScore, bool triggeredTrueFaceMoment)
        {
            // E4.2: Hujan kurangi kejenuhan 30%
            CurrentSaturation = (weather == WeatherType.Rain || weather == WeatherType.Storm) ? 0.70f : 1.0f;
            SuspicionVignetteWeight = Mathf.Clamp01(suspicionScore / 100.0f) * 0.45f;
            TrueFaceMomentActive = triggeredTrueFaceMoment;
        }
    }
}
