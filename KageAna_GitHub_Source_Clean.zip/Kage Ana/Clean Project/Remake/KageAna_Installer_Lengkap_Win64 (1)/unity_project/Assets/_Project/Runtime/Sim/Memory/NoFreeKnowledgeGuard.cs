// KAGE-ANA v3.0 Gelombang D — Real EventLog, Observed-Attribute, Motive-Leakage, Salience-Spread, Agency-Belief & Nisshi-Bounds Guard
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public sealed class NoFreeKnowledgeGuard
    {
        public int Violations;
        public string LastViolationDetail;

        public NoFreeKnowledgeGuard()
        {
            Violations = 0;
            LastViolationDetail = "";
        }

        private static int ParseSequentialSuffixOneBased(string id, string prefix)
        {
            int pLen = prefix.Length;
            if (id.Length <= pLen) return -1;
            for (int i = 0; i < pLen; i++)
            {
                if (id[i] != prefix[i]) return -1;
            }
            int val = 0;
            for (int i = pLen; i < id.Length; i++)
            {
                char c = id[i];
                if (c < '0' || c > '9') return -1;
                val = (val * 10) + (int)(c - '0');
            }
            return val - 1;
        }

        public bool ValidateAndRecordKnowledge(string npcId, string claimId, int sourceType, bool hasValidCausalWitnessOrRumor)
        {
            if (sourceType < 0 || sourceType > 3 || !hasValidCausalWitnessOrRumor)
            {
                Violations += 1;
                LastViolationDetail = "NPC '" + npcId + "' acquired unexperienced claim '" + claimId + "' without witness/rumor link.";
                return false;
            }
            return true;
        }

        public bool ValidateWorldEventSource(WorldEvent evt)
        {
            string cat = evt.EventSourceCategory;
            bool validCat = (cat == "ScheduleTransition" || cat == "EntityInteraction" || cat == "SoumaAction" || cat == "WorldCondition");
            if (!validCat)
            {
                Violations += 1;
                LastViolationDetail = "A3-2 Violation: WorldEvent '" + evt.Id + "' has invalid/unclassified EventSourceCategory='" + cat + "'.";
                return false;
            }
            if (!evt.IsFlavorOnly && evt.StateEffectSummary.Length == 0)
            {
                Violations += 1;
                LastViolationDetail = "A3-2 Violation: Non-flavor WorldEvent '" + evt.Id + "' has empty StateEffectSummary.";
                return false;
            }
            return true;
        }

        public bool ValidateRumorSalienceSpread(MemoryEntry parentMem, MemoryEntry childMem, SimSalienceConfig salCfg)
        {
            if (parentMem.IsRoutineMemory && parentMem.SalienceScore <= salCfg.RoutineMaxSalience)
            {
                if (childMem.HopCount > salCfg.RoutineMaxHops)
                {
                    Violations += 1;
                    LastViolationDetail = "Gelombang D Salience Violation: Routine memory '" + parentMem.Id + "' (salience=" + parentMem.SalienceScore.ToString() + ") spread to hop " + childMem.HopCount.ToString() + " (> " + salCfg.RoutineMaxHops.ToString() + ").";
                    return false;
                }
                if (childMem.PlaceId != parentMem.PlaceId)
                {
                    Violations += 1;
                    LastViolationDetail = "Gelombang D Salience Violation: Routine memory '" + parentMem.Id + "' spread outside local place '" + parentMem.PlaceId + "' to '" + childMem.PlaceId + "'.";
                    return false;
                }
            }
            return true;
        }

        public bool ValidateAgencyActionAgainstBelief(string actorNpcId, string beliefMemoryId, List<MemoryEntry> existingMemories, double minSalience)
        {
            if (actorNpcId.Length == 0 || beliefMemoryId.Length == 0)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang D Agency Violation: NPC '" + actorNpcId + "' attempted agency action with empty beliefMemoryId.";
                return false;
            }

            int fastIdx = ParseSequentialSuffixOneBased(beliefMemoryId, "mem_");
            int foundIdx = -1;
            if (fastIdx >= 0 && fastIdx < existingMemories.Count && existingMemories[fastIdx].Id == beliefMemoryId)
            {
                foundIdx = fastIdx;
            }
            else
            {
                for (int i = existingMemories.Count - 1; i >= 0; i--)
                {
                    if (existingMemories[i].Id == beliefMemoryId)
                    {
                        foundIdx = i;
                        break;
                    }
                }
            }

            if (foundIdx < 0)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang D Agency Violation: NPC '" + actorNpcId + "' acted on nonexistent belief memory '" + beliefMemoryId + "'.";
                return false;
            }

            MemoryEntry mem = existingMemories[foundIdx];
            if (mem.OwnerNpcId != actorNpcId)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang D Agency Violation: NPC '" + actorNpcId + "' acted on memory '" + beliefMemoryId + "' owned by '" + mem.OwnerNpcId + "'.";
                return false;
            }

            if (mem.SalienceScore < minSalience)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang D Agency Violation: NPC '" + actorNpcId + "' acted on trivial routine memory '" + beliefMemoryId + "' (salience=" + mem.SalienceScore.ToString() + " < " + minSalience.ToString() + ").";
                return false;
            }

            return true;
        }

        public bool ValidateCuratedNisshiBounds(List<NisshiEntry> curatedEntries, int minEntries, int maxEntries)
        {
            int cnt = curatedEntries.Count;
            if (cnt < minEntries || cnt > maxEntries)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang D Nisshi Violation: Curated Nisshi count " + cnt.ToString() + " is outside required bounds [" + minEntries.ToString() + ".." + maxEntries.ToString() + "].";
                return false;
            }
            return true;
        }

        // Gelombang E (E2.1): Penjaga Metrik Anti-Pengisi Kuota (menolak sim palsu berbasis modulus / lintas lokasi / tanpa mengapa)
        public bool ValidateAntiFillerMetrics(
            int totalEntityInteractions,
            int whyLinkedInteractions,
            int repeatedPairWithoutTrigger,
            int crossLocationInteractions,
            double meanEntropyBitsPerNpc,
            int unpredictableCausalEvents,
            int daysSimulated)
        {
            if (crossLocationInteractions > 0)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang E Anti-Filler Violation: Found " + crossLocationInteractions.ToString() + " cross-location NPC interactions (must be 0).";
                return false;
            }
            if (totalEntityInteractions > 0 && whyLinkedInteractions < totalEntityInteractions)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang E Anti-Filler Violation: Only " + whyLinkedInteractions.ToString() + "/" + totalEntityInteractions.ToString() + " EntityInteraction events have WhyNeedAndRelationTag (must be 100%).";
                return false;
            }
            int repeatPct = totalEntityInteractions > 0 ? ((repeatedPairWithoutTrigger * 100) / totalEntityInteractions) : 0;
            if (repeatPct >= 30)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang E Anti-Filler Violation: Repeated pair without new trigger ratio is " + repeatPct.ToString() + "% (must be < 30%).";
                return false;
            }
            if (daysSimulated >= 3 && meanEntropyBitsPerNpc < 1.25)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang E Anti-Filler Violation: Mean interaction entropy per NPC is too low (" + meanEntropyBitsPerNpc.ToString() + " bits < 1.25 bits).";
                return false;
            }
            if (daysSimulated >= 3 && unpredictableCausalEvents < 6)
            {
                Violations += 1;
                LastViolationDetail = "Gelombang E Anti-Filler Violation: Unpredictable causal events count is too low (" + unpredictableCausalEvents.ToString() + ").";
                return false;
            }
            return true;
        }

        private static bool ContainsOperatorToken(string ops, string token)
        {
            int n = ops.Length;
            int m = token.Length;
            if (m == 0) return true;
            for (int i = 0; i <= n - m; i++)
            {
                bool ok = true;
                for (int j = 0; j < m; j++)
                {
                    if (ops[i + j] != token[j])
                    {
                        ok = false;
                        break;
                    }
                }
                if (ok) return true;
            }
            return false;
        }

        public bool ValidateMemoryAgainstEventLog(
            MemoryEntry entry,
            List<WorldEvent> eventLog,
            List<MemoryEntry> existingMemories,
            string ownerCurrentPlaceId,
            string tellerCurrentPlaceId)
        {
            if (entry.OwnerNpcId.Length == 0)
            {
                Violations += 1;
                LastViolationDetail = "MemoryEntry missing OwnerNpcId.";
                return false;
            }

            if (entry.SourceType < 0 || entry.SourceType > 3)
            {
                Violations += 1;
                LastViolationDetail = "NPC '" + entry.OwnerNpcId + "' used invalid SourceType=" + entry.SourceType.ToString();
                return false;
            }

            if (entry.SourceEventId.Length == 0)
            {
                Violations += 1;
                LastViolationDetail = "NPC '" + entry.OwnerNpcId + "' memory has empty SourceEventId.";
                return false;
            }

            int foundEvtIdx = -1;
            int fastEvtIdx = ParseSequentialSuffixOneBased(entry.SourceEventId, "evt_");
            if (fastEvtIdx >= 0 && fastEvtIdx < eventLog.Count && eventLog[fastEvtIdx].Id == entry.SourceEventId)
            {
                foundEvtIdx = fastEvtIdx;
            }
            else
            {
                for (int i = eventLog.Count - 1; i >= 0; i--)
                {
                    if (eventLog[i].Id == entry.SourceEventId)
                    {
                        foundEvtIdx = i;
                        break;
                    }
                }
            }

            if (foundEvtIdx < 0)
            {
                Violations += 1;
                LastViolationDetail = "NPC '" + entry.OwnerNpcId + "' memory references nonexistent WorldEvent '" + entry.SourceEventId + "'.";
                return false;
            }

            WorldEvent rootEvt = eventLog[foundEvtIdx];

            if (entry.SourceType == 0 || entry.SourceType == 1 || entry.SourceType == 3)
            {
                if (ownerCurrentPlaceId != rootEvt.PlaceId)
                {
                    Violations += 1;
                    LastViolationDetail = "NPC '" + entry.OwnerNpcId + "' at '" + ownerCurrentPlaceId + "' claimed direct perception of event at '" + rootEvt.PlaceId + "'.";
                    return false;
                }

                if (entry.Claim.SubjectId.Length > 0 && entry.Claim.SubjectId != rootEvt.SubjectId)
                {
                    Violations += 1;
                    LastViolationDetail = "A3-1 Violation: Direct witness '" + entry.OwnerNpcId + "' Claim.SubjectId='" + entry.Claim.SubjectId + "' does not match observed SubjectId='" + rootEvt.SubjectId + "'.";
                    return false;
                }
                if (entry.Claim.ActionCode.Length > 0 && entry.Claim.ActionCode != rootEvt.ActionCode)
                {
                    Violations += 1;
                    LastViolationDetail = "A3-1 Violation: Direct witness '" + entry.OwnerNpcId + "' Claim.ActionCode='" + entry.Claim.ActionCode + "' does not match observed ActionCode='" + rootEvt.ActionCode + "'.";
                    return false;
                }
                if (entry.Claim.PlaceId.Length > 0 && entry.Claim.PlaceId != rootEvt.PlaceId)
                {
                    Violations += 1;
                    LastViolationDetail = "A3-1 Violation: Direct witness '" + entry.OwnerNpcId + "' Claim.PlaceId='" + entry.Claim.PlaceId + "' does not match observed PlaceId='" + rootEvt.PlaceId + "'.";
                    return false;
                }

                bool hasMotiveOp = ContainsOperatorToken(entry.AppliedDistortionOperators, "AddMotive");
                if (entry.Claim.MotiveId.Length > 0 && entry.Claim.MotiveId != "motive_none")
                {
                    if (entry.SourceType != 3 || !hasMotiveOp)
                    {
                        Violations += 1;
                        LastViolationDetail = "A3-1 Motive Leakage Violation: Direct witness '" + entry.OwnerNpcId + "' claimed unobserved motive '" + entry.Claim.MotiveId + "' (TrueMotive='" + rootEvt.TrueMotive + "') without AddMotive operator.";
                        return false;
                    }
                }

                return true;
            }

            if (entry.SourceMemoryId.Length == 0 || entry.TellerNpcId.Length == 0)
            {
                Violations += 1;
                LastViolationDetail = "NPC '" + entry.OwnerNpcId + "' Told memory missing SourceMemoryId or TellerNpcId.";
                return false;
            }

            if (ownerCurrentPlaceId != tellerCurrentPlaceId)
            {
                Violations += 1;
                LastViolationDetail = "NPC '" + entry.OwnerNpcId + "' and teller '" + entry.TellerNpcId + "' are not at the same place.";
                return false;
            }

            int foundParentIdx = -1;
            int fastMemIdx = ParseSequentialSuffixOneBased(entry.SourceMemoryId, "mem_");
            if (fastMemIdx >= 0 && fastMemIdx < existingMemories.Count && existingMemories[fastMemIdx].Id == entry.SourceMemoryId && existingMemories[fastMemIdx].OwnerNpcId == entry.TellerNpcId)
            {
                foundParentIdx = fastMemIdx;
            }
            else
            {
                for (int m = existingMemories.Count - 1; m >= 0; m--)
                {
                    if (existingMemories[m].Id == entry.SourceMemoryId && existingMemories[m].OwnerNpcId == entry.TellerNpcId)
                    {
                        foundParentIdx = m;
                        break;
                    }
                }
            }

            if (foundParentIdx < 0)
            {
                Violations += 1;
                LastViolationDetail = "NPC '" + entry.OwnerNpcId + "' Told memory references nonexistent parent memory '" + entry.SourceMemoryId + "' from '" + entry.TellerNpcId + "'.";
                return false;
            }

            MemoryEntry parentMem = existingMemories[foundParentIdx];
            if (parentMem.SourceEventId != entry.SourceEventId)
            {
                Violations += 1;
                LastViolationDetail = "NPC '" + entry.OwnerNpcId + "' Told memory SourceEventId mismatch with parent memory.";
                return false;
            }

            if (entry.Claim.MotiveId != parentMem.Claim.MotiveId && !ContainsOperatorToken(entry.AppliedDistortionOperators, "AddMotive"))
            {
                Violations += 1;
                LastViolationDetail = "A3-1 Motive Leakage Violation: Told memory '" + entry.Id + "' introduced motive '" + entry.Claim.MotiveId + "' without recording AddMotive operator.";
                return false;
            }

            return true;
        }
    }
}
