// KAGE-ANA v3.0 Gelombang D (Butir 4, 6b, & 8) — Modul 12: Tindakan Sōma, Dialog Bertanya Diegetik, & Wajah Asli
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimSoumaActionSystem
    {
        public static string GenerateDiegeticNpcDialogue(
            SimEventBus bus,
            string targetNpcId,
            SimPlaceGraphSystem world)
        {
            int tIdx = world.FindNpcIndexById(targetNpcId);
            if (tIdx < 0) return "Warga itu sudah beranjak pergi.";

            NpcRuntimeState ag = world.Agents[tIdx];
            string attitudeNote = "";
            if (ag.SuspicionTowardSouma >= 45 || ag.AttitudeTowardSouma == "Curiga")
            {
                attitudeNote = "(Menatap curiga dan menjaga jarak) ";
            }
            else if (ag.AttitudeTowardSouma == "Kesal_Tunggakan")
            {
                attitudeNote = "(Berkacak pinggang menagih tunggakan sewa) ";
            }
            else if (ag.FamiliarityWithSouma >= 25 || ag.AttitudeTowardSouma == "Ramah")
            {
                attitudeNote = "(Menyapa akrab sambil merapikan barang) ";
            }
            else
            {
                attitudeNote = "(Berbicara hati-hati kepada pedagang keliling) ";
            }

            int bestMemIdx = -1;
            double bestSal = -1.0;
            for (int m = bus.Memories.Count - 1; m >= 0; m--)
            {
                MemoryEntry mem = bus.Memories[m];
                if (mem.OwnerNpcId != ag.Id || !mem.Tellable) continue;
                if (mem.SalienceScore > bestSal)
                {
                    bestSal = mem.SalienceScore;
                    bestMemIdx = m;
                    if (!mem.IsRoutineMemory) break;
                }
            }

            if (bestMemIdx < 0)
            {
                return ag.DisplayName + " " + attitudeNote + ": \"Hari ini di " + world.Places[ag.CurrentPlaceIdx].Name + " belum ada kejadian aneh yang kulihat sendiri.\"";
            }

            MemoryEntry chosen = bus.Memories[bestMemIdx];
            string sourcePhrase = "";
            if (chosen.SourceType == 0)
            {
                sourcePhrase = "Aku melihatnya dengan mata kepalaku sendiri";
            }
            else if (chosen.SourceType == 1)
            {
                sourcePhrase = "Aku mendengarnya langsung dari dekat tempat kejadian";
            }
            else
            {
                string tellerName = bus.LookupSubjectDisplayName(chosen.TellerNpcId, world);
                sourcePhrase = "Aku diberitahu oleh " + tellerName + " (rantai ke-" + chosen.HopCount.ToString() + ")";
            }

            string certaintyPhrase = "";
            if (chosen.Reliability >= 0.80)
            {
                certaintyPhrase = "Aku sangat yakin soal ini (keyakinan tinggi)";
            }
            else if (chosen.Reliability >= 0.55)
            {
                certaintyPhrase = "Kabarnya cukup santer meski rinciannya mulai berubah (keyakinan sedang)";
            }
            else
            {
                certaintyPhrase = "Entahlah, itu baru bisik-bisik simpang-siur di warung (keyakinan rendah)";
            }

            return ag.DisplayName + " " + attitudeNote + ": \"" + sourcePhrase + " — " + chosen.FormattedTextId + " " + certaintyPhrase + ".\" [Sumber: " + chosen.SourceEventId + " / Ingatan: " + chosen.Id + "]";
        }

        public static WorldEvent ExecuteSoumaInquireNpc(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            string targetNpcId,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            int tIdx = world.FindNpcIndexById(targetNpcId);
            string dialogue = GenerateDiegeticNpcDialogue(bus, targetNpcId, world);
            if (tIdx >= 0)
            {
                NpcRuntimeState ag = world.Agents[tIdx];
                for (int m = bus.Memories.Count - 1; m >= 0; m--)
                {
                    if (bus.Memories[m].OwnerNpcId == ag.Id && bus.Memories[m].Tellable && bus.Memories[m].Claim.SubjectId != "souma" && !bus.Memories[m].IsRoutineMemory)
                    {
                        SimMemoryStore.RegisterSoumaKabarObservation(bus, bus.Memories[m].SourceEventId, bus.Memories[m].RootWitnessNpcId, "Told", bus.Memories[m].Claim, day, hour, world);
                        break;
                    }
                }
            }

            string pId = world.Places[world.SoumaCurrentPlaceIdx].Id;
            SimNisshiCurator.RecordKisahEventWithWhy(
                bus, day, hour, "DialogTanyaNpc", pId,
                dialogue, "", targetNpcId, "Soma bertanya langsung kepada " + targetNpcId + " di " + pId
            );

            return SimPerceptionSystem.EmitWorldEvent(
                bus,
                tick, day, hour, segment, weather,
                "SoumaInquire", "SoumaAction",
                "souma", targetNpcId, pId, "souma",
                "trade_wares", 1, "motive_none", 0.85, 14.0, false, true,
                "InquiredNpc:" + targetNpcId,
                dialogue,
                world, guard
            );
        }

        public static WorldEvent ExecuteSoumaSteal(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            int tabooMult = SimFestivalSystem.GetCurrentFestivalViolenceTabooMultiplier(bus, day);
            string pId = world.Places[world.SoumaCurrentPlaceIdx].Id;
            world.SoumaMon += 45;
            world.TotalRevenueMon += 45;
            world.HeartWarmCold = Math.Max(-100, world.HeartWarmCold - (8 * tabooMult));
            world.UpdateMonBounds();

            WorldEvent sEvt = SimPerceptionSystem.EmitWorldEvent(
                bus,
                tick, day, hour, segment, weather,
                "SoumaSteal", "SoumaAction",
                "souma", "", pId, "souma",
                "steal_item", 1, "motive_greed", 0.90, 22.0, true, false,
                "StolenMon:+45;HeartDelta=-8",
                "Souma stole items at " + pId,
                world, guard
            );
            SimNisshiCurator.RecordNisshiCandidate(
                bus, day, "JejakBayangan", sEvt.Id,
                "Hari " + day.ToString() + " — Menyelinap mengambil barang tanpa bayar di " + bus.LookupPlaceDisplayName(pId, world) + " (+45 mon, Hati mendingin).",
                0.88, 0.82
            );
            return sEvt;
        }

        public static WorldEvent ExecuteSoumaSleepAndCleanInNagaya(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            world.BloodStainLevel = 0;
            world.ActiveOdor = "None";
            world.FatigueLevel = 0;
            world.TimesSleptInNagaya += 1;
            if (world.HeartWarmCold < 20)
            {
                world.HeartWarmCold = Math.Min(20, world.HeartWarmCold + 1);
            }
            SimNisshiCurator.RecordKisahEvent(bus, day, hour, "KamarNagaya", "place_nagaya", "Soma beristirahat di Kamar Sewa Nagaya, mencuci noda pakaian, dan merapikan Papan Tinta.");
            return SimPerceptionSystem.EmitWorldEvent(
                bus,
                tick, day, hour, segment, weather,
                "SoumaRestNagaya", "SoumaAction",
                "souma", "", "place_nagaya", "souma",
                "trade_wares", 1, "motive_none", 0.30, 6.0, false, true,
                "BloodStainCleared=0;FatigueCleared=0",
                "Slept and cleaned clothes in Nagaya room",
                world, guard
            );
        }

        public static WorldEvent ExecuteSoumaElimination(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            string victimNpcId,
            bool isLoud,
            bool hideCorpse,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            int tabooMult = SimFestivalSystem.GetCurrentFestivalViolenceTabooMultiplier(bus, day);
            int vIdx = world.FindNpcIndexById(victimNpcId);
            string pId = world.Places[world.SoumaCurrentPlaceIdx].Id;

            if (vIdx >= 0)
            {
                world.Agents[vIdx].IsDead = true;
            }

            world.HeartWarmCold = Math.Max(-100, world.HeartWarmCold - ((isLoud ? 24 : 14) * tabooMult));
            if (isLoud)
            {
                world.BloodStainLevel = Math.Min(100, world.BloodStainLevel + 45);
                if (world.ActiveOdor != "FishSalt") world.ActiveOdor = "Blood";
                world.WoundCount += 1;
            }
            else
            {
                world.BloodStainLevel = Math.Min(100, world.BloodStainLevel + 10);
            }

            double vis = isLoud ? 1.25 : 0.15;
            double noise = isLoud ? 52.0 : 6.0;
            string actCode = isLoud ? "loud_violence" : "silent_elimination";

            WorldEvent evt = SimPerceptionSystem.EmitWorldEvent(
                bus,
                tick, day, hour, segment, weather,
                isLoud ? "LoudElimination" : "SilentElimination", "SoumaAction",
                "souma", victimNpcId, pId, "souma",
                actCode, 1, "motive_spy", vis, noise, isLoud, false,
                "NpcKilled:" + victimNpcId + ";Loud=" + (isLoud ? "true" : "false") + ";Hidden=" + (hideCorpse ? "true" : "false"),
                (isLoud ? "Loud clash with " : "Silent elimination of ") + victimNpcId,
                world, guard
            );

            CorpseRecord corp = new CorpseRecord();
            int nextC = world.Corpses.Count + 1;
            corp.Id = "corpse_" + nextC.ToString();
            corp.VictimNpcId = victimNpcId;
            corp.PlaceId = pId;
            corp.KilledDay = day;
            corp.KilledHour = hour;
            corp.CauseEventId = evt.Id;
            corp.IsHidden = hideCorpse;
            corp.IsDiscovered = false;
            corp.DiscoveredByNpcId = "";
            world.Corpses.Add(corp);

            SimNisshiCurator.RecordNisshiCandidate(
                bus, day, "JejakBayangan", evt.Id,
                "Hari " + day.ToString() + " — Pertikaian " + (isLoud ? "gaduh" : "senyap") + " melumpuhkan " + bus.LookupSubjectDisplayName(victimNpcId, world) + " di " + bus.LookupPlaceDisplayName(pId, world) + ".",
                0.98, 0.95
            );
            return evt;
        }

        public static WorldEvent ExecuteSoumaTrueFace(
            SimEventBus bus,
            int stage,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            world.TrueFaceStage = stage;
            string pId = world.Places[world.SoumaCurrentPlaceIdx].Id;

            if (stage == 1)
            {
                SimNisshiCurator.RecordKisahEvent(bus, day, hour, "WajahAsli_Tahap1_Retak", pId, "Wajah Asli Tahap 1 (Retak): Soma menurunkan pusat gravitasi tubuh; warga sekitar merasakan ketegangan halus (+8 kecurigaan).");
                return SimPerceptionSystem.EmitWorldEvent(
                    bus,
                    tick, day, hour, segment, weather,
                    "TrueFaceStage1_Retak", "SoumaAction",
                    "souma", "", pId, "souma",
                    "inspect_newcomers", 1, "motive_none", 0.90, 12.0, false, false,
                    "TrueFaceStage=1;NearbySuspicionDelta=+" + bus.Data.TrueFaceConfig.Stage1NearbySuspicionDelta.ToString(),
                    "True Face Stage 1 (Retak) posture shift",
                    world, guard
                );
            }
            else if (stage == 2)
            {
                world.TrueFaceActivationsCount += 1;
                world.CarryUnits = 0;
                world.GroupTrust = Math.Max(0, world.GroupTrust + bus.Data.TrueFaceConfig.GroupTrustDelta);
                world.HeartWarmCold = Math.Max(-100, world.HeartWarmCold - 15);
                world.DistrictCrackdownActive = true;
                world.CrackdownHoursRemaining = 48;

                int witnessCount = 0;
                for (int n = 0; n < world.Agents.Count; n++)
                {
                    if (!world.Agents[n].IsDead && !world.Agents[n].IsSleeping && !world.Agents[n].IsInTransit && world.Agents[n].CurrentPlaceIdx == world.SoumaCurrentPlaceIdx)
                    {
                        witnessCount += 1;
                    }
                }
                if (witnessCount < 1) witnessCount = 1;

                WorldEvent evt = SimPerceptionSystem.EmitWorldEvent(
                    bus,
                    tick, day, hour, segment, weather,
                    "TrueFaceStage2_Terbuka", "SoumaAction",
                    "souma", "", pId, "souma",
                    "true_face_exposed", witnessCount, "motive_spy", 1.50, 48.0, true, false,
                    "TrueFaceStage=2;CarryUnits=0;GroupTrustDelta=-10;Crackdown=true",
                    "True Face Stage 2 (Terbuka) lethal shinobi movement exposed",
                    world, guard
                );

                SimNisshiCurator.RecordKisahEvent(
                    bus,
                    day,
                    hour,
                    "WajahAsli_Tahap2_Terbuka",
                    pId,
                    "WAJAH ASLI TAHAP 2 (TERBUKA) DI " + world.Places[world.SoumaCurrentPlaceIdx].Name
                    + "! Biaya otomatis A.4.3 dieksekusi: Kecurigaan saksi +35, Rumor Baru (kekuatan 0.70), Kepercayaan Kelompok -10 (kini "
                    + world.GroupTrust.ToString() + "), kotak pikul jatuh (Stok=0), dan Razia aktif!"
                );
                SimNisshiCurator.RecordNisshiCandidate(
                    bus, day, "JejakBayangan", evt.Id,
                    "Hari " + day.ToString() + " — Terpaksa membuka Wajah Asli Tahap 2 (Terbuka) di hadapan " + witnessCount.ToString() + " saksi di " + world.Places[world.SoumaCurrentPlaceIdx].Name + "; kotak pikul ditinggalkan dan Kepercayaan Kelompok turun menjadi " + world.GroupTrust.ToString() + ".",
                    0.99, 0.96
                );
                return evt;
            }
            else
            {
                int escapeIdx = world.FindPlaceIndexById("place_kuil_kecil");
                if (escapeIdx < 0) escapeIdx = 0;
                world.SoumaCurrentPlaceIdx = escapeIdx;
                world.SoumaTargetPlaceIdx = escapeIdx;
                world.SoumaIsInTransit = false;
                world.SoumaPosX = (double)world.Places[escapeIdx].MapX;
                world.SoumaPosY = (double)world.Places[escapeIdx].MapY;
                world.TrueFaceStage = 0;

                SimNisshiCurator.RecordKisahEvent(bus, day, hour, "WajahAsli_Tahap3_Menghilang", pId, "Wajah Asli Tahap 3 (Menghilang): Soma melepaskan diri dari kepungan saksi menuju tempat persembunyian di " + world.Places[escapeIdx].Name + ".");
                return SimPerceptionSystem.EmitWorldEvent(
                    bus,
                    tick, day, hour, segment, weather,
                    "TrueFaceStage3_Menghilang", "SoumaAction",
                    "souma", "", pId, "souma",
                    "leave_post_early", 1, "motive_fear", 0.35, 16.0, false, false,
                    "TrueFaceStage=3;EscapedTo:" + world.Places[escapeIdx].Id,
                    "True Face Stage 3 (Menghilang) disengage",
                    world, guard
                );
            }
        }

        public static void EvaluateHourlyAutomatedSoumaPolicy(
            SimEventBus bus,
            ulong seed,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (world.SoumaManualOverride || !bus.EventEmitterEnabled || world.ActiveSoumaPolicy == "Idle")
            {
                return;
            }

            if (world.ActiveSoumaPolicy == "RecklessLoud")
            {
                if (hour == 11 && day % 2 == 1)
                {
                    ExecuteSoumaSteal(bus, tick, day, hour, segment, weather, world, guard);
                }
                if (hour == 13 && (day % 3 == 0 || day == 7 || day == 28))
                {
                    ExecuteSoumaTrueFace(bus, 2, tick, day, hour, segment, weather, world, guard);
                }
                if (hour == 15 && day == 6)
                {
                    int peddlerIdx = world.FindNpcIndexByDuty("fish_peddler");
                    string vicId = peddlerIdx >= 0 ? world.Agents[peddlerIdx].Id : (world.Agents.Count > 0 ? world.Agents[0].Id : "npc_0");
                    ExecuteSoumaElimination(bus, tick, day, hour, segment, weather, vicId, true, false, world, guard);
                }
                if (hour == 10 && world.CarryUnits > 0)
                {
                    SimEconomyAndPressureSystem.ExecuteSoumaTrade(bus, seed, tick, day, hour, segment, weather, world, guard);
                }
            }
            else
            {
                if ((hour == 9 || hour == 13) && !world.SoumaIsInTransit && world.CarryUnits > 0)
                {
                    SimEconomyAndPressureSystem.ExecuteSoumaTrade(bus, seed, tick, day, hour, segment, weather, world, guard);
                }
                if (world.ActiveSoumaPolicy == "HonestTrader" && hour == 15 && (day == 6 || day == 15 || day == 24) && bus.Data.Gigs.Count > 0)
                {
                    int gigIdx = (day / 6) % bus.Data.Gigs.Count;
                    SimGigSystem.ExecuteSoumaCompleteGig(bus, gigIdx, "Merciful", tick, day, hour, segment, weather, world, guard);
                }
                if (world.ActiveSoumaPolicy == "TraderInformant" && hour == 16 && !world.SoumaIsInTransit)
                {
                    for (int n = 0; n < world.Agents.Count; n++)
                    {
                        NpcRuntimeState ag = world.Agents[n];
                        if (!ag.IsDead && !ag.IsSleeping && !ag.IsInTransit && ag.CurrentPlaceIdx == world.SoumaCurrentPlaceIdx)
                        {
                            ExecuteSoumaInquireNpc(bus, tick, day, hour, segment, weather, ag.Id, world, guard);
                            break;
                        }
                    }
                }
                if ((world.ActiveSoumaPolicy == "TraderInformant" || world.ActiveSoumaPolicy == "Pemulih") && hour == 14 && (day % 4 == 2) && bus.Data.Gigs.Count > 0)
                {
                    int gigIdx = (day / 4) % bus.Data.Gigs.Count;
                    SimGigSystem.ExecuteSoumaCompleteGig(bus, gigIdx, "Clever", tick, day, hour, segment, weather, world, guard);
                }
                if (world.ActiveSoumaPolicy == "Pemulih" && hour == 16 && day >= 14 && !world.SoumaIsInTransit)
                {
                    for (int n = 0; n < world.Agents.Count; n++)
                    {
                        NpcRuntimeState ag = world.Agents[n];
                        if (!ag.IsDead && !ag.IsSleeping && !ag.IsInTransit && ag.CurrentPlaceIdx == world.SoumaCurrentPlaceIdx)
                        {
                            ExecuteSoumaInquireNpc(bus, tick, day, hour, segment, weather, ag.Id, world, guard);
                            break;
                        }
                    }
                }
                // E2.4: Pemain/kebijakan dapat turun tangan saat terjadi salah paham warga
                if (hour == 17 && bus.MisunderstandingChainsCount > bus.InterventionsExecutedCount)
                {
                    string mode = "MenyerahkanBukti";
                    if (world.ActiveSoumaPolicy == "HonestTrader") mode = "Bersaksi";
                    else if (world.ActiveSoumaPolicy == "Pemulih") mode = "MenyebarKabarTandingan";
                    ExecuteSoumaInterveneMisunderstanding(bus, mode, "", tick, day, hour, segment, weather, world, guard);
                }
            }
        }

        // Gelombang E (E2.4): Intervensi Soma terhadap Salah Paham NPC
        // Pilihan: "Bersaksi", "MenyerahkanBukti", "MenyuapPenjaga", "MenyebarKabarTandingan", "Membiarkan"
        public static WorldEvent ExecuteSoumaInterveneMisunderstanding(
            SimEventBus bus,
            string interventionType,
            string targetChainId,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            int targetChainIdx = -1;
            for (int c = bus.CausalChains.Count - 1; c >= 0; c--)
            {
                if (targetChainId.Length > 0 && bus.CausalChains[c].ChainId == targetChainId)
                {
                    targetChainIdx = c;
                    break;
                }
                if (targetChainId.Length == 0 && bus.CausalChains[c].IsMisunderstanding)
                {
                    targetChainIdx = c;
                    break;
                }
            }

            string pId = world.Places[world.SoumaCurrentPlaceIdx].Id;
            string accusedId = targetChainIdx >= 0 ? bus.CausalChains[targetChainIdx].SubjectNpcId : (world.Agents.Count > 0 ? world.Agents[0].Id : "npc_0");
            string accuserId = targetChainIdx >= 0 ? bus.CausalChains[targetChainIdx].RumorListenerNpcId : (world.Agents.Count > 1 ? world.Agents[1].Id : accusedId);
            string rootEventId = targetChainIdx >= 0 ? bus.CausalChains[targetChainIdx].RootEventId : (bus.EventLog.Count > 0 ? bus.EventLog[0].Id : "");
            WorldEvent rootEvt = rootEventId.Length > 0 ? bus.FindEventById(rootEventId) : new WorldEvent();
            string trueActorId = (rootEvt.Id.Length > 0 && rootEvt.SubjectId.Length > 0) ? rootEvt.SubjectId : accusedId;
            string truePlaceId = (rootEvt.Id.Length > 0 && rootEvt.PlaceId.Length > 0) ? rootEvt.PlaceId : pId;
            string actionTopic = (rootEvt.Id.Length > 0 && rootEvt.ActionCode.Length > 0) ? rootEvt.ActionCode : "hide_za_ledger";

            int guardIdx = world.FindActiveNpcIndexByRoleCategory("Guard");
            if (guardIdx < 0) guardIdx = 0;
            NpcRuntimeState guardNpc = world.Agents[guardIdx];
            int accuserIdx = world.FindNpcIndexById(accuserId);
            if (accuserIdx < 0) accuserIdx = guardIdx;
            int accusedIdx = world.FindNpcIndexById(accusedId);

            bus.InterventionsExecutedCount += 1;
            bus.StepCostAgencyOps += 2;

            string actionCode = "souma_intervene_testify";
            string outcomeStatus = "BERHASIL";
            string effectSummary = "";
            string kisahSummary = "";

            if (interventionType == "MenyerahkanBukti")
            {
                actionCode = "souma_intervene_evidence";
                bool hasTwoSourceProof = (bus.KabarUpgradedCount >= 1);
                if (!hasTwoSourceProof)
                {
                    for (int k = 0; k < bus.Kabars.Count; k++)
                    {
                        if (bus.Kabars[k].IndependentRootWitnesses.Count >= 2) { hasTwoSourceProof = true; break; }
                    }
                }

                if (hasTwoSourceProof && guardNpc.SuspicionTowardSouma < 55)
                {
                    outcomeStatus = "BERHASIL";
                    world.AddSuspicionReason(guardIdx, 8, "Pedagang keliling menyerahkan bukti silang yang terlalu rapi saat membela " + bus.LookupSubjectDisplayName(accusedId, world));
                    if (accusedIdx >= 0)
                    {
                        world.Agents[accusedIdx].NpcMon += 30;
                        world.Agents[accusedIdx].AttitudeTowardSouma = "BerhutangBudi";
                    }
                    world.HeartWarmCold = Math.Min(100, world.HeartWarmCold + 3);
                    effectSummary = "Intervention=MenyerahkanBukti;Outcome=BERHASIL;Cleared=" + accusedId + ";TrueSubject=" + trueActorId + ";GuardSuspDelta=+8";
                    kisahSummary = "INTERVENSI BERHASIL (Menyerahkan Bukti >=2 Sumber): Soma menyerahkan bukti kesaksian silang kepada " + guardNpc.DisplayName + ", membebaskan " + bus.LookupSubjectDisplayName(accusedId, world) + " dari tuduhan salah paham!";
                }
                else if (guardNpc.SuspicionTowardSouma >= 55)
                {
                    outcomeStatus = "BERBALIK";
                    world.AddSuspicionReason(guardIdx, 22, "BERBALIK CURIGA: Penjaga curiga mengapa pedagang keliling menyimpan bukti intelijen seperti mata-mata!");
                    world.SoumaMon = Math.Max(0, world.SoumaMon - 35);
                    world.TotalExpensesMon += 35;
                    world.UpdateMonBounds();
                    effectSummary = "Intervention=MenyerahkanBukti;Outcome=BERBALIK;GuardSuspDelta=+22;SoumaFined=35mon";
                    kisahSummary = "INTERVENSI BERBALIK (Backfire): " + guardNpc.DisplayName + " justru mencurigai mengapa Soma tahu begitu banyak detail tersembunyi (+22 Curiga, denda 35 mon)!";
                }
                else
                {
                    outcomeStatus = "GAGAL";
                    world.AddSuspicionReason(guardIdx, 6, "Mencoba membela warga tanpa bukti 2 saksi independen");
                    effectSummary = "Intervention=MenyerahkanBukti;Outcome=GAGAL;Reason=BuktiBelum2Sumber";
                    kisahSummary = "INTERVENSI GAGAL (Menyerahkan Bukti): Bukti Soma belum terverifikasi 2 sumber independen sehingga ditolak oleh " + guardNpc.DisplayName + ".";
                }
            }
            else if (interventionType == "MenyuapPenjaga")
            {
                actionCode = "souma_intervene_bribe";
                int bribeMon = 40;
                if (world.SoumaMon >= bribeMon)
                {
                    world.SoumaMon -= bribeMon;
                    world.TotalExpensesMon += bribeMon;
                    world.UpdateMonBounds();
                }

                if (guardNpc.Greed >= 5 && guardNpc.SuspicionTowardSouma < 40)
                {
                    outcomeStatus = "BERHASIL";
                    guardNpc.NpcMon += bribeMon;
                    if (accusedIdx >= 0) world.Agents[accusedIdx].AttitudeTowardSouma = "BerhutangBudi";
                    effectSummary = "Intervention=MenyuapPenjaga;Outcome=BERHASIL;Bribe=" + bribeMon.ToString() + "mon;Cleared=" + accusedId;
                    kisahSummary = "INTERVENSI BERHASIL (Menyuap Penjaga): Soma menyelipkan " + bribeMon.ToString() + " mon kepada " + guardNpc.DisplayName + " agar tuduhan salah paham terhadap " + bus.LookupSubjectDisplayName(accusedId, world) + " dihentikan.";
                }
                else
                {
                    outcomeStatus = "BERBALIK";
                    int fine = 30;
                    world.SoumaMon = Math.Max(0, world.SoumaMon - fine);
                    world.TotalExpensesMon += fine;
                    world.UpdateMonBounds();
                    world.AddSuspicionReason(guardIdx, 25, "Tertangkap mencoba menyuap penjaga saat penyelidikan salah paham!");
                    effectSummary = "Intervention=MenyuapPenjaga;Outcome=BERBALIK;GuardSuspDelta=+25;ExtraFine=" + fine.ToString() + "mon";
                    kisahSummary = "INTERVENSI BERBALIK (Suap Ditolak): " + guardNpc.DisplayName + " menolak uang suap Soma, menjatuhkan denda tambahan " + fine.ToString() + " mon, dan menaruh curiga keras (+25 Curiga)!";
                }
            }
            else if (interventionType == "MenyebarKabarTandingan")
            {
                actionCode = "souma_intervene_counter_rumor";
                int teaCost = 15;
                if (world.SoumaMon >= teaCost)
                {
                    world.SoumaMon -= teaCost;
                    world.TotalExpensesMon += teaCost;
                    world.UpdateMonBounds();
                }
                outcomeStatus = "BERHASIL";
                if (accusedIdx >= 0) world.Agents[accusedIdx].AttitudeTowardSouma = "Ramah";
                effectSummary = "Intervention=MenyebarKabarTandingan;Outcome=BERHASIL;Cost=15mon;Cleared=" + accusedId;
                kisahSummary = "INTERVENSI BERHASIL (Kabar Tandingan): Soma mentraktir teh seharga 15 mon dan mengembuskan kabar tandingan yang meluruskan nama " + bus.LookupSubjectDisplayName(accusedId, world) + " tanpa membuka samarannya.";
            }
            else if (interventionType == "Membiarkan")
            {
                actionCode = "souma_intervene_ignore";
                outcomeStatus = "DIBIARKAN";
                world.HeartWarmCold = Math.Max(-100, world.HeartWarmCold - 4);
                effectSummary = "Intervention=Membiarkan;Outcome=DIBIARKAN;HeartDelta=-4;Victim=" + accusedId;
                kisahSummary = "MEMBIARKAN SALAH PAHAM: Soma memilih diam demi keamanan samaran saat " + bus.LookupSubjectDisplayName(accusedId, world) + " menanggung akibat salah paham (Hati -4).";
            }
            else
            {
                // Default: "Bersaksi"
                actionCode = "souma_intervene_testify";
                if (guardNpc.SuspicionTowardSouma < 30 && world.BloodStainLevel == 0)
                {
                    outcomeStatus = "BERHASIL";
                    world.AddSuspicionReason(guardIdx, 6, "Kesaksian langsung pedagang keliling yang membela " + bus.LookupSubjectDisplayName(accusedId, world));
                    if (accusedIdx >= 0)
                    {
                        world.Agents[accusedIdx].NpcMon += 20;
                        world.Agents[accusedIdx].AttitudeTowardSouma = "Ramah";
                    }
                    world.HeartWarmCold = Math.Min(100, world.HeartWarmCold + 2);
                    effectSummary = "Intervention=Bersaksi;Outcome=BERHASIL;Cleared=" + accusedId + ";GuardSuspDelta=+6";
                    kisahSummary = "INTERVENSI BERHASIL (Bersaksi): Soma maju memberikan kesaksian langsung yang membebaskan " + bus.LookupSubjectDisplayName(accusedId, world) + " dari salah paham (+6 Curiga penjaga).";
                }
                else
                {
                    outcomeStatus = "GAGAL";
                    world.AddSuspicionReason(guardIdx, 12, "Kesaksian Soma diragukan karena gerak-geriknya sudah dicurigai penjaga");
                    effectSummary = "Intervention=Bersaksi;Outcome=GAGAL;GuardSuspDelta=+12";
                    kisahSummary = "INTERVENSI GAGAL (Bersaksi Ditolak): Karena penjaga sudah menaruh curiga (" + guardNpc.SuspicionTowardSouma.ToString() + "/100), kesaksian Soma tanpa bukti ditolak mentah-mentah!";
                }
            }

            WorldEvent intEvt = SimPerceptionSystem.EmitWorldEvent(
                bus, tick, day, hour, segment, weather,
                "SoumaIntervention", "SoumaAction",
                "souma", accuserId, pId, "souma",
                actionCode, 1, "motive_none", 0.90, 18.0, true, false,
                effectSummary,
                kisahSummary,
                world, guard
            );
            intEvt.IsUnpredictableFromSchedule = true;
            bus.UnpredictableCausalEventsCount += 1;

            // Update keyakinan NPC lewat mekanisme persepsi/ingatan yang sama (SimMemoryStore), bukan flag cerita!
            if (outcomeStatus == "BERHASIL")
            {
                MemoryEntry corrMem = new MemoryEntry();
                int nextMemNum = bus.Memories.Count + 1;
                corrMem.Id = "mem_" + nextMemNum.ToString();
                corrMem.OwnerNpcId = world.Agents[accuserIdx].Id;
                corrMem.Day = day;
                corrMem.Hour = hour;
                corrMem.PlaceId = pId;
                corrMem.SourceType = 0; // Disaksikan langsung dari intervensi Soma di pId
                corrMem.SourceEventId = intEvt.Id;
                corrMem.RootWitnessNpcId = "souma";
                corrMem.HopCount = 0;
                corrMem.Reliability = 0.92;
                corrMem.Tellable = true;
                corrMem.AppliedDistortionOperators = "ClarifiedByIntervention:" + trueActorId + "@" + truePlaceId;
                corrMem.Claim.SubjectId = "souma";
                corrMem.Claim.ActionCode = actionCode;
                corrMem.Claim.PlaceId = pId;
                corrMem.Claim.TimeLabel = segment + " (H" + day.ToString() + ")";
                corrMem.Claim.Quantity = 1;
                corrMem.Claim.MotiveId = "motive_none";
                corrMem.FormattedTextId = bus.FormatClaimFromTemplate(corrMem.Claim, world, false);
                corrMem.FormattedTextEn = bus.FormatClaimFromTemplate(corrMem.Claim, world, true);
                corrMem.SalienceScore = 0.84;
                corrMem.IsRoutineMemory = false;

                string ownerPlaceId = world.Places[world.Agents[accuserIdx].CurrentPlaceIdx].Id;
                if (ownerPlaceId == pId)
                {
                    guard.ValidateMemoryAgainstEventLog(corrMem, bus.EventLog, bus.Memories, ownerPlaceId, pId);
                }
                bus.Memories.Add(corrMem);
            }

            SimNisshiCurator.RecordKisahEventWithWhy(
                bus, day, hour, "IntervensiSalahPaham_" + outcomeStatus, pId,
                kisahSummary, intEvt.Id, world.Agents[accuserIdx].Id,
                "Intervensi '" + interventionType + "' atas rantai salah paham terhadap " + bus.LookupSubjectDisplayName(accusedId, world)
            );
            SimNisshiCurator.RecordNisshiCandidate(
                bus, day, "AgensiWarga", intEvt.Id,
                "Hari " + day.ToString() + " — " + kisahSummary + " (Jejak: " + (rootEventId.Length > 0 ? (rootEventId + " -> ") : "") + intEvt.Id + ").",
                0.93, 0.86
            );

            return intEvt;
        }
    }
}
