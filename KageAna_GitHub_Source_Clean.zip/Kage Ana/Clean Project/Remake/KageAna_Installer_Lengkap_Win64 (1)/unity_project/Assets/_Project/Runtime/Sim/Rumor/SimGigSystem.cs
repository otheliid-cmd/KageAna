// KAGE-ANA v3.0 Gelombang D (Butir 8) — Modul 9: Pekerjaan Sampingan (Gig Kitab 9.2) & Riak 1-3 Hari
// Pure C# in Runtime/Sim (tanpa UnityEngine).
using System;
using System.Collections.Generic;

namespace KageAna.Runtime.Sim
{
    public static class SimGigSystem
    {
        public static void EvaluateHourlyGigRipples(
            SimEventBus bus,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (bus.EventEmitterEnabled && hour == 10)
            {
                for (int r = 0; r < world.PendingGigRipples.Count; r++)
                {
                    PendingGigRipple rp = world.PendingGigRipples[r];
                    if (!rp.Fired && day >= rp.TriggerDay)
                    {
                        rp.Fired = true;
                        WorldEvent rpEvt = SimPerceptionSystem.EmitWorldEvent(
                            bus,
                            tick, day, hour, segment, weather,
                            "GigRipple", "WorldCondition",
                            rp.ActorNpcId, "souma", rp.PlaceId, rp.ActorNpcId,
                            "gig_ripple_event", 1, "motive_none", 1.0, 22.0, true, false,
                            "GigRippleFired:" + rp.GigId + "->" + rp.EffectSummary,
                            rp.EffectSummary,
                            world, guard
                        );
                        SimNisshiCurator.RecordKisahEventWithWhy(bus, day, hour, "RiakGig", rp.PlaceId, "RIAK GIG (" + rp.GigId + "): " + rp.EffectSummary, rpEvt.Id, rp.ActorNpcId, "Riak terjadwal 1-3 hari setelah penyelesaian Gig " + rp.GigId);
                        SimNisshiCurator.RecordNisshiCandidate(bus, day, "Gig", rpEvt.Id, "Hari " + day.ToString() + " — Riak pekerjaan sampingan terlihat di " + bus.LookupPlaceDisplayName(rp.PlaceId, world) + ": " + rp.EffectSummary + ".", 0.88, 0.78);
                    }
                }
            }
        }

        public static WorldEvent ExecuteSoumaCompleteGig(
            SimEventBus bus,
            int gigIdx,
            string chosenApproach,
            int tick,
            int day,
            int hour,
            string segment,
            string weather,
            SimPlaceGraphSystem world,
            NoFreeKnowledgeGuard guard)
        {
            if (gigIdx < 0 || gigIdx >= bus.Data.Gigs.Count) return new WorldEvent();
            SimGigDef gig = bus.Data.Gigs[gigIdx];
            for (int i = 0; i < world.CompletedGigIds.Count; i++)
            {
                if (world.CompletedGigIds[i] == gig.Id) return new WorldEvent();
            }

            world.CompletedGigIds.Add(gig.Id);
            world.SoumaMon += gig.RewardMon;
            world.TotalRevenueMon += gig.RewardMon;
            world.UpdateMonBounds();

            if (chosenApproach == "Merciful" || chosenApproach == "Social")
            {
                world.HeartWarmCold = Math.Min(100, world.HeartWarmCold + 6);
            }
            else if (chosenApproach == "Cruel" || chosenApproach == "Loud")
            {
                world.HeartWarmCold = Math.Max(-100, world.HeartWarmCold - 8);
            }

            string gigPlaceId = gig.Locations.Count > 0 ? gig.Locations[0] : world.Places[world.SoumaCurrentPlaceIdx].Id;

            PendingGigRipple rp = new PendingGigRipple();
            rp.GigId = gig.Id;
            rp.ActorNpcId = gig.GiverNpcId;
            rp.TriggerDay = day + gig.RippleDelayDays;
            rp.TriggerHour = 10;
            rp.ActionCode = "gig_ripple_event";
            rp.PlaceId = gig.RipplePlaceId;
            rp.EffectSummary = gig.RippleEffectSummary;
            rp.Fired = false;
            world.PendingGigRipples.Add(rp);

            WorldEvent gEvt = SimPerceptionSystem.EmitWorldEvent(
                bus,
                tick, day, hour, segment, weather,
                "SoumaCompleteGig", "SoumaAction",
                "souma", gig.GiverNpcId, gigPlaceId, "souma",
                "complete_gig", 1, "motive_none", 0.90, (chosenApproach == "Loud" ? 36.0 : 14.0), true, false,
                "GigCompleted:" + gig.Id + ";Approach=" + chosenApproach + ";Reward=+" + gig.RewardMon.ToString() + "mon;RippleDay=" + rp.TriggerDay.ToString(),
                "Completed Gig " + gig.Title + " via " + chosenApproach,
                world, guard
            );

            SimNisshiCurator.RecordKisahEventWithWhy(bus, day, hour, "GigSelesai", gigPlaceId, "Soma menyelesaikan Gig '" + gig.Title + "' (Pendekatan: " + chosenApproach + ", +" + gig.RewardMon.ToString() + " mon). Riak akan muncul pada Hari " + rp.TriggerDay.ToString() + "!", gEvt.Id, gig.GiverNpcId, "Permintaan warga " + gig.GiverNpcId + " diselesaikan dengan pendekatan " + chosenApproach);
            SimNisshiCurator.RecordNisshiCandidate(bus, day, "Gig", gEvt.Id, "Hari " + day.ToString() + " — Menyelesaikan Gig '" + gig.Title + "' dari " + bus.LookupSubjectDisplayName(gig.GiverNpcId, world) + " dengan pendekatan " + chosenApproach + " (+" + gig.RewardMon.ToString() + " mon).", 0.91, 0.80);
            return gEvt;
        }
    }
}
