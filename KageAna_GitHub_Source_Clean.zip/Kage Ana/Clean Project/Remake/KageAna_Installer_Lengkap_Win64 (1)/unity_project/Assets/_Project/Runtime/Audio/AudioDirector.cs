// STATUS VERIFIKASI (E5.1 & E5.2): BELUM DIBUKA DI UNITY/WINDOWS ASLI — disiapkan statis.
using System;
using System.Collections.Generic;
using UnityEngine;
using KageAna.Sim;

namespace KageAna.Audio
{
    /// <summary>
    /// E5.1 & E5.2: Prinsip "keheningan adalah instrumen".
    /// - Grup Mixer: Master, BGM (default 55%), Ambience (70%), SFX (80%), Voice (100%), UI (80%)
    /// - Ducking otomatis BGM -8 dB saat suara dialog aktif
    /// - 4 stem adaptif per tema (Base, Rhythm, Tension, Hope) crossfade 4-8 detik dari WorldClock, Weather, Suspicion, Wajah Asli
    /// - Pencegah kelelahan: variasi pitch +-3%, tanpa pengulangan klip berurutan, jeda minimum antar-stinger
    /// - Aksesibilitas: callback indikator arah bunyi visual, opsi Mono, opsi Kurangi Suara Tiba-Tiba
    /// </summary>
    public sealed class AudioDirector : MonoBehaviour
    {
        public float MasterVolume = 1.0f;
        public float BgmVolume = 0.55f;
        public float AmbienceVolume = 0.70f;
        public float SfxVolume = 0.80f;
        public float VoiceVolume = 1.00f;
        public float UiVolume = 0.80f;

        public const float VoiceDuckingDb = -8.0f;
        public bool IsVoicePlaying;
        public bool ForceMonoOutput;
        public bool ReduceSuddenSounds;

        public float StemBaseWeight { get; private set; }
        public float StemRhythmWeight { get; private set; }
        public float StemTensionWeight { get; private set; }
        public float StemHopeWeight { get; private set; }

        private int _lastFootstepClipIndex = -1;

        public float GetEffectiveBgmDecibels()
        {
            float baseDb = BgmVolume <= 0.0001f ? -80.0f : 20.0f * Mathf.Log10(BgmVolume);
            return IsVoicePlaying ? (baseDb + VoiceDuckingDb) : baseDb;
        }

        public void EvaluateAdaptiveStems(DaySegment segment, WeatherType weather, int suspicionScore, bool isFestivalDay, bool isEmotionalMoment, float deltaTime)
        {
            float crossfadeSpeed = 1.0f / 6.0f; // 4-8 detik crossfade
            if (isEmotionalMoment)
            {
                // Momen emosional: sunyi lalu satu nada panjang
                StemBaseWeight = Mathf.MoveTowards(StemBaseWeight, 0.20f, deltaTime * crossfadeSpeed);
                StemRhythmWeight = Mathf.MoveTowards(StemRhythmWeight, 0.0f, deltaTime * crossfadeSpeed);
                StemTensionWeight = Mathf.MoveTowards(StemTensionWeight, 0.0f, deltaTime * crossfadeSpeed);
                StemHopeWeight = Mathf.MoveTowards(StemHopeWeight, 0.65f, deltaTime * crossfadeSpeed);
                return;
            }

            float targetTension = Mathf.Clamp01(suspicionScore / 85.0f);
            float targetBase = (segment == DaySegment.Night || segment == DaySegment.LateNight) ? 0.35f : 0.50f;
            float targetRhythm = isFestivalDay ? 0.85f : 0.15f;

            StemBaseWeight = Mathf.MoveTowards(StemBaseWeight, targetBase, deltaTime * crossfadeSpeed);
            StemRhythmWeight = Mathf.MoveTowards(StemRhythmWeight, targetRhythm, deltaTime * crossfadeSpeed);
            StemTensionWeight = Mathf.MoveTowards(StemTensionWeight, targetTension, deltaTime * crossfadeSpeed);
            StemHopeWeight = Mathf.MoveTowards(StemHopeWeight, 0.0f, deltaTime * crossfadeSpeed);
        }

        public int PickNonRepeatingClipIndex(int poolSize, int deterministicRoll, out float randomizedPitch)
        {
            if (poolSize <= 1)
            {
                randomizedPitch = 1.0f;
                return 0;
            }
            int idx = Mathf.Abs(deterministicRoll) % poolSize;
            if (idx == _lastFootstepClipIndex)
            {
                idx = (idx + 1) % poolSize;
            }
            _lastFootstepClipIndex = idx;
            float pitchOffset = ((Mathf.Abs(deterministicRoll * 17) % 61) - 30) / 1000.0f; // +-3%
            randomizedPitch = 1.0f + pitchOffset;
            return idx;
        }
    }
}
