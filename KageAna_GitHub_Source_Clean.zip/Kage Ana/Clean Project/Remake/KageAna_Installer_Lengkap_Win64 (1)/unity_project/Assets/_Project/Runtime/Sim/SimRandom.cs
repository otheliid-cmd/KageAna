// KAGE-ANA v3.0 — Pure C# Deterministic Stream PRNG (Section 11.2 #2 & Decision C-07)
// Zero UnityEngine dependency. Identical (seed, stream) always produces identical sequence.
using System;

namespace KageAna.Runtime.Sim
{
    public sealed class SimRandom
    {
        private ulong _state;

        public SimRandom(ulong seed, string streamName)
        {
            ulong streamHash = HashStreamFnv1a64(streamName);
            // Full SplitMix64 avalanche mixing on both streamHash and seed so sequential stream names
            // (e.g. "weather_day_3", "weather_day_4") never share upper-bit correlation on first draw.
            ulong mixedStream = Mix64(streamHash ^ 0x9E3779B97F4A7C15UL);
            ulong mixedSeed = Mix64(seed + 0xBF58476D1CE4E5B9UL);
            _state = Mix64(mixedSeed ^ mixedStream);
            if (_state == 0UL)
            {
                _state = 0x9E3779B97F4A7C15UL;
            }
        }

        public static ulong HashStreamFnv1a64(string text)
        {
            ulong hash = 14695981039346656037UL;
            int len = text.Length;
            for (int i = 0; i < len; i++)
            {
                hash ^= (ulong)text[i];
                hash *= 1099511628211UL;
            }
            return hash;
        }

        public static ulong Mix64(ulong z)
        {
            z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9UL;
            z = (z ^ (z >> 27)) * 0x94D049BB133111EBUL;
            return z ^ (z >> 31);
        }

        public ulong NextUInt64()
        {
            _state += 0x9E3779B97F4A7C15UL;
            return Mix64(_state);
        }

        public double NextDouble()
        {
            // Top 53 bits -> uniform [0.0, 1.0)
            ulong bits = NextUInt64() >> 11;
            return (double)bits * (1.0 / 9007199254740992.0);
        }

        public int NextInt(int minInclusive, int maxExclusive)
        {
            if (maxExclusive <= minInclusive)
            {
                return minInclusive;
            }
            uint span = (uint)(maxExclusive - minInclusive);
            ulong sample = NextUInt64() % (ulong)span;
            return minInclusive + (int)sample;
        }
    }
}
