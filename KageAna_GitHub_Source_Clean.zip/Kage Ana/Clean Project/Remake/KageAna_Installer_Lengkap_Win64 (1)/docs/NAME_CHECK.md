# DAFTAR PEMERIKSAAN NAMA & MEREK DAGANG — KAGE-ANA (影穴)
**Status (E7):** Daftar tugas verifikasi untuk dijalankan pengguna di jaringan internet terbuka. Jangan mengklaim nama bebas sengketa sebelum seluruh baris di bawah ini diperiksa dan dicatat tanggalnya.
**Nama Utama:** **KAGE-ANA (影穴)**
**Subjudul Toko Aplikasi (Opsional):** *"Pedagang di siang hari. Bayangan di malam hari."*

## Tabel Pemeriksaan Mandiri oleh Pengguna
| Saluran Pemeriksaan | Kueri Pencarian | Status Saat Ini | Tanggal Periksa | Catatan / Bukti Tangkapan Layar |
|---|---|---|---|---|
| **Steam Store** | `"Kage-Ana"`, `"Kage Ana"`, `"影穴"` | `BELUM DIPERIKSA PENGGUNA` | — | Periksa kategori perangkat lunak hiburan |
| **Google Play Store (Android)** | `"Kage-Ana"`, `"Kage Ana"` | `BELUM DIPERIKSA PENGGUNA` | — | Pastikan `applicationId` `com.kageana.kurokawa` belum terpakai |
| **PDKI DJKI Indonesia (Merek Kelas 9 & 41)** | `"KAGE-ANA"`, `"KAGE ANA"` | `BELUM DIPERIKSA PENGGUNA` | — | `https://pdki-indonesia.dgip.go.id/` |
| **USPTO / WIPO Global Brand Database** | `"KAGE-ANA"` (Nice Class 9, 41) | `BELUM DIPERIKSA PENGGUNA` | — | `https://branddb.wipo.int/` |
| **Domain Web & Media Sosial** | `kageana.com`, `kage-ana.jp` | `BELUM DIPERIKSA PENGGUNA` | — | Opsional untuk halaman pers |
