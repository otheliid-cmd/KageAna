# CARA UJI APK ANDROID (1 HALAMAN) — KAGE-ANA (E9.2)
1. **Cara Memasang APK Uji:** Hubungkan ponsel Android ke PC dengan kabel data, salin `Build/Android/KageAna_Debug_IrisanVertikal.apk`, buka melalui aplikasi *Files by Google*, izinkan *"Pasang aplikasi tidak dikenal"* khusus untuk aplikasi pengelola berkas tersebut, pasang APK, lalu **matikan kembali izin tersebut** demi keamanan ponsel Anda.
2. **Izin & Penyimpanan:** Aplikasi hanya menulis ke ruang terisolasi `Application.persistentDataPath` tanpa meminta izin kamera, kontak, lokasi, atau internet.
3. **Kontroler Bluetooth:** Pasangkan kontroler Xbox / DualSense / Switch Pro lewat menu Bluetooth Android sebelum membuka aplikasi, atau gunakan kontrol sentuh bawaan (≥ 48 dp, opsi kidal di menu Pengaturan).
4. **Mengirim Laporan Uji & Log:** Buka menu Pengembang di pojok atas → ketuk **"Kirim Laporan Uji"** untuk mengemas log sesi dan metrik FPS ke berkas `.zip` di `persistentDataPath` yang langsung membuka *Share Sheet* Android.
