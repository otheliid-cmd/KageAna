# DESIGN_REFERENCE.md — Core Loop, Mechanical Parameters & Scope Control

## 1. One-Sentence Core Loop
> **"Observe guard patrol & lantern light cones → traverse dark rooftops or extinguish lights → execute silent elimination or deflect blade in weighty duel → reach the Watchtower objective without raising the district alarm."**

## 2. Extracted & Validated Mechanical Parameters

### 2.1 Player Locomotion & Parkour
| Parameter | Value | Unit | Notes |
| :--- | :--- | :--- | :--- |
| Walk Speed | `3.6` | m/s | Balanced pace, moderate footstep noise |
| Sprint Speed | `7.4` | m/s | High acoustic footprint; drains stamina (`12/s`) |
| Crouch Speed | `1.9` | m/s | Near-silent (`3 dB`), lowers eye height from `1.68m` to `1.05m` |
| Jump Velocity | `6.8` | m/s | Allows reaching `y = 3.2m` *Engawa*/roof eaves via stepping crates |
| Ledge Mantle Reach | `1.5` | m | Automatic climb onto white-cloth-marked (*Sarashi*) roof ledges |
| Max Stamina | `100` | pts | Regenerates at `18/s` when grounded and not sprinting/swinging |

### 2.2 Surface Acoustics Table
| Surface Type | Base Walk dB | Crouch dB | Sprint dB | Slippery When Steep |
| :--- | :--- | :--- | :--- | :--- |
| `Tatami` | `4` | `1` | `10` | No |
| `Wood` (*Engawa*) | `14` | `4` | `26` | No |
| `Stone` (Main Road) | `11` | `3` | `22` | No |
| `ClayTile` (*Kawara* Roof) | `20` | `5` | `36` | Yes (`> 24°`) |
| `Gravel` (Courtyard) | `26` | `7` | `44` | No |

### 2.3 Combat & Game Feel Parameters
| Action | Windup | Active Strike | Recovery | Hit-Stop | Stamina Cost |
| :--- | :--- | :--- | :--- | :--- | :--- |
| Katana Heavy Slash (`LMB`) | `0.15s` | `0.12s` | `0.35s` | `65 ms` | `20` |
| Katana Thrust / Stealth Kill (`RMB` / `F`) | `0.18s` | `0.10s` | `0.38s` | `80 ms` | `22` |
| Blade Deflect / Parry (`Q`) | `0.04s` | `0.24s` | `0.20s` | `55 ms` | `10` |
| Kunai Throw (`K` — Snipes Lanterns/Guards) | `0.08s` | `0.05s` | `0.25s` | `40 ms` | `8` |

### 2.4 Guard AI Perception & State Machine
- **States**: `PATROL` (0–29% suspicion) → `SUSPICIOUS` (30–69%: stops, turns toward stimulus) → `SEARCH` (70–99%: walks to last known sound/sight position) → `COMBAT` (100%: alerts nearby guards within 16m, closes distance, telegraphs overhead slash).
- **Vision Cone**: `75°` half-angle, `18m` range in lit zones, reduced to `6.5m` when player is crouched in shadow or when nearby *Tōrō* lantern is extinguished.

## 3. What Worked vs. What Is Frozen (Section 5.7 Scope Control)
### Kept for Vertical Slice (High Impact, Proven Fun)
- First-person rooftop & shadow stealth across a focused `60×60 m` Sengoku courtyard.
- Interactive lighting: extinguishing stone lanterns (`[E]` up close or `[K]` Kunai from afar) to create real shadow paths.
- Weighty non-spammable Katana slash, parry deflect with metallic sparks, and `65 ms` hit-stop.
- Distinct 3D character silhouettes (Shinobi, Samurai Guard, Peasant, Monk).

### Frozen Until After Vertical Slice Approval (Section 5.7)
- Multi-district 6-zone open world, Ryo currency economy, clan conflict meter, multi-option NPC chat trees, graveyard soil-push minigame, poison nets, and per-limb dismemberment IK.
