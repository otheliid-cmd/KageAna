# PANDUAN CASTING SUARA JEPANG ASLI — KAGE-ANA (影穴)
**Status (E6.5):** Panduan Audisi Pengisi Suara Penutur Asli Jepang (Tanpa Suara Sintetis untuk Rilis).
**Arah Umum:** Bahasa Jepang era lampau/Sengoku yang terdengar wajar dan membumi (bukan gaya anime modern hiperbolik). Prioritas pada kalimat pendek (*bark*), sapaan pasar, gumaman, tawa, batuk, dan bisikan. Percakapan panjang tampil sebagai teks Bahasa Indonesia dengan *bark* pembuka.

## Profil Suara Utama & Baris Audisi Contoh
1. **Shinonome Sōma (Pria, usia tampak 26 — Bariton muda hangat di siang hari, tenang lirih di malam hari):**
   - *Audisi 1 (Omote - Ramah menawarkan barang):* 「いらっしゃい。良い油と薬が入ったよ。」 (*Irasshai. Yoi abura to kusuri ga haitta yo.* — Silakan mampir. Minyak dan obat bagus baru masuk.)
   - *Audisi 2 (Ura - Gumaman batin saat salah paham):* 「……違う、あの男じゃない。」 (*...Chigau, ano otoko janai.* — ...Bukan, bukan pria itu pelakunya.)
2. **O-Hana (Wanita, usia tampak 42 — Induk semang Nagaya, tegas namun berhati hangat):**
   - *Audisi 1 (Menagih sewa):* 「颯真！今月の店賃、忘れてないだろうね？」 (*Souma! Kongetsu no tana-chin, wasuretenai darou ne?* — Sōma! Sewa bulan ini tidak kau lupakan, kan?)
   - *Audisi 2 (Iba melihat Sōma kesulitan):* 「ったく……温かい汁でも飲んでいきな。」 (*Ttakku... atatakai shiru demo nonde ikina.* — Dasar kau ini... minumlah sup hangat dulu sebelum pergi.)
3. **O-Kiku (Wanita, usia tampak 27 — Pemilik Kedai Teh Pasar, lembut namun jeli):**
   - *Audisi 1:* 「お茶が冷めますよ。今日も妙な噂が流れていますね。」 (*Ocha ga samemasu yo. Kyou mo myou na uwasa ga nagarete imasu ne.* — Tehnya nanti dingin. Hari ini pun kabar aneh sedang mengalir ya.)
4. **Ryōta (Pria, usia tampak 22 — Penjaga Gerbang, agak santai/konyol namun tegas saat curiga):**
   - *Audisi 1:* 「ふぁあ……また雨か。おい商人、荷を見せろ。」 (*Fuaa... mata ame ka. Oi shounin, ni wo misero.* — Huaah... hujan lagi ya. Hei pedagang, perlihatkan bawaanmu.)
