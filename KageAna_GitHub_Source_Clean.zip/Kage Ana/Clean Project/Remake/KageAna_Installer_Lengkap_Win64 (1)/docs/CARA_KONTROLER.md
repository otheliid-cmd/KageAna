# PANDUAN KONTROLER (GAMEPAD, SENTUH, KEYBOARD+MOUSE) — KAGE-ANA (E8)

## 1. Skema Input Tunggal (14 Aksi)
| Aksi | Keyboard + Mouse | Gamepad (Xbox / PS / Switch Pro) | Layar Sentuh Android (≥ 48 dp, Opsi Kidal) |
|---|---|---|---|
| **Gerak** | `WASD` / Panah | Stik Kiri / D-Pad | Joystik Virtual Kiri |
| **Kamera** | Geser Mouse | Stik Kanan | Geser Layar Kanan |
| **Interaksi (Dagang/Bukti)** | `E` / `1` | `A` / `Cross` / `B` | Tombol Aksi Kontekstual Utama |
| **Tanya / Bicara NPC** | `F` / `2` | `X` / `Square` / `Y` | Tombol Dialog Kontekstual |
| **Mengendap (Crouch)** | `Ctrl` / `C` | `B` / `Circle` / `A` | Tombol Jongkok |
| **Lari** | `Shift` | `LB` / `L1` / `L` | Dorong penuh Joystik Kiri |
| **Sembunyi / Ganti Omote-Ura** | `Z` / `3` | `RB` / `R1` / `R` | Tombol Salin Pakaian / Bayangan |
| **Buka Nisshi (Catatan Harian)** | `J` / `Tab` | `View` / `Share` / `-` | Ketuk Ikon Gulungan Nisshi |
| **Menu** | `Esc` | `Menu` / `Options` / `+` | Ketuk Ikon Kamon Pojok |
| **Konfirmasi / Batal** | `Enter` / `Esc` | `A` / `B` (`Cross` / `Circle`) | Ketuk Tombol Ya / Kembali |
| **Fokus (Bidik Pandang)** | `Klik Kanan` | `LT` / `L2` / `ZL` | Tahan Ikon Mata |
| **Wajah Asli** | `V` / `5` | `LT + RT` bersamaan | Tombol Khusus (Muncul Saat Terdesak) |
| **Tindakan Khusus (Campur Tangan Salah Paham E2.4)** | `G` / `6` | `Y` / `Triangle` / `X` | Tombol Campur Tangan Salah Paham |

## 2. Cara Memasangkan Kontroler Bluetooth di Windows & Android
1. **Xbox Wireless Controller:** Tekan dan tahan tombol *Pair* di bagian atas selama 3 detik hingga logo Xbox berkedip cepat, lalu pilih `Xbox Wireless Controller` di menu Bluetooth Windows 10/11 atau Android.
2. **PlayStation DualSense / DualShock 4:** Tekan dan tahan tombol `Create/Share + Tombol PS` bersamaan hingga lampu berkedip ganda, lalu pasangkan di menu Bluetooth.
3. **Nintendo Switch Pro Controller:** Tekan tombol *Sync* kecil di samping port USB-C hingga lampu indikator berjalan bolak-balik.

## 3. Daftar Jujur Perangkat Keras yang BELUM DIUJI Fisik (E8)
- Uji logika untuk ke-14 aksi pada 3 skema dilakukan melalui simulasi kode (`InputAndBridgeEditModeTests.cs`) dan dukungan XInput/WinMM di `SandboxProgram.cs`.
- Perangkat fisik nyata (**Xbox Series Controller**, **PS5 DualSense**, **Switch Pro Controller**, **8BitDo Pro 2**, dan layar sentuh ponsel Android nyata) **BELUM DIPEGANG/DIUJI FISIK** di dalam wadah ini dan harus diverifikasi oleh pengguna menggunakan *Unity Input Debugger*.
