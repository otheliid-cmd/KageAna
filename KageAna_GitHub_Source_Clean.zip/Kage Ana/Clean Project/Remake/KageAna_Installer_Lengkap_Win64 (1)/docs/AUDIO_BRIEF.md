# BRIEF KOMPOSER & PERANCANG SUARA — KAGE-ANA (影穴)
**Status (E5.3):** Dokumen Sutradara Audio untuk Kontrak Komposer (*Work-for-Hire / Buyout*).
**Prinsip Utama:** *Keheningan adalah instrumen.* Pada banyak waktu tidak ada musik sama sekali, hanya ambience. Musik hadir singkat untuk menandai pergantian waktu (senja, ketegangan, kelegaan), lalu menghilang. Tidak boleh ada melodi pendek yang berulang mencolok dalam 20 menit.

## 1. Spesifikasi Teknis Penyerahan Aset
- **Format Rekaman:** WAV 48 kHz, 24-bit (uncompressed), *loop-ready* dengan titik *zero-crossing* bersih + penyerahan berkas proyek mentah dan stem terpisah.
- **Struktur Stem Adaptif (4 Stem per Komposisi Inti):**
  1. `Stem_01_Base`: Drone ruang / napas shakuhachi jarang.
  2. `Stem_02_Rhythm`: Denyut kayu/koto lembut atau ketukan festival.
  3. `Stem_03_Tension`: Ketukan rendah & petikan shamisen *staccato* tipis (naik perlahan mengikuti `Suspicion`; **tanpa jump-scare** atau stinger keras).
  4. `Stem_04_Hope`: Satu nada panjang koto/biwa hangat saat salah paham pulih atau fajar tiba.

## 2. Daftar 8 Komposisi Inti & Ambience
| ID | Judul Tema | Suasana & Instrumentasi | Durasi Target |
|---|---|---|---|
| `BGM_01_PasarSiang` | Pasar Kaki Kastil (Omote) | Kerumunan rendah, sandal kayu di tanah, petikan koto/biwa jarang dan hangat | 3 mnt (4 stem) |
| `BGM_02_SenjaPergantian` | Lentera Pertama Menyala | Transisi ukiyo-e ke sumi-e; tiupan shakuhachi tunggal memanjang | 1.5 mnt (4 stem) |
| `BGM_03_MalamMengendap` | Lorong Nagaya (Ura) | Hampir hening; serangga malam, gesekan kain, denyut taiko sangat jauh | 3.5 mnt (4 stem) |
| `BGM_04_KecurigaanNaik` | Bayangan yang Dilirik | Shamisen staccato tipis + detak rendah adaptif menurut `Suspicion` | 2.5 mnt (4 stem) |
| `BGM_05_WajahAsli` | Retakan Topeng | Satu tarikan napas tertahan + resonansi lonceng perunggu rendah | 0.5 mnt (stinger halus) |
| `BGM_06_FestivalObonHanami` | Malam Seribu Lentera | Ritme hangat fue & taiko perayaan empat musim (Obon, Setsubun, Hanami, Aki Matsuri) | 3 mnt (4 stem) |
| `BGM_07_SalahPahamTerbongkar` | Harga Sebuah Kabar | Sunyi 2 detik lalu satu nada biwa panjang yang getir | 1.5 mnt (4 stem) |
| `BGM_08_FajarPulih` | Buka Warung Kembali | Udara pagi, burung jauh, koto gading yang tenang | 2 mnt (4 stem) |

## 3. Perkiraan Anggaran Komposer & Foley (Asumsi Eksplisit, Bukan Harga Pasti)
- **Asumsi Tarif Indie Asia Tenggara / Jepang (Buyout Komersial Penuh tanpa Royalti):**
  - Musik Adaptif (±18 menit total dipecah ke 8 komposisi × 4 stem): asumsi USD $120–$220 per menit selesai → **±USD $2.160 – $3.960** (±Rp 34 juta – Rp 63 juta).
  - Paket Foley Organik Kustom (5 permukaan langkah × 6 variasi, gesekan kain Omote/Ura, pintu shoji, sempoa, lentera, sekitar 80 klip SFX): asumsi USD $15–$30 per klip → **±USD $1.200 – $2.400** (±Rp 19 juta – Rp 38 juta).
  - **Total Perkiraan Anggaran Audio Final:** **±USD $3.360 – $6.360** (tergantung negosiasi dan lisensi paket CC0/komersial pendamping).
