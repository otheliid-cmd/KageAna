# DAFTAR PERIKSA KONTRAK PENGISI SUARA (VOICE ACTOR CHECKLIST) — KAGE-ANA
**Peringatan Penting (E6.5):** Dokumen ini adalah daftar periksa produser teknis, **BUKAN nasihat hukum**. Pengguna wajib berkonsultasi dengan konsultan hukum/pengacara HKI sebelum menandatangani kontrak rekaman komersial.

## Butir Wajib dalam Perjanjian Tertulis (*Work-for-Hire / Buyout*)
- [ ] **1. Cakupan Wilayah & Komersial:** Hak distribusi komersial di seluruh dunia (*worldwide commercial release*).
- [ ] **2. Cakupan Platform:** Mencakup PC (Windows/Steam), perangkat seluler (Android/Google Play), konsol masa depan, dan materi promosi/trailer.
- [ ] **3. Jangka Waktu:** Berlaku selamanya (*in perpetuity*) untuk proyek `KAGE-ANA` beserta pembaruan/sekuel langsung yang disepakati.
- [ ] **4. Hak Penyuntingan Teknis:** Izin tertulis untuk memotong, menyesuaikan volume/EQ, menambahkan efek ruang (reverb), dan memasangkan dengan sistem *lip-sync* visem.
- [ ] **5. Klausul Perlindungan AI (Wajib Jelas):** Larangan tegas bagi pengembang maupun pihak ketiga untuk menggunakan rekaman suara aktor guna melatih model kloning suara AI / TTS tanpa persetujuan tertulis terpisah.
- [ ] **6. Penyerahan Berkas Mentah:** Aktor menyerahkan WAV 48 kHz / 24-bit bersih tanpa musik latar atau kompresi merusak.
- [ ] **7. Pencantuman Kredit:** Nama panggung yang disepakati untuk dicantumkan di layar kredit & `ASSETS_LICENSE.md`.
- [ ] **8. Struktur Tarif & Pembayaran:** Tarif per baris (*per-line*) atau per sesi (*per-hour buyout*) tanpa kewajiban royalti berulang yang menghambat rilis indie.
