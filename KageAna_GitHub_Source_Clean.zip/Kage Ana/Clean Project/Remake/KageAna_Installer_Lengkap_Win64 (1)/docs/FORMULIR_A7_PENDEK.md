# FORMULIR PENDEK A.7 (LATAR PRIBADI SŌMA) — DAPAT DIJAWAB DALAM 10 MENIT
**Aturan Kejujuran (E7):** Selama formulir ini belum dijawab pengguna, seluruh kolom `[ISI-PENGGUNA]` di `unity_project/Assets/_Project/Data/player/souma.json` dan `group_orders.json` tetap memakai awalan **`TEMP_`**.

Pilih satu huruf (A/B/C) atau tulis satu kalimat singkat untuk 5 pertanyaan di bawah ini:

1. **Kanji Nama Depan Sōma (`givenNameKanji_ISI_PENGGUNA`):**
   - [ ] **A.** 颯真 (Sōma — angin menderu & kebenaran)
   - [ ] **B.** 蒼馬 (Sōma — kuda biru pucat)
   - [ ] **C.** Lainnya (tuliskan): `____________________`

2. **Nama Samaran Publik Kelompok (`affiliatedGroupPublicName_ISI_PENGGUNA`):**
   - [ ] **A.** Serikat Pengangkut Garam Lembah Barat
   - [ ] **B.** Perguruan Juru Tulis & Ukur Tanah
   - [ ] **C.** Lainnya (tuliskan): `____________________`

3. **Alasan Sōma Masuk ke Lembah Kurokawa (`personalBackstory_ISI_PENGGUNA.motive`):**
   - [ ] **A.** Menebus utang nyawa keluarganya kepada sang mentor
   - [ ] **B.** Mencari jejak adiknya yang hilang saat perang perbatasan
   - [ ] **C.** Lainnya (tuliskan): `____________________`

4. **Rahasia yang Disembunyikan Sōma dari Kelompoknya Sendiri (`secretFromGroup`):**
   - [ ] **A.** Ia pernah sengaja mengaburkan satu laporan agar seorang warga tak bersalah selamat
   - [ ] **B.** Ia berencana memutus ikatan dan menetap sebagai pedagang sungguhan
   - [ ] **C.** Lainnya (tuliskan): `____________________`

5. **Hubungan Sōma dengan Muraku / Kontak Tua di Desa (`relationToMuraku`):**
   - [ ] **A.** Muraku adalah mantan rekan ayahnya yang pura-pura tidak mengenal Sōma
   - [ ] **B.** Muraku adalah pengawas lama yang mulai ragu pada perintah kelompok
   - [ ] **C.** Lainnya (tuliskan): `____________________`
