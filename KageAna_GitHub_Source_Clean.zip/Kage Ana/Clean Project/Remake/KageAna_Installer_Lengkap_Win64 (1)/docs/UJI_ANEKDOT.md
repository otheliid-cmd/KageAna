# PROTOKOL UJI ANEKDOT v2 — Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)

> **Dokumen Resmi Gelombang D (Butir 7 — Gerbang 1 Pilot)**
> Protokol ini merevisi penuh versi Gelombang C yang sebelumnya menggiring jawaban penguji. Tujuan utama protokol v2 adalah menguji secara jujur apakah seseorang yang mencoba **Sandbox Uji Sistem (2D dari atas, BUKAN tampilan final)** selama 20–45 menit dapat menceritakan **satu kejadian spesifik yang tak dirancang, tanpa diberi petunjuk atau pancingan topik**.

---

## 1. Struktur Dua Tahap: Pilot 2 Orang Lalu Uji Utama 5 Orang

Jangan langsung menjalankan uji ke 5 orang sekaligus. Lakukan dalam dua tahap berurutan:

| Tahap | Jumlah Penguji | Durasi Sesi | Tujuan & Ambang Lanjut |
| :--- | :--- | :--- | :--- |
| **Tahap 1: Sesi Pilot** | **2 orang asing** (belum pernah membaca dokumen desain atau kode) | **20 menit** per orang (Mode Manual bawaan) | Menguji keterbacaan antarmuka ("Kisah Hari Ini", dialog "Tanya NPC", kartu petunjuk 1 layar) dan mengisi **Lembar Catatan Kebingungan**. Minimal **1 dari 2 penguji pilot** harus mampu menceritakan 1 kejadian spesifik yang cocok dengan log sebelum lanjut ke Tahap 2. Jika 0/2, perbaiki antarmuka yang membingungkan terlebih dahulu. |
| **Tahap 2: Uji Utama Gerbang 1** | **5 orang asing baru** (di luar 2 penguji pilot) | **30–45 menit** per orang (Mode Manual bawaan) | Menguji syarat **Gerbang 1**: minimal **3 dari 5 penguji (`>= 60%`)** menceritakan satu kisah spesifik dari pengalamannya sendiri tanpa diarahkan, yang saat diperiksa penilai secara buta terbukti cocok dengan rantai sebab-akibat (`>= 3` kejadian) di berkas log. |

---

## 2. Aturan Ketat Sebelum & Selama Sesi (Tanpa Pengarahan)

1. **Pemasangan Mandiri**: Berikan hanya berkas `KageAna_Sandbox_Uji_Setup.exe` (atau paket portabel jika memakai fallback) dan 1 halaman `CARA_UJI_COBA.md`. Biarkan penguji memasang dan membuka sendiri aplikasi.
2. **Dilarang Memberi Petunjuk Lisan**: Selama 20–45 menit sesi berlangsung, pengamat **dilarang keras** menjelaskan siapa NPC tertentu, menyuruh penguji pergi ke tempat tertentu, atau menjelaskan arti angka/rumor.
3. **Kartu Petunjuk Awal 1 Layar**: Penguji hanya membaca kartu petunjuk non-modal di layar (yang dapat ditutup kapan saja) dan mengikuti umpan **"1. KISAH HARI INI"** serta tombol **"Tanya NPC (Dialog)"**.
4. **Pengumpulan Bukti Otomatis**: Di akhir sesi, minta penguji mengklik menu **`Bantuan -> Kirim laporan uji`** (yang menghasilkan berkas `Laporan_Uji_KageAna_<waktu>.zip` di Desktop berisi rekaman sesi `sesi_*.jsonl`) dan klik **`Pengembang -> Ekspor Nisshi ke Berkas Teks (.txt)`**.

---

## 3. Urutan Wawancara Pasca-Sesi (WAJIB TANPA GIRING)

> **PERINGATAN KERAS**: Pada Gelombang C, pertanyaan wawancara menyebut kata *"kabar burung"*, *"berubah bentuk"*, dan *"mengapa NPC curiga"*, sehingga menggiring penguji mengarang jawaban sesuai istilah sistem. Pada v2 ini, **Pertanyaan 1 wajib diajukan apa adanya, kata demi kata, dan direkam/dicatat selesai sebelum pertanyaan lanjutan boleh diucapkan.**

### Langkah A — Pertanyaan Pertama (Tanpa Giring, Wajib Dicatat Mentah)

Ajukan kalimat tunggal ini:

> **Pertanyaan 1 (Utama & Tanpa Giring):**
> *"Ceritakan satu kejadian yang kamu ingat."*

* **Aturan Pencatatan**:
  - Biarkan penguji bercerita bebas dengan bahasanya sendiri.
  - Jangan menyela, jangan bertanya *"Apakah itu karena rumor?"*, dan jangan meminta penguji menyebutkan 3 mata rantai.
  - Tulis/rekam jawaban Pertanyaan 1 hingga tuntas, lalu **kunci catatan Jawaban 1** (beri stempel waktu). Hanya Jawaban 1 (ditambah klarifikasi faktual di Langkah B bila nama tokoh lupa) yang sah dinilai untuk syarat tidak diarahkan.

### Langkah B — Pertanyaan Lanjutan (HANYA SETELAH Jawaban 1 Selesai Dicatat)

Setelah Jawaban 1 dikunci di lembar catatan, barulah pewawancara boleh menanyakan 3 pertanyaan klarifikasi berikut untuk membantu pencocokan log dan evaluasi keterbacaan:

1. **Klarifikasi Tokoh/Tempat (Jika penguji lupa nama di Jawaban 1)**:
   *"Kejadian yang barusan kamu ceritakan itu kira-kira terjadi di sekitar tempat mana di peta, dan melibatkan warga atau penjaga yang mana?"*
2. **Kejelasan Umpan Cerita**:
   *"Dari mana kamu mengetahui kejadian itu di layar? Apakah dari kotak 'Kisah Hari Ini', dari obrolan tombol 'Tanya NPC', atau dari perubahan sikap warga terhadap Soma?"*
3. **Kebingungan Antarmuka (Untuk Lembar Catatan Kebingungan)**:
   *"Bagian mana di layar atau tombol mana yang paling membuatmu bingung atau tidak yakin fungsinya?"*

---

## 4. Lembar Catatan Kebingungan (Wajib Diisi pada Pilot 2 Orang & Uji 5 Orang)

Catat setiap momen penguji tampak ragu, salah klik, atau bertanya selama sesi tanpa mengintervensi:

| Kode Penguji | Menit Ke- | Gejala Kebingungan yang Terlihat (Tanpa Diintervensi) | Panel / Tombol Terkait | Tindak Lanjut Perbaikan UI |
| :--- | :--- | :--- | :--- | :--- |
| `PILOT-01` | `[  :  ]` | *(Misal: Tidak sadar Klik Kanan dipakai untuk pindah tempat selama 2 menit pertama)* | Peta / Kartu Petunjuk | `[                         ]` |
| `PILOT-01` | `[  :  ]` | *(Misal: Mencari alasan mengapa uang berkurang setiap pagi)* | Baris Uang / Kisah Hari Ini | `[                         ]` |
| `PILOT-02` | `[  :  ]` | `[                                                           ]` | `[                   ]` | `[                         ]` |

---

## 5. Cara Penilaian Buta (Blind Scoring) oleh Penilai

Untuk mencegah bias konfirmasi, pencocokan cerita penguji ke berkas log dilakukan secara **buta (blind evaluation)**:

1. **Penyamaran Berkas oleh Pewawancara**:
   - Pewawancara menyerahkan kepada Penilai dua berkas yang diberi kode acak (mis. `SAMPEL_K7`):
     a) Transkrip **Jawaban Pertanyaan 1** penguji;
     b) Berkas log kejadian (`Nisshi_Soma.txt` dan `sesi_*.jsonl` dari ZIP laporan uji), dengan **baris nama kebijakan/mode dihapus atau ditutup (`[DISEMBUNYIKAN]`)**.
   - Penilai **tidak boleh mengetahui** apakah sesi tersebut dijalankan dengan kecenderungan diam, berdagang jujur, mengumpulkan kabar, atau gaduh, maupun siapa pengujinya.
2. **Tugas Penilai (Bukan Tugas Penguji!)**:
   - Penguji **TIDAK dituntut** menghafal 3 mata rantai atau ID kejadian.
   - **Penilailah** yang memeriksa berkas log (`Nisshi_Soma.txt`, `sim_report_L1.json`, atau `sesi_*.jsonl`) untuk melihat apakah kejadian spesifik yang diceritakan penguji benar-benar tercatat di log dan berasal dari rantai sebab-akibat `>= 3` kejadian (`WorldEvent` sumber -> saksi/rumor -> tindakan agensi NPC / perubahan keadaan).

---

## 6. Kriteria Lulus yang Disederhanakan (Per Penguji & Gerbang 1)

Seorang penguji dinyatakan **LULUS (1 poin)** apabila memenuhi **keempat syarat sederhana** berikut:

| No | Kriteria | Cara Memeriksa | Lulus / Gagal |
| :--- | :--- | :--- | :--- |
| **1** | **Kisah Spesifik** | Jawaban Pertanyaan 1 menyebut satu peristiwa konkret (ada pelaku/warga, tindakan/masalah seperti denda salah paham, kenaikan harga lapak, penyitaan kotak pikul oleh O-Hana, atau pembelaan warga), **bukan** kesan umum seperti *"saya cuma jalan-jalan dan berdagang"*. | `[ ] Lulus  [ ] Gagal` |
| **2** | **Dari Pengalamannya Sendiri** | Rekaman `sesi_*.jsonl` membuktikan penguji benar-benar berada di sekitar lokasi/waktu tersebut, menanyakan NPC terkait, atau mengalami langsung akibatnya pada sesi itu. | `[ ] Lulus  [ ] Gagal` |
| **3** | **Tak Diarahkan** | Kisah muncul langsung pada **Jawaban Pertanyaan 1** ("Ceritakan satu kejadian yang kamu ingat") sebelum ada pertanyaan lanjutan apa pun dari pewawancara. | `[ ] Lulus  [ ] Gagal` |
| **4** | **Cocok ke Log (Rantai `>= 3` Kejadian Dicek Penilai)** | Penilai buta menemukan kecocokan di log simulasi dengan rantai minimal 3 kejadian (mis. `evt_...` kejadian awal -> `mem_...` rumor/saksi -> `evt_...` tindakan agensi NPC / denda / boikot / teguran sewa). | `[ ] Lulus  [ ] Gagal` |

* **Syarat Lulus Pilot (2 Orang)**: Minimal **1 dari 2 penguji pilot** lulus keempat kriteria di atas, dan seluruh temuan di Lembar Catatan Kebingungan telah ditangani.
* **Syarat Lulus Gerbang 1 (5 Orang)**: Minimal **3 dari 5 penguji (`>= 60%`)** lulus keempat kriteria di atas.
