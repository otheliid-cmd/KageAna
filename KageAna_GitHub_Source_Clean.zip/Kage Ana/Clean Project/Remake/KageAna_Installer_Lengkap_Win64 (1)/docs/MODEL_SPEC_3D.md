# SPESIFIKASI PEMODELAN 3D & INTEGRASI VRM 1.0 — KAGE-ANA (影穴)
**Status (E6.4):** Spesifikasi Teknis untuk Pembuatan Model di VRoid Studio / Blender dan Integrasi ke Unity 6 (`UniVRM v0.128.3`).

## 1. Anggaran Poligon & Tekstur (Kontrak Performa E3.3)
| Kategori Karakter | Anggaran Segitiga (PC) | Anggaran Segitiga (Android Menengah) | Ukuran Atlas Tekstur | Jumlah Material Maks |
|---|---|---|---|---|
| **Sōma (Karakter Utama)** | ≤ 40.000 tris | **≤ 20.000 tris** | 2048×2048 (PC) / **1024×1024 ASTC** (Android) | 2 material (Tubuh+Wajah, Pakaian+Rambut) |
| **NPC Utama Distrik (8–10 NPC)** | ≤ 24.000 tris | **≤ 12.000 tris** | 1024×1024 ASTC | 1–2 material |
| **NPC Latar Pasar** | ≤ 12.000 tris | **≤ 8.000 tris** | 512×512 atau 1024×1024 bersama | 1 material (SRP Batcher kompatibel) |

## 2. Tulang Humanoid & SpringBone
- **Rig Wajib:** Unity Humanoid standar (52 tulang utama termasuk jari dasar) + maksimal **12 tulang SpringBone** pada Android (hanya untuk ujung lengan kimono, celemek, dan helai rambut depan).
- **Garis Tinta (Outline):** Menggunakan shader MToon / URP Cel dengan metode *inverted hull* warna Sumi (`#1C1B1A`), bukan efek pasca-proses layar.

## 3. Daftar Expression / BlendShape Wajib (VRM 1.0)
1. **Emosi Dasar (9 Preset):** `Neutral`, `Happy`, `Angry`, `Sad`, `Surprised`, `Relaxed`, `Suspicious` (kustom: alis menyipit + sudut bibir tegang), `Embarrassed` (kustom), `BlinkLeft` & `BlinkRight`.
2. **Visem Sinkronisasi Bibir (5 Preset Wajib):** `aa` (あ), `ih` (い), `ou` (う), `ee` (え), `oh` (お).

## 4. Prosedur Model Uji Satu Karakter (Sebelum Membuat 27 Karakter)
1. Unduh **VRoid Studio Stable Ver.** atau ambil model sampel berlisensi **CC0** (`AvatarSample_A.vrm` dari dokumentasi resmi Pixiv VRoid: `https://vroid.com/en/studio/guidelines`).
2. Simpan sebagai `unity_project/Assets/_Project/Art/Models/TestCharacter_SampleA.vrm`.
3. Pasang komponen `CharacterExpressionController`, `LipSyncFromAudio`, `GestureLibrary`, dan `LookAtTarget` untuk memverifikasi ekspresi dari keadaan Sim dan anggaran 30 fps di Android sebelum memproduksi ke-27 karakter.
