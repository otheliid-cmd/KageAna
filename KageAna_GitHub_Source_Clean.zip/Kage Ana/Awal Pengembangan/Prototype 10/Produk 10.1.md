# KAGE-ANA — LAMPIRAN A: PROTAGONIS "SHINONOME SŌMA" & REALITA SHINOBI
### Tambahan untuk Kitab Dunia v3.0 · Versi Lampiran: A.1 · Status: **menimpa** bagian Kitab yang disebut di A.6

> **Cara memakai:** Lampiran ini dibaca **setelah** Kitab dan **menang** atas Kitab bila bertentangan (hanya pada butir di A.6). Butir bertanda **[ISI-PENGGUNA]** adalah bagian yang hanya bisa diputuskan pembuat game; AI **dilarang mengarang** isinya sebelum diisi, cukup memakai placeholder berlabel `TEMP_`. Butir bertanda **[USUL]** adalah rancangan yang menunggu persetujuan.

---

## A.1 Realita shinobi (hasil riset) dan artinya untuk desain

**Batas keandalan, wajib diingat:** tiga naskah utama tentang shinobi, *Ninpiden* (1560), *Bansenshūkai* (1676, Fujibayashi Yasutake) dan *Shōninki* (1681, Natori Masatake), dua di antaranya ditulis pada awal zaman Edo, **setelah** Sengoku berakhir. Isinya campuran teknik praktis, filsafat, dan kepercayaan zaman itu. Maka "realita Sengoku" di sini adalah **rekonstruksi yang masuk akal**, bukan catatan harian. Gunakan sebagai pagar agar dunia terasa nyata, bukan sebagai buku sejarah.

| # | Fakta (dengan tingkat keyakinan) | Artinya untuk KAGE-ANA |
|---|---|---|
| 1 | Pekerjaan inti shinobi adalah **spionase, penyusupan, sabotase, pembakaran, pengintaian, penyesatan**. Pembunuhan bukan pekerjaan utamanya. *(sumber sekunder, konsisten)* | **Informasi adalah inti permainan.** Pembunuhan jarang, mahal, dan berekor. Ini cocok dengan Kitab 1.3 #5. |
| 2 | *Shōninki* membahas dasar-dasar penyamaran dan persembunyian, membobol rumah, **mengumpulkan informasi**, memasang jejak palsu, **membaca watak dan niat orang**, serta menangkal mata-mata musuh. | Mekanik pembacaan orang (sifat, kebohongan, niat) dan **jejak palsu** adalah hal inti, bukan tambahan. |
| 3 | **Penyamaran (*shichihōde*, "tujuh bentuk")**: pendeta, **pedagang**, petani, dan lain-lain. Daftar tujuh persisnya berbeda antar sumber. *(daftar lengkap: **belum kuverifikasi**; AI wajib mengecek terjemahan sumber primer sebelum membakukannya)* | **Pedagang adalah penyamaran klasik**, bukan karangan. Pedagang masuk rumah, pasar, dan jalan raya tanpa dicurigai. |
| 4 | **Tidak ada seragam hitam.** Naskah menyarankan warna **senada bulan dan lingkungan**. Citra serba-hitam berasal dari kostum panggung dan film abad ke-20. *(sumber sekunder)* | Hapus "shōzoku hitam" di Kitab 9.6. Pakaian malam = **indigo gelap / abu-cokelat**, bukan hitam total. Ini **cocok dengan palet Ai-Zome kita**. |
| 5 | **"Ninjatō" lurus bersaling persegi tidak punya bukti di era feodal.** Shinobi membawa katana/wakizashi biasa agar tampak seperti samurai atau orang biasa. | Senjata default = **pedang biasa**, sering **disembunyikan di dagangan**. Bukan senjata khas. |
| 6 | **Kunai** adalah perkakas (mirip sekop/penyungkil kecil) untuk menggali dan mencongkel. | Kunai di game = **alat panjat dan bongkar**, bukan pisau lempar utama. Shuriken: peran kecil dan tidak andal (**tidak diverifikasi**, perlakukan sebagai pelengkap). |
| 7 | Alat nyata: **tangga lipat** untuk memanjat tembok, **bubuk mesiu** (granat, bom asap, panah api untuk benteng), serta keahlian **farmasi, kriptografi, bahasa, meteorologi**. | Item dunia: tangga lipat, asap, api, **ramuan dan racun**, sandi sederhana, **ramalan cuaca** (cuaca sudah jadi sistem di L1). Farmasi cocok dengan dagangan obat. |
| 8 | Asal sosial: **ji-samurai** (petani-prajurit) dari **Iga dan Kōka**, komunitas berpemerintahan sendiri (*Iga ikki*). Oda Nobunaga menghancurkan Iga pada **1581**; sebagian lari ke gunung Kii, sebagian mengabdi pada Tokugawa. | Latar belakang Sōma yang masuk akal: asal pedesaan/pegunungan, **jaringan terpecah setelah kehancuran**. Menjelaskan mengapa kelompok kecil, tersembunyi, dan rapuh. |
| 9 | "Ninja" adalah istilah belakangan. Sumber lama memakai **shinobi** dan sebutan lain. | Pakai **shinobi** di dalam dunia. Kata "ninja" hanya di pemasaran/UI luar. |
| 10 | Tidak ada kemampuan gaib. Kuji-in adalah praktik keagamaan. | **Shadow-Meld = lisensi permainan.** Ground-kan sebagai *penguasaan diam dan bayangan*, tidak pernah sihir. Pertahankan, tetapi tandai di `DECISIONS.md` sebagai lisensi artistik. |

**Sumber:** [Bansenshūkai](https://en.wikipedia.org/wiki/Bansensh%C5%ABkai) · [Shōninki](https://en.wikipedia.org/wiki/Sh%C5%8Dninki) · [Iga ikki](https://en.wikipedia.org/wiki/Iga_ikki) · [The Collector: mitos vs fakta ninja](https://www.thecollector.com/pop-culture-myths-feudal-japanese-ninjas). Sumber-sumber ini sekunder; AI diminta menambah rujukan akademik bila ada, dan **mencatat kutipan mana yang belum terverifikasi**.

---

## A.2 Protagonis: Shinonome Sōma

- **Nama:** **Shinonome (東雲) Sōma**. *Shinonome* berarti awan timur yang memerah sebelum fajar: cahaya di antara malam dan siang. Itu **persis tema Omote/Ura**; nama keluarga sudah bercerita.
- **Kanji nama depan:** **[ISI-PENGGUNA]**. *Usul:* 颯真 (cekatan, sejati). Jangan dibakukan sebelum pembuat memilih.
- **Peran siang:** **pedagang keliling** yang menetap sementara di Lembah Kurokawa. Berdagang apa pun yang sedang dibutuhkan (A.4.1). Ramah, cerewet, tahu harga, ingat nama anak orang.
- **Peran sebenarnya:** anggota **kelompok** yang menjadikan dagang sebagai kedok pengumpulan informasi (A.3). Dagang bukan sekadar mencari nafkah: **setiap transaksi adalah kesempatan mendengar dan membaca orang**.
- **Peran malam:** bergerak sebagai shinobi (menyusup, mengambil, mengintai, membakar, bila terpaksa membunuh).
- **Wajah Asli (A.4.3):** sosok sebenarnya dapat muncul **kapan pun** bila ia terancam, termasuk di siang bolong di tengah pasar.
- **Latar belakang pribadi:** **[ISI-PENGGUNA]**. Slot yang perlu diisi: asal daerah, siapa yang melatihnya, alasan ia memilih jalan ini, apa yang ia sembunyikan dari kelompoknya, apa yang ia takuti. *Selama kosong, AI memakai `TEMP_backstory` dan tidak menulis dialog yang bergantung padanya.*
- **Suara:** dua register. **Omote:** hangat, jenaka, kalimat panjang bernada dagang. **Ura:** singkat, datar, nyaris tanpa kata. **Peralihan antara keduanya adalah momen akting terbaik game ini.**
- **Aturan penulisan:** Sōma **bukan mesin pembunuh yang pura-pura ramah**, ia manusia yang sungguh-sungguh menyukai pasar *dan* sungguh-sungguh dingin di malam hari. Keduanya benar. Ketegangannya ada di situ.

---

## A.3 Kelompok (afiliasi langsung) **[USUL, butuh persetujuan]**

Kitab lama menyebut pemain sebagai "murid terakhir". Konsep baru: Sōma **berafiliasi langsung dengan sebuah kelompok**. Rekonsiliasi yang diusulkan:

| Elemen | Usulan |
|---|---|
| **Wajah publik** | Rombongan/serikat pedagang (nama: **[ISI-PENGGUNA]**; placeholder `TEMP_Kumi_Dagang`). Terdaftar di Za Pasar bila memungkinkan. |
| **Wajah rahasia** | Jaringan shinobi. Nama rahasia dipertahankan: **Ryū Kage-Ana** (rujukan di seluruh Kitab tetap berlaku). |
| **Struktur** | **Sel-sel kecil terpisah** (khas jaringan rahasia): Sōma hanya mengenal **atasan langsungnya** dan satu **kurir**. Ia tidak tahu seluruh organisasi. |
| **Mengapa Sōma di Kurokawa** | Sensei Muraku (kepala stasiun lembah) **berhenti mengirim kabar** tiga tahun lalu. Sōma dikirim **menggantikan dan memulihkan aliran informasi**. Misteri Muraku tetap menjadi benang jangka panjang, **bukan misi utama**. |
| **Mengapa kelompok rapuh** | Latar historis: kehancuran jaringan Iga/Kōka (A.1 #8) membuat sisa-sisanya kecil, curiga, dan miskin. Kelompok tidak akan menolongnya tanpa alasan. |
| **Hubungan dengan Sōma** | Kelompok memberi **modal dagang kecil**, **Pesanan** (daftar informasi yang dibutuhkan), dan **jalur lapor**. Sebagai gantinya ia wajib melapor **berkala**. Kelompok **bisa memutus** hubungan bila ia ceroboh (tanpa jaring pengaman). |

**Mekanik kelompok (data, bukan skrip):**
- **Pesanan Kelompok (mingguan):** 2–4 permintaan informasi dengan tenggat dan imbalan (modal, alat, akses). Menggantikan peran "papan gig" sebagai sumber **tujuan** utama; gig Kitab 8.8 tetap ada sebagai **peluang tambahan**.
- **Kepercayaan Kelompok (0–100):** naik bila laporan akurat dan tepat waktu; turun bila terlambat, salah, atau cover terbongkar. Memengaruhi modal, dukungan, dan kesempatan.
- **Jalur lapor:** kurir/titik serah (dead drop) yang **harus dikunjungi** tanpa dibuntuti. Mengikuti kurir adalah cara musuh menemukan kelompok (peluang konflik).
- **Kas Kelompok:** modal dagang bersifat **pinjaman** yang harus dikembalikan; dagangan yang hilang karena kekerasan adalah kerugian nyata.

---

## A.4 Mekanik baru (spesifikasi; tuning di `Data/tuning/*.json`)

### A.4.1 Dagangan Berganti ("pedagang serba bisa")
Sōma **tidak punya satu pekerjaan sampul tetap**. Ia memilih/mengganti **dagangan** menurut kebutuhan. Kebutuhan datang dari tiga sumber: (a) **Pesanan Kelompok**, (b) **permintaan dunia** (wabah → obat; panen gagal → beras; festival → topeng/lentera; hujan → payung), (c) **kebutuhan akses** (ingin masuk benteng → jual tinta dan kertas kepada juru tulis).

| Dagangan | Akses alami | Bonus / profil | Risiko khas |
|---|---|---|---|
| **Obat & ramuan** | Rumah warga, Sōan, kuil | Dipercaya; bahan racun/obat | Bau obat → dikenali Sōan |
| **Kain & benang** | Pasar, rumah samurai (istri/pelayan) | Gosip kalangan atas | Modal besar; mahal bila rusak |
| **Ikan kering & garam** | Dermaga, nagaya, barak | **Bau ikan menutupi bau darah** | Bau melekat; menarik anjing |
| **Kertas, tinta, lilin** | Kuil, juru tulis benteng | Akses dokumen | Mencolok bila dipakai berlebihan |
| **Peralatan dapur & perkakas** | Nagaya, tukang kayu | Masuk dapur/halaman belakang | Berat; sulit lari |
| **Sake & makanan ringan** | Izakaya, penjaga, festival | Penjaga lengah | Bersaing dengan Za |
| **Arang & kayu bakar** | Semua rumah | Masuk rumah mana pun | Murah; informasi minim |
| **Barang festival (topeng, lentera, jimat)** | Musiman | Penyamaran, keramaian | Hanya musim tertentu |

- **Za (serikat pedagang):** menjual barang di luar hak serikat memancing **Haruki** dan konflik. Itu hidup di dunia nyata abad pertengahan Jepang (za adalah serikat pedagang), jadi masuk akal dan sudah ada di Kitab.
- **Modal & stok:** beli di sumber (dermaga/ladang/kuil), jual di tujuan; harga dinamis (Kitab 6.4). **Stok terbatas** (kotak pikul) dan memengaruhi kecepatan dan suara.
- **Dagangan = alat:** kotak pikul menyembunyikan senjata; tongkat pikul bisa jadi senjata darurat; caping menyembunyikan wajah. Pemain bisa **kehilangan dagangan** (dicuri/rusak), yang berarti kehilangan kedok.

### A.4.2 Kabar (informasi sebagai barang)
```
Kabar {
  id, subject (npcId|faction|place|item), claim (typed),
  source: Saw | Heard | Told | Read | Inferred,
  reliability 0..1, freshness (hari sejak kejadian), sensitivity 0..1,
  verifiedBy[]  // sumber independen yang mengonfirmasi
}
```
- **Kabar adalah rumor yang diverifikasi pemain.** Ia lahir dari Grafik Rumor (Kitab 8.3), tetapi pemain menilainya: satu sumber = lemah; dua sumber independen = kuat.
- **Verifikasi** adalah gameplay inti siang hari: bertanya, mengamati, memancing, mencocokkan jadwal NPC.
- **Pelaporan:** kabar dilaporkan ke kelompok untuk memenuhi Pesanan. Kabar salah menurunkan Kepercayaan Kelompok.
- **Menjual/memakai:** kabar dapat dijual, dipakai memeras, atau ditanam sebagai rumor (Kitab 8.3). Setiap penggunaan punya akibat moral dan sosial.
- **Papan Tinta** menampilkan kabar yang diketahui; **ketebalan tinta = keandalan**.

### A.4.3 Wajah Asli (sosok asli saat terancam)
Sōma dapat **meninggalkan perannya kapan saja**. Ini senjata terakhir, **tidak pernah gratis**.

| Tahap | Pemicu | Yang terjadi |
|---|---|---|
| **1. Retak** | Ancaman awal (ditodong, dituduh, diikuti) | Sikap tubuh berubah; tangan mencari barang di dagangan; NPC dekat merasakan "ada yang aneh" (**Kecurigaan +8**) |
| **2. Terbuka** | Nyawa/orang dekat terancam, atau pemain memilih | **Wajah Asli penuh**: gerak cepat, mematikan, singkat (1–3 detik per lawan biasa). Saksi melihat. |
| **3. Menghilang** | Setelah ancaman | Kabur, atau membungkam saksi (Dingin), atau membiarkan saksi hidup (risiko rumor) |

- **Biaya otomatis:** setiap saksi yang melihat Wajah Asli → **Kecurigaan lonjakan +35 (nilai awal)** pada saksi itu, rumor baru *"pedagang itu bukan pedagang biasa"* (kekuatan awal 0,7), dan **Kepercayaan Kelompok −10** (kedok bocor).
- **Pemulihan kedok:** ganti dagangan, ganti rute, ganti penampilan, pindah distrik sementara, atau bungkam/alibi. Bukan menu; **tindakan di dunia**.
- **Aturan desain:** pertarungan siang hari **pendek, mematikan, dan lebih sering berakhir dengan kabur** daripada menang. Jika pemain memakai Wajah Asli rutin, dunia **menyesuaikan** (patroli, perburuan, tetangga menjauh).
- **Visual:** bukan berganti kostum. Yang berubah adalah **postur, tatapan, suara, dan bayangan** (Kitab 10.3), lalu barang dagangan jatuh atau dilepas. Berbeda dengan "transformasi pahlawan super".

### A.4.4 Kostum dan alat (pengganti Kitab 9.6 dan sebagian 10.5)
- **Pakaian:** kosode pedagang + caping (siang); **pakaian kerja malam indigo gelap/abu-cokelat** (bukan hitam total); jubah biksu/Komusō dan penyamaran lain tersedia (A.1 #3).
- **Senjata default:** pedang biasa (wakizashi/katana), **bisa disembunyikan di dagangan**.
- **Alat:** kunai = perkakas panjat/bongkar; tangga lipat; kaginawa; bom asap & api (mesiu); ramuan/racun; makibishi (opsional). Shuriken: pelengkap kecil.
- **Shadow-Meld:** dipertahankan sebagai lisensi permainan (A.1 #10).

---

## A.5 Dampak ke Hati, Uji Hidup, dan nada
- **Hati (Hangat↔Dingin)** kini punya **dua sumber**: kebaikan dagang/keakraban (Hangat) dan tindakan malam/Wajah Asli (Dingin). Pedagang yang ramah *dan* menggorok leher orang adalah **inti ketegangan**, bukan kontradiksi yang harus diselesaikan.
- **Uji Hidup #3** (sambungan dua wajah) diperkuat: dagangan, bau, uang, dan informasi adalah jembatan antara siang dan malam.
- **Kitab 1.3 #6** (rutinitas pendek & bermakna): aktivitas berdagang harus menghasilkan **kabar atau akses** setiap kali, bukan sekadar uang.

---

## A.6 Butir Kitab yang DITIMPA lampiran ini

| Bagian Kitab | Perubahan |
|---|---|
| **1.1 Jiwa game** | Tambahkan: protagonis bernama **Shinonome Sōma**, pedagang yang menyembunyikan kerja informasi dan jalur shinobi. |
| **2.3–2.4 Sejarah/legenda** | Sensei Muraku = kepala stasiun lembah yang diam; Sōma = pengganti. Ceritakan keruntuhan Iga/Kōka sebagai latar kelompok (A.3, A.1 #8). |
| **7.1 Pemeran** | Tambah **#0 `souma`** sebagai pemain (bukan NPC). Hapus frasa "murid terakhir". |
| **8.7 Pekerjaan sampul** | **Diganti** oleh **Dagangan Berganti** (A.4.1). Empat pekerjaan tetap sebagai pilihan *dagangan awal* (obat, ikan/garam, kain, perkakas/arang), bukan identitas kerja. |
| **8.8 Gig** | Tambah **Pesanan Kelompok** sebagai sumber tujuan utama (A.3). Gig lama = peluang tambahan. |
| **9.6 Pakaian** | **Diganti** A.4.4 (tanpa hitam total). |
| **9.7 Tujuh hari pertama** | H1: bangun, ambil dagangan awal, jual pertama · H2: Pesanan Kelompok pertama · H3: Hanami (kabar + Ura pertama) · H4–H5: verifikasi kabar, Papan Tinta · H6: aspirasi + Hisame · **H7: lapor pertama ke kelompok + sewa jatuh tempo.** |
| **10.5 Aset** | Tambah: kotak pikul, tongkat pikul, caping, timbangan, dagangan per kategori; viewmodel/animasi menjual, menawar, menyembunyikan senjata di dagangan, Wajah Asli. |
| **13 (D1 Kamera)** | Rekomendasi **orang ketiga makin kuat**: caping, dagangan, dan postur adalah identitas pemain dan harus terlihat. |
| **14.2 Prompt** | Sisipkan **L1.5** sebelum L2 (lihat bawah). |

**Tugas L1.5 (tempel setelah L1 diperbaiki):**
```
Tugas L1.5 (data & skema saja, tanpa logika gameplay): baca Lampiran A. (1) Tambahkan entri pemain
`souma` + skema player_profile (placeholder TEMP_ untuk bagian [ISI-PENGGUNA]). (2) Skema
dagangan (8 kategori A.4.1), kabar (A.4.2), pesanan_kelompok & kepercayaan_kelompok (A.3), dan
tahap Wajah Asli (A.4.3) beserta tuning awal di Data/tuning/. (3) Validator: referensi silang
dagangan→tempat akses, kabar→NPC, pesanan→kabar. (4) Perbarui DECISIONS.md: A.6 sebagai "diusulkan"
bila belum disetujui; Shadow-Meld sebagai lisensi artistik. (5) Perbarui ART_BIBLE (tanpa hitam total)
dan daftar aset 10.5. Bukti: CI hijau + tes negatif baru untuk tiap validator baru. BERHENTI setelah
laporan.
```

---

## A.7 Pertanyaan yang hanya bisa dijawab pembuat game

1. **Latar belakang Sōma** (asal, guru, alasan, rahasia dari kelompok, ketakutan terbesar).
2. **Kanji nama depan** dan kebenaran nama keluarga **Shinonome**.
3. **Nama dan sifat kelompok** (usulan A.3 sudah cukup, atau ada struktur/nama sendiri?).
4. **Sensei Muraku:** tetap sebagai misteri jangka panjang, atau Sōma punya hubungan pribadi dengannya?
5. **Wajah Asli:** sepenuhnya mematikan dan singkat (usulan), atau ada pilihan nonmematikan di tahap 2?
