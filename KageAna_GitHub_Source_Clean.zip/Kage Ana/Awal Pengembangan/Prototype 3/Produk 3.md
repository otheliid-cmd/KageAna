# KAGE-ANA (影穴) — Audit v1.0 & Strategi Menjadi Game yang Kompetitif

> Dasar audit: `KageAna_VerticalSlice_CleanRepo_v1.0.zip`. Saya membaca dokumen, kode WebGL, shader, skrip Unity, data, lalu menjalankan slice WebGL di browser dan mengambil screenshot.
> Catatan metode: FPS yang saya ukur (4–6 FPS) berasal dari renderer software tanpa GPU, jadi **tidak mewakili performa di PC Anda**. Overlay game sempat menampilkan 86 FPS, tapi angka itu juga datang dari lingkungan tanpa GPU nyata. Jangan jadikan dasar. Ukur di mesin Anda sendiri.

---

## BAGIAN 0 — Vonis Jujur

**Ada lompatan nyata, dan Anda patut mengakuinya.** Dari kardus Canvas 2D menjadi pipeline WebGL dengan depth buffer, shadow map, cel-shading, kontur tinta, kabut berwarna, lentera bercahaya, siluet menembus kertas shoji, dan HUD yang bersih. Screenshot pertama kini terbaca sebagai *suasana*: torii merah di depan, deretan lentera, menara di ujung. Itu sudah punya "mood".

**Tapi Anda benar: belum memuaskan, dan belum kompetitif.** Alasannya bukan lagi "jelek", melainkan **"belum ada alasan bagi orang asing untuk membeli ini dibanding 20 game sejenis"**. Pasar 2026 tidak mengalahkan game karena grafis rendah saja. Ia mengalahkan game yang **tidak punya hook**, **tidak punya momen yang bisa dipotong jadi 15 detik klip**, dan **tidak punya alasan kembali bermain**.

Ringkasan skor saya (1–10, untuk standar rilis Steam indie yang kompetitif):

| Aspek | Sebelum (v0.7) | Sekarang (v1.0) | Target demo |
|---|---|---|---|
| Fondasi render | 1 | 6 | 8 |
| Arah seni (konsep) | 2 | 6 | 9 |
| Hasil visual di layar | 2 | 4 | 8 |
| Karakter & animasi | 1 | 2 | 7 |
| *Game feel* | 3 | 3 (belum bisa dinilai penuh) | 8 |
| AI & stealth | 3 | 3 | 7 |
| Konten (kedalaman, variasi) | 4 (lebar) | 2 (satu halaman kosong) | 6 |
| **Hook / pembeda pasar** | 2 | **2** | **9** |
| Kesiapan komersial (Steam) | 0 | 1 | 6 |

**Kesimpulan:** teknis sudah naik kelas, **identitas produk belum lahir**. Sisa laporan ini berisi (1) kritik tajam atas v1.0, (2) "gebrakan" yang saya yakini bisa menjadi pembeda, dan (3) instruksi baru untuk AI Anda agar berhenti memoles hal kecil dan mulai membangun *momen* yang menjual.

---

## BAGIAN 1 — Audit v1.0

### 1.1 Yang sudah benar (pertahankan)

- Keputusan membuang Canvas 2D, membuang aset scan berlisensi tidak jelas, dan menulis `ASSETS_LICENSE.md`.
- Pipeline WebGL asli: depth test, shadow map PCF, cel-shading bertingkat, outline Sobel, kabut eksponensial berpangkat, butiran film (grain).
- Dokumen tata kelola (`AGENTS.md`, `ART_BIBLE.md`, `DESIGN_REFERENCE.md`) dan data JSON terpisah dari kode.
- Parameter mekanik yang terukur (kebisingan per permukaan, jendela parry, hit-stop 65 ms).
- Skenario uji otomatis untuk AI stealth (`runAutomatedStealthScenarios`), tangkisan sempurna yang membuka kuda-kuda musuh, dan kegagalan dasar lewat vitalitas.
- Konsep jantung gameplay yang tepat: **cahaya adalah mekanik** (padamkan lentera, jejak bayangan).
- HUD minimal bergaya Sengoku (empat elemen, tidak bertumpuk).

### 1.2 Kritik tajam (sebanyak mungkin, sesuai permintaan Anda)

Tingkat: **[KRITIS]** menghalangi daya saing · **[BESAR]** terlihat jelas oleh pemain/streamer · **[SEDANG]** poles

#### A. Visual di layar

1. **[KRITIS] Palet berlumpur dan kontras rendah.** Di screenshot, langit, kabut, tanah, dan bayangan semuanya berada di rentang cokelat-marun gelap yang sama. Tidak ada titik fokus yang menang. Art Bible menjanjikan *Ukiyo-e Noir* (bidang bersih, kontras tegas, aksen merah), tapi hasil di layar lebih mirip *"senja berkabut dengan filter cokelat"*. Ukiyo-e hidup karena **kontras bidang warna bersih**, bukan karena kegelapan.
2. **[KRITIS] Karakter hanyalah siluet hitam seragam.** Penjaga, bayangan jauh, dan penduduk tampak sama: hitam padat, tanpa warna peran, tanpa detail wajah/topeng, tanpa kostum bermakna. Pada jarak menengah pemain tidak bisa membedakan "penjaga berbahaya" dari "warga". Ini merusak fondasi stealth (keterbacaan).
3. **[KRITIS] Tidak ada animasi karakter sejati.** Pencarian kata `skin/bone/joint` di seluruh kode JS tidak menemukan apa pun. README menyebut "3D rigged characters", padahal yang ada adalah mesh tabung runcing (tapered limb) yang digerakkan secara prosedural. Tidak ada skeleton, skinning, atau blending animasi. **Klaim "rigged" tidak terbukti.**
4. **[BESAR] Viewmodel (tangan dan katana) terlihat seperti balok bertekstur.** Pada screenshot tebasan, "tangan" adalah bentuk geometris berwarna kulit di sudut kiri-bawah dengan pegangan berpola batu bata. Dalam game orang-pertama, tangan adalah **karakter utama di layar 100% waktu**. Ini area dengan dampak visual terbesar sekaligus yang paling lemah.
5. **[BESAR] Tekstur prosedural terlihat kasar.** Kayu dan atap tampak seperti piksel besar blok-blok. (Sebagian karena tekstur render target memakai `NEAREST` di `WebGLRenderer.js`, sebagian karena resolusi prosedural rendah.) Tampilan "pixel besar" tidak konsisten dengan kontur tinta halus.
6. **[BESAR] Tanah dan area terbuka kosong.** Halaman dan jalan tampak sebagai bidang datar tanpa batu pijakan, genangan, rumput, ranting, jejak roda, atau bayangan pohon. Mata tidak punya apa-apa untuk dibaca.
7. **[BESAR] Langit datar.** Tidak ada awan tinta, sapuan kuas, gradasi cetak kayu, burung gagak, siluet gunung berlapis ala *bokashi*. Satu warna marun menutupi sepertiga layar.
8. **[BESAR] Tidak ada post-processing selain grain.** Tidak ada bloom (padahal lentera dan shoji bercahaya seharusnya "bernapas"), tone mapping, color grading terarah, vignette, aberasi halus, atau *light shafts*.
9. **[BESAR] Tidak ada partikel atau atmosfer bergerak.** Tidak ada kelopak sakura, bara lentera, debu di cahaya, asap, kabut tanah, serangga. Dunia terasa *dibekukan*.
10. **[SEDANG] Torii besar menutup komposisi awal.** Menarik sebagai bingkai, tapi dua tiangnya yang hitam tebal memakan sepertiga layar. Komposisi pertama harus dirancang seperti poster.
11. **[SEDANG] Overlay telemetri ("WebGL GPU • FPS • 1% Low: 1 • Draw Calls • Tris") tampil di HUD utama.** Bagus untuk pengembang, tapi harus disembunyikan (F-key) agar screenshot dan klip tidak "bocor" debug.
12. **[SEDANG] Ketebalan kontur seragam.** Garis tinta ukiyo-e hidup karena **variasi tebal-tipis**. Sobel konstan terasa digital.

#### B. Isi game

13. **[KRITIS] Isinya satu halaman: 7 bangunan, 5 NPC, 6 lentera, 4 peti.** Tidak ada variasi level, tidak ada ritme, tidak ada kejutan. Ini lebih seperti *level uji* daripada *irisan vertikal* yang menjual.
14. **[KRITIS] Struktur menang/kalah belum utuh.** Ada kegagalan dasar: vitalitas turun 34 per tebasan musuh, dan saat habis `player.reset()` memindahkan pemain ke titik awal dengan pesan "Gugur dalam duel". Namun itu hanya teleport, tanpa layar kegagalan, tanpa konsekuensi (penjaga, lentera, dan status tidak diulang secara bermakna), dan **tidak saya temukan kondisi menang**: `objective` hanya dipakai untuk menampilkan jarak ke menara di HUD, tanpa pemeriksaan "tujuan tercapai", layar hasil, atau peringkat. Tanpa akhir yang jelas, stealth tidak punya klimaks.
15. **[BESAR] Tidak ada momen puncak.** Tidak ada "klimaks di menara", pembunuhan sinematik, dialog target, atau pelarian.
16. **[BESAR] AI penjaga hanya mesin keadaan berbasis ambang kecurigaan** (Patrol → Suspicious → Search → Combat) tanpa memori pencarian cerdas, tanpa koordinasi, tanpa jalur navigasi yang terbukti (versi Unity bahkan tidak punya gerak sama sekali).
17. **[BESAR] Tutorial berupa satu kalimat panjang di bawah layar.** Pemain baru tidak diajari lewat ruang.
18. **[BESAR] Tidak ada musik.** Audio hanya efek berbasis osilator (`LayeredAudio`). Atmosfer Sengoku sebagian besar adalah suara.
19. **[SEDANG] Tidak ada narasi, tokoh, atau alasan.** Siapa kita, kenapa membunuh, siapa penjaga? Tanpa itu, tidak ada emosi yang bisa dijual di trailer.

#### C. Teknis dan proses

20. **[KRITIS] Dua implementasi paralel yang akan saling menyimpang** (JS WebGL dan Unity C#). Data juga dobel: `data/*.json` di WebGL, `Assets/_Project/Data/*.json` di Unity, ditambah `data_bundle.js` yang digenerate manual. Ini melanggar aturan "satu sumber kebenaran" yang Anda tulis sendiri di `AGENTS.md`.
21. **[KRITIS] Proyek Unity adalah rangka kosong, bukan "ready-to-open".** Scene `VerticalSlice_Blockout.unity` hanya berisi pengaturan render dan oklusi (19 baris) **tanpa satu GameObject pun**. Skrip C# singkat (AI 52 baris tanpa gerak/NavMesh, combat 63 baris). `ProjectVersion.txt` memuat hash revisi palsu (`1234567890ab`). Tidak ada prefab, Animator, input action, atau URP asset. Klaim di README **berlebihan**.
22. **[BESAR] Engine WebGL buatan sendiri tidak akan sanggup jadi game komersial.** Tidak ada pipeline aset (glTF/FBX), animasi tulang, fisika sungguhan, middleware audio, dukungan gamepad penuh, integrasi Steam (achievement, cloud save, overlay), pembuatan build desktop, atau alat editor level. Setiap fitur harus ditulis dari nol. Ini cocok sebagai **laboratorium tampilan**, bukan sebagai **mesin produk**.
23. **[BESAR] Geometri sepenuhnya prosedural dari kotak dan tabung.** Ini bagus untuk prototipe, tetapi keindahan komersial (atap melengkung rumit, kain, kayu bertekstur lukis, wajah, topeng) datang dari **aset hasil pahat/lukis manusia** di Blender/ZBrush/Substance, bukan dari fungsi `addBox`.
24. **[SEDANG] `AGENTS.md` dan `CLAUDE.md` identik** (diff kosong). Pertahankan satu, buat yang lain menunjuk ke sana.
25. **[SEDANG] Folder `legacy/` hanya berisi README**, sehingga prototipe v0.7 yang menyimpan banyak ide (deduksi identitas, kuil respawn, disarm) kini tidak bisa diacu. Arsipkan sebagai tag git atau zip.
26. **[SEDANG] Komentar kode kembali hiperbolik** ("ZERO cone roofs!", "authentic"). Itu pola yang sama yang kita kritik: komentar menjanjikan lebih dari yang diberikan.
27. **[SEDANG] Tes otomatis ada tapi tipis.** Credit: `main.js` memuat `runAutomatedStealthScenarios()` dengan skenario (lewat tak terdeteksi, terdeteksi di cahaya, eliminasi senyap, dan seterusnya), praktik yang bagus. Kekurangannya: tes hanya menguji ambang kecurigaan di dalam logika JS, tidak menguji tampilan, tidak berjalan otomatis di CI, dan tidak ada padanannya di Unity (hanya satu berkas EditMode kecil).

#### D. Pasar dan produk

28. **[KRITIS] Belum ada hook yang bisa dijelaskan dalam satu kalimat dan dilihat dalam tiga detik.** "Stealth Sengoku orang pertama" adalah genre, bukan hook.
29. **[BESAR] Belum ada "momen klip"** (adegan 10–15 detik yang membuat orang berhenti menggulir).
30. **[BESAR] Belum ada alasan bermain ulang.** Satu jalur, satu cara, satu hasil.
31. **[BESAR] Persaingan di ruang Sengoku/ninja sangat ramai dan didominasi nama besar.** Judul AAA (Assassin's Creed Shadows, Ghost of Yōtei, Shinobi: Art of Vengeance dan sejenisnya) sudah menghabiskan "ruang tampilan realistis dan sinematik". Anda tidak akan menang di sana. Indie menang lewat **ide aneh yang tajam** dan **gaya yang tak bisa dikopi** (verifikasi daftar judul terkini di Steam/SteamDB sebelum menulis halaman toko).
32. **[SEDANG] Kekerasan eksplisit belum diputuskan sebagai identitas atau bumbu.** Keputusan ini memengaruhi rating, tampilan toko, dan siapa yang membeli.

---

## BAGIAN 2 — Posisi Pasar: Di Mana Game Ini Bisa Menang

### 2.1 Jebakan yang harus dihindari

- **Bersaing di "realisme sinematik"**: kalah mutlak melawan AAA.
- **Bersaing di "dunia terbuka luas"**: butuh ratusan jam konten.
- **Menjadi "Tenchu/Dishonored versi kecil"**: orang akan membandingkan dan melihat kekurangan.

### 2.2 Ruang kosong yang realistis

1. **Gaya visual yang langsung dikenali dari thumbnail** (cetak kayu hidup + tinta + satu warna aksen).
2. **Mekanik cahaya/bayangan/suara yang dipakai sebagai pusat desain**, bukan fitur sampingan.
3. **Sesi pendek dan padat** (misi 10–25 menit, bisa diulang dengan cara berbeda), cocok untuk streamer dan *speedrunner*.
4. **Keterbacaan stealth yang sangat jelas** (pemain selalu tahu kenapa ia ketahuan), karena banyak game stealth gagal di sini.
5. **Mode berbagi** (foto ukiyo-e, ghost replay, kontrak harian) untuk menumbuhkan komunitas tanpa biaya iklan.

### 2.3 Kalimat hook yang saya usulkan (pilih/ubah)

> **"Kage-Ana: stealth Sengoku orang-pertama di mana bayanganmu adalah senjata, suara adalah tinta, dan satu tebasan menentukan hidup."**

Versi pendek untuk judul toko: **"Jadilah bayangan. Lukis dengan tinta. Satu tebasan."**

---

## BAGIAN 3 — GEBRAKAN (Ide-Ide Pembeda)

> Tiap ide dinilai **Dampak** (pada keseruan/daya jual) dan **Biaya** (waktu solo + AI): ★ rendah – ★★★★★ tinggi. Saya urutkan dari yang menurut saya paling menentukan.

### G1. Bayanganmu adalah sumber daya hidup — *"Kage-Ana" secara harfiah* (Dampak ★★★★★ · Biaya ★★★)

Nama game berarti "lubang bayangan". Jadikan itu mekanik inti:
- **Pemain punya bayangan nyata** yang terlihat di tanah/dinding (dari lentera dan bulan). Ukuran dan ketebalannya menunjukkan **kekuatan Anda**: di cahaya terang bayangan menipis (lemah, mudah terlihat), di kegelapan ia menebal (cepat, senyap).
- **Shadow-Meld:** bila menyentuh bayangan objek yang cukup besar, pemain dapat **"menyelam" ke dalam bayangan** dan bergerak antar bayangan yang terhubung (seperti lubang). Putus-nyambung bayangan karena lentera dipadamkan/dipindahkan = teka-teki ruang yang elegan.
- **Cahaya bisa dimanipulasi dua arah:** padamkan lentera untuk membuat jalur gelap, **nyalakan** lentera di sisi lain untuk memancing penjaga, atau **geser** lentera (tarik tali) untuk memindahkan bayangan.
- **Kenapa kuat:** satu mekanik, satu identitas, satu klip trailer. Tidak ada game stealth yang memakai nama game sebagai mekanik literal. Cocok dengan shader cel dan shadow map yang sudah ada.

### G2. Suara sebagai tinta — "Mata Telinga" (Dampak ★★★★★ · Biaya ★★★)

- **Setiap suara di dunia digambar sebagai riak tinta sumi-e** yang mengembang di tanah/dinding dari sumbernya (langkah Anda di kerikil = riak besar, di tatami = nyaris tak terlihat). Pemain **melihat** apa yang didengar penjaga.
- **Tombol "Dengar" (hold):** dunia memudar menjadi kertas washi putih, hanya **sapuan kuas** yang menunjukkan lokasi penjaga (garis kuas bergerak), air, dan lentera. Efeknya seperti "Sheikah/Daredevil sense" tetapi dengan identitas ukiyo-e.
- Ini **menyelesaikan masalah keterbacaan stealth** sekaligus menjadi **tanda visual unik**. Screenshot-nya langsung terkenal (hitam-putih + merah).
- Biaya moderat: *shader* ruang layar + sistem peristiwa suara yang sudah ada di data (`acoustics`).

### G3. Satu tebasan — duel *iai* yang mematikan (Dampak ★★★★ · Biaya ★★★★)

- Tinggalkan kombo spam. Terapkan **pertarungan satu-dua pukulan mematikan untuk kedua pihak** (Anda dan penjaga mati dalam 1–2 tebasan). Ini membuat setiap konfrontasi tegang, mempercepat ulang percobaan, dan cocok untuk stealth.
- **Standoff (kamae):** saat berhadapan, layar turun ke ketegangan: musuh dan Anda saling menunggu. Pemain mengatur jarak dan *timing*; mengayun lebih dulu = rentan, parry tepat = tebasan balasan.
- **Sarung pedang sebagai alat:** menarik pedang dari sarung (*iai*) memberi serangan pembuka tercepat tapi **bersuara keras**; membiarkannya tersarung = membunuh senyap dengan belati kecil. Pilihan taktis di setiap pertemuan.
- Hit-stop, jejak tebasan, dan suara berlapis yang sudah ada menjadi lebih bermakna.

### G4. Gema Bayangan (*Kage-Echo*) — kematianmu menjadi senjata (Dampak ★★★★★ · Biaya ★★★★)

- Setiap kali pemain gagal dan mengulang, **bayangan 10 detik terakhirnya (gema)** muncul sebagai hantu kabur yang memutar ulang gerakan itu. Penjaga **bereaksi pada gema** (mengejarnya, tertarik suaranya).
- Jadi kegagalan **bukan hukuman, melainkan alat**: "coba lagi, biarkan gema versi dirimu yang gagal memancing penjaga sementara kamu lewat".
- Ini mekanik *time-loop ringan* yang mudah dipahami, sulit ditiru, sangat bisa dipotong jadi klip ("aku menggunakan kematianku sendiri sebagai umpan").
- Teknis: cukup merekam posisi + aksi pemain setiap 0,1 detik (ringan) dan memutarnya.

### G5. Siluet di balik shoji — arsitektur sebagai informasi (Dampak ★★★★ · Biaya ★★)

- Lentera di dalam rumah membuat **siluet orang tampak di kertas shoji** dari luar. Pemain dapat membaca jumlah dan arah gerak penghuni tanpa masuk. Sebaliknya, siluet **Anda** juga tampak dari dalam bila berdiri di antara lampu dan dinding.
- Estetika luar biasa (sudah ada tekstur shoji dan lentera), mekanik membaca keadaan, dan efek visual yang sangat "fotogenik".
- Gunakan untuk **intel gratis**: pemain mengintai lewat siluet sebelum memutuskan masuk.

### G6. Kontrak pembunuhan *"kotak pasir sosial"* + deduksi Obra Dinn — kembalikan jiwa v0.7 (Dampak ★★★★ · Biaya ★★★★★)

Prototipe lama punya ide emas: **identitas target tidak ditulis melayang di udara**, tapi harus dideduksi lewat petunjuk (pakaian, perilaku, percakapan, dokumen).
- Rencanakan sebagai **mode kedua** setelah slice: satu desa kecil, satu target, banyak cara (racun di sake, jatuhkan lentera, ledakan bom asap, samarkan diri).
- Dibekukan dulu sampai slice stealth terbukti seru, tetapi **simpan sebagai pilar jangka menengah**: "Hitman bertemu Return of the Obra Dinn di Sengoku".

### G7. Cuaca dan waktu sebagai aturan permainan (Dampak ★★★★ · Biaya ★★★)

- **Hujan** meredam langkah di atap tapi membuat genteng licin dan menghapus bayangan bulan.
- **Kabut pagi** memangkas jarak pandang dua arah.
- **Angin kencang** menutupi suara tetapi memadamkan lentera acak (mengubah peta bayangan).
- **Malam purnama** memberi bayangan tajam; **malam tanpa bulan** membuat Anda hampir tak terlihat tapi buta.
- Satu level yang sama terasa **seperti level berbeda** pada cuaca berbeda: konten gratis (3–4 variasi dari satu peta).

### G8. Kastil modular yang diacak — konten tanpa tim (Dampak ★★★★ · Biaya ★★★★)

- Bangun 15–20 **ruang tangan-rakitan** (halaman, gudang, jembatan, menara, taman, dapur, kuil kecil) dengan titik sambung. Sistem merangkai 5–7 ruang menjadi **kastil harian** dengan aturan (selalu ada rute atap, selalu ada rute bayangan).
- Hasil: **replayability tinggi** dari aset yang sedikit, plus **Kontrak Harian** (seed yang sama untuk semua pemain, papan peringkat).
- Ini kunci bagi solo developer: menggandakan konten tanpa menggandakan seni.

### G9. Daimyo's Challenge — pemain merancang, pemain lain menyusup (Dampak ★★★ · Biaya ★★★★★)

- Editor sederhana: letakkan penjaga, lentera, jebakan, tentukan rute patroli, lalu unggah ke Steam Workshop. Pemain lain mencoba menembusnya dan memberi peringkat.
- Memperpanjang umur game tanpa Anda membuat konten. **Rencanakan setelah rilis** (butuh data level yang rapi, yang kini sudah ada sebagai JSON).

### G10. Mode Foto Ukiyo-e & Papan Tinta (Dampak ★★★★ · Biaya ★★)

- Tombol satu klik mengubah tangkapan layar menjadi **cetak kayu** (garis tebal, bidang warna datar, tekstur kertas, stempel hanko dengan nama pemain).
- Pemain membagikan ini dengan sukarela, **pemasaran organik gratis**, sangat cocok dengan gaya game.
- Tambahkan **cetak peta kuas**: peta level digambar bertahap di gulungan (*emakimono*) sesuai area yang Anda jelajahi.

### G11. Tangan yang "hidup": tubuh orang pertama (Dampak ★★★★ · Biaya ★★★)

- Viewmodel penuh: lengan berbalut kain, **tekko-kōkō**, jari yang bergerak membentuk **segel tangan (kuji-in)** untuk kemampuan (asap, kabur, bayangan), menarik pedang, merayap, memanjat tali.
- Gerak tangan adalah **bahasa visual utama** di orang-pertama. Investasi di sini paling terasa oleh pemain dan streamer.

### G12. Kaginawa dan verticality — "peta tiga lapis" (Dampak ★★★★ · Biaya ★★★)

- Tiga lapis rute: **tanah (ramai/terang), atap (cepat/licin), bawah panggung/saluran (sempit/gelap)**. Tiap area wajib menyediakan ketiganya.
- Kait tali (kaginawa) dengan titik jangkar berpenanda kain putih; busur ayun yang bisa dibaca; tali jemuran/tali pemadam sebagai jalur.

### G13. Audio yang adaptif dan diam yang menegangkan (Dampak ★★★★ · Biaya ★★★)

- Musik **lapis-lapis**: shakuhachi tunggal saat tenang → taiko menyusup saat curiga → ritme penuh saat tempur → **hening total** sesaat sebelum eksekusi.
- **Foley** sungguhan: kain, tatami, kerikil, kayu, genteng, pedang di sarung, tali. Ini 50% dari rasa "premium".
- **Pencarian suara oleh penjaga** memakai peta akustik (sudah ada), disuarakan lewat gumam (*barks*) singkat.

### G14. Kepribadian penjaga (Dampak ★★★ · Biaya ★★★★)

- Penjaga bukan klon: **si pemalas** (tertidur di pos), **si paranoid** (sering menoleh), **si veteran** (hafal pola), **si pemuda gugup** (panik cepat).
- Mereka **bicara** satu sama lain (gumam), mengungkap petunjuk, dan bereaksi saat rekan hilang (mereka mencari, lalu waspada seluruh area). Ini menciptakan cerita tak terduga.

### G15. Moralitas ringan yang berdampak sistemik (Dampak ★★★ · Biaya ★★★)

- Membunuh hanya target = reputasi "hantu"; membunuh semua = reputasi "iblis" (penjaga lebih agresif, warga lebih takut, misi berubah).
- Mode **tanpa membunuh** (hanya membuat pingsan/menyelinap) sebagai tantangan *rank S*.

### G16. Opsi kekerasan sebagai identitas (Dampak ★★★ · Biaya ★★)

- Rancang kekerasan sebagai **gaya cetak tinta**: darah menjadi **percikan tinta merah di kertas**, bukan realisme grafis. Ini lebih estetis, lebih murah, lebih unik, dan membantu rating lebih lunak sambil tetap memuaskan.
- Pertahankan toggle (Off/Rendah/Tinggi) yang sudah ada.

### G17. Struktur sesi yang menghormati waktu pemain (Dampak ★★★★ · Biaya ★★)

- Muat ulang < 2 detik setelah gagal. Titik simpan otomatis tiap ruang.
- Setiap misi punya **tiga tujuan opsional** (tanpa terlihat, tanpa membunuh, di bawah 5 menit) → peringkat → membuka kosmetik/alat.

### G18. Wajah di balik topeng — identitas tanpa "uncanny valley" (Dampak ★★★ · Biaya ★★)

- Hampir semua karakter memakai **topeng/penutup** (menpō, topi anyaman, kain), jadi Anda tidak perlu wajah detail. Ini juga membuat karakter **dapat dibedakan lewat motif topeng/lambang klan**, memecahkan masalah "semua siluet hitam" (kritik A2).

### G19. Lokal dan identitas (Dampak ★★ · Biaya ★★)

- Sediakan **ID/EN/JP** sejak awal, dan boleh menonjolkan identitas studio dari Indonesia (cerita di balik pembuatan, bukan setting). Narasi pengembang yang jujur sering membantu liputan komunitas indie.

### G20. "Tiga detik pertama" sebagai disiplin desain (Dampak ★★★★★ · Biaya ★)

- Seluruh proyek diuji dengan satu pertanyaan: **"Jika seseorang melihat 3 detik klip ini di Reels/TikTok/Steam, apakah ia mau tahu lebih banyak?"** Jika tidak, fitur itu bukan prioritas.

### Peta prioritas (Dampak vs Biaya)

| Segera (slice) | Setelah slice | Pasca-demo |
|---|---|---|
| G1 Bayangan hidup, G2 Suara-tinta, G5 Siluet shoji, G11 Tangan hidup, G20 Disiplin 3 detik, G17 Siklus ulang cepat, G16 Darah tinta | G3 Duel satu tebasan, G4 Gema, G7 Cuaca, G13 Audio adaptif, G10 Mode foto, G14 Penjaga berkepribadian | G8 Kastil modular, G6 Kontrak sosial, G9 Workshop, G15 Moralitas |

**Pilar yang saya rekomendasikan (jangan lebih dari tiga):**
1. **Bayangan** (G1 + G5 + G7)
2. **Tinta/Suara** (G2 + G16 + G10)
3. **Satu Tebasan** (G3 + G4)

Semua fitur lain harus melayani salah satu pilar ini, atau tunda.

---

## BAGIAN 4 — Peningkatan Visual Konkret (dari screenshot v1.0)

Urut berdasarkan **dampak per jam kerja**:

1. **Perbaiki hierarki nilai (value) dulu.** Tentukan tiga lapis: latar (terang-lembut/kabut), tengah (mid), depan (gelap pekat). Pastikan penjaga dan jalur utama ada di lapis dengan kontras tertinggi. Gunakan uji grayscale (F4) yang sudah ada sebagai penguji wajib.
2. **Palet disiplin.** Ganti marun-cokelat menyeluruh menjadi: **kertas krem hangat, tinta biru-hitam, satu merah cinnabar** sebagai aksen tunggal (torii, darah, mata musuh), plus **kuning lentera** sebagai satu-satunya sumber hangat. Kurangi saturasi lain.
3. **Langit ala cetak kayu.** Gradasi *bokashi* berlapis, awan bidang datar bertepi tinta, bulan/matahari sebagai lingkaran datar, siluet gunung berlapis di kabut.
4. **Bloom halus pada lentera dan shoji** + **cahaya volumetrik/berkas cahaya** melalui celah. Satu perubahan ini mengangkat suasana paling cepat.
5. **Kontur tinta bervariasi** (tebal di siluet luar, tipis di lipatan, putus-putus di jarak jauh), dan **tekstur kertas** di seluruh layar (grain berbasis serat, bukan acak murni).
6. **Bayangan bergaya**: tepi keras, isi dengan *hatching/halftone* tipis; bayangan pemain dan penjaga terlihat jelas (mendukung G1).
7. **Partikel penghidup:** kelopak, bara lentera, debu cahaya, asap dapur, kunang-kunang malam. Cukup 3–4 jenis yang halus.
8. **Material lukis tangan**, bukan prosedural kasar: kayu bergaris tinta, genteng dengan pola gelombang, tanah dengan sapuan, kain dengan motif. Gunakan filter `LINEAR + mipmap` konsisten (hindari `NEAREST` pada elemen yang tampil di layar).
9. **Karakter peran-terbaca:** warna aksen per peran (penjaga = biru indigo + lambang klan di punggung; kepala penjaga = jambul/helm; warga = warna bumi), topeng/hiasan kepala berbeda (G18). Lampu tangan/lentera membuat penjaga terbaca dari jauh.
10. **Viewmodel tangan** dikerjakan ulang (G11): lengan berlapis kain, jari, sarung pedang di pinggang, cahaya tepi (rim light) hangat.
11. **Dunia isi:** batu pijakan, pagar bambu, sumur, gerobak, tumpukan jerami, bendera klan, tali jemuran, kuil kecil, genangan yang memantulkan lentera.
12. **Transisi tinta** antar menu/area (sapuan kuas menutup layar) dan **UI cetak**: panel kertas, stempel hanko, garis kuas, kamon.
13. **Sembunyikan telemetri debug** (F1 toggle) dan tambahkan **mode sinematik** (HUD hilang) untuk tangkapan trailer.

### Keputusan teknologi (ini penting, jawab dulu)

Dua implementasi tidak boleh hidup berdampingan. Pilih **satu**:

| Jalur | Pilih jika | Konsekuensi |
|---|---|---|
| **A. Unity 6 + URP (saran saya)** | Ingin rilis Steam serius dengan aset/animasi nyata | Pindahkan *shader* dan data dari prototipe WebGL; WebGL slice menjadi **laboratorium tampilan yang dibekukan** (jangan dikembangkan lagi) |
| B. Godot 4 | Ingin gratis, ringan, kontrol penuh | Tulis ulang; ekosistem efek lebih kecil tapi cukup untuk gaya ini |
| C. Tetap Web (Three.js/Babylon + glTF + pembungkus desktop) | Ingin tetap di browser dan menjual lewat itch/Steam via pembungkus | Gunakan **pustaka** (bukan engine buatan sendiri) agar dapat animasi tulang, glTF, fisika |

Alasan saya menyarankan A: Anda butuh **animasi tulang, pipeline aset, VFX Graph, Cinemachine, audio mixer, Steamworks, gamepad, build desktop**. Semua itu sudah ada dan tidak perlu ditulis ulang. Gaya cel/tinta Anda bisa dipindahkan ke Shader Graph/HLSL.

---

## BAGIAN 5 — Rencana Produksi 90 Hari ("Wow Slice" → Demo)

| Minggu | Fokus | Keluaran yang diperiksa |
|---|---|---|
| 1 | Putuskan engine, bekukan WebGL, buat proyek Unity yang **benar-benar berjalan** (scene berisi pemain, tanah, lampu, kamera) | Build Windows terbuka, bisa jalan-jalan |
| 2 | Look dev: palet, langit, pencahayaan, bloom, kontur bervariasi, material lukis | 3 screenshot standar (awal, vista, aksi) |
| 3 | Viewmodel tangan + katana + animasi (G11), karakter penjaga ber-rig (G18) | Video 20 detik tangan; uji siluet |
| 4 | **Bayangan hidup (G1)** + siluet shoji (G5) | Klip 15 detik "meld" lewat bayangan |
| 5 | **Suara-tinta (G2)** + HUD gaya cetak | Klip 15 detik "Mata Telinga" |
| 6 | AI penjaga berjalan (NavMesh, patroli, pencarian, alarm) + fail state + muat ulang cepat | 5 skenario uji otomatis lulus |
| 7 | Duel satu tebasan + standoff (G3) + hit-stop/suara berlapis | Klip duel 15 detik |
| 8 | Gema bayangan (G4) | Klip "gema memancing penjaga" |
| 9 | Audio adaptif + foley + musik | Rekaman 60 detik berlayar penuh |
| 10 | Level satu misi 15 menit (3 area, 3 rute, 1 klimaks menara) | Orang asing bisa menamatkan tanpa penjelasan |
| 11 | Playtest 5–8 orang asing, perbaiki 10 masalah teratas | Catatan playtest + perubahan |
| 12 | Trailer 60 detik, halaman Steam, build demo | Halaman toko draf + demo terpasang |

**Gerbang kualitas (go/no-go) di minggu 4, 8, dan 12:** tampilkan klip/hasil kepada 5 orang asing tanpa penjelasan. Jika mereka tidak paham atau tidak antusias, **jangan tambah fitur**, perbaiki yang ada.

---

## BAGIAN 6 — Kesiapan Komersial (Steam)

- **Halaman toko lebih dulu daripada game**: kapsul, 5–6 tangkapan layar terbaik, trailer (3 detik pertama = hook G1/G2), deskripsi tajam. Buat sejak minggu ke-6 dan kumpulkan *wishlist* lebih awal. (Praktisi umum menyebut ambang kasar beberapa ribu *wishlist* sebelum rilis; verifikasi angka terkini di sumber komunitas pengembang Steam.)
- **Demo gratis** dan ikut **Steam Next Fest**; rilis demo pendek (15 menit) yang menampilkan pilar.
- **Rating & konten**: siapkan kuesioner IARC, tampilkan pilihan kekerasan, catat label konten.
- **Legal & aset**: `ASSETS_LICENSE.md` selalu mutakhir; hindari aset dengan lisensi "free for non-commercial"; simpan bukti pembelian.
- **Audio & suara**: musik komisi/lisensi bersih (shakuhachi/biwa/taiko rekaman), foley rekaman sendiri; suara bahasa Jepang oleh penutur asli bila ada dialog; jangan pakai sintesis suara browser/OS.
- **Kualitas rilis**: kontrol gamepad, remap tombol, subtitle, opsi aksesibilitas, simpan otomatis, laporan kerusakan.
- **Anggaran & pendanaan**: hitung jujur biaya aset, audio, alat, dan waktu. Cari hibah/inkubator game dan penerbit indie yang cocok dengan skala ini; bawa **demo + trailer**, bukan hanya ide.
- **Nama dan IP**: periksa "Kage-Ana", "Kuro-no-Wa", dan nama klan agar tidak bentrok dengan merek yang ada.

---

## BAGIAN 7 — INSTRUKSI BARU UNTUK AI ANDA (v2)

> Ganti isi `AGENTS.md` dengan Bagian 7 ini (dan jadikan `CLAUDE.md` hanya menunjuk ke `AGENTS.md`). Berikan prompt bertahap di 7.6 satu per sesi.

### 7.1 Peran dan fakta dasar (jangan dibantah)

Kamu adalah **lead gameplay engineer + technical artist** untuk **KAGE-ANA (影穴)**, game stealth-aksi orang pertama Sengoku untuk Steam. Tujuan: **game yang dapat bersaing di pasar**, bukan sekadar demo teknis.

Fakta hasil audit v1.0:
- Slice WebGL buatan sendiri adalah **laboratorium tampilan**. Ia **tidak** akan dikembangkan menjadi produk. Jangan menambah fitur ke dalamnya kecuali diminta sebagai eksperimen *look-dev* dan ditandai demikian.
- Proyek Unity saat ini **rangka kosong**: scene tanpa GameObject, AI tanpa gerak, tidak terbukti kompil. Anggap **belum ada game Unity**.
- Klaim "rigged characters" **tidak terbukti** (tidak ada skeleton/skinning).
- Hook produk dan identitas pasar belum ada. Tiga pilar: **Bayangan, Tinta/Suara, Satu Tebasan**.

### 7.2 Aturan tak boleh dilanggar

1. **Jujur.** Dilarang menulis "authentic", "photorealistic", "AAA", "rigged", "ready-to-open", "100%" atau klaim sejenis tanpa bukti yang dapat diperiksa (screenshot, uji, atau build). Komentar kode menjelaskan **apa yang dilakukan kode**, bukan memuji.
2. **Satu basis kode.** Hanya satu implementasi produk (Unity). Tidak ada logika/data ganda di dua tempat. Data gameplay: **satu** lokasi (ScriptableObject/JSON di Unity). Berkas turunan (misalnya `data_bundle.js`) harus dihasilkan otomatis oleh skrip, dan tidak diedit tangan.
3. **Wow-first.** Setiap tugas harus lolos **Uji 3 Detik**: apakah hasilnya menambah momen yang layak menjadi klip 3–15 detik atau memperjelas pilar? Jika tidak, usulkan penundaan, jangan kerjakan.
4. **Pilar dulu.** Dilarang menambah fitur di luar tiga pilar sampai Gerbang Minggu 8 lolos. Fitur beku: kontrak sosial/deduksi, Workshop, kastil acak, moralitas, ekonomi, dunia terbuka.
5. **Bukti wajib.** Setiap tugas visual/gameplay diakhiri dengan **klip/GIF atau screenshot dari build yang benar-benar berjalan**, plus pengukuran (FPS rata-rata, 1% low, draw call, memori) **di perangkat dengan GPU nyata**. Jika hanya bisa dijalankan tanpa GPU, **tulis itu dengan jelas** dan jangan menyajikan angka FPS sebagai kinerja nyata.
6. **Aset: buatan manusia/berlisensi bersih.** Bentuk akhir karakter, bangunan, dan viewmodel dibuat/dibeli sebagai aset terotorisasi (Blender → glTF/FBX), bukan dirakit dari `addBox`. Prosedural hanya untuk prototipe cepat dan harus ditandai `TEMP_`. Catat semua di `ASSETS_LICENSE.md` sebelum dipakai.
7. **Tidak ada duplikat dan tidak ada aset tertanam di kode** (base64, data gambar di JS/C#).
8. **Keterbacaan stealth adalah hukum.** Pemain harus selalu bisa menjawab: *"Kenapa saya terlihat/terdengar?"* Setiap deteksi harus punya penyebab visual atau audio yang jelas.
9. **Kegagalan itu murah.** Muat ulang setelah gagal < 2 detik; tidak ada layar muat panjang.
10. **Cabang dan commit kecil.** Satu fitur per cabang; pesan commit jelas; jangan menghapus berkas pengguna tanpa persetujuan.
11. **Tanya sebelum keputusan besar** (engine, gaya, ruang lingkup, rating). Untuk hal kecil putuskan sendiri dan catat asumsi.
12. **Bahasa:** komunikasi dengan pengguna dalam Bahasa Indonesia; identifier, komentar, dan nama berkas dalam Bahasa Inggris.

### 7.3 Standar penerimaan "Wow Slice"

Visual:
- Dari tiga screenshot standar (awal, vista, aksi), **uji grayscale** menunjukkan titik fokus jelas dan lapisan nilai terbaca.
- Palet sesuai Art Bible v2 (krem hangat / biru-hitam tinta / satu merah cinnabar / kuning lentera).
- Ada bloom halus, kabut berwarna, cahaya volumetrik di setidaknya dua tempat, partikel penghidup, kontur tinta bervariasi.
- Karakter ber-rig **sungguhan** (skinned mesh + Animator), siluet berbeda per peran, topeng/lambang pembeda.
- Viewmodel tangan penuh dengan animasi: diam, jalan, jongkok, tarik pedang, tebas, parry, lempar kunai, segel tangan.
- HUD maksimum empat elemen; telemetri debug tersembunyi secara bawaan.

Gameplay:
- **Bayangan hidup (G1):** pemain punya bayangan nyata; bayangan menebal/menipis menurut cahaya; *Shadow-Meld* bekerja antar bayangan terhubung; lentera dapat dipadamkan, dinyalakan, digeser.
- **Suara-tinta (G2):** setiap langkah/suara penting menampilkan riak tinta; mode "Dengar" menampilkan penjaga sebagai sapuan kuas.
- **Fail state sungguhan** (layar kegagalan, penjelasan penyebab, muat ulang cepat) dan **kondisi menang** (tujuan tercapai, layar hasil, peringkat); klimaks di menara.
- AI: NavMesh, patroli, kecurigaan, pencarian titik terakhir, alarm ke penjaga terdekat, memori sederhana.

Teknis:
- ≥ 60 FPS rata-rata, 1% low ≥ 45 pada GPU kelas GTX 1060/RX 580 (1080p, Medium). Tidak ada alokasi per-frame di jalur panas.
- Build Windows dapat dijalankan tanpa editor.
- Tes otomatis untuk logika murni (kecurigaan, kebisingan, stamina) dan 5 skenario AI.

### 7.4 Art Bible v2 — perubahan wajib

- Palet resmi (HEX final dibuat AI dan disetujui pengguna): **Kertas Krem, Tinta Biru-Hitam, Cinnabar (aksen tunggal), Kuning Lentera (sumber hangat tunggal)**; warna lain hanya turunan bernilai rendah-saturasi.
- Aturan komposisi tiga lapis (latar/tengah/depan) dan aturan kontras fokal pada penjaga dan jalur.
- Gaya kontur: tebal pada siluet luar, tipis pada lipatan, memudar pada jarak jauh.
- Gaya darah: **percikan tinta merah** (cetak), bukan fluid realistis; ada toggle Off/Rendah/Tinggi.
- UI: panel kertas, stempel hanko, sapuan kuas, kamon; font serif tegas untuk judul + sans bersih untuk isi.
- Anggaran: poligon pemain/penjaga, ukuran tekstur, draw call, memori (tulis angka final).

### 7.5 Gerbang kualitas

- **Gerbang Minggu 4 / 8 / 12:** tunjukkan klip/hasil ke 5 orang yang tidak mengenal proyek, tanpa penjelasan. Catat: apa yang mereka pahami, di mana mereka bingung, apa yang mereka ceritakan ulang. Jika kurang dari 3 dari 5 antusias, hentikan fitur baru dan perbaiki.
- Laporan gerbang berisi: klip, tabel temuan, 10 perbaikan teratas, keputusan lanjut/ubah arah.

### 7.6 Prompt bertahap (berikan satu per sesi)

**W1 — Proyek Unity yang benar-benar berjalan**
```
W1. Hapus ketergantungan pada slice WebGL (bekukan sebagai tag git "webgl-lookdev").
Di Unity 6 + URP buat scene yang berjalan: tanah, 1 bangunan placeholder, matahari
terarah + bayangan, kamera orang pertama (Cinemachine), gerak WASD/jongkok/lompat
dengan Input System. Pasang URP Asset, Volume global, dan profil Input Actions.
Bukti: build Windows + video 15 dtk + pengukuran di perangkat GPU nyata. Jangan
menambah fitur lain.
```

**W2 — Look Dev v2**
```
W2. Terapkan Art Bible v2: palet 4 warna, langit gaya cetak kayu, bloom halus,
cahaya volumetrik, kontur tinta bervariasi (Shader Graph/HLSL), tekstur kertas,
bayangan bergaya. Ganti material prosedural kasar dengan material lukis (impor
tekstur berlisensi bersih atau buat sendiri). Hasilkan 3 screenshot standar +
uji grayscale + 3 hal yang masih jelek.
```

**W3 — Tangan dan karakter**
```
W3. Buat viewmodel tangan + katana ber-rig dengan animasi (diam, jalan, jongkok,
tarik pedang, tebas, parry, lempar kunai, segel tangan). Buat 1 karakter penjaga
ber-rig (Animator) dengan topeng/lambang klan; uji siluet hitam. Catat sumber/lisensi
tiap aset di ASSETS_LICENSE.md. Bukti: video 20 dtk tiap hal.
```

**W4 — Bayangan hidup + siluet shoji**
```
W4. Implementasikan pilar Bayangan: (a) bayangan pemain nyata dan tingkat cahaya
yang memengaruhi kecepatan/kebisingan/visibilitas, (b) Shadow-Meld antar bayangan
terhubung, (c) lentera: padamkan, nyalakan, geser, (d) siluet penghuni di balik shoji.
Bukti: klip 15 dtk "meld" + tabel parameter di data (bukan di kode).
```

**W5 — Suara-tinta + HUD cetak**
```
W5. Implementasikan pilar Tinta/Suara: riak tinta untuk setiap suara berdasar tabel
acoustics, mode "Dengar" (dunia memudar ke kertas, penjaga jadi sapuan kuas), dan
HUD cetak 4 elemen. Pastikan setiap deteksi punya penjelasan visual. Bukti: klip
15 dtk + uji grayscale.
```

**W6 — AI & fail state**
```
W6. Bangun AI penjaga dengan NavMesh/behavior tree: patroli, kecurigaan, pencarian
titik terakhir, alarm ke penjaga terdekat, memori sederhana. Tambahkan fail state
dan muat ulang < 2 dtk dengan titik simpan per ruang. Buat 5 skenario uji otomatis
(lewat, terdeteksi, dicari, dibunuh senyap, kabur). Laporkan hasil.
```

**W7 — Satu Tebasan**
```
W7. Pilar Satu Tebasan: duel 1–2 pukulan mematikan untuk kedua pihak, standoff
(kamae), iai (tarik cepat tapi bersuara) vs bunuh senyap, parry, hit-stop, jejak
tebasan, suara berlapis, percikan tinta (toggle gore). Bukti: klip duel 15 dtk +
parameter di data.
```

**W8 — Gema Bayangan**
```
W8. Rekam 10 dtk terakhir gerak pemain saat gagal dan putar sebagai gema hantu yang
dapat memancing penjaga. Batasi biaya memori. Bukti: klip 15 dtk "gema jadi umpan".
```

**W9 — Audio**
```
W9. Audio adaptif berlapis (tenang→curiga→tempur→hening), foley per permukaan,
mixing 3D dengan oklusi sederhana. Hanya aset berlisensi bersih/rekaman sendiri.
Bukti: rekaman 60 dtk + daftar aset di ASSETS_LICENSE.md.
```

**W10 — Level 15 menit + klimaks**
```
W10. Rangkai satu misi 15 menit: 3 area, 3 rute (tanah/atap/bawah), 1 klimaks di
menara, 3 tujuan opsional, peringkat akhir. Tutorial lewat tata ruang, bukan teks
panjang. Bukti: build + rekaman penuh + 5 orang asing menamatkan tanpa bantuan.
```

**W11 — Playtest & polesan**
```
W11. Jalankan playtest dengan 5–8 orang asing. Rekam titik bingung, kematian
berulang, dan momen antusias. Perbaiki 10 masalah teratas tanpa fitur baru.
Laporkan sebelum/sesudah.
```

**W12 — Toko & demo**
```
W12. Siapkan trailer 60 dtk (3 dtk pertama = hook Bayangan/Suara), kapsul,
6 screenshot, deskripsi tajam, dan build demo 15 menit. Periksa lisensi aset,
rating IARC, dan checklist Steam.
```

### 7.7 Format laporan setiap tugas

```
## Ringkasan jujur (apa jadi, apa belum)
## Bukti (klip/screenshot, FPS rata-rata + 1% low + draw call + memori,
##        spesifikasi mesin uji, apakah GPU nyata)
## Uji 3 Detik: lolos/tidak + alasan
## Perubahan (berkas, aset, lisensi baru)
## Masalah tersisa (daftar jujur, termasuk yang jelek)
## Langkah berikutnya (maks. 3, satu prioritas)
```

### 7.8 Daftar periksa selesai (per tugas)

- [ ] Build berjalan tanpa error/peringatan baru
- [ ] Bukti dari build nyata (bukan mockup) dan angka performa dengan GPU yang disebutkan
- [ ] Lolos Uji 3 Detik dan melayani satu pilar
- [ ] Tidak ada duplikasi logika/data/berkas
- [ ] Aset tercatat lisensinya; tidak ada aset prosedural tanpa label `TEMP_`
- [ ] Tidak ada klaim berlebihan di komentar/README/CHANGELOG
- [ ] `CHANGELOG.md`/`VERSION` diperbarui dengan isi yang benar-benar berubah

---

## BAGIAN 8 — Langkah Segera (minggu ini)

1. **Putuskan jalur teknologi** (saran: Unity 6 + URP) dan **bekukan** slice WebGL sebagai laboratorium.
2. **Pilih tiga pilar** (saran: Bayangan, Tinta/Suara, Satu Tebasan) dan tulis kalimat hook di README.
3. **Ganti `AGENTS.md`** dengan Bagian 7, dan jadikan `CLAUDE.md` hanya menunjuk ke sana.
4. **Kerjakan W1 lalu W2**, lalu uji dengan 5 orang asing sebelum lanjut.
5. **Siapkan GPU nyata** untuk setiap pengukuran dan simpan spesifikasinya.
6. **Mulai catatan "momen klip"**: setiap kali sesuatu terasa keren, rekam 10 detik. Itu bahan trailer Anda.

---

## Penutup

Kemajuan Anda dari v0.7 ke v1.0 membuktikan arah ini bisa dikerjakan. Sekarang taruhannya berubah: bukan lagi *"apakah terlihat bagus?"* tetapi *"apakah orang asing akan berhenti, menonton, dan menunggu rilisnya?"*. Game stealth yang **menjadikan bayangan sebagai nyawa, suara sebagai tinta, dan satu tebasan sebagai taruhan** punya peluang itu. Bangun satu momen yang menakjubkan terlebih dahulu, lalu perluas.
