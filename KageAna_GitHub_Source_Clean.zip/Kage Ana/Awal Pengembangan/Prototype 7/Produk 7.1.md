\### 1. Pemahaman tentang Jiwa Game (Maksimal 12 Baris)



\*\*KAGE-ANA (影穴)\*\* bukanlah permainan menyelesaikan panggung misi satu per satu, melainkan simulasi menjalani kehidupan ganda seorang manusia biasa di Lembah Kurokawa yang kebetulan merupakan murid terakhir jaringan shinobi \*Ryū Kage-Ana\*.

Pada siang hari (\*Omote\*), ia adalah tetangga yang dikenal warga Nagaya dan Pasar Timur: punya kamar sewa di rumah Ohana, pekerjaan sampul untuk mencari nafkah, tagihan sewa mingguan, etika sosial, serta kebiasaan sehari-hari.

Pada malam hari (\*Ura\*), ia menyelinap lewat atap, kolong, dan lubang bayangan (\*kage-ana\*) untuk menjalankan pekerjaan gelap, mencuri informasi, atau menebas sasaran yang tidak boleh diketahui siapa pun.

Inti ketegangan, konsekuensi, dan humor gelap permainan lahir dari \*\*sambungan antara dua wajah itu\*\*: luka tebasan semalam bisa dicium oleh Tabib Sōan esok pagi, uang hasil curian memicu kecurigaan jika tak sebanding dengan upah kerja sampul, dan rumor menyebar serta terdistorsi dari mulut ke mulut di rumah teh.

Tidak ada alur cerita linear, bar HP tradisional, maupun layar "Mission Complete" berperingkat S/A/B; cerita muncul secara sistemik dari jadwal, ingatan, keyakinan, dan gosip 26 penduduk desa yang hidup dalam siklus kalender 28 hari (4 musim).

Setiap tindak kekerasan memiliki harga sosial dan menggeser Hati pemain antara \*\*Hangat\*\* dan \*\*Dingin\*\*, hingga akhirnya seluruh jejak hidup selama setahun dirangkum secara jujur tanpa skor di dalam gulungan buku harian \*\*Nisshi\*\*.



\### 2. Hal yang Ambigu atau Bertentangan (Antara Kitab Dunia v3.0 dan Zip v2.0.1)



1\. \*\*Struktur Penyelesaian Misi vs Siklus Hidup \& \*Nisshi\* (Kitab 1.3 #4 \& 8.10 vs Zip v2.0.1):\*\* Zip `v2.0.1` (baik di `webgl\_vertical\_slice/index.html`, `src/main.js`, maupun `AGENTS.md` lama) masih menampilkan modal kemenangan `"KONTRAK SELESAI"` dengan segel peringkat `Rank S/A/B`, padahal Kitab Bagian 1.3 #4 secara tegas melarang layar menang/peringkat misi dan menggantinya dengan siklus harian serta gulungan \*Nisshi\* di Hari 28.

2\. \*\*Sudut Pandang Kamera Utama (Kitab 11.2 #9 \& 13 D1 vs Zip v2.0.1):\*\* Zip `v2.0.1` (`AGENTS.md`, `README.md`, `FirstPersonStealthLocomotion.cs`, dan WebGL) dibangun sebagai \*first-person\* murni dengan \*viewmodel\* tangan, sedangkan Kitab Bagian 11.2 #9 dan Bagian 13 (D1) merekomendasikan \*\*orang ketiga + opsi intip orang pertama\*\* agar pakaian/identitas sosial (\*Omote/Ura\*) terlihat jelas saat berinteraksi dengan warga.

3\. \*\*Empat Elemen HUD Diegetik (Kitab 10.7 vs Zip v2.0.1):\*\* HUD di zip `v2.0.1` menampilkan bar persentase `Vitalitas`, `Stamina`, `Kekuatan Bayangan`, serta kompas jarak meter ke Menara Utara, sedangkan Kitab Bagian 10.7 menetapkan 4 elemen HUD berbeda tanpa bar HP/mana klasik: (1) penanda kesadaran NPC (cap \*hanko\*), (2) indikator suara (riak tinta), (3) jam/segmen hari (disk matahari/bulan), dan (4) indikator Hati (nyala lentera kecil saat berubah).

4\. \*\*Aturan "Mata Telinga" / Listen Mode (Kitab 10.7 vs Zip v2.0.1):\*\* Di zip `v2.0.1`, \*Mata Telinga\* (`\[V]/\[Tab]`) adalah \*toggle\* bebas tanpa batas waktu yang mengubah seluruh layar menjadi kertas \*washi\* penuh; di Kitab Bagian 10.7, \*Mata Telinga\* dibatasi \*\*durasi aktif 5 detik\*\* dengan \*\*cooldown 12 detik\*\* dan bingkai \*washi\* yang menutup tepi layar.

5\. \*\*Mekanik Kematian, \*Fast Reload\*, \& \*Kage-Echo\* (Kitab 3.4 D4, 8.6, 8.8 vs Zip v2.0.1):\*\* Zip `v2.0.1` menggunakan layar gagal + \*fast reload\* `< 1 detik` yang memunculkan hantu rekaman 10 detik terakhir (\*Kage-Echo\*), sedangkan Kitab Bagian 8.8 menyatakan kegagalan tidak mengulang level melainkan memicu konsekuensi berlanjut (atau bangkit kembali secara terkendali di Kuburan Tua/Kuil Kurama D4 per Bagian 3.4). Perlu konfirmasi apakah \*Kage-Echo\* dihapus dari kanon utama atau disimpan sebagai teknik khusus.

6\. \*\*Arsitektur `Sim` Murni Tanpa `MonoBehaviour` \& Determinisme Seed (Kitab 1.3 #2, 11.1, 11.2 vs Zip v2.0.1):\*\* Skrip C# di `unity\_project/Assets/\_Project/Scripts/` pada zip `v2.0.1` masih berupa `MonoBehaviour` yang mencampur logika dan komponen `UnityEngine`, belum dipisah ke `Assets/\_Project/Runtime/Sim/` (C# murni tanpa `UnityEngine.GameObject` dan wajib memakai `SimRandom(seed, stream)`).

7\. \*\*Struktur Berkas Data Kanonis (Kitab 11.1 \& 11.3 vs Zip v2.0.1):\*\* Zip `v2.0.1` hanya memiliki dua berkas JSON monolitik (`GameplayConfig.json` dan `VerticalSliceLevelData.json`), sedangkan Kitab Bagian 11.1 \& 11.3 mewajibkan struktur terpisah per domain (`Data/npcs/\*.json`, `places/\*.json`, `gigs/\*.json`, `stories/\*.json`, `rumors/\*.json`, `items/\*.json`, `clothing/\*.json`, `festivals/\*.json`, `tuning/\*.json`, `lighting/\*.json`) beserta skema validasi di `docs/schemas/`.

8\. \*\*Skrip Tes Arah `test\_fix.js` yang Disebut di Kitab 12.6 Belum Ada di Dalam Zip v2.0.1:\*\* Kitab Bagian 12.6 menyebut \*"Rujukan: `test\_fix.js` pada v2.0.1 sudah memuat tiga dari empat uji ini untuk lab WebGL"\*, namun di dalam arsip `KageAna\_PC\_Game\_Setup\_v2.0.1\_MouseFix.zip` berkas `test\_fix.js` tersebut tidak ikut terkemas (hanya penjelasannya di `CHANGELOG.md` dan implementasi `this.projMat\[0] = -this.projMat\[0]; gl.frontFace(gl.CW);` di `WebGLRenderer.js`), sehingga skrip uji regresi arah otomatisnya perlu kita wujudkan secara nyata di Tugas L0.



\### 3. Rencana Tugas L0 (Bagian 14.2 — Sinkron \& Fondasi)



Kami akan bekerja di salinan kerja cabang/folder baru tanpa menghapus berkas asli Anda, dan hanya mengeksekusi cakupan \*\*Tugas L0\*\* (tanpa membuat konten atau aset baru):



\* \*\*Berkas yang Akan Dibuat / Diubah:\*\*

1\. `AGENTS.md` (diperbarui ke v3.0 sebagai ringkasan ketat Bagian 1 + Bagian 14 Kitab Dunia, menggantikan `AGENTS.md` v2 lama) dan `CLAUDE.md` (tetap penunjuk 1 baris ke `AGENTS.md`).

2\. `ART\_BIBLE.md` dan `ARCHITECTURE.md` (disinkronkan dengan Bagian 10 dan Bagian 11 Kitab Dunia v3.0, mencatat pembekuan `webgl\_vertical\_slice/` sebagai laboratorium tampilan `LAB\_`).

3\. `DECISIONS.md` (memuat 10 keputusan terbuka D1–D10 dari Bagian 13 dengan status `"diusulkan"` beserta pencatatan 8 pertentangan di atas).

4\. `IDEAS.md` (tempat menampung ide di luar fase aktif, termasuk pencatatan mekanik lama seperti \*Kage-Echo\* bila ditunda/diubah).

5\. `ASSETS\_LICENSE.md` (diperbarui sesuai Bagian 1.3 #10 dengan label `TEMP\_` untuk seluruh prosedural sementara dan larangan TTS peramban/aset tak berlisensi).

6\. `docs/schemas/\*.schema.json` (skema validasi JSON dasar untuk `npcs`, `places`, `gigs`, `stories`, `rumors`, `tuning`, dan `lighting` sesuai Bagian 11.3).

7\. `tools/validate\_data.py` (validator skema JSON dan pemeriksaan referensi silang ID tempat/NPC/barang, jadwal tumpang-tindih, jam tak terjangkau, serta syarat `≥ 3` pendekatan per gig).

8\. `tools/test\_handedness.py` \& `tools/test\_fix.js` (tes regresi arah/handedness otomatis sesuai Bagian 12.6: uji matematis `forward`/`right`, uji proyeksi NDC `+X > 0` dan `-X < 0`, uji input `movementX`/`movementY`, serta verifikasi matriks `WebGLRenderer.js`).

9\. `tools/run\_headless\_sim.py` (kerangka runner simulasi headless deterministik berbasis seed yang menghasilkan format laporan `SIM REPORT` Bagian 12.2 dengan pemeriksaan `violations: 0`).

10\. `.github/workflows/ci.yml` \& `tools/run\_ci.py` (pipeline CI lokal \& GitHub Actions yang menjalankan `validate\_data.py`, tes arah 12.6, pemeriksaan kata terlarang Bagian 12.5, dan `run\_headless\_sim.py` dummy).





\* \*\*Bukti yang Akan Diberikan di Akhir Tugas L0:\*\*

1\. Output eksekusi nyata `tools/run\_ci.py` yang memperlihatkan seluruh tahapan CI \*\*HIJAU (PASS)\*\*: validator data, 4 uji regresi arah/handedness (12.6), pendeteksi \*red-flag\* (12.5), dan laporan `SIM REPORT` headless kerangka awal (`violations: 0`).

2\. Daftar lengkap berkas yang dibuat/diubah beserta ringkasan jujur apa yang sudah selesai di L0 dan apa yang baru akan dikerjakan di L1.







Saya berhenti di sini sesuai aturan Bagian 0. Silakan beri persetujuan Anda (atau koreksi atas keputusan terbuka D1–D10 / poin ambigu di atas) sebelum saya mulai mengerjakan \*\*Tugas L0\*\*.

