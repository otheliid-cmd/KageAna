// ============================================================================
// KAGE-ANA v0.4 (Tahap 3): Anatomical Combat, Stealth Choke & Corpse Hiding
// ============================================================================

const BODY_ZONES = {
  HEAD: { id: 'HEAD', label: 'KEPALA ([Klik Kiri] Penggal Instan)', offset: { x: 0, y: 1.64, z: 0 }, size: { w: 0.26, h: 0.26, d: 0.26 } },
  NECK: { id: 'NECK', label: 'LEHER / ARTERI ([F] Cekik Senyap / [Klik Kiri] Penggal)', offset: { x: 0, y: 1.44, z: 0 }, size: { w: 0.18, h: 0.14, d: 0.18 } },
  THORAX_HEART: { id: 'THORAX_HEART', label: 'DADA / JANTUNG ([Klik Kanan] Tusuk Tembus & Tancap Pedang)', offset: { x: 0, y: 1.18, z: 0 }, size: { w: 0.44, h: 0.38, d: 0.26 } },
  ABDOMEN: { id: 'ABDOMEN', label: 'PERUT / ORGAN DALAM ([Klik Kanan] Tusuk Tembus)', offset: { x: 0, y: 0.86, z: 0 }, size: { w: 0.38, h: 0.26, d: 0.24 } },
  RIGHT_ARM: { id: 'RIGHT_ARM', label: 'LENGAN KANAN PEDANG ([Klik Kiri] Putus Tangan / [Q] Rebut Pedang)', offset: { x: 0.32, y: 1.12, z: 0.08 }, size: { w: 0.18, h: 0.52, d: 0.18 } },
  LEFT_ARM: { id: 'LEFT_ARM', label: 'LENGAN KIRI', offset: { x: -0.32, y: 1.12, z: 0 }, size: { w: 0.18, h: 0.52, d: 0.18 } },
  RIGHT_LEG: { id: 'RIGHT_LEG', label: 'KAKI KANAN ([Klik Kiri] Putus / Lumpuhkan)', offset: { x: 0.14, y: 0.42, z: 0 }, size: { w: 0.18, h: 0.74, d: 0.18 } },
  LEFT_LEG: { id: 'LEFT_LEG', label: 'KAKI KIRI ([Klik Kiri] Putus / Lumpuhkan)', offset: { x: -0.14, y: 0.42, z: 0 }, size: { w: 0.18, h: 0.74, d: 0.18 } }
};

class AnatomicalNPC {
  constructor(config) {
    this.id = config.id;
    this.name = config.name;
    this.role = config.role;
    this.isTarget = !!config.isTarget;
    this.storyChapterId = config.storyChapterId || null;
    this.disguiseType = config.disguiseType || 'GUARD';
    this.faction = config.faction || (this.isTarget ? 'SYNDICATE_TARGET' : 'SYNDICATE_GUARD');
    this.isInnocent = this.faction === 'INNOCENT_CIVILIAN' || this.faction === 'ALLIED_CLAN';
    this.publicRole = config.publicRole || this.role;
    this.dailyActivity = config.dailyActivity || 'Berpatroli mengamati sekitar';
    this.secretClue = config.secretClue || (this.isTarget
      ? '🔍 PETUNJUK COCOK: Menyembunyikan lencana Sindikat Kuro-no-Wa & daftar upeti darah!'
      : (this.isInnocent
        ? '🕊️ WARGA TAK BERSALAH / KLAN SEKUTU: Sedang beraktivitas normal. JANGAN DIBUNUH!'
        : '⚔️ Penjaga Bersenjata Sindikat Kuro-no-Wa.'));
    this.isIdentityInspected = !!config.isIdentityInspected;
    this.projectileCooldown = 1.8 + Math.random() * 1.5;
    this.x = config.x;
    this.y = config.y || 0;
    this.z = config.z;
    this.yaw = config.yaw || 0;
    this.patrolPts = config.patrolPts || [{ x: this.x, z: this.z }];
    this.patrolIdx = 0;

    this.tunicColor = config.tunicColor || (this.isTarget ? '#8a1c24' : '#233858');
    this.accentColor = config.accentColor || (this.isTarget ? '#d4af37' : '#3a506b');
    this.hatStyle = config.hatStyle || (this.isTarget ? 'KABUTO_GOLD' : 'JINGASA');
    this.wearsNeckArmor = !!config.wearsNeckArmor;

    this.bloodVolume = 100;
    this.bleedRate = 0;
    this.isDead = false;
    this.isChokedUnconscious = false;
    this.isBodyHidden = false; // Stage 3: True once hidden in a Bamboo Bush or River!
    this.wasCorpseSpotted = false;
    this.isIncapacitated = false;
    this.hasWeapon = config.hasWeapon !== undefined ? config.hasWeapon : !this.isInnocent;
    this.hasImpaledKatanaStuck = false;
    this.aiState = 'PATROL';
    this.suspicion = 0;
    this.blindTimer = 0;
    this.attackCooldown = 1.2;
    this.animTime = Math.random() * 10;
    this.isMoving = false;

    this.zones = {};
    Object.keys(BODY_ZONES).forEach(k => {
      this.zones[k] = {
        severed: false,
        impaled: false,
        crippled: false
      };
    });
  }

  buildCharacterMeshesAndHitboxes() {
    if (this.isBodyHidden) {
      return { hitboxes: [], visualMeshes: [] };
    }

    if (this.isDead) {
      const cy = this.y || 0.14;
      const cosY = Math.cos(this.yaw), sinY = Math.sin(this.yaw);
      const pHead = { x: this.x + 0.55 * sinY, y: cy + 0.08, z: this.z + 0.55 * cosY };
      const pTorso = { x: this.x, y: cy + 0.10, z: this.z };
      const pFeet = { x: this.x - 0.65 * sinY, y: cy + 0.06, z: this.z - 0.65 * cosY };
      return {
        hitboxes: [],
        visualMeshes: [
          { shape: 'hd_shadow', x: this.x, y: 0.02, z: this.z, w: 1.55 },
          { shape: 'hd_capsule', p1: pTorso, p2: pFeet, r1: 0.20, r2: 0.13, color: this.tunicColor, material: 'cloth' },
          { shape: 'hd_capsule', p1: pHead, p2: pTorso, r1: 0.16, r2: 0.22, color: this.tunicColor, material: 'cloth' },
          ...(this.zones.HEAD.severed ? [] : [{
            shape: 'hd_head', x: pHead.x, y: pHead.y + 0.08, z: pHead.z, w: 0.24, h: 0.26,
            yaw: this.yaw, hairColor: '#3b2419', hatStyle: 'NONE'
          }])
        ]
      };
    }

    const cosY = Math.cos(this.yaw), sinY = Math.sin(this.yaw);
    const hitboxes = [];
    const visualMeshes = [];

    const strideAmp = this.isMoving ? (this.aiState === 'COMBAT' ? 0.46 : 0.30) : 0.03;
    const walkSwing = Math.sin(this.animTime * 5.8) * strideAmp;
    const kneeL = this.isMoving ? Math.max(0, -Math.cos(this.animTime * 5.8)) * 0.34 : 0.04;
    const kneeR = this.isMoving ? Math.max(0, Math.cos(this.animTime * 5.8)) * 0.34 : 0.04;
    const breath = Math.sin(this.animTime * 2.4) * 0.012;
    const collapseMult = this.isIncapacitated ? 0.42 : 1.0;

    const toWorld = (lx, ly, lz) => ({
      x: this.x + (lx * cosY + lz * sinY),
      y: this.y + ly * collapseMult,
      z: this.z + (-lx * sinY + lz * cosY)
    });

    // 1. Register 8 Anatomical Raycast Hitboxes (100% preserved for dismemberment & combat!)
    Object.keys(BODY_ZONES).forEach(key => {
      const zState = this.zones[key];
      if (zState.severed) return;
      const def = BODY_ZONES[key];
      const wp = toWorld(def.offset.x, def.offset.y, def.offset.z);
      hitboxes.push({
        npc: this,
        zoneKey: key,
        label: def.label,
        x: wp.x,
        y: wp.y,
        z: wp.z,
        w: def.size.w,
        h: def.size.h,
        d: def.size.d
      });
    });

    // 2. Soft V-Ray Ground Contact Shadow
    visualMeshes.push({
      shape: 'hd_shadow',
      x: this.x,
      y: 0.02,
      z: this.z,
      w: 0.95
    });

    const isFemaleStyle = this.id.includes('woman') || this.id.includes('aya') || this.name.includes('Hana') || this.name.includes('Aya');
    const legSkinMaterial = (isFemaleStyle || this.disguiseType === 'PEASANT') ? 'skin' : 'cloth';
    const shoeColor = isFemaleStyle ? '#7ec8e3' : '#26201b';

    // 3. Smooth Organic Articulated LEGS (Hip -> Knee -> Ankle -> Foot)
    if (!this.zones.LEFT_LEG.severed) {
      const lHip = toWorld(-0.12, 0.84, 0);
      const lKneeZ = Math.sin(walkSwing) * 0.22;
      const lKnee = toWorld(-0.12, 0.46, lKneeZ);
      const lAnkleZ = lKneeZ - Math.sin(kneeL) * 0.20;
      const lAnkle = toWorld(-0.12, 0.10, lAnkleZ);
      const lToe = toWorld(-0.12, 0.04, lAnkleZ + 0.14);

      visualMeshes.push({
        shape: 'hd_capsule', p1: lHip, p2: lKnee, r1: 0.095, r2: 0.072,
        color: this.zones.LEFT_LEG.crippled ? '#8a1c1c' : this.tunicColor,
        material: legSkinMaterial, depthBias: 0.06
      });
      visualMeshes.push({
        shape: 'hd_capsule', p1: lKnee, p2: lAnkle, r1: 0.068, r2: 0.045,
        color: this.zones.LEFT_LEG.crippled ? '#8a1c1c' : '#232733',
        material: legSkinMaterial
      });
      visualMeshes.push({
        shape: 'hd_capsule', p1: lAnkle, p2: lToe, r1: 0.048, r2: 0.042,
        color: shoeColor, material: 'cloth', trimColor: '#e8f4f8'
      });
    }

    if (!this.zones.RIGHT_LEG.severed) {
      const rHip = toWorld(0.12, 0.84, 0);
      const rKneeZ = Math.sin(-walkSwing) * 0.22;
      const rKnee = toWorld(0.12, 0.46, rKneeZ);
      const rAnkleZ = rKneeZ - Math.sin(kneeR) * 0.20;
      const rAnkle = toWorld(0.12, 0.10, rAnkleZ);
      const rToe = toWorld(0.12, 0.04, rAnkleZ + 0.14);

      visualMeshes.push({
        shape: 'hd_capsule', p1: rHip, p2: rKnee, r1: 0.095, r2: 0.072,
        color: this.zones.RIGHT_LEG.crippled ? '#8a1c1c' : this.tunicColor,
        material: legSkinMaterial, depthBias: 0.06
      });
      visualMeshes.push({
        shape: 'hd_capsule', p1: rKnee, p2: rAnkle, r1: 0.068, r2: 0.045,
        color: this.zones.RIGHT_LEG.crippled ? '#8a1c1c' : '#232733',
        material: legSkinMaterial
      });
      visualMeshes.push({
        shape: 'hd_capsule', p1: rAnkle, p2: rToe, r1: 0.048, r2: 0.042,
        color: shoeColor, material: 'cloth', trimColor: '#e8f4f8'
      });
    }

    // 4. HD Contoured Torso, Collarbone V-Neck, Inner Dress/Kosode, Outer Cardigan/Haori & Pleated Skirt/Hakama
    const chestCol = this.zones.THORAX_HEART.impaled ? '#4a0606' : (this.zones.THORAX_HEART.crippled ? '#751414' : this.tunicColor);
    const innerCol = isFemaleStyle ? '#f7f3eb' : (this.isTarget ? '#ebe0cc' : '#d8d2c7');
    visualMeshes.push({
      shape: 'hd_torso',
      pTop: toWorld(0, 1.38 + breath, 0),
      pWaist: toWorld(0, 1.02 + breath * 0.5, 0),
      pHip: toWorld(0, 0.66, 0),
      wShoulder: isFemaleStyle ? 0.20 : 0.23,
      wWaist: isFemaleStyle ? 0.145 : 0.175,
      wHip: isFemaleStyle ? 0.23 : 0.21,
      coatColor: chestCol,
      innerColor: innerCol,
      trimColor: '#ead4bc',
      obiColor: this.accentColor,
      isFemaleStyle
    });

    // 5. Smooth Articulated ARMS (Shoulder -> Elbow -> Wrist -> Sculpted Hand)
    if (!this.zones.LEFT_ARM.severed) {
      const lSh = toWorld(-0.22, 1.34 + breath, 0);
      let lElb, lWr, lHand;
      if (this.zones.RIGHT_ARM.severed) {
        // Clutching bleeding right shoulder stump
        lElb = toWorld(-0.10, 1.18, 0.18);
        lWr = toWorld(0.14, 1.28, 0.20);
        lHand = toWorld(0.20, 1.30, 0.18);
      } else if (isFemaleStyle && !this.isMoving) {
        // Graceful 091_W_Aya hand pose near collarbone/cheek!
        lElb = toWorld(-0.25, 1.08 + breath, 0.10);
        lWr = toWorld(-0.18, 1.36 + breath, 0.20);
        lHand = toWorld(-0.14, 1.44 + breath, 0.22);
      } else {
        const laSwing = -walkSwing * 0.70;
        lElb = toWorld(-0.25, 1.10 + breath, Math.sin(laSwing) * 0.12);
        lWr = toWorld(-0.24, 0.88 + breath, Math.sin(laSwing) * 0.22 + 0.10);
        lHand = toWorld(-0.23, 0.80 + breath, Math.sin(laSwing) * 0.25 + 0.13);
      }
      visualMeshes.push({ shape: 'hd_capsule', p1: lSh, p2: lElb, r1: 0.068, r2: 0.055, color: chestCol, material: 'cloth', depthBias: -0.10 });
      visualMeshes.push({ shape: 'hd_capsule', p1: lElb, p2: lWr, r1: 0.054, r2: 0.042, color: chestCol, material: 'cloth', trimColor: '#ead4bc', depthBias: -0.12 });
      visualMeshes.push({ shape: 'hd_capsule', p1: lWr, p2: lHand, r1: 0.042, r2: 0.032, color: '#f3cbb4', material: 'skin', depthBias: -0.14 });
    } else {
      const st1 = toWorld(-0.22, 1.34, 0), st2 = toWorld(-0.25, 1.22, 0);
      visualMeshes.push({ shape: 'hd_capsule', p1: st1, p2: st2, r1: 0.065, r2: 0.05, color: '#9e0e0e', material: 'cloth' });
    }

    if (!this.zones.RIGHT_ARM.severed) {
      const rSh = toWorld(0.22, 1.34 + breath, 0);
      let raSwing = walkSwing * 0.70;
      if (this.aiState === 'COMBAT' && this.hasWeapon) {
        raSwing = -0.68 + Math.sin(this.animTime * 4.5) * 0.18;
      }
      const rElb = toWorld(0.25, 1.10 + breath, Math.sin(raSwing) * 0.12);
      const rWr = toWorld(0.24, 0.90 + breath, Math.sin(raSwing) * 0.22 + 0.14);
      const rHand = toWorld(0.23, 0.82 + breath, Math.sin(raSwing) * 0.25 + 0.18);

      visualMeshes.push({ shape: 'hd_capsule', p1: rSh, p2: rElb, r1: 0.068, r2: 0.055, color: chestCol, material: 'cloth', depthBias: -0.10 });
      visualMeshes.push({ shape: 'hd_capsule', p1: rElb, p2: rWr, r1: 0.054, r2: 0.042, color: chestCol, material: 'cloth', trimColor: '#ead4bc', depthBias: -0.12 });
      visualMeshes.push({ shape: 'hd_capsule', p1: rWr, p2: rHand, r1: 0.042, r2: 0.032, color: '#f3cbb4', material: 'skin', depthBias: -0.14 });

      if (this.hasWeapon) {
        const wPos = toWorld(0.28, 1.08, 0.54);
        const bladeBox = {
          npc: this,
          zoneKey: 'WEAPON_BLADE',
          label: 'PEDANG LAWAN ([Q] Tangkis / Rebut Jujutsu)',
          x: wPos.x,
          y: wPos.y,
          z: wPos.z,
          w: 0.04,
          h: 0.04,
          d: 0.92,
          yaw: this.yaw,
          pitch: raSwing * 0.4,
          color: '#e2ebf5',
          shape: 'box'
        };
        hitboxes.push(bladeBox);
        visualMeshes.push(bladeBox);
      }
    } else {
      const st1 = toWorld(0.22, 1.34, 0), st2 = toWorld(0.25, 1.22, 0);
      visualMeshes.push({ shape: 'hd_capsule', p1: st1, p2: st2, r1: 0.065, r2: 0.05, color: '#9e0e0e', material: 'cloth' });
    }

    // 6. Smooth Subsurface Neck & Photorealistic Textured 3D Head ('hd_head')
    if (!this.zones.NECK.severed && !this.zones.HEAD.severed) {
      const nBot = toWorld(0, 1.36 + breath, 0);
      const nTop = toWorld(0, 1.49 + breath, 0);
      visualMeshes.push({
        shape: 'hd_capsule',
        p1: nTop, p2: nBot,
        r1: this.wearsNeckArmor ? 0.095 : 0.062,
        r2: this.wearsNeckArmor ? 0.110 : 0.072,
        color: this.wearsNeckArmor ? '#848c98' : '#f3cbb4',
        material: this.wearsNeckArmor ? 'armor' : 'skin'
      });
    }

    if (!this.zones.HEAD.severed) {
      const hPos = toWorld(0, 1.60 + breath, 0.01);
      visualMeshes.push({
        shape: 'hd_head',
        x: hPos.x,
        y: hPos.y,
        z: hPos.z,
        w: 0.23,
        h: 0.26,
        yaw: this.yaw,
        hairColor: isFemaleStyle ? '#4a2c1d' : '#1e1612',
        hairStyle: this.disguiseType === 'MONK' ? 'MONK_SHAVED' : 'AYA_BOB',
        hatStyle: isFemaleStyle ? 'NONE' : this.hatStyle,
        hatColor: this.hatStyle === 'KASA' ? '#c8a86b' : this.accentColor,
        hasMustache: !isFemaleStyle && (this.isTarget || this.faction === 'SYNDICATE_GUARD'),
        hasMask: this.faction === 'CLAN_AVENGER'
      });
    }

    // 7. Impaled Katana Sticking Out of Chest
    if (this.hasImpaledKatanaStuck) {
      const kPos = toWorld(0, 1.18, 0.38);
      const stuckBox = {
        npc: this,
        zoneKey: 'STUCK_KATANA',
        label: '⚔️ PEDANGMU MENANCAP DI DADA! ([Klik Kanan / F] Cabut Paksa!)',
        x: kPos.x,
        y: kPos.y,
        z: kPos.z,
        w: 0.07,
        h: 0.07,
        d: 0.86,
        yaw: this.yaw,
        color: '#ffe082',
        shape: 'box',
        emissive: true
      };
      hitboxes.push(stuckBox);
      visualMeshes.push(stuckBox);
    }

    return { hitboxes, visualMeshes };
  }

  /**
   * Stage 3 Feature: Bloodless Stealth Choke [Key F]
   * Eliminates/incapacitates target silently with ZERO bloodstain and steals their clean disguise!
   */
  applyStealthChoke(worldState, onToast) {
    if (this.isDead) return;
    KageAudio.playChoke();
    this.isChokedUnconscious = true;
    this.isDead = true;
    this.isIncapacitated = true;
    this.dropWeaponToGround(worldState);

    // Cleanly equip the target's disguise with 0% bloodstain!
    const stolenDisguise = DISGUISES[this.disguiseType] || DISGUISES.GUARD;
    worldState.currentDisguise = stolenDisguise;
    worldState.bloodstainOnClothes = 0;

    onToast(`🤫 CEKIKAN SENYAP TANPA DARAH! ${this.name} dilumpuhkan & pakaian [${stolenDisguise.name}] diambil bersih (0% Noda Darah)! Tekan [X] untuk sembunyikan tubuhnya.`);

    if (this.isTarget) {
      worldState.completeContractForTarget(this, onToast);
    }
  }

  applyStrike(zoneKey, strikeType, slashDirection, worldState, onToast) {
    if (this.isDead) return;
    const z = this.zones[zoneKey];
    if (!z || z.severed) return;

    if ((zoneKey === 'NECK' || zoneKey === 'HEAD') && this.wearsNeckArmor && strikeType === 'SLASH') {
      KageAudio.playClash();
      worldState.spawnClashSparks(this.x, this.y + 1.5, this.z, 10);
      worldState.playerWeapon.reduceGrip(25, worldState, onToast);
      onToast(`TEBASAN MENTAL! ${this.name} memakai Pelindung Leher Besi (Nodowa)! Tusuk [Klik Kanan] ke Dada/Jantung atau tebas Lengan Kanan!`);
      this.aiState = 'COMBAT';
      return;
    }

    worldState.spawnBloodPool(this.x, this.z);
    worldState.spawnArterialSpray(this.x, this.y + 1.25, this.z, 9);

    if (zoneKey === 'HEAD' || zoneKey === 'NECK') {
      if (strikeType === 'SLASH') {
        KageAudio.playSever();
        z.severed = true;
        this.zones.HEAD.severed = true;
        worldState.spawnSeveredPart(this.x, this.y + 1.65, this.z, '#c89e82', 0.25);
        this.killInstantly(`KEPALA ${this.name.toUpperCase()} TERPENGGAL (${slashDirection})! Tewas seketika.`, worldState, onToast);
      } else {
        KageAudio.playPierce();
        z.impaled = true;
        this.killInstantly(`LEHER/KEPALA ${this.name.toUpperCase()} TERTUSUK TEMBUS! Tewas seketika.`, worldState, onToast);
      }
    } else if (zoneKey === 'THORAX_HEART') {
      if (strikeType === 'PIERCE') {
        KageAudio.playPierce();
        z.impaled = true;
        this.isIncapacitated = true;
        this.bleedRate += 25;
        this.hasImpaledKatanaStuck = true;
        worldState.playerWeapon.lodgeBladeInTarget(this);
        onToast(`DADA ${this.name.toUpperCase()} BOLONG TERTUSUK! Pedangmu menancap di tulang rusuknya—Tekan [Klik Kanan] atau [F] untuk mencabut paksa!`);
      } else {
        KageAudio.playSlash();
        z.crippled = true;
        this.bleedRate += 15;
        this.aiState = 'COMBAT';
        onToast(`Tebasan ${slashDirection} merobek dada ${this.name}! Pendarahan hebat dimulai.`);
      }
    } else if (zoneKey === 'RIGHT_ARM' || zoneKey === 'LEFT_ARM') {
      KageAudio.playSever();
      z.severed = true;
      z.crippled = true;
      this.bleedRate += 16;
      worldState.spawnSeveredPart(this.x + 0.35, this.y + 1.2, this.z, this.tunicColor, 0.22);

      if (zoneKey === 'RIGHT_ARM' && this.hasWeapon) {
        this.dropWeaponToGround(worldState);
        this.aiState = 'DISARMED_FLEE';
        onToast(`LENGAN KANAN ${this.name.toUpperCase()} PUTUS TERTEBAS! Senjatanya jatuh & ia memegang bahu buntungnya sambil kabur!`);
      } else {
        this.aiState = 'DISARMED_FLEE';
        onToast(`Lengan kiri ${this.name} putus tertebas! Target syok dan mengalami pendarahan arteri.`);
      }
    } else if (zoneKey === 'RIGHT_LEG' || zoneKey === 'LEFT_LEG') {
      KageAudio.playSever();
      z.crippled = true;
      this.bleedRate += 12;
      if (strikeType === 'SLASH') {
        z.severed = true;
        this.isIncapacitated = true;
        worldState.spawnSeveredPart(this.x, this.y + 0.4, this.z, '#1b1f29', 0.24);
        onToast(`KAKI ${this.name.toUpperCase()} PUTUS TERTEBAS! Target tumbang tak berdaya di tanah!`);
      } else {
        onToast(`Tendon kaki ${this.name} tertusuk! Pergerakannya pincang parah.`);
      }
    } else if (zoneKey === 'ABDOMEN') {
      KageAudio.playPierce();
      z.impaled = true;
      z.crippled = true;
      this.bleedRate += 18;
      this.isIncapacitated = true;
      if (strikeType === 'PIERCE') {
        this.hasImpaledKatanaStuck = true;
        worldState.playerWeapon.lodgeBladeInTarget(this);
        onToast(`PERUT ${this.name.toUpperCase()} TERTUSUK TEMBUS! Pedang menancap—Tekan [Klik Kanan / F] untuk mencabutnya!`);
      } else {
        onToast(`Perut ${this.name} robek parah! Target ambruk mengalami pendarahan internal.`);
      }
    }
  }

  dropWeaponToGround(worldState) {
    if (!this.hasWeapon) return;
    this.hasWeapon = false;
    worldState.droppedWeapons.push({
      x: this.x + 0.35,
      y: 0.12,
      z: this.z + 0.35,
      yaw: Math.random() * Math.PI
    });
  }

  killInstantly(reason, worldState, onToast) {
    if (this.isDead) return;
    this.isDead = true;
    this.isIncapacitated = true;
    if (this.hasImpaledKatanaStuck) {
      this.hasImpaledKatanaStuck = false;
      worldState.playerWeapon.recoverImpaledBlade();
    }
    this.dropWeaponToGround(worldState);
    onToast(reason);

    if (this.isTarget) {
      worldState.completeContractForTarget(this, onToast);
    }
  }
}
