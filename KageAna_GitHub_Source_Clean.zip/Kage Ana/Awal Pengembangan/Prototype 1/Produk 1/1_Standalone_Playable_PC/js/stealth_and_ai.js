// ============================================================================
// KAGE-ANA v0.5 (Tahap 4): Lethal Enemies, 3D Projectiles, Immobilize & Civilians
// ============================================================================

const DISGUISES = {
  SHINOBI:  { id: 'SHINOBI',  name: 'Shinobi Hitam (Stealth Malam)', color: '#161922', allowedZone: 'NONE' },
  PEASANT:  { id: 'PEASANT',  name: 'Nelayan / Petani Desa (Topi Kasa)', color: '#5c4832', allowedZone: 'PUBLIC' },
  MERCHANT: { id: 'MERCHANT', name: 'Saudagar Pasar Timur (Jubah Sutra)', color: '#6b3fa0', allowedZone: 'MARKET' },
  MONK:     { id: 'MONK',     name: 'Biksu Kuil Suci Kurama (Jubah Safron)', color: '#8c5828', allowedZone: 'SHRINE' },
  GUARD:    { id: 'GUARD',    name: 'Samurai Garnisun (Zirah Biru)', color: '#233656', allowedZone: 'ALL' }
};

function canNpcStepTo(nx, nz, structures) {
  if (Math.abs(nx) > 45 || nz < -41 || nz > 41) return false;
  for (let i = 0; i < structures.length; i++) {
    const s = structures[i];
    if (!s.solidWall) continue;
    const hx = s.w * 0.5 + 0.52;
    const hz = s.d * 0.5 + 0.52;
    if (nx >= s.x - hx && nx <= s.x + hx && nz >= s.z - hz && nz <= s.z + hz) {
      return false;
    }
  }
  return true;
}

function spawnEnemyProjectile(npc, p, worldState, onToast) {
  const dx = p.x - npc.x;
  const dy = (p.y - 0.35) - (npc.y + 1.25);
  const dz = p.z - npc.z;
  const dist = Math.max(0.5, Math.hypot(dx, dy, dz));

  // 45% chance to throw an Immobilizing Torinawa Net / Kusarigama Chain Snare, 55% Poison Kunai/Shuriken!
  const isSnareNet = Math.random() < 0.45 && p.immobilizedTimer <= 0;
  const speed = isSnareNet ? 13.5 : 17.5;

  KageAudio.playKunai();
  worldState.enemyProjectiles.push({
    ownerName: npc.name,
    type: isSnareNet ? 'TORINAWA_NET' : 'POISON_KUNAI',
    x: npc.x + (dx / dist) * 0.6,
    y: npc.y + 1.25,
    z: npc.z + (dz / dist) * 0.6,
    vx: (dx / dist) * speed,
    vy: (dy / dist) * speed,
    vz: (dz / dist) * speed,
    yaw: Math.atan2(dx, dz),
    life: 2.2
  });

  if (isSnareNet) {
    onToast(`🕸️ AWAS! ${npc.name} melemparkan Jaring Pemberat (Torinawa) untuk mengikat kakimu! Hindari dengan [A/D] atau tangkis [Q]!`);
  } else {
    onToast(`🗡️ AWAS! ${npc.name} melemparkan Kunai Beracun ke arahmu! Menunduk [C], melompat [Space], atau tangkis [Q]!`);
  }
}

function updateEnemyProjectiles(dt, worldState, onToast) {
  const p = worldState.parkour;
  const pw = worldState.playerWeapon;

  for (let i = worldState.enemyProjectiles.length - 1; i >= 0; i--) {
    const proj = worldState.enemyProjectiles[i];
    proj.life -= dt;
    if (proj.life <= 0) {
      worldState.enemyProjectiles.splice(i, 1);
      continue;
    }

    proj.x += proj.vx * dt;
    proj.y += proj.vy * dt;
    proj.z += proj.vz * dt;

    const hitDist = Math.hypot(proj.x - p.x, proj.z - p.z);
    const heightDiff = Math.abs(proj.y - (p.y - 0.4));

    if (hitDist < 0.85 && heightDiff < 1.1) {
      worldState.enemyProjectiles.splice(i, 1);

      // Active Parry [Q] or Sliding dodges the projectile!
      if (pw.swingTimer > 0 && pw.swingType === 'PARRY') {
        KageAudio.playClash();
        worldState.spawnClashSparks(p.x, p.y - 0.3, p.z, 10);
        onToast(`⚡ TANGKISAN SEMPURNA! Kamu menepis lemparan ${proj.type === 'TORINAWA_NET' ? 'Jaring Torinawa' : 'Kunai Beracun'} dari ${proj.ownerName}!`);
        continue;
      }

      if (proj.type === 'TORINAWA_NET') {
        p.applyImmobilize(2.6, `Terjerat Jaring Rantai (Torinawa) milik ${proj.ownerName}!`);
        worldState.playerBloodVolume = Math.max(0, worldState.playerBloodVolume - 14);
        onToast(`⛓️ KAMU TIDAK BISA BERGERAK! Terikat Jaring Rantai ${proj.ownerName} (2.6 dtk)! Tekan [Space] / [Q] cepat untuk melepaskan ikatan atau [L] Kaginawa!`);
      } else {
        KageAudio.playPierce();
        worldState.playerBloodVolume = Math.max(0, worldState.playerBloodVolume - 28);
        worldState.playerBleedRate += 7.5;
        onToast(`🩸 TERTANCAP KUNAI BERACUN dari ${proj.ownerName}! Darah -28% & Pendarahan Hebat! Tekan [R] untuk cabut & balut luka!`);
      }

      if (worldState.playerBloodVolume <= 0) {
        worldState.triggerPlayerDeathAndShrineRespawn(`Gugur akibat serangan proyektil mematikan dari ${proj.ownerName}!`, onToast);
        return;
      }
    }
  }
}

function updateAllNPCs(dt, worldState, onToast) {
  const p = worldState.parkour;
  const todVision = (worldState.engine && worldState.engine.timeOfDay) ? worldState.engine.timeOfDay.visionMult : 1.0;

  updateEnemyProjectiles(dt, worldState, onToast);

  let anyEnemyInCombat = p.immobilizedTimer > 0;

  worldState.npcs.forEach(npc => {
    npc.isMoving = false;
    if (npc.isDead) return;

    // 1. Arterial Bleeding
    if (npc.bleedRate > 0) {
      npc.bloodVolume -= npc.bleedRate * dt;
      if (Math.random() < 0.85 * dt) {
        worldState.spawnBloodPool(npc.x, npc.z);
      }
      if (npc.bloodVolume <= 32 && !npc.isIncapacitated) {
        npc.isIncapacitated = true;
        onToast(`${npc.name} ambruk karena kehabisan darah dari luka terbuka!`);
      }
      if (npc.bloodVolume <= 0) {
        npc.killInstantly(`${npc.name} tewas kehabisan darah.`, worldState, onToast);
        return;
      }
    }

    if (npc.isIncapacitated) return;

    if (npc.blindTimer > 0) {
      npc.blindTimer -= dt;
      return;
    } else if (npc.aiState === 'BLINDED') {
      npc.aiState = (npc.hasWeapon && !npc.isInnocent) ? 'COMBAT' : 'DISARMED_FLEE';
    }

    const dx = p.x - npc.x;
    const dz = p.z - npc.z;
    const dist = Math.hypot(dx, dz);
    const heightDiff = Math.abs((p.y - 1.68) - npc.y);

    // 2. Auto-Inspect Clues when player observes an NPC up close (< 7.5m) for a moment
    if (dist < 7.5 && !npc.isIdentityInspected) {
      const fwd = p.getForwardVector();
      const dot = ((-dx) / (dist || 1)) * (-fwd.x) + ((-dz) / (dist || 1)) * (-fwd.z);
      if (dot > 0.72) {
        npc.inspectProgress = (npc.inspectProgress || 0) + dt;
        if (npc.inspectProgress >= 0.85) {
          npc.isIdentityInspected = true;
          KageAudio.playInspectClue();
          onToast(npc.secretClue);
        }
      }
    }

    // 3. Innocent Civilians & Allied Clan Members: perform normal daily activities or flee if panicked!
    if (npc.isInnocent) {
      worldState.npcs.forEach(other => {
        if (other.isDead && !other.isBodyHidden && Math.hypot(other.x - npc.x, other.z - npc.z) < 8.5) {
          npc.aiState = 'DISARMED_FLEE';
        }
      });

      if (npc.aiState === 'DISARMED_FLEE') {
        if (dist < 15) {
          const fleeAngle = Math.atan2(-dx, -dz);
          npc.yaw = fleeAngle;
          const nx = npc.x + Math.sin(fleeAngle) * 2.6 * dt;
          const nz = npc.z + Math.cos(fleeAngle) * 2.6 * dt;
          if (canNpcStepTo(nx, nz, worldState.structures)) {
            npc.x = nx; npc.z = nz; npc.isMoving = true;
          }
          npc.animTime += dt * 1.6;
        }
        return;
      }

      // Normal peaceful daily routine walk
      const pt = npc.patrolPts[npc.patrolIdx];
      const pdx = pt.x - npc.x, pdz = pt.z - npc.z;
      const pdist = Math.hypot(pdx, pdz);
      if (pdist < 0.5) {
        npc.patrolIdx = (npc.patrolIdx + 1) % npc.patrolPts.length;
        npc.animTime += dt * 0.6;
      } else {
        npc.yaw = Math.atan2(pdx, pdz);
        const nx = npc.x + (pdx / pdist) * 1.15 * dt;
        const nz = npc.z + (pdz / pdist) * 1.15 * dt;
        if (canNpcStepTo(nx, nz, worldState.structures)) {
          npc.x = nx; npc.z = nz; npc.isMoving = true;
        } else {
          npc.patrolIdx = (npc.patrolIdx + 1) % npc.patrolPts.length;
        }
        npc.animTime += dt * 0.85;
      }
      return;
    }

    // 4. Armed Guards & Syndicate Targets check for unhidden corpses
    worldState.npcs.forEach(other => {
      if (other.isDead && !other.isBodyHidden && !other.wasCorpseSpotted) {
        const cDist = Math.hypot(other.x - npc.x, other.z - npc.z);
        if (cDist < 9.5) {
          other.wasCorpseSpotted = true;
          npc.suspicion = Math.min(100, npc.suspicion + 75);
          npc.aiState = 'COMBAT';
          worldState.districtHeat = Math.min(100, worldState.districtHeat + 12);
          onToast(`🚨 MAYAT DITEMUKAN! ${npc.name} menemukan jasad ${other.name} dan langsung bersiaga tempur!`);
        }
      }
    });

    if (npc.aiState === 'DISARMED_FLEE' || !npc.hasWeapon) {
      if (dist < 14) {
        const fleeAngle = Math.atan2(-dx, -dz);
        npc.yaw = fleeAngle;
        const legSpeed = (npc.zones.LEFT_LEG.crippled || npc.zones.RIGHT_LEG.crippled) ? 1.1 : 2.4;
        const nx = npc.x + Math.sin(fleeAngle) * legSpeed * dt;
        const nz = npc.z + Math.cos(fleeAngle) * legSpeed * dt;
        if (canNpcStepTo(nx, nz, worldState.structures)) {
          npc.x = nx; npc.z = nz; npc.isMoving = true;
        }
        npc.animTime += dt * 1.5;
      }
      return;
    }

    // Clan Avengers or High Clan Conflict makes enemies attack on sight!
    if (npc.faction === 'CLAN_AVENGER' && dist < 24) {
      npc.aiState = 'COMBAT';
    }

    const maxSightRange = (p.isHiddenInBush && p.isCrouching) ? 2.0 : (16.0 * todVision);
    if (dist < maxSightRange && heightDiff < 3.2) {
      let suspicionRate = 0;
      if (worldState.clanConflict >= 70) suspicionRate += 95;
      if (p.carryingBodyNpc) suspicionRate += 130;
      if (worldState.currentDisguise.id === 'SHINOBI') suspicionRate += 60 * todVision;
      if (worldState.playerWeapon.isWeaponDrawn && worldState.currentDisguise.id !== 'GUARD') suspicionRate += 80 * todVision;
      if (p.isSprinting || p.isSliding || !p.isGrounded) suspicionRate += 45 * todVision;
      if (worldState.bloodstainOnClothes > 20 && dist < 9) suspicionRate += worldState.bloodstainOnClothes * 0.9;
      if (npc.isTarget && dist < 3.8 && worldState.currentDisguise.id !== 'GUARD') suspicionRate += 40;

      if (suspicionRate > 0) {
        npc.suspicion = Math.min(100, npc.suspicion + suspicionRate * dt);
        if (npc.suspicion >= 100 && npc.aiState !== 'COMBAT') {
          npc.aiState = 'COMBAT';
          onToast(`⚔️ MUSUH MENYERANG! ${npc.name} mencabut senjata & siap melempar jaring/menebasmu!`);
        }
      } else {
        npc.suspicion = Math.max(0, npc.suspicion - 15 * dt);
      }
    }

    const legPenalty = (npc.zones.LEFT_LEG.crippled || npc.zones.RIGHT_LEG.crippled) ? 0.42 : 1.0;

    if (npc.aiState === 'PATROL') {
      if (dist < 5.2 && !p.isHiddenInBush) {
        npc.yaw = Math.atan2(dx, dz);
        npc.animTime += dt * 0.4;
        return;
      }
      const pt = npc.patrolPts[npc.patrolIdx];
      const pdx = pt.x - npc.x, pdz = pt.z - npc.z;
      const pdist = Math.hypot(pdx, pdz);
      if (pdist < 0.6) {
        npc.patrolIdx = (npc.patrolIdx + 1) % npc.patrolPts.length;
      } else {
        npc.yaw = Math.atan2(pdx, pdz);
        const stepSpeed = 1.45 * legPenalty;
        const nx = npc.x + (pdx / pdist) * stepSpeed * dt;
        const nz = npc.z + (pdz / pdist) * stepSpeed * dt;
        if (canNpcStepTo(nx, nz, worldState.structures)) {
          npc.x = nx; npc.z = nz; npc.isMoving = true;
        } else {
          npc.patrolIdx = (npc.patrolIdx + 1) % npc.patrolPts.length;
        }
        npc.animTime += dt * legPenalty;
      }
    } else if (npc.aiState === 'COMBAT') {
      anyEnemyInCombat = true;

      if (p.isHiddenInBush && p.isCrouching && dist > 6.8) {
        npc.aiState = 'PATROL';
        npc.suspicion = 45;
        onToast(`${npc.name} kehilangan jejakmu di dalam Semak Bambu!`);
        return;
      }

      npc.yaw = Math.atan2(dx, dz);

      // Ranged Projectile Throw (Torinawa Net Snare or Poison Kunai) when 3.8m..18.5m away or player on roof!
      npc.projectileCooldown = (npc.projectileCooldown || 2.0) - dt;
      if ((dist > 3.6 && dist < 18.5) || heightDiff > 1.8) {
        if (npc.projectileCooldown <= 0) {
          npc.projectileCooldown = 2.8 + Math.random() * 1.4;
          spawnEnemyProjectile(npc, p, worldState, onToast);
        }
      }

      if (heightDiff > 2.2) return;

      if (dist > 1.80) {
        const chaseSpeed = 4.3 * legPenalty;
        const nx = npc.x + (dx / dist) * chaseSpeed * dt;
        const nz = npc.z + (dz / dist) * chaseSpeed * dt;
        if (canNpcStepTo(nx, nz, worldState.structures)) {
          npc.x = nx; npc.z = nz; npc.isMoving = true;
        }
        npc.animTime += dt * 1.7 * legPenalty;
      } else {
        npc.attackCooldown -= dt;
        if (npc.attackCooldown <= 0) {
          npc.attackCooldown = 1.15 + Math.random() * 0.4;
          executeLethalEnemyStrikeOnPlayer(npc, worldState, onToast);
        }
      }
    }
  });

  KageAudio.bgmCombatMode = anyEnemyInCombat;
}

/**
 * Stage 4 Lethal Challenging Enemy Strike:
 * Can severely wound, disarm, immobilize (grapple-pin), or kill an unguarded player!
 */
function executeLethalEnemyStrikeOnPlayer(npc, worldState, onToast) {
  const pw = worldState.playerWeapon;
  const parkour = worldState.parkour;

  if (pw.hasWeapon && pw.isWeaponDrawn && pw.swingTimer > 0 && pw.swingType === 'PARRY') {
    pw.clashBladesWith(npc, worldState, onToast);
    return;
  }

  const roll = Math.random();
  if (roll < 0.28 && parkour.immobilizedTimer <= 0) {
    // Enemy Grapple-Pin / Leg Sweep that immobilizes the player!
    parkour.applyImmobilize(2.2, `Dikunci tendangan sapuan & kuncian ${npc.name}!`);
    worldState.playerBloodVolume = Math.max(0, worldState.playerBloodVolume - 26);
    onToast(`⛓️ KUNCIAN LAWAN! ${npc.name} mengunci pergerakanmu (Darah -26%)! Tekan [Space] / [Q] cepat untuk lepas sebelum ditebas mati!`);
  } else if (roll < 0.55 && pw.hasWeapon) {
    pw.reduceGrip(65, worldState, onToast);
    worldState.playerBloodVolume = Math.max(0, worldState.playerBloodVolume - 34);
    worldState.playerBleedRate += 6.0;
    KageAudio.playSlash();
    onToast(`⚔️ TEBASAN KERAS ${npc.name.toUpperCase()}! Darah -34% & Genggaman pedangmu hampir lepas!`);
  } else {
    // Lethal Arterial /Vital Strike!
    const dmg = parkour.immobilizedTimer > 0 ? 58 : 44;
    worldState.playerBloodVolume = Math.max(0, worldState.playerBloodVolume - dmg);
    worldState.playerBleedRate += 9.5;
    parkour.leftLegCrippled = true;
    KageAudio.playSever();
    onToast(`🩸 TEBASAN MEMATIKAN DARI ${npc.name.toUpperCase()}! Darah terkuras -${dmg}% & Arteri Bocor! Segera tangkis [Q], gunakan Kaginawa [L], atau perban [R]!`);
  }

  if (worldState.playerBloodVolume <= 0) {
    worldState.triggerPlayerDeathAndShrineRespawn(`Tewas ditebas oleh ${npc.name} dalam pertarungan jarak dekat!`, onToast);
  }
}
