// ============================================================================
// KAGE-ANA v0.4 (Tahap 3): Combat, Jujutsu Disarm, Stealth Choke & Clash Sparks
// ============================================================================

class PlayerWeaponController {
  constructor() {
    this.hasWeapon = true;
    this.gripStability = 100;
    this.maxGripStability = 100;
    this.metsubushiCount = 4;
    this.kunaiCount = 6;
    this.isWeaponDrawn = true;

    this.impaledTargetNPC = null;
    this.lastMouseDeltaX = 0;
    this.lastMouseDeltaY = 0;
    this.lastSlashArcLabel = 'Tebasan Horizontal';
    this.slashArcAngle = 0;

    this.swingTimer = 0;
    this.swingType = 'NONE';
    this.targetedHitbox = null;
    this.stealthChokeCandidate = null;
  }

  recordMouseMovement(dx, dy) {
    this.lastMouseDeltaX = dx;
    this.lastMouseDeltaY = dy;
  }

  lodgeBladeInTarget(npc) {
    this.hasWeapon = false;
    this.impaledTargetNPC = npc;
  }

  recoverImpaledBlade() {
    this.hasWeapon = true;
    this.isWeaponDrawn = true;
    this.impaledTargetNPC = null;
    this.gripStability = Math.max(75, this.gripStability);
  }

  tryRipOutImpaledBlade(worldState, onToast) {
    if (!this.impaledTargetNPC) return false;
    const npc = this.impaledTargetNPC;
    const p = worldState.parkour;
    const dist = Math.hypot(p.x - npc.x, p.z - npc.z);

    if (dist <= 4.2) {
      KageAudio.playImpaleRip();
      npc.hasImpaledKatanaStuck = false;
      this.recoverImpaledBlade();
      worldState.spawnArterialSpray(npc.x, npc.y + 1.2, npc.z, 14);
      npc.killInstantly(`PEDANG DICABUT PAKSA DARI DADA ${npc.name.toUpperCase()}! Arteri jantung pecah & target tewas seketika!`, worldState, onToast);
      return true;
    } else {
      onToast(`Dekati ${npc.name} (Jarak: ${dist.toFixed(1)}m) untuk mencabut pedangmu yang menancap!`);
      return false;
    }
  }

  /**
   * Stage 3: Pressing [F] either rips out an impaled sword OR performs a Bloodless Stealth Choke!
   */
  tryStealthChokeOrRipBlade(worldState, onToast) {
    if (this.impaledTargetNPC) {
      return this.tryRipOutImpaledBlade(worldState, onToast);
    }
    if (this.stealthChokeCandidate) {
      this.swingTimer = 0.28;
      this.swingType = 'UNARMED';
      this.stealthChokeCandidate.applyStealthChoke(worldState, onToast);
      this.stealthChokeCandidate = null;
      return true;
    }
    onToast('Dekati musuh secara senyap (< 3.4m saat ia belum menyerang) untuk Cekikan Tanpa Darah [F], atau tusuk dada dulu untuk cabut pedang.');
    return false;
  }

  update(dt, eyeOrigin, forwardDir, npcHitboxes, npcs) {
    if (this.hasWeapon && this.gripStability < this.maxGripStability) {
      this.gripStability = Math.min(this.maxGripStability, this.gripStability + 14 * dt);
    }
    if (this.swingTimer > 0) {
      this.swingTimer = Math.max(0, this.swingTimer - dt);
    }

    this.targetedHitbox = null;
    this.stealthChokeCandidate = null;
    let closestDist = 4.1;

    for (let i = 0; i < npcHitboxes.length; i++) {
      const hb = npcHitboxes[i];
      const hit = Engine3D.raycastAABB(eyeOrigin, forwardDir, hb, closestDist);
      if (hit && hit.distance < closestDist) {
        closestDist = hit.distance;
        this.targetedHitbox = hb;
      }
    }

    if (npcs) {
      let bestNpc = null;
      let bestDist = 3.4;
      for (let i = 0; i < npcs.length; i++) {
        const npc = npcs[i];
        if (npc.isDead) continue;
        const dx = npc.x - eyeOrigin.x;
        const dz = npc.z - eyeOrigin.z;
        const d = Math.hypot(dx, dz);
        if (d < bestDist) {
          const dot = (dx / (d || 1)) * forwardDir.x + (dz / (d || 1)) * forwardDir.z;
          if (dot > 0.35) {
            bestDist = d;
            bestNpc = npc;
          }
        }
      }
      if (bestNpc) {
        if (bestNpc.aiState !== 'COMBAT' || bestNpc.blindTimer > 0) {
          this.stealthChokeCandidate = bestNpc;
        }
        if (!this.targetedHitbox) {
          let preferredZone = 'THORAX_HEART';
          if (forwardDir.y > 0.12 && !bestNpc.zones.HEAD.severed) preferredZone = 'HEAD';
          else if (forwardDir.y < -0.18) preferredZone = 'RIGHT_LEG';
          const found = npcHitboxes.find(h => h.npc === bestNpc && h.zoneKey === preferredZone) ||
                        npcHitboxes.find(h => h.npc === bestNpc);
          if (found) this.targetedHitbox = found;
        }
      }
    }
  }

  determineDirectionalSlash() {
    const ax = Math.abs(this.lastMouseDeltaX);
    const ay = Math.abs(this.lastMouseDeltaY);
    if (ay > ax * 1.4) {
      this.slashArcAngle = this.lastMouseDeltaY > 0 ? Math.PI * 0.5 : -Math.PI * 0.5;
      this.lastSlashArcLabel = 'Tebasan Vertikal Atas-Bawah';
    } else if (ax > 2 && ay > 2) {
      this.slashArcAngle = this.lastMouseDeltaX > 0 ? -0.65 : 0.65;
      this.lastSlashArcLabel = 'Tebasan Diagonal Silang';
    } else {
      this.slashArcAngle = 0.08;
      this.lastSlashArcLabel = 'Tebasan Horizontal Presisi';
    }
  }

  performPrimaryAttack(worldState, onToast) {
    if (this.impaledTargetNPC && this.targetedHitbox && this.targetedHitbox.zoneKey === 'STUCK_KATANA') {
      this.tryRipOutImpaledBlade(worldState, onToast);
      return;
    }

    if (!this.hasWeapon) {
      this.swingTimer = 0.25;
      this.swingType = 'UNARMED';
      KageAudio.playSlash();
      if (this.targetedHitbox && this.targetedHitbox.npc) {
        const npc = this.targetedHitbox.npc;
        const fwd = worldState.parkour.getForwardVector();
        npc.x += fwd.x * 1.5;
        npc.z += fwd.z * 1.5;
        npc.blindTimer = 2.2;
        onToast(`Bantingan Jujutsu Tangan Kosong pada ${npc.name}! Tekan [Q] di dekatnya untuk merebut pedangnya!`);
      } else {
        onToast('Serangan Tangan Kosong! Dekati musuh & tekan [Q] untuk Jujutsu Disarm (Rebut Pedang), atau [F] Cekik Senyap.');
      }
      return;
    }

    this.determineDirectionalSlash();
    this.isWeaponDrawn = true;
    this.swingTimer = 0.26;
    this.swingType = 'SLASH';
    KageAudio.playSlash();

    if (this.targetedHitbox) {
      if (this.targetedHitbox.zoneKey === 'WEAPON_BLADE') {
        this.clashBladesWith(this.targetedHitbox.npc, worldState, onToast);
      } else {
        this.targetedHitbox.npc.applyStrike(this.targetedHitbox.zoneKey, 'SLASH', this.lastSlashArcLabel, worldState, onToast);
        worldState.addBloodstainToClothes(24, onToast);
      }
    }
  }

  performSecondaryPierce(worldState, onToast) {
    if (this.impaledTargetNPC) {
      if (this.tryRipOutImpaledBlade(worldState, onToast)) return;
    }

    if (!this.hasWeapon) {
      this.throwMetsubushi(worldState, onToast);
      return;
    }

    this.isWeaponDrawn = true;
    this.swingTimer = 0.28;
    this.swingType = 'PIERCE';
    KageAudio.playPierce();

    if (this.targetedHitbox) {
      if (this.targetedHitbox.zoneKey === 'WEAPON_BLADE') {
        this.clashBladesWith(this.targetedHitbox.npc, worldState, onToast);
      } else {
        this.targetedHitbox.npc.applyStrike(this.targetedHitbox.zoneKey, 'PIERCE', 'Tusukan Lurus', worldState, onToast);
        worldState.addBloodstainToClothes(20, onToast);
      }
    }
  }

  throwKunai(worldState, npcHitboxes, onToast) {
    if (this.kunaiCount <= 0) {
      onToast('Persediaan Kunai lempar sudah habis!');
      return;
    }
    this.kunaiCount--;
    this.swingTimer = 0.20;
    this.swingType = 'PIERCE';
    KageAudio.playKunai();

    const eye = worldState.parkour.getEyePositionForRaycast();
    const fwd = worldState.parkour.getForwardVector();
    let bestHit = null;
    let bestDist = 20.0;

    for (let i = 0; i < npcHitboxes.length; i++) {
      const hb = npcHitboxes[i];
      const hit = Engine3D.raycastAABB(eye, fwd, hb, bestDist);
      if (hit && hit.distance < bestDist) {
        bestDist = hit.distance;
        bestHit = hb;
      }
    }

    if (bestHit && bestHit.npc) {
      if (bestHit.zoneKey === 'RIGHT_ARM' || bestHit.zoneKey === 'WEAPON_BLADE') {
        bestHit.npc.dropWeaponToGround(worldState);
        bestHit.npc.aiState = 'DISARMED_FLEE';
        onToast(`KUNAI TEPAT SASARAN (${bestDist.toFixed(1)}m)! Pergelangan tangan ${bestHit.npc.name} tertancap Kunai & pedangnya terjatuh!`);
      } else {
        bestHit.npc.applyStrike(bestHit.zoneKey, 'PIERCE', 'Lemparan Kunai Jarak Jauh', worldState, onToast);
      }
    } else {
      onToast(`Kunai dilempar! (Sisa Kunai: ${this.kunaiCount}). Bidik tepat ke tubuh atau tangan musuh.`);
    }
  }

  /**
   * Stage 3 Enhanced [Q]:
   * - If Armed: Active Parry / Blade Deflect with 3D sparks!
   * - If Unarmed: Jujutsu Wrist-Lock Disarm — steals the enemy's Katana directly into your hands!
   */
  performParryOrJujutsuDisarm(worldState, onToast) {
    const p = worldState.parkour;

    if (!this.hasWeapon) {
      for (let i = 0; i < worldState.npcs.length; i++) {
        const npc = worldState.npcs[i];
        if (!npc.isDead && npc.hasWeapon && Math.hypot(npc.x - p.x, npc.z - p.z) < 3.4) {
          npc.hasWeapon = false;
          npc.aiState = 'DISARMED_FLEE';
          this.hasWeapon = true;
          this.isWeaponDrawn = true;
          this.gripStability = 90;
          this.swingTimer = 0.28;
          this.swingType = 'PARRY';
          KageAudio.playClash();
          worldState.spawnClashSparks(npc.x, npc.y + 1.2, npc.z, 12);
          onToast(`🥋 JUJUTSU DISARM BERHASIL! Kamu memelintir pergelangan tangan ${npc.name} dan langsung merebut Katananya!`);
          return;
        }
      }
      onToast('Jujutsu Disarm: Dekati musuh bersenjata (< 3.4m) saat tangan kosong lalu tekan [Q] untuk merebut pedangnya!');
      return;
    }

    this.swingTimer = 0.30;
    this.swingType = 'PARRY';
    this.gripStability = Math.min(this.maxGripStability, this.gripStability + 20);
    KageAudio.playClash();
    if (this.targetedHitbox && this.targetedHitbox.npc) {
      this.clashBladesWith(this.targetedHitbox.npc, worldState, onToast);
    } else {
      onToast('Kuda-kuda Tangkisan (Active Deflect) aktif! Memperkuat Grip Stability tangan.');
    }
  }

  clashBladesWith(npc, worldState, onToast) {
    KageAudio.playClash();
    worldState.spawnClashSparks(npc.x, npc.y + 1.25, npc.z, 14);
    this.reduceGrip(22, worldState, onToast);
    if (npc.hasWeapon && Math.random() < 0.55) {
      npc.dropWeaponToGround(worldState);
      npc.aiState = 'DISARMED_FLEE';
      onToast(`⚡ BENTURAN PEDANG BERPERCIK API! Katana milik ${npc.name} terpental lepas dari tangannya!`);
    } else {
      onToast(`⚡ PEDANG BERADU! Bunga api memercik — Grip Stability tanganmu ${Math.round(this.gripStability)}%.`);
    }
  }

  reduceGrip(amount, worldState, onToast) {
    this.gripStability -= amount;
    if (this.gripStability <= 0 && this.hasWeapon) {
      this.forceDisarmPlayer(worldState, 'SENJATA TERPENTAL! Genggaman tangan lepas akibat benturan keras! Tekan [Q] untuk rebut pedang lawan atau [G] pungut pedang!');
    }
  }

  forceDisarmPlayer(worldState, reason) {
    if (!this.hasWeapon) return;
    this.hasWeapon = false;
    this.gripStability = 0;
    KageAudio.playClash();

    const p = worldState.parkour;
    const fwd = p.getForwardVector();
    worldState.droppedWeapons.push({
      x: p.x + fwd.x * 1.3,
      y: Math.max(0.12, p.y - 1.5),
      z: p.z + fwd.z * 1.3,
      yaw: p.yaw + 0.8
    });

    worldState.showToast(reason);
  }

  tryPickupDroppedWeapon(worldState, onToast) {
    if (this.impaledTargetNPC) {
      if (this.tryRipOutImpaledBlade(worldState, onToast)) return;
    }
    if (this.hasWeapon) return;
    const p = worldState.parkour;
    for (let i = 0; i < worldState.droppedWeapons.length; i++) {
      const w = worldState.droppedWeapons[i];
      const dist = Math.hypot(p.x - w.x, p.z - w.z);
      if (dist < 3.4) {
        worldState.droppedWeapons.splice(i, 1);
        this.hasWeapon = true;
        this.isWeaponDrawn = true;
        this.gripStability = 85;
        KageAudio.playStep('Stone');
        onToast('Katana berhasil dipungut kembali dari lantai! Siap bertarung.');
        return;
      }
    }
    onToast('Tidak ada pedang di dekatmu! Tekan [Q] di dekat musuh untuk merebut pedangnya (Jujutsu Disarm).');
  }

  throwMetsubushi(worldState, onToast) {
    if (this.metsubushiCount <= 0) {
      onToast('Bubuk pembuta (Metsubushi) sudah habis!');
      return;
    }
    this.metsubushiCount--;
    const p = worldState.parkour;
    let blindedCount = 0;
    worldState.npcs.forEach(npc => {
      if (!npc.isDead && Math.hypot(npc.x - p.x, npc.z - p.z) < 9.5) {
        npc.blindTimer = 6.0;
        npc.aiState = 'BLINDED';
        blindedCount++;
      }
    });
    onToast(`METSUBUSHI DILEMPAR! (${blindedCount} musuh buta selama 6 detik). Dekati & tekan [F] untuk Cekikan Senyap!`);
  }

  drawFirstPersonViewmodel(ctx, width, height, parkour, disguiseColor) {
    if (parkour.cameraMode !== 'FIRST_PERSON') return;

    if (this.swingTimer > 0 && this.swingType === 'SLASH') {
      ctx.save();
      ctx.translate(width * 0.5, height * 0.5);
      ctx.rotate(this.slashArcAngle);
      ctx.strokeStyle = `rgba(220, 240, 255, ${(this.swingTimer / 0.26) * 0.75})`;
      ctx.lineWidth = 8;
      ctx.beginPath();
      ctx.arc(0, 0, 175, -0.75, 0.75);
      ctx.stroke();
      ctx.restore();
    }

    const bobX = Math.sin(parkour.stepPhase) * 3.5;
    const bobY = Math.abs(Math.cos(parkour.stepPhase)) * 3.5;

    if (!this.hasWeapon) {
      ctx.save();
      const punchOffset = this.swingTimer > 0 ? -65 : 0;
      ctx.fillStyle = '#222630';
      ctx.fillRect(width * 0.26 - bobX, height * 0.75 + bobY, 46, 120);
      ctx.fillStyle = '#d4aa88';
      ctx.fillRect(width * 0.265 - bobX, height * 0.71 + bobY, 38, 34);

      ctx.fillStyle = '#222630';
      ctx.fillRect(width * 0.68 + bobX, height * 0.75 + bobY + punchOffset, 48, 120);
      ctx.fillStyle = '#d4aa88';
      ctx.fillRect(width * 0.685 + bobX, height * 0.71 + bobY + punchOffset, 40, 36);
      ctx.restore();
      return;
    }

    if (!this.isWeaponDrawn) return;

    ctx.save();
    let baseX = width * 0.74 + bobX;
    let baseY = height * 0.76 + bobY;
    let rot = -0.24;

    if (this.swingTimer > 0) {
      if (this.swingType === 'SLASH') {
        baseX -= 185 * (1 - this.swingTimer / 0.26);
        baseY += 40;
        rot = -1.25 + this.slashArcAngle * 0.4;
      } else if (this.swingType === 'PIERCE') {
        baseX -= 55;
        baseY -= 110 * Math.sin((this.swingTimer / 0.28) * Math.PI);
        rot = -0.05;
      } else if (this.swingType === 'PARRY') {
        baseX -= 120;
        baseY -= 48;
        rot = -0.88;
      }
    }

    ctx.translate(baseX, baseY);
    ctx.rotate(rot);

    ctx.fillStyle = '#1b1f29';
    ctx.fillRect(-105, 38, 95, 28);
    ctx.fillStyle = '#d4aa88';
    ctx.fillRect(-16, 34, 24, 24);

    const bladeGrad = ctx.createLinearGradient(-8, -330, 10, 0);
    bladeGrad.addColorStop(0, '#ffffff');
    bladeGrad.addColorStop(0.5, '#cdd6e0');
    bladeGrad.addColorStop(1, '#8c96a4');
    ctx.fillStyle = bladeGrad;
    ctx.beginPath();
    ctx.moveTo(-7, 0);
    ctx.lineTo(-5, -315);
    ctx.lineTo(7, -340);
    ctx.lineTo(7, 0);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#9e1b1b';
    ctx.fillRect(-2, -260, 2.5, 250);
    ctx.fillStyle = '#c4a462';
    ctx.fillRect(-19, 0, 38, 8);
    ctx.fillStyle = '#1c1e24';
    ctx.fillRect(-8, 8, 16, 88);

    ctx.fillStyle = '#d4aa88';
    ctx.fillRect(-12, 14, 24, 26);
    ctx.fillStyle = '#161922';
    ctx.fillRect(-16, 48, 34, 95);

    ctx.restore();
  }
}
