// ============================================================================
// HD PHOTOREALISTIC HUMANOID TEXTURE ATLAS (From 091_W_Aya 3D Scan Standard)
// ============================================================================
const AYA_FACE_IMAGE = new Image();
AYA_FACE_IMAGE.src = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABwCAYAAACen2dSAABUKUlEQVR42m39W7NlyZEeiH3uHhHrsvc+18ysrHuhUECjm0CzpymKupgocvgim+GDXmbM9DB/TZLZDEfSiGYjmvXo0s0eawoakmqqbwOCQAPoRqNQBVShKjPPZe+91ooId9dDrH3yFMhjdizvmSd9xfJw//z7Pqd/8l/9H8DMqLXi9EFEICIwMwDA3aHuEBHUWuGqCCGAiGBmcHdEEtze3uCHP/wh/uz/9yeUc8bQ9TTPM+cyM9cqKSVRt+juYRiGRERdKaVj5l5V+67rhnEch77vezfq99Oxq7V2IYQ4m4XdbhfGrieQUc3F5/noUULdbrf1O9/5ThmGYRm3m0VimkNKcxzGqZpOteocAs3MvABYhDmXrDXGWHLOGpjV3c2JzN2dmaFWHEQAABGBa4uDuz/E5ivxUYWvMVJVxBhRawUzQ1UR3B05ZzDzQ4DdHQBgZg/f0hpkAAghQrW2L8AdX3zxBb7/F9/Dn/7pn1CSABEhq0q38y3XUliEJAoF1RJFYpIgMefcm1nHzAMzD8MwDCGEwd2HaZp6AB2APoSQmDltt5sAInl5+5KXwxGuFUJuUYLqMtd//S++m0OXssHnuWr35Pkb3W9+57fTW++8nVLXJdcctdYQQgjzPEuQVGqtLCLFQWSuykQEwEII7lVBRFBVhzuI+OFQ0foAToE/BdjMHmLyOJ5EhHB6YgZHihHLsiCl9JVgt+Ab+r5DKQUMgivwyccf44//+I/x1z/5K1B16lIEg2g5TlzKwiIiKcXAjFBrjSGEzuBdzbUnoj7GbqAgI4DBWMYKGmLqhvv7+6Hruq5a7YKk1I1jOhxvZZomqbkwk9Mm9b4ZBhNihZsSkLnWHLu4dDEtLz/7bPrDTz6Z3n3//elv/0e/c3zz6bPeSTqvmJKk5ESzAcGAhQgFXV+LajUtukyTDX1nruYCI6g5iTwE7fEhfPzj08k+nerTzzMz6L/6L//3cHeM44jb21uklBDXgDMzyB0xRpT1D6oqbl6+xHe/+1381Y9/guPxiJQSJRJydzJVNjMm8hBCCMxIRJTIvQPQE9EI5oE5jCKyEZGRiMbYpdHdR1XtQwj9NE39uN0kEUk3NzeRzcS8CgC6vrikwOJaig9Dr1ZVibioar4/7PNhmubN7mzenp3NHOJR3Y7vvfPu8e/83f/Jseu6gxMdXcKUazn2fT8f52khCVlEMjsqEyoAK0u2LoqrqoODnw7d6a1/nF4fp15mfjjpzNzS7H/9T/6PD0/H16DWWtsvuqPWipQSzAw5Z3zvL/5H/P7v/z7mecaQOnRdR9M0UWThUgqrqoiQxBgjM3cM6wAMYB5VdSSiTQhhIxK3YNow8yaEsCFpv87M/TRN/W63S2aW7u/vEzOHkGcppfC7H7zP7o67uzvsdjsDYDlnLbnWaZqyqubNZpM3m83s7jPAx67rjhLDgUQOv/O7/9Hhgw+/vlf3gxMOCj+yyNEMUyllEZGFQcXd1d01hWDubga4u/sp0KeYnVLE6USfPn490OH0CyLy8GSICEKEJWf0fY+cMw43d/jn//yf43vf+x5CCOglghykpVIKkUvO7O5BhEKMMYlIR649gJGINg5siWjrhJ3BdwTdksvW3bfuPmqto5kNy7L0m83QHff3iYgiTIOZBq9FPnz/A8650O39HYbtBqVWP8yzAdDb29saQqibYShd12WYLV51jjFOPfPxME9HAPt/9d3/z/5wv9//xt/6zXuF38cY9wRPTh6J/dilKMuyLG6Wu9RTUa0iAgZsDa4/zs2n4J4C/h/6UFWEx6f5lMyZ+eGJ1Vrx2Wef4b/9P/9fcX9/jy4m5Jyxu7ig4+FATsSqymY1MHMMIXbM6Ml1ALABbAvQmTvviOiMmM4A7Mxsx4wtgI27j1XrANPeVTstNc3zHPvUxRhYjsejvPnkCc/zkfbHA3XdQCVXX0p2SdG/+PKlDcOg23GjfUpFaylWa+5iWgg+393fTtX9aMAhdXH//e/9+f2nP/+bzTvvvze+8ebz4ezsrO+6LgEedTmGIEE49exOSwsmKhHg7nY6sL9+ch+nk8cp5fR7wuMncXo6NWeICEII+PM//3P83u/9HjAXhNBegM040jxNFEJgVRUiCiISmbkDbIBhNGBL5DsiOnf3c7CdM/M5nM7gOKP1hAMYVctQc+1D4BQlpP3dfdztxlCXLHnJcnV+zpIi3d7eUhpGUgOKVriTf/nFjQsH3447U1UtWTV1qWrJZVrmLEQ5xjgH4YmIjjDfe8nb493t5qc//OH48Y9/PIQQ+vc/+jC9/e67McYupEFEq7I6KKWOSilEhLrGx9Yg+uNgngL9OH08/ginIKsq+r7HMk0YhgGlFPzhH/4h/uiP/ggxRmyGATlnmBmZGYkIq5kQczCzGELo3X0gt42575hxDtA5EV0AuBTiCzjOADs38I6INjAfVetgZr2pJw4Sl2mK52dnAtOQtfJmHGjbD/zquKcwDAQiFC1QdRwPM7y6n12eeZLOsi4OsLlRBYs6vDhxKbCspcwhhDGyjH03bLoujuQY2HSoU+5/+uMfpb/68Y9i6of4jW/9LXnjzbeYYk+1VgIJ3OvjFPFwsh/X0o8vylPAT9+GUxJPIQBmiDFiv9/jD/7gD/Bnf/ZniDGCQaeyj1SVJASutQoBoZSS+r7vCDa66xbAjpkviPwCwCWAK2a6EJELMzs3sx2TbRk8wr0vtfa11jSkIczHY9hsNkFLZgAciHnseso5k5KD3GiaF0RJqKVgWQq249Y3wwbLUl1C8BiDqWrMuRhHrhSo1lprn2Lvav246YfdZjMElr4P0ptZX+Yl3S1zIgnRqobv/9vvyae//Iz/1t/+Xe7HDQEEd9CpSSEi1FptDaKfGr7Hv34K8OkgBxdC4AA2QJeCnDN+7//2z/DDH/4QNWdsz3YopaDrOlItJMJcy8LMHMw09V3s4DrGwDtnPluW5UJELon4SkSurOpVTPGiAhdLLbthGLa12Kjufc61A1Nk6eJUs7CwcAicy8xelbabkbJWsIM4bpBzpsAd8rQg54x+06Pb9X5X9hCGSwhQyw5VF6glDMFVtKOk28BxIyV9bZu6p2fSSR+6F3fHTtF1sr1Mc85pphzu6n3YCEt6ufAn/+bI3/g7/1OS3TkURyh3kMzgTXLTGZHccreBlOBBEmAzOgKqV5Q1kZNWxEAIKUSUUkCtfsE//af/FJ/+/BMAwHa7Rc0FMUVyUyIicncGEABEAJ27jiKyA3BmZpcxxsta65NhGK5KKdcxxkt3Pzf3s77vt6o6uqMHkFQ1DmmIpRQRIe66jomIhCMZO9WiCFFQTUmXjC4lzMcJ1Q1GwHYc4e4UQkAkcuEAqxkSgxMRm1cXJ0kpGccQzndn4ezpWXj7nWfR2WN/mOKLV8doRYJvu0iWQ6Jejre3wgh0vz/QD//6J3jn29/GTiIsRAQKnnN1VKup6/yYMxyEnpM7ALMKYkIMAQ6GMQNeEXLOrdNzxz/7Z/8MP//Zx1iWBX3XwcyQUiIOQnnKxC0hCYDIzB2RDyKyDSGcWa2XzHxlZtcppSfufh1jvHK1CwBnBNkSZNSqPRGlZVniOA6ScxFmZmGiKIFyzkTttaNqiogI04pIhHyYYG4oWrHdbVG0ogtdq5RAxM5YisKZIARiwLvINPaR3911/NFbT/mDJ2fha0+uQhcplKWGF91duL+bws00h7ui4klYn13y3ct7OAkdP/8U3dkG9I1vuJXqLKMHh8cwuubs3dCbmcA0QxgOMxAFmDvUFAwBgRBgjtgl/Pe//wf4wQ9+gCgBIYRWkoT2/TkvREQsImJmkYg6ZgwiaUtEZ8x8YcAVET0B8CSEcG1mVymly6p25u47Zh5rrb2ZRXePzCxExLDKMXYUUiIzQ55nYmaklBrW4IA6ENVQckZxwzAOqKYr2GNgMEqp4C4ixgirhcwq+hRx1gm98eTMPzi/oq+9/S69ebXjlMDX1+csIvLW+0FuXt3Jr5aJf/XyBf/qxZc0Hxd6/s4VzUsl3R/x8U//xp/sNn5+9bZPc/ZOggvcl7o4q6OwGpt6DOvl5wozhpqBJcCJEQIzvv+97+Ff/w//EiEE1FLhZggpta5vngnmJO0juHsiop6IRhHZmtl5baf52qxexxiva63XKaXLUsp5ENmWmkcQ9e6U3CkQIYx9z8fjkYahIyJCF4XmeQZgYA4Pl8qcK8wAW5b1lYyPalMB04qOhQBVBwuBhdBRwMU40OWmw7tXZ/jOuxf01rs7GneJlSvrk0C+SRzON5TKQB+8LPTmzRnffbqhsDh98jcfo+6iX/Sdf3K7ty9++mN7fvGGHhFV4QZ164bRDnkCddFDiESkMJjDCSQMYQaLALUi3N/e4f/+e/8dmBnzPCOFiL7vEWOknDOZGYUQWNyEzBPUusAYhGgrROcALsz9ipiviOja3a9CCJdmdk5EOzMbAfSqntbcLn3fcy2FUgoEcxo3I5Y8oyyv63cAqIYGYnFApYagdaHhLptxhOYCjiuWwAHzfATU0ImjT4KzIeDt8w2+/sYlfevdr2H3xhU8MGjTMzoOGDoyDjScR+Jg1F29QWdP38X+81f4jWfv+Jdffun8xefWp0H5yxd68zd/rdtvfEeLkTKLFs82xOAHuHnrF8EkMCb3FfEDABKBkFW8+NUXYGZECS0vN7yDVJWZmc0sBOZkZp153cQYz5j5gpmv3P0JMz8loidEuDazq67rLmqtuxDCxtQGELrqHN0RRFgiB16WmbbjSOaKru9wOBxgpkghIcSIag35Umu3twseUsWmH2C1tgvHHSklzEtGCAIJwNAHnMWIty42+O0PP8B3PvoQ8Z0Avk6E8w583hOGSBgieSTiMTG2PWPXMa5His82VAZQ6ghbVjxN7INE+8Uvf2V+eaXoeqPgeswH3abOsxWjys5EiIFd4ahqUBAAB5NDzsfhNaznjr7vUUqhGCO1+pyFmWMM6FTr6O7bruvOiejK3a9boPGEWa5rLVcppXMAZyGEsdY6BJHk8FCNBe4cY6LjYU/jZqC8zDi/OMc8z/Cq4CAIIUJCQFWDGVZM2MBJAHeMXQ+vCi+KyIJxGDAvCxyONPSAK87GAW9eX+A3338Hf/sbH+LN63PgKoL7EWG3o8WYQjcCkoj6jjRGMhaqJKQcSGPk8fwCgwNbih7mbBdpsNtj1Z9r1eHyupqbpihKOavBLMhoRHBhgprDiUEiMFW4V8j77zxHKRnRgBADmEDMBMA5EAnDI1dNxDKY+jaEeJZSvARw5e5PROQJszwBcFVKvej77kxVN2se76rW4IDMVXkce5rmIzEDKUakLoKcUHJBdQeLwMEAB+Ra4A7UqpAYULUghYAuRMw5w5IAiaGwVrFGRtKK513EO2OH3/rac3z7m1/D1dUO/dghDiNCtwW6ERS3AEUiSUCIRMTk3BFjIEJHRj0pC4XzHbBJmMSc53u7crEvX31Zz7aj3ibXEKJyJe1ltD0tbuqeuHMS9gqlkAhdSKDKkOfXlxDmdrEEgaqSiFDOWaKE4GZRYujdfePuuxDCRZB4ZabraeYnAK5yzpdd153VqtsQZFiWJbl7dHdxd2YJZGZUa0WXEpgIfd8hL0tDDJlBJCARLEsG0CY6IgEOIIZWKJkqslakoQPLCleaIgAYiHA9Dvj2Nz7Eb37jQ1xdX+Dy+hzddgRiAqUOJglGDGstM0EITk4AkbAQeSAiIYDARCAhSAw2LLOTir7KWedKmq93Fc61V1aqrhaDweDM7NWrV8twAOwMUSCwttGYxAACkTFTA+6JzSwwcxSRXlUHZt6GEE5A0QWAC3c/N7Mzd9+GEEZV7c2QzCwAaCUcQMxM7bJtl10QAZGgqKFaqyAMAK8Y+HqPtJmbGwILyIE5ZxAHkAiKFaAUBBBGczy5PMfX33oT3/za1/DB++9id7VF2ibADZRGICQQBRAExAQngABiYsCFoQwCXJgBEqsgjelMw3Uq7ocC/Xx5fz8vP/7JL5bt86u5hLAUQqYhlgiqlWHWajR3J2M4yNQFAhZmpBgfgKUV+Keu68TMQoixa8GzDTPvROTMzM5NcbEG/KzWuo0xjrXWPqWUlmUJIlEAZlUlAKQlw7Vis9kAAGLXtdx8GpkBYA4oZU0VtSKuX1fgdgm2AShBYqtNa60wVUQiXI09rscRH73/Dr727lu4urpA2nQoTMB2AKSDOwPOEMhrxFINUBAcBCKGk5BzYIQEpL4gjZnHLV1dn3VvXp9fXo4XA+u523JmWncAb4SkZ0MHcDBiMSbiIGAQ2BwCRxhSh2VZQEEIALGD3V2YWTiGSESdmo1mtiWiHYDzWuu5u58Rwpmqbmutmy4Nval1JWswMxERbkgfyN1R8owuJQgRdAVdpqUAIDgJmAPUDdUUTOER8uUQidC6QNVBHCDSHoSVighHEsbFpsP77zzHh197D1dPLkB9AJLA2WEhAdSm9uQAyCHEMFdADYBCg5GIwcAMBxgSCNwZXJW4atqW+E5Ytl/cz8+eXkxfHg9T6MeZgsxVfYmqGWbF2KsTjEEONzMzKILzsizYbrft5LTcTDFGLqXElFJnZj0zj3DeEuTMzM5U9dzdz9x9V2vdEKQ3Qicpxv10lNgNXA2k7jDgYd7YdR2WZUJgxjRNAFZcGQwSRi0GOCPnjBBCw2DWwfAJghQJUDjyvADmiE7YsODJxQ7f+Oh9PHvzCmEbgURACki7M6gBHFpPDgbgLbggB5kDub0ZDsCEyBkMuJBzFIQuUuwV55s6bHb9u2+eXb5xfb588fLswuPZbLrNUUYm71moAxDhyuIgAZOBocLgGCPKkolbqUFmxqF1DBFAV91GZt4S0c7dd2Zop5lop6qbWusQY+wBjisOIkREZkaqTu4EVcXQdwjyemSfc4W6wa29wiVrO6WPpsu/PpAQkcYtKYZaFZEYmxDwdLfD1z/6ANdPryBdgAUAHaOQAwaEkGCocC9AnoEyQ/MMLRleMjwXhOpAVXJXcgLBVeAqgEUAfarboVrY4K2rXfjojbPDMp+HYjuq2A0WtuQ2CqFjQhRDCC7MkFY2irQrxwkQEFSVpQ0PQ4wxlVJ6AGMbSWF3OsUAb5l5o6pDrbUPIUR3D/Ocpe97WpblocKotULVMQwDzGxtlRvZpJZ2UsGMpWQ4tRMeY4S7o+u6hyCfTveJkELm6CViTD3euLzGm2++ie35FmGIuFv2uM8TQoooplA1OPt6ExS4LoBVMAwMAjmBtMJLha/BNgI5VOAW1C3CUw/eDEXC5tl7724v0rCrN4ez0A+7qeqmah7Na++uCe6B1kLAiVBBCBCmUoyIiJmZVVUCPGqtXR+lr7WOqroFYyeRd6XkHRG27hiXZelTSqmUEkOXRLUwM+g0azzNITebDVQV85IxjiMOhwnqBAIhhYRpnhGDYFkWCDNsnfaUFUx3d2QK6PsBdV4Qjkdsu4AzNjy5HPHhb34NtE24o4pQK0KXcBkvMN8rhr5vL5pWmCkIAWSALA4Uep1KQgXnCckKWulRiTiywSQgxBpfacBZz6BRzy6357tnx1cvfnYI9uTgIew92UG9HNVoJsRcPZSGwBmbL8aqCocCZOTuLCIBQCKizt1Pp3kLYJtz3jHztpQyquqgql2MMRKR1FqFiCjnTKUUMrOvDHuXlQ11Sg+ncU8pBar6cGJP6eH066ffO/Qd8jS1CzAwxq7DbrfBt7/9bVxcX7S3oCqOxwllrg0jccBqhS4LtFZoLqilAKqwWmG5fR/ucFVoKTAzWK1EpmSmBEAcLsE4klvHwCDC4wdff3f74sUXOzbdBrdtqb5hj2Mk7kgtqZVgBCZyIq3g9XUkMztVG9HMEhH1qj6sU+otM+/WymNDRGPOuReRxMyBmUVVycyolEKq+sDUec0JaYEsRR9wDADItf3nWnMir/NwreA2em6fVsFuYFL0fcIwdvjt3/4O3nnvbWw2G+QTymftt9/d3WO/Pz4AVWSNRXR6cGatXDxBDzUX1FyAau0BAORqxFhTiElgQwLQI/j4wTc+2NwfX22tzrukvjUPGzEZOpM+gJKTRyUTwDg4tTrX3an1Ci4Aopl1RDS0E81bM9sC2BDRppQyMHOfc05934daq6x/lk659zE1KoSAnPN6sfGKxp2u/9dUKlohRVuDcOKXPIzslwUBijEFjCngN7/1Eb724fsYxg7uiiAJZsByXJAXwzxV1GrIuSLnDHcCjGAKFPX1gRDICFDAqsKzgdTguQLqIK1AQy0YgDhRUPekhL6/PhsK22bJ80agW+Fu64pRKg0dhy4Ejso1uDsnJgqqSikldlc287Desl3raGkDYGOGjYtvzG0spQwAkhEihEMphd1aldGIPPQQzBAClrXF7scequ00x7iyVx8xfFrGIpjpr1GrFO6GSA5xR2TDR19/F7/xza+jTwwih6zdpinhUDIktvKwC45lWVrVM3TtRMOx3nTtgZuBVGFQOAugBiIDqsJbbQmQEiQxKIRqiE6SpB8G9N04Wd2cEzaEsGG3jbvvQdYReSSQNNyRjZmZ1jZZmPkE7HfuPhDRaK1Z2QAYa62Du3fTNKW+77/SmJyCW2vLj6fKYZqmlqcpoOTXxL9WjWi7oB7RrFqm8BWTNrADXhXRHYKK50+u8M1vfA19HxACw72RCKec20l1Qi6GeanYTxPmpaCaoqi1btLaia5o05ucK5aisFxA1WDZ2knOGV4LoAUwJyNnB4mRBEVICNvu8tlbg5qPBt1AMRLRaOJDsdKZlhScojNJNmcGQCfOHIDo7omZezMb3H1Q1VOwh1pr542sGGOMwd2ZiKiUQqfUUUppOZEaRYGI0HUdaq3IWtdRvUHXy7LRgBubtf7aaT6lIqyg0rPLS3z7t34Tm6FHYId5AQuw1AVqgHrDr5dcYU6oKwA154xSCqoZDA6DA0woqitK6KjVQO5AVcAcmgvIAVdb84sRwTl6ChFDhPfd3/3d/0VXig4wGllpNMJQGYOS9e6eoBYAFuXATOQEGKtqWOd5CUC3zvfGVt75kGvpDd5V05j6LhicwcS5FprzAhFp/5lfI0V2XYeUGo1MVR9O/WPCSUjx4YJ6zIk4/T5mxtgl/MY3v4Gry3OMfYJau0T1MQ1LYqvT12Fzri2QpRQc5xk551b1rIE2rAT7GAA7EV50pSUb+DUNCQ4ld+PAHQdLAYXj3/07f6/TYj2DBgGNajZWeE/CnRAnrxpNESgm4UDMgVjcPQCIIYSumvahH4ZsPniMQyEftFifQpeO+ynuNmdi1RlG5AoiZzoFNqWEWiuOxyOICOM4Yp5nTEWRuhPbqYLJUTW31ru2FBKYMc8TYmCwFUhZkHTGTiq+/t5beOuNS3QR4EgIXQAFAtihbiBhqDpqBcQDSnFodSy5IK8P0EAwFswG3M0ZhRicEo65gNMAN4FXB4kgwEFm8DwDJVPGQhl7Ui9MPEkdDtGfbpOHuT8GH+YuDCbj0AsPSee+V+mipATRsCiEQcZqRdw9EFE0s87de1XtSynD2v11zJyOx2PcbDZSSmldjzudULZTjj698sz80Kicqo7TqT2ljJUm0PK0t+6v73tA20NjAsiBd958C2+//Ta22y1iTA/VTCNjvj75qmsd7PrwJpzSWF7Th+paA54OK9rvARGMAGda62yFLjOoGmAEd0KiQDkvTK4SwEKm8aOvfzOhGzqGD4ANDvTm1CtRZ/AIIAipBABiZo8Dndy9M9W+1tpLDJ2Zdaqacs5xu92GtVWnnDOtWPNDOfagaYlxBZGWtRkJD3XrKW0IMYgdao61oUQQQlkyNE/oUsT15QU++vrXcHl5ib7vEboAZoFWg5GB2RDjqlBwB5E9BN2dIRK+wodzMzg1TKmqAdQwUqVWJSWJcDMwEWquMM9ALhj9SHlR9JLIpiOza2CR+Pe/+V76F3/yva7E686deyPrK4eOPCZ3TQyNIAthLWhPgU5rDd3D0bt739hInuZ5/soFqKqUV/50KeUBbTuRJU+Yxuk0G+Gh0mg59bUWhMnhhodcDi1gAEOf8P57b+P5kysM2w2cCG7UAKUYH/gn7gCZt9lcYFgtMK8o4gjisCrwIDAUsDkgASKtjjY3CDGmuqCDI1ZBWeYHLNyXguM84dXP/gYvX7xCZKanm5EsLzxcXoXwxjtxREx7sq6S9WDq3blnT51bjUQlCDSE9TQLkUdgvQxbedcB6EzRmSKVUsJms5F1YMvzPNPptWwEPzyc6L7vvwIEvSZkG4gEITACExwGGCAcYEwQBpa5gL1gkyKeXl3ivbfeRJdaKXdKBe4OQisZ10Fzu8zcAdM2NnGDlooi1HhwXQKrQcQh0SFRQOLt4XF7yEyt9CzzjLuXr/Diiy9x+/IVXr68QVcz+hQQ2MluhT94933OxWTe70MQSWbWwdA5akeErk1+PQGIoDXQVjWQcACQ3D3Bkcy8A5BqrWkV+oR1In7KzTSOIy3L0r64tayLMZ7UTA/ppJQCCmmtjwUp0JofG57WSDNNN1M1I7rj4nyHd996C9fnW2z7iLrm9K4bHqbj7oxAK4m+LmtbbQ8PBFXhuT2YyRcwFzAXxNjBu/XvoIYohkjI84RaFpT9Ea++/AJf/vJzLPu5pZtRsN1d0uX5Fu+8/w6ZRH767oeC7WX42f2fRjsgmVliWMdEiQwJzong0YEQyFuO5iCxlXea3LhzRyKSpLVEMwvjMJxaba610qmkKqU8tNwxNvLN6XJ63I4zP9Z8nNReDnKC1QonQs4LxB3b3QZvvfUW3nh6jS4FpBjAXYQ70B4swBQaYKQF+/0dyF6Xj6chQwgB281Zq4QiWkA5Isb6iGYLWJew5IqyzNBlRp0nzIdGxtl0CeMwILzzDq4ur3BxuUX3ztsU33qLCyUOPMp735bwiz/+iwjkJK7JHR25JTWPYI4gD4EI4m5h5UpHd08Oj+5IzBwBRCIKMUYBwCfQSEROxPSv8PT6vsc0TQ+17QksWjGmNb3oKgsDzBS1tkaCvQXjyfU13n3rTQxDI1payahCMAOyKvJSMU0T9nd3yHnG3d0dgueHOtxMkVKHvu/x5MkznJ+fo7/aNVFmAIgEnBngFS2MBq2tQXms6bm8uMAQEs43W9Tzc2xTwK7rWrUDo8ZCV3nrjWeBKUTnGpk8wRAZnhwUDRyZKIYK5uIkCRIEEjmGmHNN7BQVGq1aiDGJlT1L6ogcJCIUU0e3t7cgafVCkrjW0BkhMEpRlKKANw6d5AUSI1gBZ4FwhKPArK4lgAOo2IwD3nt+hW0n6IPAK2OeHJ4NyzTj1ZcvcHdz24YE1rCLlBI8MDZ9D3fHfNgjzwVBGRaPYO7gQ4JtBQsxZp+R1JFMEAkgNVAFur5DJCCCkOIE6hOOMeBwfg7IPbw/A6dzkplpL4WAWwq4ZkIvXPtAMcapUHLk1POchEMiHSJ5CGFtvYOZBXcPqo3tqWrR4dHgbTzFIu7Epk6xT8i5IISIXAv6vkMUXru+tfuyE7OyVRv9WiWA1/ztBqiurbiCtGAcRzx/co3dZkQMAVEao/Swn/By/wVuXr3Czc0NGIRhGEDCGMYRF9dXINY1lS1IwnCr6CUijQkeHGwAV4NSASNCUGFeG6tIAsIKUO3ONti/nIHdgFwqjIDpcMTuWYJ6xav9HZ4OEfV4pHHccEGWLgZJscisUyTSKCLRYNFrjqoehUMMZibMLKueJZpqBFFUrRHCYeVnMCFSNRBJgKnTQ9pQg0irCk6UhRMtoA1VW2UikYHQLiatgGnDO6AOOGMQxaZjvHF9ibNxgLg10vlS8erVK/zyeNt4drseT6+u8cYbb+Ds8qJVCyJAaQ1JrkvrPEFgOIIQupggTq1RUQczQRBATghOGNKA4SzA6wJmQtx2eDXdoTphnhZshgS/OSA7wDsgnF3Q2csFzD2p3RIS8zjUkI85iFBgDtHVIkQjkUalGkIr7SgQUWDmAEVg5lDdQgA/PIjqYCamIJGmpeG7tbZSLrDA3VZI0x/ypKohxoC+76CooLUrdELDG9RAzggMnG8CLrYjzscOrBX3tzeoS0UtQCmK3TDi+fPneP7sDWw2G6SUMI4jDE3LHoYGw2bNUCtwN5hVCK1Y98xwtPJPi0EJbawlHRwM14rEhPNNj+N0Aw/Azd09RtrCDjM+n+5x2QuWFy9wz4Rn0xntYNS9/ZThB9mNJPfHEtS6WBXRqscUEUMIcalLDKt8raWPpg1/+FQzObGWSlXq+0hFX0OiITDGcYTbaRTlX4FAsba3IQSoGaoV6DpdMVXADImpjaVGxtVuRGLCvL+DlgpTQj9ucHH9FLgecXF5iXR5BhkGLLVCU6t04sUZRmMAtjZJM5Y8tzRmiqwFxARFhZECDmQFggjYHcUdT8cNKB+hS0ZHhG3q8bLcgthRZ4VtO/z4k8/x08++wMu7e4y10NnzM/rod75F/6v/5d/j59cX/OWLO1FPAkoBkgOJRxaPkTmGE2PU3UVVxd2De8vXbiYAxNay3sG4398jiJCZYey7NcjL2unxCjm20qnr+hXJa/kT3nK4mcGtIsDQxw5nY49NB5zvNmAzOBxdFGyuzjHsznF59QR+3iHECPXaPoODxTGjESQHahr2Tnp0JSKVDqVm7I9HTIeKwEDWDGKAGVAvYHRQZlS0MvVqtwPrjAvd4OXnL+D7BROOMA347h//Gf7tj/8Kx+L4n/3H/5C+/cEH/vkXP8Of/MF3eTjO9A/+0X8iKC7VPFCSQBRjqUtQ88CcYiBqZH5zF3YXMImWdspruygZACucprzQKYgpCoiBnE8sfXmYw7EAXWrw6GNB+mlmp1YaKbELuNxtcH2+xfnouDg7wxgCxj4hpYSLqydA6tANCemuYtx2ILT7IJsiOkHdwaw4pgkDO8YwIvUDJKYVEhXkYoi5YJ4r2gicUNVA1iEEAxmBhwTeDIhKuP3Vr7ChgMEYP/vVr/CnP/gR/vKLW6Qnz0HHgu7t9/B3/vH/FvP+c/rLP/x/0Sc//RtObYQikUWMOYAomFNwR6yKENydmxcIn8gvss4Om/QYTtxuNszLkUSEHIpx3EFrO8lDlzCt0rlSF3Rdt3Iy8IB/nEZXD2SYQNiMPc53A87PNjjfCK4uL9Ex43K3hbohdgHG3N6lIaCyIdcJoo5CDgGgpogS0UsPg6NYAStDS0XVBpUCjWTvVkFFwSSN5RkcKUQM3YjLN54gCoBJcXl5if3nr3D75Q2+/4Of4K9/+Uv4vMGX9QZ9GvHi8ztcXL1B3cWOfiXfBdBTWWaCKbNAqqk4V2Hy4A4ppUhYx1hM5qyurG5sXtlg7O5MEK5GxLWQ1YrUEXb9AF0mOBQcGcUaeAQWpP4McRhgIpjnGaYV5gZwhzztkVCx7QRPNgPONglvX20w9gEXV2eQEDCcn4GGAYkZDkMXGOQz9mxIlBBDB8oLkgSMXUIVwnSccfPyrt0L7DjbbaAlg9GGrX0pWAbBOJxBpwVxaZVQioKw7PFGUlDogOECeQCyOzYv7vDF/rv4dz//GAcY8pKRioDlgK9LxeblL/Czn/47/OLmY/pP/vE/oP6dtxg/+RnXpXJgY9giDOJMUVK/lQAwmYGZnFbRBZ9OubtTU2aATqhcl+IDWNQPbZJyt78DcUKkABIGtFG2NJfWXq9gT2THGBOuzzd4ernD+abH+e4MQ5dwfnaJYTO2dCMMOGBQVDOQOWLnCGCgGCAJmhU/+dkP8ekvPsOnv/wcuRkPoB87nO0GPH/zGZ5enkPIMfYdKA/t6+CGJKpWUM7oUg8jIIYOyAVx6JGuErq3FnDf46NvfB3/5n/8C0jqMXYJ77/5HE87xve++0foB8J/8V/87wAqBHa8+c5b9MMf/ZwCdUxujYyUEh/zwmHldBAFWYXMIAC0BpnMjAwEXn/OzNBUfa9hT3YGc5OeYQX+ay7QUuBmIFOwVox9h+vdBm8+ucLlbsT5dsB2HNDFhNT3iDEBLCteYRAIZEX/eQ4wCTCJ+KtPXuJnX7zETz7+BT7+4gsUYxQB3nz+DP+b//k/xPVmwMd/+e/w+eef4L1nT+HbhPMrAougRsCx1vlkcHLUmrEERjdsUUBgrojnl4gcsZsL/vO/9/fx9IPnODs7w+X2DG8+ucbl5Rmuv/k+4bqnOjLEmb75rW/Qj370MZFWYhIqtZKjcJSBw8kLqMEQrz8eCfNb0NfAEhwSUyOR57KyiDao4IZSljYF11LhtYKtnf5dZDy7PMOTyzM8vTzDkAS7zYg+xYe5YkipTU5IVmjPYFgZ/Uw4LjM+/vRz/PCnv8DPv7jBp1/cIo5nEGGMuxaEf/S//ge46AXlt7+F//af/Jf47Jd/A372FLvtu+C+AwVAbeXiEaFqxu39LS5nBQZHdWkjiO0Gf/8f/6f43d95iePLO9z7AcdpQvWAL1/MsHIPjIYhvou4eUZKgQKPCBzIihOzUN9taK4gcSJeg3oi0Xzl++u3DcgkgIMAxMh6AvDlwVDFqbGOcs6ouTRzKa+ITNh2EW8+ucA7b1zj7afXuNiN2I7tNG82G2y3W6SU0K1tOvFrBqmboVbDMSt+8tOP8eOffYKffvoLfHFzAxfB/XzE/TRjf3eD25sboBZs+wHnmw1+529/BxfbDT775aewusKnXYKkhsvEtZvdH++xzPuWemgDcIdwfomrd97FxdNzsCgCDDEJ9suEIkA6GxCGEWncoSICGJGL07e+9VskoafqTBWBYuhIiBrj+8H24Nesar7ysU5JmAAHwZuqqElx1WC0WpKpwlzBXhDYse06XJyNePfNZ3hyfblSBQgpBXRDjxg7SN8jhYAQZOV9ONhXewZT1Fzx6ad3+PyLIz778tBkEhqx3x8ATsg1gzPw1lvPUUrBF599jleffoyf/uivkQ8ZOhvmWiDu4PXosDlcKyqA/QL88rNPMDy5gMRrBCQsKDj/4AOcQ0E14/bmS5h0cOmx2Y0Ig6B7cgmNAYQE8ogYBB998zfxb7//l6AQULQgkSGIIDwOKhGBib/i68bcxkQqhGwKJ0eSAHNA62suWyUD1FaMoSIFxq5LeHK+xdMnl3j+xjU2w4h+6ACtGMcRoevBISDEhC4xQhRodRhsZeYDeTHcv7rHL1/8Eje3rxAw4apLGAl4Hjosc8FmHHG+GfC3R8En3/19vP3GUzy73OE/+0//IVLHuLl5iT/70WdAFJAEBK1gONwUboBDsP/ZzyHvvw+Ku4Z16BEmhOGDazzbRdSf/wRSeoSaEAy4enYGU0NUBpTgq8YGUHASWCSwCXTJ4GoIROQEcSJqn81/wonMmdmZAV7r0xACCLxyjnWdYLcmhZKA3MGBECli13d4cj7izSdXePPZU5xvR8QUVp50xbjdAiQIKSENA6hleRg7qALEDDhBc8HhMOHJxTt4cvUu5pKxPT97mD26Gna7Hd5+doXdZoMP3nqO3dDjYreBlgl397dgD4hjD2dCNYO4gxztHpEGPs0648d/9SN881vvALmi6wY4MgBHOt/gnfA25s8zhrmHECPPE8KmQ8kTQupB6Qzw6hDy9z96z3/w1z/2KMFTT07T4qHWjBDbsWaHE7NXM48xojhg5m5k3s0JUEeVNn02s1b0U0CQBKcKiIIp46IXvH/d4d2n1zg7O8NuN2AchzZlTglBNiC01JNCRCcBHDqYO6pXxDE+dJS8GfH0vXcxz/baY84rXFuRtN1uV2OAW1Q74Pg3t3j69BpP9ApnZ2comwHLwtjtgGIBqh3UOsy2BwVGJELIDOeK/WdfYnrrZxje+BAjdigwmGxBOKDungL+AvXuFpILEo2AhkZsouyEyUkS1OC/9dG3/Od/+ROnal6cHeHSwzradCJyEXGj9USLeAjuUrVxd8jd3FxVodBH6aYFHu4QYWzHEZfnIy4uLrDZbDCOI4ZhaAFepzBMK9iUWkl4MssKIWAQAQV+OLHDMAAAxs1rJuo0Ta29rorj8QhmRj/EB0Ar50Y/UzzidkiDRVsZ9cgckAVKgM0FEjKOd/cYrmYgdE0NAAJxRBJHHLcQr8DhCBjgwk1/bN4UUQQXFldzF2l+ecxs6m6heZ24qWr7ttFCDYARtaxD1m4R82b80eSPBMJrt8fQtJGIMT4E9oTchRAQY3zgPjMJYpce5nonWPW1VQ5gZOswtvlxHI7Lwyzw5Hxwohu0obCsf54enCjbAMJR1AGW9ZYvIDcEoTbOW3FyXggojsPNDa7zAegGMIe1rUgttfUd4CPgjeLrMYFjADP7qYQgkDOzDcNg+/1emdlqbYE+BdWY2cjURMQoBEtOVkIwVXdtAv6vuJERMdjwMGt7zNVQVRRTELjVxY/ctCS2wJ9OMwAMXXrgggCOsJ56ozbQlRBRiiKl9BU9S13nhF2UB3UBiJCL4jhPkFWPKDygUoZ7BaP9G+1EE5QciQNQW6DL4R5xswHxBu4CR4CjQoiBGOFdgok2YSmLkzfDp6bRMGNyu7g41+mwNzNVJlYmIls/ldgVgIYQlBkWQrAQgguxm1W4q5+ifKJ3AW2afZpwn04bc4BwgKQIkvDaiG+lJJzq71PwAwuE+IGxdAqkNJ1rY5RGAXMTg4aUAOaT5QVIIiAMCgI/2aQ5gyVCYgBbI1I6KpQyjCrgDqsOyxVAS1fH23vsX70ApnsAK4HepXnIQIAgsJSAlNxF2uFT8zZVgLmbAtBnT54oEVVVVSLSAECJqOlSVdXMVIKoOpRguooSDMJO8OaxdwraWg4GDmByhP+ANdlplEXcWuCHPP3o957miA+U3dY3fYWyEIKAWR5OuWlrkMCN30HCsFWcSUTQGNtc0hRlqXDlxr6lCqdVtoHmAktwWGwlZc4F9y9vsH1yjTiegcQBEgDSlLdY7YyDAOpuBgeJrRQVNVcVknp+fl6JqIK0EHkN1DyTlZkVgDJz7bqu5mrV1TQE18jiGsjUT1KIZoAlLBBqJ1ECwGvAHutEaq1wo9cenWtOfh1VegguPfZrfhiJGTgIKrzNIEMCmYEDo5MW4ODc2KmokNDw6pbLG7yQtcLr+rWTwaXpG0kdoo3sXqMhcoPf727ucHE4IJ4vgOxWik/T07gTzOBsBnIBkRuYV4qUqkAq3GvfpwLTyqDqQAkA1N1VmCuAysw1xlgNWg2qImbMbCuB+FShPBBo4A5zQ1jzMDkeGEvM4SGYJ8XVYydaMD38+FQTqxuY6SveywyCyMlMfO1A8cizmQUxhofLM8b278MdusIFXmUd1/rDvBK5wLWpZ+feAepAzDgcDpiPEza5QHp9lOLa+21V4dWdqFVrWIsHuCuIFI4WYPciEkoFSqg1awqhulp1t0qgGiVUV1SH18O06BiSGlfL5u5BHGQQA8RaeSdBUMvS8qx06NNKMrH6EMDUj+3dckeXwgOd9nTSXVt5xyuz6XS626l2xEDgGBFAIAkrLSwgEMHaKUOMHfo0NJ4eGtqqTqiSMNVbGGcwC5bDjOQJeX/ELhICVcwzQc42MAk41opPfvYx0rjDxeYKjgUuCs0zUikIh9L012yOSAa4mkG5HyvYCyiUSqU4oZSiJaauBCJSIlIHKjmKwwszF2YUVa211mrmRqsCXlbVemBqBiqrxLjl3VOneCLGpK9oVk6l2muaGD/U0LKe7F+/VE/BLusL9VrngpWmSw9l3enfeuDmndISMzgQdMnIdUInAcvdBF0WIFec7UYMKaKWDICQ+g7FFJ9++ikQNrh4/n6rDlOE+9QMqkqBhNQGl8GMU6hgVHWrglKEqASW4iSlqFZeL8PKzJWoHfcoXESk1FqLmamZKTOpEFtrz9eTuGLHBIfr6zIrhID4yLW31OXhsnvMVX7sk3/K7aefa43Ha5rXayxm/TfXv7+5HUjLkNUfyDsPVcuJtB5a6kpgLHcHTPd3IHK4MCYtoLIgwBFShIwjXBKO93vcfv4Z8q9+DpQCmMLJsJ/24FIc82J2OKrVqtmKOlCIUGBeypKLmRW0UUU51dHKLBVAcfcCIBNRgWsJgStz0JqLGbWjbW4Oc2deTUVEwGzoV5JjXC+hdkLtIQ+fxESndPFYZ9i4IV/1Yj4F65Tf4a3uZQjc1/x+gnFP1u8r6teaI17J5g6FYtofwKVgvjkgJQHYwV0ExdA8mkZChWFeFjAEyR03n3+K5eZLfABGuu7BQ/BSJyfrVwGMmy6kyxBqSH0hxAzyvExzNrOMQIWJayAiBVDXz8KgDKAQtW9jjCXGWBetmp2MHW5aVx+RVekaBLISHIe+Q4itu8PK81AzWFWUJQO2StvMAfOHepri6xQTQnjoIk8U4OZ4a/C61u3c8rR544+QhCbyWVOZraVjtTYYXqY9lv0RNBf4nBG6DTwQjKkNgH1lWZUK4+aQA3eU6Yh6vMPHP/oRPvrd3wDYMAw9/KBO7sbEqnmujKG4LS1uFMqclxxCKJWoMHEJzNzqaNVCRIWZM4CF4ZkZWRhFRGoMrKJuRdUY5K1zI0QmhLjiFoH/vSBVLZiXI2LghzTw68qsE7v+sebk8Wl29zYVWaUTtDrIeHOoBLOvaN/jh8XN/MQMVRW1LBA3lGmBEGOpC4bd7jQmxTRXhJhRzYFcYNQhiEBFYb5g+eRnGM4Zi8z48N133ea91WkxkaRsUinnQtJnipbBtry6fZUNXtyssEg70e5eYV6NPIuErKqZiJYQQlb1zOSl67q6aNXi1SSwdxy8DwlMgaIEpBQf5og5Z1RmWHidDk4rSB6LhR67iK+Ovg8l28M88pTHiZpYGKugx5t485TrmztNGwWVaoiqUGrlXa0VQwyYSoUtDR1UWQk1FFCOFUslBJpAKUNCI+osTFDOmPSAXRnwq+9+6s/ef+IfvveW8xDtsJ9UstVBhhJyyRw1I9ribvnLVy+zu2etXgJ5Dd76amXmUk0LgGxmCxG1xQKsCxHlvuvrMU8aPRgY1oXESSLBXjcWJ8de8teqp8fNy+OVI6cAn/L2Y2Prx53l659rUx4ignkrXfVUXWAlVDoDK8ldVVG4uSfknJu8WQLCOGK/7GGRgGwgr/jkJz/H//fPf4huCHj7nWf4jW98C9dXz1FBmHDEve6R7/f4/MtP8bWP/lErxYfepD+qZ6uuNScOC+AL1JaKukzznCXFXBXFqtbgTqaAgmsVtmy6LKx5ZgrzWepmmssiHLJHKmfbbdUXi1k1T+I+9OvpswwCYTPsABgO5kjcvh5GRUSGe3g4zY9J6g/rMx5VFid6L51kE25Q5aa4AgFkEI4wLQ3b0BkNbGiXH0tCrq3ergigOKD0AbjucMczJjcM3KPcFnQp4tWLmwa1pg1efrHHv/z8X+Lv/p3fbUSe/T0+fPoEb37zHP3f/Q7Onn/giM8cHVseco2yFCLJc7GlH2jGdDOHxWeuw7KfaulTqTnkdqJPF2KrNDyLyELg2czmYbtZarWl67uM1JX5cKj7/T4GYo/Ent2QhImlUQO62GFICZGbhtDresGQPaSVU8l1qqlPQtDXii1qIya3r2zUcF+7Om+UAaNH9m1BviLlOL0hp7KSWbDZnMEL0KHDfDwihQ4Mxtc++BBP3/wAFAilLpjnI371q19hOt7hrTee45t/6zdx/WT0/uKZ4/zaMfQGLlUClR4pUy4LeVngZYbqfDgsy5xr5hhytVrgUsO6iUEdXkFc3OtiwMzuczGdxnEzHedlsaoZ5mVInVaZtEyzxO2Gh81IOTfyYDCgk4CIRqJhPiml6CtD35M04/T9k6z5cdp4DE4x8wo8rWYp63QcsPbzXsH6Wt5cq61BLnBd74QawARsNufo44gYe7ADx+OM88srbIlXKd+CYgX7u1cwLdjtNnjj+XOM5wnYbl03vSG65iXrMKSiL19lqboIeNIyT2KYP/vyy7mSLyAu5KGqiwZVNRFSEKqZFTgtqj4b2VRrncA0pZSm/d3trLnkwFLOttt08/KF3d+88qurK981vyQia6051OC1kc+by5z8ew3LaaLyuMZ+0B1yA4see+S3P9fcaxQOVYZT4xr/+oD59OOay0MjJDGi5gKJPRyCiyebhp10x0ZwH3ocDwf0/YCnu6cY4nuoZcEb11eoS3ak0RGD05jMYBoiitaSxW0GfGIvU5kPE4Vx+tUXt7OkzbJkZOGuujehvYcQjKjZaHGQDGABMDvoeJyWY9/30263m+fDcWFC6TdjDYS4v72xVy++pHfeeYu4b4A8XBv9FC2IwusU5NcWDTy+EImo+d1BUE1BbogIEGGQN9MSe7S3q5p+hQ7RLtXylWaH14v29MkxwZmbkWEXG2YdCEN31lKaFaTzEZu+x/X5GcgU+b4ZZEUiqLmzsHHX2Wy59hzLYX+/bExnmE9YytESjod5mQ/HuviOspMV9lgjm4Z164KZFSWgdYXCsxtNAKb7+/ujsxy3fZxs8kXASz92Xd89iee7UY7HPR+PRz+/OketTRseQjuRTKtmxYFhnaY81oOfqoPWGcav4M9Nfvy6XT/pu8HcvOrcUd1AtOrM13zMzOC1kzz93WaGXDK6EFGrou8af7CN5xSFK5wJXd9jKbnxyJXQjQOmvLiZuYFdTS0BNTgVzMdlkLh89tc/nzZdf8Qox+7J9fTFr24mCcNctOYUU6WpauBqwaw6kAxgJfJqZpmZl1J1csLxuMxH7PcH1XhcSp64S6Mz5bPtWXr77bfCfNzz/f0txa4js7paSTCKKhariNyBVlrC4xr611/1X/f64F9zoyHjh9JOawWIm+HUWl4ivnZmXP+Fr9gFBSe4VsANZda1Frfmsi6AxL4RMWNEGhLy8YB+t8EQI7QLDiYDkQJeg6SMm7vl5pdfTj/8/g+PFxdXh+vnV8frs4vjyxf7idAvqlNOQYoASlotmJmbmUURE0YtpRRmXtzrxMwHIjosOR9ynQ59CMeidTwej0MXpCx5CtWrXD97yu7qYEe9vyd1Q64FSykY10n049f89OPH5d6v7516vMru8do6d8dSywokOfSEaTffPgi9fmte+zcBXud1K9KA4/GI8/MdpnWlIDEg6+lnaa45u80GIuIK9/sy+3LjNnap+v5QEkv2pUz/8l/8D8ebL18cbm72h27sDmdFD/NcJqNuoUDFtGiUTmtdLDCzU2Oim7lqrbXUWpfYpalO8zHGuN8fpn1MOLiVgyBtxouzue9CB60xEoK4MRHoycU5XWw3+PSXn0OXDIsJWiqYHZoUTs0lhknaZIVbvm11c0PkfD2BbVkCw9XWhgYQYeRlQYgB5Ia5zM1LyR22rHqW2OF+v8cwDIgkmKe5XYiTYtwOWI7Tg80+k8AWR0odFA5fKnBQzPev0MWMbd+Bzf142Nv9cdFw+UUN3VXWFOcf//Ivpj/5wz86PHn7a4cxDftSdL9/5cclDNMUwsLwUinXfcom2Hh4NNY2EVGc8rRjDiFMAA4557253xvxViVuvOqgxbq028QgFHKeebPZMAfxriM8va50d3eHPC+Y4gTuBxSt4JwfVLanbtKazGAlj7YLkteTe8K3m8zOUUpDAtvlqAjEzZRQCOQOBTDtm4fTtD8ghISaM6ZpQp7a7hZJAhJG9PSwdZOWguVuj+U4YdnPqMcZlKt7UXctXnPRrfT17HzMV8P1nPp4vOEvD+998O6+35zdU+T9cL473OdpcuFZ4bm6lUDQWtTAbOE0bjKrHiSae8vTxL70fX8Mh+lARPtlmveI8X5ZyoYojuO46VU95XmJ2+1WSlWOJNR1CeOwxe3NPWWtWI6Nna8av2IsWNf1qqeq43H5d1rz9+u1t+MxW6l9X9CCbFVXwouh5FYqHqY9Pv74YzAzLjdPUQ4L7MggV1CIQHEshyOWKePm9h51ySjzAlZ4ZPFA5EFIuxh1WkpRmZZdqtPv/OZvHfntb+///Ad/fn9/M+/j9WY/Prk+fPJyPrpsF3LPkaTGIGaluiA27t36v7ETNm1mhVmXGMc5pXTsh7R/NR/urSybPqTNtJTxfj/3Qahjt/Ty1Z2koeNQwftj5sPxnm7u90jS0Li0JIQ4P3gtTcuCuLo8PuRf/vd3AZ46weZC0Hbdvl5q+WiRWp4eHkDXdbi/3YOI8ItPP8EvPv45AOBm3DfCjghQC1gJVBQo3mTTxSEQdAiILOgkOBFZjKL92Jdv/dZ38lu/9bX5+W5z9Hm/pze39x+Ur99//jef3vvVuPeuP871MLv4QmolMqmoGSkZGXl4fQkRmNmYWc2suns20xmwY5Rw2OzO729evBxv7vebi+O8GYZx4Oy9MFJKKZQ5SykHvr+/pWmafF4mnG1G4jkjpgWxCqoZ4qOh6ylPk7z24miDWFm5fevXRngY7DK3RsX+A8sbAaAsGX2fMO0naC544403cHNzg/4+w/YZZRXaUwgQjpAhQCRiEzY43+6w2Wx8t9n6+cXOt2cb3Z5v6/n5WRl4mPHGZsLdlwdn29NuvO92m7tx198PT54cstIR3M3knMW8dgz1YgYwzLxtfzNlNzaYmQvBXGvlritr43Jk5r1zGM6ursc6L+Onn30+5lr63WbsI0viaQmH5Sj7/V6Oxz0ROW2GDhmAuFI2xzQtCOEI90ZMNDT7TNVmxP2oMPlqCllxDmVAYQhD91C2nQwMHQ7h19VJFxNqrHjnnXegpeLp9RM8KQPuDnscDoe13g4Y0oBNv0GfBgybLS7Pr/zq6sLPz8/97GyrHKFFcyl1mnlZprvDLw63d5/cf/1vvXeHSLeIcj+e7+6vtpf7nxzqEZIWqBRhqwyYk7uE6NnQTvRrKFKdiLyUYtsQSmBZUggRwNFT2ufpOHCKw5Lz+Mnnv+qFuR+7lFQ1TnkJ83wUFqIYhRGYQykUU8Ihz+i4Wc1zEHRDj+DxKyBQm9r7V2kGa4PzsDF0hUpB9AAiGTVqGjHgZBiGoS0mjgGXmw1ub2+x2WxwdAfXgE3doRwzjjd7vLrf4+54RETAmXS47T/Hl5uNb7db256NGrpQqi1L9Tonp4OP8f75N7Z39HS4Vct3/XZzV+/3+23cHl/dHeZqcYGjMGC5Ls7iDjYUX9dVr6fD1zxnqqpCzCJSQggLgGMupQtd37Nbb2YDiwx1mftX9/tOVeNxOQZVSD8I51KYyCFC1A0d6lxp17a4Ia9VwOMNQkspCKF7vYd8Hfoa4WFhWjFFH2N7WCsWkpcFEgPMKowcViu6zQCbJgCtWjk7O2vooAPanLYwSsQ29bCtYjkuWPYTbvYH71F8RrHbvFe5pepcF7DPFPhwJWk/XO3uPIx3CPVWunRLHO7H3XZvuR4ry6KQwhQVblqWyQKRG6kXJwQRQvGMUcZmOdZ86xyACqMysERCHKweTLVrC8l4UNV+JuqMqcvVokgXq1dZvJPihb0K+H6hi7GwwHEfC3mooAD4/ogUe4w9odaCkQS1PpqAmyMKIz8yU0kM1LIgnii96o1XgoqwwqogwTQ1g+55PkKDrpoYghSDmoICo9QKZ0PcCDwHYIoec3IisgJoIa1g5NCl2cyOJLxPFO/O3ru+PX//oxuE4RblcDeM3f3cf3j487/+bA4YFiarVe+1uHrsQjOezcDA0lahOk6ERThaV2WrSquKCBPRrKrRwfu2Xo96EelCCF0p1rl7NLPY/JmqgMErpEmt22IupeDkXlNgOBwO6FJC18UGlS5NcfvYPijG2FTo3paNPbx9xM17e0XmDK20O70hJ1UYYgLsNRXi9OvMjGVpLgim6s0Nw2xdUV1JKJthLrAjEe2HONy9/7X3b9//jQ9v0tDfoEu3WOyeQ9jnY5mO8zyjH8rK9DIGrZRneiCEBqJm9fvQ7rZGwt3V3F1DCFWEMxFNZt6sgJpRbBKRTpUTgEjgSERSahUIc0FBjURTXtANPbJWXpYFS1qIuohpmnBICSHsYNza6ROv49R+PwaJSinrklw8UBgezGOVwExYpvmBLx04YplnlHVlXy328Pc2m84OruYhwJWrhSGqM1URzqnv5hDC0Zn2Mca76+vr2w+eP3t1drG9ccGNlXwL0L2Bjr/8/IvJibO7VzfT1TDST4oIrJBAeNwsrE/bV2NYNzOT0E41My9qdgQQ1o1BCWi+SyISxRHYXEwzExMXVWRlKtVgxAhtdMVzXpC6QNUNh+MRXXei8FJ77Vf5hbtDS6suUkqIsuIhcJi95oicLCmc8JWt80SEIF0zMFRFk7rTw4MQIa+1uhCbSFQRqSGELCnOfd8fQXTv7nchhJthO7waNt0rg76K3XhLgjuI7OdpOf67v/zR8sZ73yxro2cMcxLAzdxBgDRXh4fL0I3A4QEz9vb6qouIhciVmQtg82qiEs3sZGwVY4yR3IKYi6s0mbMBtqaOdvEJ0GgGnHNGYEEphU7SiG7oXw9u1R6C0mo7Q30AnF4fDFesRHdCrRkitHIN/WFUZmbQWkG0YiohuINbynAyJlZOUhvZRWYWOYLoHkx3BL+RyK9CCK/M86sujDcEuXXzPUk4/umf/PH8ve//oDx991sV1BQSTOyNJbJWR8xwMMKJ8aOqiJCHHLbSAxyNkK7uXlYXhInb/itBc38UWbsJEWcRIXUjo+bNnGvxquopBV8rG1mWhYWYOAHH45HMDFu0LRUMwmLLal/Z+HylFKTutASnfdKj4YGqQvixQXg7MI+n67AKM35ocZjZYuR1VsqZmWdmPjrhvpreuuorEXnp7i9U9UXO88vO7MbV7xy0DwjT7/13f5BvJpTadra2FS7UhsrM3CSCK/M1PIYpH/jIzKiaXUTWFthXwKnmk5GKmQmak0PzZGIXkcgpgaZlbs7oaijqvtTqgycH4CEEh2tQVTYzLEvTpkgMdMKhmbktQiB+IIw/JtyY2QPv7zWZ3RFDetgPoN541euh8RQiwOJw86puHFMVoOalZHab3e0Ipb3Ab939lWp5ycwvVPXl7e3ty+s43IRput2c7/aSNtP3/+L7yyc//2Xuzp7r7c3Bdk96b0N7d3YHE7WpkDvA615wfiQJfu0dZyBuk1B39xCCNpYY8iMHBHlYPEZgZqZAibhkhMBOmp2ZbRUktZzYDxYkuDQrZa6uHM2oLY40aFcppQSXdWh70rqE8BqUUgPHk6LaHyqUnDNABAkBJEDO2UMISH3nnrMzkQUJplbV3QsRFQAziRzZ6Z6I7kIIr0Lgl4C9UNUXy7K82O/3r46D3W5K3c+H+dhLN/83/80/zWO/qftp0c8++9zPnz11xkkQ4Q+XOIPahs7nl2erv76h69qmNIZBS8HT62uQO7lWzAbMxz0CC6COIBE1Z48rB8NqgYTgpu7maLiGCLapw67v0HWrOkuamRUc8NXNS0Bg8ibo1ApblxiQnxQLhqwOEIO4vWVOaP7Rqy7GqoGJEUOEG1w4wpw8pd5T7N2imcKUQ6wOyWS+CMlkqgdhuk8h3tZSX93d3bwMIbwwsy/N7EXg+JJAN0L1btxe7Id+O/3ljz5efu//8S8KhY0uU7WBg3/jW7/RZIFxpRAXReQAhIAshHB6JQM7TPXBBfzRyg5vAapgZgshKGClmFIIgdSMnEAhBIAEInARQdFsqmrmqqpaVbWGEOoKWPUCSkQcoRYrqqyErnWRmZGrQWN47bywinnaddD8h3TtaGKMIGZ/mEESXN1WBTCd3mANIRThWAJRVrVZVY8ppT3gd8uy3KYuvNrK9sWyLC+J6MsU+1dE/MrM75Zs+y++fDUN50+X/9N//X8pzKxkbl1M/tOf/tTzMjl1TZrhRI8YU4AbIRRtnAp4hVaHxCYAMmvrodN2ixDEReg0zzMRqbVWSjHSNM+Nix0j3BkpkVe4L2XWUwNgZkVVKzsKXAvMi0jombirmquqRm6rsGXN3aylUCnhtNOFUjNtJYQABGobPZnAIGcQFi1tva5WjzF6o1GIzSUra9XUcYFzKfOyhJDmEMKRmfeqer8s802KclNzeUlEL939JUFe1ao3INyJyP2k4UiHsvzR//tflZcv7yopjEQ8TweP/eD397c4667WN3DFaWy9eskQ3FZhpJ7I4RGMClkrj90K7kQJnoJAtVgICVWkUhBIaElf2tzOO4pWvE1rSOuJDpyt1GxdXcxkUdUFTKOQ9Ar07p5qrauTpAYGuAAsIlxrpWVZKHUVKSVKUR4UBiklMJO37tCdiNzMLIRgqmoAajGtzFwZlOE8AzznXI5EdQ/gHsBtYLmJhJuK+jKE8EpiuHHwTcl2D+Z9yXacyrTgdsr/z9//7yuJWNdvLZfqKYqLO169eoGzpxeNQrzK/9ybECmCW8OSa0Enr7dEEL+m1p4A9ZgC+r73+5t7SOgsSCMWRgmopr4KhdayKVoIQU2neiK2MyPHEOYoYRbQTEQbZh5DCAPD+2w1ubbaHM0+ORARrxuLuFalWhJp1z0IktaGxkMInvpkIHJTtcKlaiu2C9wLgXItPquWKYR0VLUDgPso4dbM7lJKN4f9zStJ3c39YX9rTre784v74nbIc51q1fnLu7vyR3/0R7XrOt1tz83n2WPoPLuh1BkvX3yJD+gj6EpZCyemFdqFGJgZWhu/WG3dY0W+lkVzExrB0IWIzTBgf7t3d0dksUWbQTfbuheQ2ZnZg8NESF24mHtx15xiP4vIJCKTMI7s2ArzloOMRDRo1t7d07o+Krp7c5EkErXKhEBaKmmpFEKbglipLQ/3vU+qRkTqBK1VK4Bi1TIRZWaeQwpTKeVoRnutvhfmOyG7K6XcuvsthG/n+Xhbqt4by/7F7d0RFKfDcVn+4t9+v/ybf/uDarXqW8+fW8zFyc2329A89NTw8uWX6+j1ZL/fQCWCA64ICn+Yeqy67+Zh9GiB2Gnkn1LE0CeoVicOYCITEFzEragHCm4gl0CWUlKvUomoOFMGMFvVCWJHRBzauj7bMvNGQOMwDIOq9u7eEVEiohhEIjPEjKRkY69K1TNZqVTXhyoiDnerbYm5cgwFQBGR7O4LEc0AJop8ZJZDjHXvRvdudk9Ed0R+l1K6h+c7J+yXnA8U03R7d5y/94MfLT/68V+XOVu9U7MuJlvU3UUcapiX48Nmo7v7mzU/ywM/kNp2XwBr1VEfmJ36IHonqg/o2KkpEGpCyf3+CGFzEYJWmIjAi9UV5HERsRiCagiVpf2nhXgmoomIjiJyCBL2KcQtEW0EtCnQEUBvZi3YQGJGjE0OIJH8YVHwaadLDMHhbvM8KxqhvgTVoqo5xrgU01lEZnc/UuUDQAc32gvznpnvieieGfvj8bhPnR8+/PCj43h2Pv/gx3+1/Mmf/qv8s08/rzf7Y63qVtNgZOrZ1HMtsLIgxKERKWEPG0d/nb/i7AhECJEMrgtm7ZFSB4SIam3XFJnC6gxyRSwKF0UauHk6a0XN6mMaoFmNAoOFK5E6AzaQ6VJUrd/UGWOZUXMnPrNgIrVDZN+a2YaDbBBkFA8jSxpMy+BqHTs6IU4AB2aOYRce1kUlG2hZFu9i8pyzFTctuRRmrhDO1XRhkoUYU655EpFjKHok2IHdDpLCfnc2Hp49uz68++bz47Pr6+PFs27qoyyf/vzV8pN/PZXP7l33tdfsizm5pYKmifeKrAsieVvaYCcTLEJZFDGtQlYHNPi6g4sQuq5r2zEf7Q8kcOO2rRs2TxsiTgz7IXW4Px4RY4Sqeqta1MzdGeRGZidO36nECyFkpjADmN39aGYHMhuFwhhjHHPRgZkHJhoMpWNHF2Po1gXDkWMQABJjpMCBxnF0M/OV261d15VSSnH3RQIvDiy5lImZpxjjNEQ+bjfD8cnV5fH62fXx4mo3jZv+uEndPKS4gGuel5znea5fvHhRq6nN82xF3a1UjzG4rBIRsx7VCszkoYv+daneSfQP0tcwaUP8FcwRBkdkhhCQZ4UpEIYAmMBqRgoRE68LIZ2hapBAbhBozi6pGekEFu9iOjkkVNVczCwT0cLME3M4ElFPRAMRDTHGnogGN+urW0/mHZySu8e28SgGdxcRISamruvczDylpA0KqU3TZ5rNbBGRebvdzrFLEzPPY0/TbjNM5xfn89nFZh62w5z6tKQQcoqpyCbVOh3rkrPe3N3atBRTuJMwGMFNV2FpXocNpW0j4hO7ddWUP2Av63Y5X1HIUKsBK7W2gTSv+W+n3SlwfljIG2OE6R5diFiW8jC97lPwqplijA5Ta7ma3F0NVrWUotZZdaO13ONZRDoiOppZH2LXAejB3DG896qdmSU3i8yczKzlDmbKS6aUkscYPMagAKqq5hBCUbeTBmcWoSWlNNdal2Gk+exsXC4utsswdjlEyURenL2SoIJIQ99Z0WrzPPv9Ye8Ogho8SDyt13gg+1Cpr7XoDd9+mAKZGYRO3O8AeEHgIECtyLXC0DR7D7cmSduoWSvKI9Z+IMa6QRuuQPXadgSaOxOhyZitmWG5u1kT7p8UYLXWYsFy5G5Zgz0TSXLXjpm7kPrOuaRSSmdAZOboaoFYJLCwxUAcuDE828y1dqkvRFTEfQldyO6+lFIWCrJ0KeazC8m7890ybLtCgYt6rVGSpr5T7gatuvdAMCP44ThjmYubN05GcYWQwLx5/9VaIWYIUTDPBSmkBwCJH1VvD1N6EEKMEctpUrHStNqpboSWrLXtOUCTHuyPx7ag9+UrRIlY6tKsFbQ8AEAAPIrAQoAI2dq+e3NJgMGbZQURVSKpRJSJKAKSmbEIceduUVWTwxOBI3MI7iQAqO97CiH4+qEhhFqsFBHJ1ErJ4oRFYsgcaEkplnHbl2HsS9fFSkEqx2AxRiUig1aTJPBaPHL0/b4xnbTUZihQK4TiQwVWSkE4sWLNkYLA+LWNHRwgWy012EAS8P8HdkNi0DgnylcAAAAASUVORK5CYII=';

// ============================================================================
// KAGE-ANA v0.4 (Tahap 3): Sculpted 3D Engine, Time-of-Day & Full Audio Synth
// ============================================================================

const TIME_PRESETS = {
  PAGI: {
    id: 'PAGI',
    label: '🌅 Pagi (06:30)',
    skyTop: '#1d2b44',
    skyMid: '#5c5268',
    skyBot: '#e09f67',
    groundTop: '#262d26',
    groundBot: '#151915',
    sunColor: '#ffdf9e',
    sunPitch: 0.22,
    sunYaw: 0.75,
    lightMult: 0.92,
    lanternGlow: false,
    visionMult: 0.90,
    ambientFreq: 520
  },
  SIANG: {
    id: 'SIANG',
    label: '☀️ Siang (12:00)',
    skyTop: '#1c4e80',
    skyMid: '#4682b4',
    skyBot: '#9bc4e2',
    groundTop: '#2e3829',
    groundBot: '#1b2218',
    sunColor: '#fffbe0',
    sunPitch: 0.65,
    sunYaw: 0.15,
    lightMult: 1.12,
    lanternGlow: false,
    visionMult: 1.15,
    ambientFreq: 660
  },
  SORE: {
    id: 'SORE',
    label: '🌇 Sore (17:45)',
    skyTop: '#1a142e',
    skyMid: '#6e2534',
    skyBot: '#d96b38',
    groundTop: '#291f1e',
    groundBot: '#141012',
    sunColor: '#ff7733',
    sunPitch: 0.14,
    sunYaw: -0.85,
    lightMult: 0.82,
    lanternGlow: true,
    visionMult: 0.85,
    ambientFreq: 410
  },
  MALAM: {
    id: 'MALAM',
    label: '🌙 Malam (23:00)',
    skyTop: '#040711',
    skyMid: '#0b1326',
    skyBot: '#162238',
    groundTop: '#11151c',
    groundBot: '#090b10',
    sunColor: '#dce8ff',
    sunPitch: 0.48,
    sunYaw: -0.35,
    lightMult: 0.58,
    lanternGlow: true,
    visionMult: 0.60,
    ambientFreq: 290
  }
};

const KageAudio = {
  ctx: null,
  muted: false,
  stepToggle: false,
  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      try { this.ctx.resume(); } catch (e) {}
    }
  },

  playTone(freq, type, duration, gainVal = 0.12, slideFreq = null) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = type;
      osc.frequency.setValueAtTime(freq, now);
      if (slideFreq) {
        osc.frequency.exponentialRampToValueAtTime(Math.max(20, slideFreq), now + duration);
      }
      gain.gain.setValueAtTime(gainVal, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + duration);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + duration);
    } catch (e) {}
  },

  playStep(surface, isSprinting = false, isCrouching = false) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;
    try {
      const now = this.ctx.currentTime;
      this.stepToggle = !this.stepToggle;
      const footPitchShift = this.stepToggle ? 1.0 : 1.09;
      const volScale = isCrouching ? 0.35 : (isSprinting ? 1.25 : 0.85);

      const surfCfg = {
        Stone:    { tapFreq: 920, bodyFreq: 195, dur: 0.045 },
        Tatami:   { tapFreq: 520, bodyFreq: 115, dur: 0.040 },
        Wood:     { tapFreq: 740, bodyFreq: 155, dur: 0.050 },
        ClayTile: { tapFreq: 1150, bodyFreq: 260, dur: 0.045 },
        WetRoof:  { tapFreq: 1320, bodyFreq: 290, dur: 0.055 },
        Gravel:   { tapFreq: 1480, bodyFreq: 230, dur: 0.058 }
      }[surface] || { tapFreq: 860, bodyFreq: 180, dur: 0.045 };

      const oscTap = this.ctx.createOscillator();
      const gainTap = this.ctx.createGain();
      oscTap.type = 'triangle';
      oscTap.frequency.setValueAtTime(surfCfg.tapFreq * footPitchShift, now);
      oscTap.frequency.exponentialRampToValueAtTime(surfCfg.bodyFreq, now + surfCfg.dur);
      gainTap.gain.setValueAtTime(0.14 * volScale, now);
      gainTap.gain.exponentialRampToValueAtTime(0.001, now + surfCfg.dur);
      oscTap.connect(gainTap);
      gainTap.connect(this.ctx.destination);
      oscTap.start(now);
      oscTap.stop(now + surfCfg.dur);

      const oscToe = this.ctx.createOscillator();
      const gainToe = this.ctx.createGain();
      oscToe.type = 'sine';
      oscToe.frequency.setValueAtTime(surfCfg.bodyFreq * 1.4 * footPitchShift, now + 0.018);
      oscToe.frequency.exponentialRampToValueAtTime(65, now + 0.018 + surfCfg.dur);
      gainToe.gain.setValueAtTime(0.09 * volScale, now + 0.018);
      gainToe.gain.exponentialRampToValueAtTime(0.001, now + 0.018 + surfCfg.dur);
      oscToe.connect(gainToe);
      gainToe.connect(this.ctx.destination);
      oscToe.start(now + 0.018);
      oscToe.stop(now + 0.018 + surfCfg.dur);
    } catch (e) {}
  },

  playJump() { this.playTone(190, 'sine', 0.12, 0.12, 340); },
  playLand(surface) {
    this.playStep(surface, true, false);
    this.playTone(110, 'triangle', 0.09, 0.16, 48);
  },
  playSlash() {
    this.playTone(580, 'sawtooth', 0.11, 0.14, 110);
    this.playTone(920, 'sine', 0.08, 0.08, 240);
  },
  playPierce() { this.playTone(680, 'triangle', 0.16, 0.18, 70); },
  playKunai() { this.playTone(1250, 'sine', 0.09, 0.12, 380); },
  playChoke() {
    this.playTone(145, 'sine', 0.28, 0.18, 65);
    this.playTone(220, 'triangle', 0.18, 0.10, 95);
  },
  playBushHide() {
    this.playTone(420, 'triangle', 0.14, 0.11, 180);
    this.playTone(310, 'sine', 0.20, 0.09, 120);
  },
  playImpaleRip() {
    this.playTone(250, 'sawtooth', 0.24, 0.22, 52);
    this.playTone(420, 'triangle', 0.18, 0.15, 95);
  },
  playClash() {
    this.playTone(1580, 'square', 0.20, 0.18, 680);
    this.playTone(2380, 'sine', 0.28, 0.12, 960);
  },
  playSever() { this.playTone(195, 'sawtooth', 0.26, 0.24, 42); },
  playSlide() { this.playTone(240, 'sine', 0.22, 0.10, 85); },
  playSlipCrash() { this.playTone(330, 'sawtooth', 0.42, 0.22, 52); },
  playMissionSuccess() {
    this.playTone(440, 'sine', 0.25, 0.14, 554);
    setTimeout(() => this.playTone(659, 'sine', 0.45, 0.15, 880), 140);
  },
  playTimeBell(freq) {
    this.playTone(freq, 'sine', 0.55, 0.11, freq * 0.98);
    this.playTone(freq * 1.5, 'triangle', 0.35, 0.05, freq * 1.48);
  },
  playSnareTrap() {
    this.playTone(980, 'sawtooth', 0.16, 0.20, 140);
    this.playTone(320, 'square', 0.25, 0.16, 85);
  },
  playKaginawa() {
    this.playTone(420, 'sawtooth', 0.18, 0.15, 1380);
    this.playTone(880, 'triangle', 0.12, 0.12, 1760);
  },
  playInspectClue() {
    this.playTone(587.33, 'sine', 0.14, 0.10, 880);
  },
  playShrineRespawn() {
    this.playTone(220, 'sine', 0.85, 0.22, 216);
    this.playTone(330, 'triangle', 0.65, 0.12, 326);
  },
  // Stage 4: Procedural Feudal Japanese Pentatonic BGM (Hirajoshi Scale: Shamisen, Shakuhachi & Taiko)
  bgmEnabled: true,
  bgmTimer: null,
  bgmStep: 0,
  bgmCombatMode: false,
  hirajoshiNotes: [146.83, 164.81, 174.61, 220.00, 233.08, 293.66, 329.63, 349.23, 440.00],
  startBGM() {
    this.init();
    if (this.bgmTimer) return;
    const tick = () => {
      if (this.bgmEnabled && !this.muted && this.ctx) {
        const step = this.bgmStep++;
        const scale = this.hirajoshiNotes;
        if (this.bgmCombatMode) {
          // Intense Taiko War Drum + Fast Shamisen Pluck during Combat!
          if (step % 2 === 0) {
            this.playTone(62, 'triangle', 0.18, 0.16, 34); // Heavy Taiko Hit
          } else {
            this.playTone(110, 'sine', 0.09, 0.09, 55);   // Taiko Rim
          }
          const note = scale[(step * 3 + (step % 4)) % scale.length];
          this.playTone(note * 1.5, 'sawtooth', 0.14, 0.045, note * 1.48);
        } else {
          // Calm Atmospheric Koto/Shamisen & Shakuhachi Flute during Village Stealth
          if (step % 4 === 0) {
            this.playTone(55, 'sine', 0.32, 0.08, 38); // Soft distant Taiko heartbeat
          }
          if (step % 2 === 0) {
            const note = scale[(step + (step % 3)) % scale.length];
            this.playTone(note, 'triangle', 0.36, 0.045, note * 0.99);
          }
          if (step % 8 === 3) {
            const fluteNote = scale[(step % 5) + 3];
            this.playTone(fluteNote, 'sine', 0.65, 0.035, fluteNote * 1.02);
          }
        }
      }
      const interval = this.bgmCombatMode ? 210 : 380;
      this.bgmTimer = setTimeout(tick, interval);
    };
    tick();
  },
  toggleBGM() {
    this.init();
    this.bgmEnabled = !this.bgmEnabled;
    if (this.bgmEnabled && !this.bgmTimer) this.startBGM();
    return this.bgmEnabled;
  }
};

class Engine3D {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.fov = 75 * (Math.PI / 180);
    this.near = 0.15;
    this.far = 110.0;
    this.timeOfDay = TIME_PRESETS.SORE;
    this.resize();
    window.addEventListener('resize', () => this.resize());
  }

  resize() {
    this.canvas.width = window.innerWidth || 1280;
    this.canvas.height = window.innerHeight || 720;
    this.width = this.canvas.width;
    this.height = this.canvas.height;
    this.aspect = this.width / this.height;
    this.focal = 1.0 / Math.tan(this.fov * 0.5);
  }

  worldToCamera(pt, cam) {
    let dx = pt.x - cam.x;
    let dy = pt.y - cam.y;
    let dz = pt.z - cam.z;

    const cosY = Math.cos(cam.yaw);
    const sinY = Math.sin(cam.yaw);
    let x1 = dx * cosY - dz * sinY;
    let z1 = dx * sinY + dz * cosY;

    const cosP = Math.cos(cam.pitch);
    const sinP = Math.sin(cam.pitch);
    let y2 = dy * cosP - z1 * sinP;
    let z2 = dy * sinP + z1 * cosP;

    const cosR = Math.cos(cam.roll || 0);
    const sinR = Math.sin(cam.roll || 0);
    let x3 = x1 * cosR - y2 * sinR;
    let y3 = x1 * sinR + y2 * cosR;

    return { x: x3, y: y3, z: z2 };
  }

  projectPoint(camPt) {
    const safeZ = Math.max(0.05, camPt.z);
    const sx = (camPt.x * (this.focal / this.aspect)) / safeZ;
    const sy = (camPt.y * this.focal) / safeZ;
    return {
      x: (sx + 1) * 0.5 * this.width,
      y: (1 - sy) * 0.5 * this.height,
      z: safeZ
    };
  }

  clipPolygonNear(verts) {
    const out = [];
    for (let i = 0; i < verts.length; i++) {
      const a = verts[i];
      const b = verts[(i + 1) % verts.length];
      const aIn = a.z >= this.near;
      const bIn = b.z >= this.near;
      if (aIn && bIn) {
        out.push(b);
      } else if (aIn && !bIn) {
        const t = (this.near - a.z) / (b.z - a.z);
        out.push({
          x: a.x + t * (b.x - a.x),
          y: a.y + t * (b.y - a.y),
          z: this.near
        });
      } else if (!aIn && bIn) {
        const t = (this.near - a.z) / (b.z - a.z);
        out.push({
          x: a.x + t * (b.x - a.x),
          y: a.y + t * (b.y - a.y),
          z: this.near
        });
        out.push(b);
      }
    }
    return out;
  }

  transformLocalToWorld(p, cx, cy, cz, cosY, sinY, cosP, sinP, cosR, sinR) {
    const xR = p.x * cosR - p.y * sinR;
    const yR = p.x * sinR + p.y * cosR;
    const yP = yR * cosP - p.z * sinP;
    const zP = yR * sinP + p.z * cosP;
    const wx = xR * cosY + zP * sinY;
    const wz = -xR * sinY + zP * cosY;
    return { x: cx + wx, y: cy + yP, z: cz + wz };
  }

  createShapeFaces(item) {
    const cx = item.x, cy = item.y, cz = item.z;
    const hx = item.w * 0.5, hy = item.h * 0.5, hz = item.d * 0.5;
    const yaw = item.yaw || 0;
    const pitch = item.pitch || 0;
    const roll = item.roll || 0;

    const cosY = Math.cos(yaw), sinY = Math.sin(yaw);
    const cosP = Math.cos(pitch), sinP = Math.sin(pitch);
    const cosR = Math.cos(roll), sinR = Math.sin(roll);

    const shape = item.shape || 'box';

    if (shape === 'cylinder' || shape === 'cone') {
      const segs = item.segs || 8;
      const topScale = shape === 'cone' ? (item.topScale !== undefined ? item.topScale : 0.08) : (item.topScale !== undefined ? item.topScale : 0.88);
      const botScale = item.botScale !== undefined ? item.botScale : 1.0;

      const botRing = [];
      const topRing = [];
      for (let i = 0; i < segs; i++) {
        const ang = (i / segs) * Math.PI * 2;
        const ca = Math.cos(ang), sa = Math.sin(ang);
        botRing.push(this.transformLocalToWorld(
          { x: ca * hx * botScale, y: -hy, z: sa * hz * botScale },
          cx, cy, cz, cosY, sinY, cosP, sinP, cosR, sinR
        ));
        topRing.push(this.transformLocalToWorld(
          { x: ca * hx * topScale, y: hy, z: sa * hz * topScale },
          cx, cy, cz, cosY, sinY, cosP, sinP, cosR, sinR
        ));
      }

      const faces = [];
      for (let i = 0; i < segs; i++) {
        const next = (i + 1) % segs;
        const shade = 0.72 + 0.34 * (0.5 + 0.5 * Math.cos((i / segs) * Math.PI * 2 - 0.6));
        faces.push({
          verts: [botRing[i], botRing[next], topRing[next], topRing[i]],
          color: item.color,
          shade,
          stroke: null,
          emissive: !!item.emissive
        });
      }
      faces.push({
        verts: topRing,
        color: item.color,
        shade: 1.08,
        stroke: null,
        emissive: !!item.emissive
      });
      return faces;
    }

    const localPts = [
      { x: -hx, y: -hy, z: -hz },
      { x:  hx, y: -hy, z: -hz },
      { x:  hx, y:  hy, z: -hz },
      { x: -hx, y:  hy, z: -hz },
      { x: -hx, y: -hy, z:  hz },
      { x:  hx, y: -hy, z:  hz },
      { x:  hx, y:  hy, z:  hz },
      { x: -hx, y:  hy, z:  hz }
    ];

    const worldPts = localPts.map(p =>
      this.transformLocalToWorld(p, cx, cy, cz, cosY, sinY, cosP, sinP, cosR, sinR)
    );

    const indices = [
      { idx: [0, 1, 2, 3], shade: 0.90 },
      { idx: [5, 4, 7, 6], shade: 0.82 },
      { idx: [4, 0, 3, 7], shade: 0.75 },
      { idx: [1, 5, 6, 2], shade: 0.95 },
      { idx: [3, 2, 6, 7], shade: 1.06 },
      { idx: [4, 5, 1, 0], shade: 0.55 }
    ];

    return indices.map(f => ({
      verts: f.idx.map(i => worldPts[i]),
      color: item.color,
      shade: f.shade,
      stroke: item.stroke || null,
      emissive: !!item.emissive
    }));
  }

  shadeHex(hex, factor) {
    const clean = (hex || '#888888').replace('#', '');
    const num = parseInt(clean, 16);
    let r = Math.min(255, Math.max(0, Math.round(((num >> 16) & 255) * factor)));
    let g = Math.min(255, Math.max(0, Math.round(((num >> 8) & 255) * factor)));
    let b = Math.min(255, Math.max(0, Math.round((num & 255) * factor)));
    return `rgb(${r},${g},${b})`;
  }

  renderScene(cam, shapes, billboards) {
    const ctx = this.ctx;
    const tod = this.timeOfDay || TIME_PRESETS.SORE;
    const horizonY = Math.max(0, Math.min(this.height, this.height * (0.5 + Math.tan(cam.pitch) * 0.42)));

    const skyGrad = ctx.createLinearGradient(0, 0, 0, Math.max(10, horizonY));
    skyGrad.addColorStop(0, tod.skyTop);
    skyGrad.addColorStop(0.55, tod.skyMid);
    skyGrad.addColorStop(1, tod.skyBot);
    ctx.fillStyle = skyGrad;
    ctx.fillRect(0, 0, this.width, horizonY);

    const sunDir = {
      x: cam.x + Math.sin(tod.sunYaw) * 60,
      y: cam.y + Math.sin(tod.sunPitch) * 60,
      z: cam.z + Math.cos(tod.sunYaw) * 60
    };
    const sunCam = this.worldToCamera(sunDir, cam);
    if (sunCam.z > 1.0) {
      const sunScreen = this.projectPoint(sunCam);
      if (sunScreen.y < horizonY + 40) {
        const rad = tod.id === 'MALAM' ? 28 : 42;
        const glow = ctx.createRadialGradient(sunScreen.x, sunScreen.y, 4, sunScreen.x, sunScreen.y, rad * 2.5);
        glow.addColorStop(0, tod.sunColor);
        glow.addColorStop(0.4, tod.sunColor + '66');
        glow.addColorStop(1, 'transparent');
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(sunScreen.x, sunScreen.y, rad * 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    ctx.fillStyle = tod.id === 'SIANG' ? '#243a4c' : (tod.id === 'MALAM' ? '#080d18' : '#1f1924');
    ctx.beginPath();
    ctx.moveTo(0, horizonY);
    for (let mx = 0; mx <= this.width; mx += 60) {
      const worldAngle = cam.yaw + (mx / this.width - 0.5) * this.fov;
      const mHeight = Math.sin(worldAngle * 3.0) * 28 + Math.cos(worldAngle * 7.0) * 14 + 34;
      ctx.lineTo(mx, horizonY - mHeight);
    }
    ctx.lineTo(this.width, horizonY);
    ctx.closePath();
    ctx.fill();

    const groundGrad = ctx.createLinearGradient(0, horizonY, 0, this.height);
    groundGrad.addColorStop(0, tod.groundTop);
    groundGrad.addColorStop(1, tod.groundBot);
    ctx.fillStyle = groundGrad;
    ctx.fillRect(0, horizonY, this.width, this.height - horizonY);

    const renderList = [];

    for (let i = 0; i < shapes.length; i++) {
      const s = shapes[i];
      const dx = s.x - cam.x, dz = s.z - cam.z;
      if (dx * dx + dz * dz > this.far * this.far) continue;

      // HD V-Ray Humanoid Primitives (Zero faceted polygon edges!)
      if (s.shape === 'hd_shadow') {
        const camPt = this.worldToCamera(s, cam);
        if (camPt.z > this.near && camPt.z < this.far) {
          const proj = this.projectPoint(camPt);
          const radX = Math.max(4, (s.w * 0.5 * (this.focal / this.aspect) * this.width * 0.5) / proj.z);
          const radY = Math.max(2, radX * 0.38);
          renderList.push({
            type: 'hd_shadow',
            depth: Math.hypot(camPt.x, camPt.y, camPt.z) + 0.35,
            x: proj.x, y: proj.y, radX, radY
          });
        }
        continue;
      }

      if (s.shape === 'hd_capsule') {
        const c1 = this.worldToCamera(s.p1, cam);
        const c2 = this.worldToCamera(s.p2, cam);
        if (c1.z <= this.near && c2.z <= this.near) continue;
        const sc1 = this.projectPoint({ x: c1.x, y: c1.y, z: Math.max(this.near, c1.z) });
        const sc2 = this.projectPoint({ x: c2.x, y: c2.y, z: Math.max(this.near, c2.z) });
        const scale1 = (this.focal * this.height * 0.5) / sc1.z;
        const scale2 = (this.focal * this.height * 0.5) / sc2.z;
        const r1 = Math.max(1.8, s.r1 * scale1);
        const r2 = Math.max(1.5, s.r2 * scale2);
        const mx = (c1.x + c2.x) * 0.5, my = (c1.y + c2.y) * 0.5, mz = (c1.z + c2.z) * 0.5;
        const trueDist = Math.hypot(mx, my, mz);
        const distFactor = Math.max(0.28, 1.0 - (mz / this.far) * 0.72) * tod.lightMult;
        renderList.push({
          type: 'hd_capsule',
          depth: trueDist + (s.depthBias || 0),
          x1: sc1.x, y1: sc1.y, r1,
          x2: sc2.x, y2: sc2.y, r2,
          color: s.color,
          material: s.material || 'cloth',
          trimColor: s.trimColor || null,
          light: distFactor
        });
        continue;
      }

      if (s.shape === 'hd_torso') {
        const cTop = this.worldToCamera(s.pTop, cam);
        const cWaist = this.worldToCamera(s.pWaist, cam);
        const cHip = this.worldToCamera(s.pHip, cam);
        if (cTop.z <= this.near || cHip.z <= this.near) continue;
        const sTop = this.projectPoint(cTop);
        const sWaist = this.projectPoint(cWaist);
        const sHip = this.projectPoint(cHip);
        const scaleTop = (this.focal * this.height * 0.5) / sTop.z;
        const scaleWaist = (this.focal * this.height * 0.5) / sWaist.z;
        const scaleHip = (this.focal * this.height * 0.5) / sHip.z;
        const trueDist = Math.hypot(cWaist.x, cWaist.y, cWaist.z);
        const distFactor = Math.max(0.28, 1.0 - (cWaist.z / this.far) * 0.72) * tod.lightMult;
        renderList.push({
          type: 'hd_torso',
          depth: trueDist - 0.08,
          sTop, sWaist, sHip,
          wShoulder: Math.max(4, s.wShoulder * scaleTop),
          wWaist: Math.max(3.5, s.wWaist * scaleWaist),
          wHip: Math.max(4, s.wHip * scaleHip),
          coatColor: s.coatColor,
          innerColor: s.innerColor || '#f2ece1',
          trimColor: s.trimColor || '#e6d2b5',
          obiColor: s.obiColor || '#c4a462',
          isFemaleStyle: !!s.isFemaleStyle,
          light: distFactor
        });
        continue;
      }

      if (s.shape === 'hd_head') {
        const cHead = this.worldToCamera(s, cam);
        if (cHead.z <= this.near || cHead.z > this.far) continue;
        const sHead = this.projectPoint(cHead);
        const scaleH = (this.focal * this.height * 0.5) / sHead.z;
        const rx = Math.max(3.5, s.w * 0.5 * scaleH);
        const ry = Math.max(4.2, s.h * 0.5 * scaleH);
        const trueDist = Math.hypot(cHead.x, cHead.y, cHead.z);
        const distFactor = Math.max(0.32, 1.0 - (cHead.z / this.far) * 0.70) * tod.lightMult;
        // Relative angle between character facing direction and camera view
        const npcToCamYaw = Math.atan2(cam.x - s.x, cam.z - s.z);
        const relYaw = Math.atan2(Math.sin(s.yaw - npcToCamYaw), Math.cos(s.yaw - npcToCamYaw));
        renderList.push({
          type: 'hd_head',
          depth: trueDist - 0.16,
          x: sHead.x, y: sHead.y, rx, ry,
          relYaw,
          hairColor: s.hairColor || '#2b1d16',
          hairStyle: s.hairStyle || 'AYA_BOB',
          hatStyle: s.hatStyle || 'NONE',
          hatColor: s.hatColor || '#c8a86b',
          hasMustache: !!s.hasMustache,
          hasMask: !!s.hasMask,
          maskColor: s.maskColor || '#181c26',
          light: distFactor
        });
        continue;
      }

      const faces = this.createShapeFaces(s);
      for (let f = 0; f < faces.length; f++) {
        const camVerts = faces[f].verts.map(v => this.worldToCamera(v, cam));
        const clipped = this.clipPolygonNear(camVerts);
        if (clipped.length < 3) continue;

        let avgZ = 0, avgX = 0, avgY = 0;
        const screenPts = [];
        for (let k = 0; k < clipped.length; k++) {
          avgZ += clipped[k].z;
          avgX += clipped[k].x;
          avgY += clipped[k].y;
          screenPts.push(this.projectPoint(clipped[k]));
        }
        avgZ /= clipped.length;
        avgX /= clipped.length;
        avgY /= clipped.length;
        const trueDist = Math.hypot(avgX, avgY, avgZ);

        const distFactor = Math.max(0.22, 1.0 - (avgZ / this.far) * 0.78);
        const light = faces[f].emissive ? 1.38 : (faces[f].shade * distFactor * tod.lightMult);
        renderList.push({
          type: 'poly',
          depth: trueDist,
          pts: screenPts,
          fill: this.shadeHex(faces[f].color, light),
          stroke: faces[f].stroke
        });
      }
    }

    for (let i = 0; i < billboards.length; i++) {
      const bb = billboards[i];
      const camPt = this.worldToCamera(bb, cam);
      if (camPt.z <= this.near || camPt.z > this.far) continue;
      const proj = this.projectPoint(camPt);
      if (proj) {
        const trueDist = Math.hypot(camPt.x, camPt.y, camPt.z);
        renderList.push({
          type: 'label',
          depth: trueDist - 0.3,
          distMeters: trueDist,
          x: proj.x,
          y: proj.y,
          text: bb.text,
          subtext: bb.subtext || '',
          color: bb.color || '#ffffff',
          isStoryBeacon: !!bb.isStoryBeacon
        });
      }
    }

    renderList.sort((a, b) => b.depth - a.depth);

    for (let i = 0; i < renderList.length; i++) {
      const item = renderList[i];
      if (item.type === 'hd_shadow') {
        ctx.save();
        ctx.translate(item.x, item.y);
        ctx.scale(1, item.radY / Math.max(1, item.radX));
        const shGrad = ctx.createRadialGradient(0, 0, item.radX * 0.1, 0, 0, item.radX);
        shGrad.addColorStop(0, 'rgba(0, 0, 0, 0.46)');
        shGrad.addColorStop(0.55, 'rgba(0, 0, 0, 0.20)');
        shGrad.addColorStop(1, 'rgba(0, 0, 0, 0.0)');
        ctx.fillStyle = shGrad;
        ctx.beginPath();
        ctx.arc(0, 0, item.radX, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else if (item.type === 'hd_capsule') {
        const dx = item.x2 - item.x1;
        const dy = item.y2 - item.y1;
        const len = Math.hypot(dx, dy) || 1;
        const nx = -dy / len;
        const ny = dx / len;
        const rAvg = (item.r1 + item.r2) * 0.5;
        const midX = (item.x1 + item.x2) * 0.5;
        const midY = (item.y1 + item.y2) * 0.5;

        const grad = ctx.createLinearGradient(
          midX - nx * rAvg, midY - ny * rAvg,
          midX + nx * rAvg, midY + ny * rAvg
        );
        if (item.material === 'skin') {
          // Photorealistic V-Ray Subsurface Scattering Skin Shader (Matching 091_W_Aya)
          grad.addColorStop(0.00, this.shadeHex('#fae5d7', item.light * 1.06));
          grad.addColorStop(0.28, this.shadeHex('#f3cbb4', item.light * 1.04));
          grad.addColorStop(0.62, this.shadeHex('#dfa88c', item.light * 0.96));
          grad.addColorStop(0.88, this.shadeHex('#be856a', item.light * 0.85));
          grad.addColorStop(1.00, this.shadeHex('#d19a80', item.light * 0.92));
        } else {
          // Smooth V-Ray Fabric / Silk / Armor Cylindrical Shader
          grad.addColorStop(0.00, this.shadeHex(item.color, item.light * 1.12));
          grad.addColorStop(0.26, this.shadeHex(item.color, item.light * 1.28));
          grad.addColorStop(0.64, this.shadeHex(item.color, item.light * 0.96));
          grad.addColorStop(0.90, this.shadeHex(item.color, item.light * 0.58));
          grad.addColorStop(1.00, this.shadeHex(item.color, item.light * 0.72));
        }

        const ang = Math.atan2(dy, dx);
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(item.x1, item.y1, item.r1, ang + Math.PI * 0.5, ang + Math.PI * 1.5);
        ctx.arc(item.x2, item.y2, item.r2, ang - Math.PI * 0.5, ang + Math.PI * 0.5);
        ctx.closePath();
        ctx.fill();

        // Optional cuff / ankle trim ring
        if (item.trimColor && item.r2 > 2.5) {
          ctx.strokeStyle = this.shadeHex(item.trimColor, item.light * 1.08);
          ctx.lineWidth = Math.max(1.2, item.r2 * 0.32);
          ctx.beginPath();
          ctx.moveTo(item.x2 - nx * item.r2 * 0.9, item.y2 - ny * item.r2 * 0.9);
          ctx.lineTo(item.x2 + nx * item.r2 * 0.9, item.y2 + ny * item.r2 * 0.9);
          ctx.stroke();
        }
      } else if (item.type === 'hd_torso') {
        const { sTop, sWaist, sHip, wShoulder, wWaist, wHip, coatColor, innerColor, trimColor, obiColor, isFemaleStyle, light } = item;

        // 1. Contoured Upper Torso Jacket / Cardigan / Haori with V-Ray smooth gradient
        const torsoGrad = ctx.createLinearGradient(sWaist.x - wShoulder, sWaist.y, sWaist.x + wShoulder, sWaist.y);
        torsoGrad.addColorStop(0.00, this.shadeHex(coatColor, light * 1.10));
        torsoGrad.addColorStop(0.28, this.shadeHex(coatColor, light * 1.28));
        torsoGrad.addColorStop(0.65, this.shadeHex(coatColor, light * 0.95));
        torsoGrad.addColorStop(1.00, this.shadeHex(coatColor, light * 0.58));

        ctx.fillStyle = torsoGrad;
        ctx.beginPath();
        ctx.moveTo(sTop.x - wShoulder, sTop.y);
        ctx.quadraticCurveTo(sTop.x, sTop.y - wShoulder * 0.18, sTop.x + wShoulder, sTop.y);
        ctx.quadraticCurveTo(sWaist.x + wWaist * 1.05, (sTop.y + sWaist.y) * 0.5, sWaist.x + wWaist, sWaist.y);
        ctx.lineTo(sHip.x + wHip, sHip.y);
        ctx.quadraticCurveTo(sHip.x, sHip.y + wHip * 0.16, sHip.x - wHip, sHip.y);
        ctx.lineTo(sWaist.x - wWaist, sWaist.y);
        ctx.quadraticCurveTo(sWaist.x - wWaist * 1.05, (sTop.y + sWaist.y) * 0.5, sTop.x - wShoulder, sTop.y);
        ctx.closePath();
        ctx.fill();

        // 2. Inner Dress / Kosode & Exposed Subsurface Skin Collarbone (091_W_Aya style!)
        if (wShoulder > 5) {
          // Inner floral/silk dress panel
          ctx.fillStyle = this.shadeHex(innerColor, light * 1.08);
          ctx.beginPath();
          ctx.moveTo(sTop.x - wShoulder * 0.42, sTop.y + 1);
          ctx.lineTo(sTop.x + wShoulder * 0.42, sTop.y + 1);
          ctx.lineTo(sHip.x + wHip * (isFemaleStyle ? 0.82 : 0.25), sHip.y);
          ctx.lineTo(sHip.x - wHip * (isFemaleStyle ? 0.82 : 0.25), sHip.y);
          ctx.closePath();
          ctx.fill();

          // Subsurface Skin Chest / Collarbone neckline
          ctx.fillStyle = this.shadeHex('#f3cbb4', light * 1.05);
          ctx.beginPath();
          ctx.arc(sTop.x, sTop.y + wShoulder * 0.12, wShoulder * 0.34, 0, Math.PI);
          ctx.fill();

          // Cardigan / Haori Lapel Trim Borders
          ctx.strokeStyle = this.shadeHex(trimColor, light * 1.15);
          ctx.lineWidth = Math.max(1.2, wShoulder * 0.11);
          ctx.beginPath();
          ctx.moveTo(sTop.x - wShoulder * 0.42, sTop.y);
          ctx.lineTo(sWaist.x - wWaist * 0.36, sWaist.y);
          ctx.moveTo(sTop.x + wShoulder * 0.42, sTop.y);
          ctx.lineTo(sWaist.x + wWaist * 0.36, sWaist.y);
          ctx.stroke();

          // Obi Belt / Waist Sash & Pleat Folds
          ctx.fillStyle = this.shadeHex(obiColor, light * 1.05);
          ctx.fillRect(sWaist.x - wWaist * 0.92, sWaist.y - wWaist * 0.16, wWaist * 1.84, wWaist * 0.32);

          // Soft vertical drapery folds on skirt/hakama
          ctx.strokeStyle = 'rgba(0, 0, 0, 0.18)';
          ctx.lineWidth = Math.max(0.8, wHip * 0.06);
          for (let f = -0.5; f <= 0.5; f += 0.5) {
            ctx.beginPath();
            ctx.moveTo(sWaist.x + wWaist * f * 0.7, sWaist.y + 2);
            ctx.lineTo(sHip.x + wHip * f * 0.85, sHip.y - 2);
            ctx.stroke();
          }
        }
      } else if (item.type === 'hd_head') {
        const { x, y, rx, ry, relYaw, hairColor, hairStyle, hatStyle, hatColor, hasMustache, hasMask, maskColor, light } = item;
        const isFacingCam = Math.cos(relYaw) > -0.82;
        const yawShiftX = Math.sin(relYaw) * rx * 0.28;

        // 1. Back/Side 3D Hair Volume (Silky Bob / Long Hair framing neck like 091_W_Aya)
        ctx.fillStyle = this.shadeHex(hairColor, light * 0.85);
        ctx.beginPath();
        ctx.ellipse(x, y + ry * 0.10, rx * 1.18, ry * 1.16, 0, 0, Math.PI * 2);
        ctx.fill();

        // 2. Smooth 3D Subsurface Skin Head Oval & Jawline
        const skinGrad = ctx.createRadialGradient(x - rx * 0.25, y - ry * 0.2, rx * 0.15, x, y, ry * 1.05);
        skinGrad.addColorStop(0.0, this.shadeHex('#fde8dc', light * 1.08));
        skinGrad.addColorStop(0.55, this.shadeHex('#f1c6ae', light * 1.0));
        skinGrad.addColorStop(1.0, this.shadeHex('#b88268', light * 0.86));
        ctx.fillStyle = skinGrad;
        ctx.beginPath();
        ctx.ellipse(x + yawShiftX * 0.2, y + ry * 0.04, rx * 0.94, ry * 1.0, 0, 0, Math.PI * 2);
        ctx.fill();

        // 3. Map Real Photorealistic 091_W_Aya Face Texture (includes realistic eyes, eyebrows, nose, lips & hair bangs!)
        if (isFacingCam && AYA_FACE_IMAGE.complete && AYA_FACE_IMAGE.naturalWidth > 0 && rx > 4.0) {
          ctx.save();
          ctx.beginPath();
          ctx.ellipse(x + yawShiftX * 0.2, y + ry * 0.02, rx * 1.02, ry * 1.06, 0, 0, Math.PI * 2);
          ctx.clip();
          ctx.drawImage(
            AYA_FACE_IMAGE,
            x + yawShiftX * 0.22 - rx * 1.08,
            y - ry * 1.08,
            rx * 2.16,
            ry * 2.18
          );
          ctx.restore();
        }

        // 4. Role-Specific Facial Overlays (Mustache/Goatee for Samurai/Bosses, Menpo Mask for Shinobi/Avengers)
        if (isFacingCam && rx > 5.0) {
          const fx = x + yawShiftX * 0.28;
          const eyeSpan = rx * 0.36;
          if (hasMask) {
            ctx.fillStyle = this.shadeHex(maskColor, light * 0.95);
            ctx.beginPath();
            ctx.ellipse(fx, y + ry * 0.36, rx * 0.88, ry * 0.54, 0, 0, Math.PI);
            ctx.fill();
          } else if (hasMustache) {
            ctx.strokeStyle = this.shadeHex('#241c18', light);
            ctx.lineWidth = Math.max(1.2, rx * 0.14);
            ctx.beginPath();
            ctx.moveTo(fx - eyeSpan * 0.85, y + ry * 0.36);
            ctx.quadraticCurveTo(fx, y + ry * 0.24, fx + eyeSpan * 0.85, y + ry * 0.36);
            ctx.stroke();
          }
        }

        // 6. Optional Feudal Headgear (Kasa Straw Hat or Ornate Samurai Kabuto)
        if (hatStyle === 'KABUTO_GOLD') {
          ctx.fillStyle = this.shadeHex('#1c1917', light * 1.05);
          ctx.beginPath();
          ctx.ellipse(x, y - ry * 0.55, rx * 1.45, ry * 0.55, 0, Math.PI, Math.PI * 2);
          ctx.fill();
          // Gold Maedate Crest
          ctx.strokeStyle = '#ffd54f';
          ctx.lineWidth = Math.max(1.5, rx * 0.18);
          ctx.beginPath();
          ctx.arc(x + yawShiftX * 0.3, y - ry * 0.78, rx * 0.55, Math.PI * 0.15, Math.PI * 0.85);
          ctx.stroke();
        } else if (hatStyle === 'KASA' || hatStyle === 'JINGASA') {
          const brimGrad = ctx.createLinearGradient(x - rx * 2, y - ry, x + rx * 2, y - ry * 0.4);
          brimGrad.addColorStop(0, this.shadeHex(hatColor, light * 1.15));
          brimGrad.addColorStop(0.5, this.shadeHex(hatColor, light * 0.95));
          brimGrad.addColorStop(1, this.shadeHex(hatColor, light * 0.65));
          ctx.fillStyle = brimGrad;
          ctx.beginPath();
          ctx.moveTo(x - rx * 2.05, y - ry * 0.38);
          ctx.quadraticCurveTo(x, y - ry * 1.55, x + rx * 2.05, y - ry * 0.38);
          ctx.quadraticCurveTo(x, y - ry * 0.18, x - rx * 2.05, y - ry * 0.38);
          ctx.closePath();
          ctx.fill();
        }
      } else if (item.type === 'poly' && item.pts.length >= 3) {
        ctx.beginPath();
        ctx.moveTo(item.pts[0].x, item.pts[0].y);
        for (let k = 1; k < item.pts.length; k++) {
          ctx.lineTo(item.pts[k].x, item.pts[k].y);
        }
        ctx.closePath();
        ctx.fillStyle = item.fill;
        ctx.fill();
        if (item.stroke) {
          ctx.strokeStyle = item.stroke;
          ctx.lineWidth = 0.6;
          ctx.stroke();
        }
      } else if (item.type === 'label') {
        const scale = Math.max(0.72, Math.min(1.35, 11.0 / Math.max(3.5, item.distMeters)));
        const boxW = Math.round((item.isStoryBeacon ? 245 : 218) * scale);
        const boxH = Math.round((item.subtext ? 34 : 20) * scale);
        ctx.fillStyle = item.isStoryBeacon ? 'rgba(38, 12, 12, 0.86)' : 'rgba(8, 10, 15, 0.78)';
        ctx.fillRect(item.x - boxW * 0.5, item.y - boxH, boxW, boxH);
        ctx.strokeStyle = item.isStoryBeacon ? '#ffd54f' : 'rgba(196, 164, 98, 0.45)';
        ctx.lineWidth = item.isStoryBeacon ? 1.5 : 1;
        ctx.strokeRect(item.x - boxW * 0.5, item.y - boxH, boxW, boxH);

        ctx.font = `bold ${Math.round(11.5 * scale)}px Segoe UI`;
        ctx.textAlign = 'center';
        ctx.fillStyle = item.color;
        ctx.fillText(item.text, item.x, item.y - (item.subtext ? boxH * 0.52 : boxH * 0.28));
        if (item.subtext) {
          ctx.font = `${Math.round(10 * scale)}px Segoe UI`;
          ctx.fillStyle = '#ddd';
          ctx.fillText(item.subtext, item.x, item.y - boxH * 0.16);
        }
      }
    }
  }

  static raycastAABB(origin, dir, box, maxDist) {
    const pad = 0.09;
    const minX = box.x - box.w * 0.5 - pad, maxX = box.x + box.w * 0.5 + pad;
    const minY = box.y - box.h * 0.5 - pad, maxY = box.y + box.h * 0.5 + pad;
    const minZ = box.z - box.d * 0.5 - pad, maxZ = box.z + box.d * 0.5 + pad;

    let tmin = (minX - origin.x) / (dir.x || 1e-6);
    let tmax = (maxX - origin.x) / (dir.x || 1e-6);
    if (tmin > tmax) [tmin, tmax] = [tmax, tmin];

    let tymin = (minY - origin.y) / (dir.y || 1e-6);
    let tymax = (maxY - origin.y) / (dir.y || 1e-6);
    if (tymin > tymax) [tymin, tymax] = [tymax, tymin];

    if ((tmin > tymax) || (tymin > tmax)) return null;
    if (tymin > tmin) tmin = tymin;
    if (tymax < tmax) tmax = tymax;

    let tzmin = (minZ - origin.z) / (dir.z || 1e-6);
    let tzmax = (maxZ - origin.z) / (dir.z || 1e-6);
    if (tzmin > tzmax) [tzmin, tzmax] = [tzmax, tzmin];

    if ((tmin > tzmax) || (tzmin > tmax)) return null;
    if (tzmin > tmin) tmin = tzmin;
    if (tzmax < tmax) tmax = tzmax;

    if (tmin < 0 || tmin > maxDist) return null;
    return {
      distance: tmin,
      point: {
        x: origin.x + dir.x * tmin,
        y: origin.y + dir.y * tmin,
        z: origin.z + dir.z * tmin
      }
    };
  }
}
