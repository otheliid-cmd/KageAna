// ============================================================================
// KAGE-ANA v0.4 (Tahap 3): Expanded Village Locomotion, Bush Stealth & Body Carry
// ============================================================================

class ParkourPhysicsController {
  constructor() {
    this.x = 0;
    this.y = 1.68;
    this.z = -24; // Starts at South Kurokawa Safehouse Pier looking toward the village!
    this.vx = 0;
    this.vy = 0;
    this.vz = 0;

    this.yaw = 0;
    this.pitch = 0;
    this.roll = 0;
    this.peekOffset = 0;

    this.cameraMode = 'FIRST_PERSON';
    this.thirdPersonDistance = 3.35;
    this.sprintToggleLock = false;

    this.isGrounded = true;
    this.isCrouching = false;
    this.isSprinting = false;
    this.isSliding = false;
    this.slideTimer = 0;
    this.isStumbled = false;
    this.stumbleTimer = 0;
    this.isHiddenInBush = false;
    this.carryingBodyNpc = null;
    this.immobilizedTimer = 0; // Stage 4: Locked in place by enemy Torinawa Net / Kusarigama Chain!
    this.immobilizedReason = '';
    this.grappleCooldown = 0;
    this.activeGrappleLine = null;

    this.gripStamina = 100;
    this.maxGripStamina = 100;
    this.currentSurface = 'Wood';
    this.currentSlope = 0;
    this.currentNoiseDb = 4;

    this.leftLegCrippled = false;
    this.rightLegCrippled = false;
    this.leftArmSevered = false;
    this.rightArmSevered = false;

    this.stepPhase = 0;
    this.lastStepHalfCycle = 0;
    this.animTime = 0;
  }

  toggleCameraMode() {
    this.cameraMode = this.cameraMode === 'FIRST_PERSON' ? 'THIRD_PERSON' : 'FIRST_PERSON';
    return this.cameraMode;
  }

  applyImmobilize(duration, reason) {
    this.immobilizedTimer = Math.max(this.immobilizedTimer, duration);
    this.immobilizedReason = reason || 'Terikat Jaring Pemberat (Torinawa)!';
    this.vx = 0;
    this.vz = 0;
    KageAudio.playSnareTrap();
  }

  struggleBreakFree() {
    if (this.immobilizedTimer > 0) {
      this.immobilizedTimer = Math.max(0, this.immobilizedTimer - 0.65);
      KageAudio.playStep('Gravel', true, false);
      return this.immobilizedTimer <= 0;
    }
    return false;
  }

  launchKaginawaGrapple(structures, onToast) {
    if (this.grappleCooldown > 0) {
      onToast(`Kaginawa sedang digulung ulang (${this.grappleCooldown.toFixed(1)}dtk)!`);
      return false;
    }
    const fwd = this.getForwardVector();
    let bestRoof = null;
    let bestDist = 26.0;
    for (let i = 0; i < structures.length; i++) {
      const s = structures[i];
      if (!s.walkable || (s.y + s.h * 0.5) < 1.8) continue;
      const dx = s.x - this.x;
      const dz = s.z - this.z;
      const d = Math.hypot(dx, dz);
      if (d > 2.0 && d < bestDist) {
        const dot = (dx / d) * fwd.x + (dz / d) * fwd.z;
        if (dot > 0.35) {
          bestDist = d;
          bestRoof = s;
        }
      }
    }
    if (bestRoof) {
      const topY = bestRoof.y + bestRoof.h * 0.5;
      this.activeGrappleLine = {
        x1: this.x, y1: this.y, z1: this.z,
        x2: bestRoof.x, y2: topY, z2: bestRoof.z,
        timer: 0.35
      };
      this.x = bestRoof.x;
      this.y = topY + 1.68;
      this.z = bestRoof.z;
      this.vy = 2.5;
      this.immobilizedTimer = 0;
      this.grappleCooldown = 1.8;
      KageAudio.playKaginawa();
      onToast(`🪝 KAGINAWA GRAPPLING HOOK! Kamu melesat ke atas atap (${topY.toFixed(1)}m) & melepaskan diri dari kepungan musuh!`);
      return true;
    }
    onToast('Kaginawa [L]: Arahkan pandangan ke atap rumah, menara, gerbang Torii, atau Kuil (< 26m) untuk melesat naik!');
    return false;
  }

  getCameraState() {
    let eyeHeight = 1.68;
    if (this.isSliding) eyeHeight = 0.78;
    else if (this.isCrouching) eyeHeight = 1.08;

    const planarSpeed = Math.hypot(this.vx, this.vz);
    const speedNorm = Math.min(1.0, planarSpeed / 9.5);

    const forwardSurge = Math.sin(this.stepPhase * 2.0) * 0.040 * speedNorm;
    const microVertical = Math.sin(this.stepPhase * 2.0) * 0.007 * speedNorm;
    const microPitchNod = Math.sin(this.stepPhase * 2.0) * 0.004 * speedNorm;

    const fwdX = Math.sin(this.yaw);
    const fwdZ = Math.cos(this.yaw);
    const rightX = Math.cos(this.yaw);
    const rightZ = -Math.sin(this.yaw);

    const headX = this.x + rightX * this.peekOffset + fwdX * forwardSurge;
    const headY = this.y - 1.68 + eyeHeight + microVertical;
    const headZ = this.z + rightZ * this.peekOffset + fwdZ * forwardSurge;

    if (this.cameraMode === 'THIRD_PERSON') {
      const camDist = this.thirdPersonDistance;
      const shoulderRight = 0.42;
      const camX = headX - fwdX * camDist * Math.cos(this.pitch) + rightX * shoulderRight;
      const camY = Math.max(0.45, headY + 0.55 - Math.sin(this.pitch) * camDist * 0.75);
      const camZ = headZ - fwdZ * camDist * Math.cos(this.pitch) + rightZ * shoulderRight;
      return {
        x: camX,
        y: camY,
        z: camZ,
        yaw: this.yaw,
        pitch: this.pitch - 0.08 + microPitchNod,
        roll: this.roll * 0.25
      };
    }

    return {
      x: headX,
      y: headY,
      z: headZ,
      yaw: this.yaw,
      pitch: this.pitch + microPitchNod,
      roll: this.roll - this.peekOffset * 0.15
    };
  }

  getEyePositionForRaycast() {
    let eyeHeight = this.isCrouching ? 1.08 : 1.68;
    return {
      x: this.x,
      y: this.y - 1.68 + eyeHeight,
      z: this.z
    };
  }

  getForwardVector() {
    const cosP = Math.cos(this.pitch);
    return {
      x: Math.sin(this.yaw) * cosP,
      y: Math.sin(this.pitch),
      z: Math.cos(this.yaw) * cosP
    };
  }

  isKeyPressed(keys, codes) {
    for (let i = 0; i < codes.length; i++) {
      if (keys[codes[i]]) return true;
    }
    return false;
  }

  update(dt, keys, worldStructures, stealthBushes, onAlert, onNoise) {
    this.animTime += dt;
    if (this.grappleCooldown > 0) this.grappleCooldown = Math.max(0, this.grappleCooldown - dt);
    if (this.activeGrappleLine) {
      this.activeGrappleLine.timer -= dt;
      if (this.activeGrappleLine.timer <= 0) this.activeGrappleLine = null;
    }
    if (this.immobilizedTimer > 0) {
      this.immobilizedTimer = Math.max(0, this.immobilizedTimer - dt);
      this.vx = 0;
      this.vz = 0;
      this.roll = Math.sin(this.animTime * 22) * 0.06;
      return;
    }

    if (this.isStumbled) {
      this.stumbleTimer -= dt;
      this.roll = this.roll * 0.9 + 0.22 * 0.1;
      this.vy -= 19.6 * dt;
      this.y += this.vy * dt;
      const floorY = this.detectSurfaceBelow(worldStructures).height;
      if (this.y <= floorY + 1.68) {
        this.y = floorY + 1.68;
        this.vy = 0;
        this.isGrounded = true;
      }
      if (this.stumbleTimer <= 0) {
        this.isStumbled = false;
      }
      return;
    }

    const moveW = this.isKeyPressed(keys, ['KeyW', 'ArrowUp', 'w', 'W']);
    const moveS = this.isKeyPressed(keys, ['KeyS', 'ArrowDown', 's', 'S']);
    const moveA = this.isKeyPressed(keys, ['KeyA', 'a', 'A']);
    const moveD = this.isKeyPressed(keys, ['KeyD', 'd', 'D']);

    if (this.isKeyPressed(keys, ['ArrowLeft'])) this.yaw -= 1.85 * dt;
    if (this.isKeyPressed(keys, ['ArrowRight'])) this.yaw += 1.85 * dt;

    const crouchHeld = this.isKeyPressed(keys, ['ControlLeft', 'ControlRight', 'KeyC', 'c', 'C']);
    const sprintHeld = this.isKeyPressed(keys, ['ShiftLeft', 'ShiftRight', 'Shift']) || this.sprintToggleLock;
    const jumpHeld = this.isKeyPressed(keys, ['Space', ' ']);

    let targetPeek = 0;
    if (this.isKeyPressed(keys, ['KeyZ', 'z', 'Z'])) targetPeek = -0.42;
    else if (this.isKeyPressed(keys, ['KeyX', 'x', 'X'])) targetPeek = 0.0; // X is now Carry/Hide Body!
    this.peekOffset = this.peekOffset * 0.82 + targetPeek * 0.18;

    if (sprintHeld && crouchHeld && moveW && this.isGrounded && !this.isSliding && this.slideTimer <= 0 && !this.carryingBodyNpc) {
      this.isSliding = true;
      this.slideTimer = 0.60;
      KageAudio.playSlide();
    }

    if (this.slideTimer > 0) {
      this.slideTimer -= dt;
      if (this.slideTimer <= 0) this.isSliding = false;
    }

    this.isCrouching = crouchHeld && !this.isSliding;
    const isMovingInput = moveW || moveS || moveA || moveD;
    this.isSprinting = sprintHeld && !this.isCrouching && isMovingInput && !this.carryingBodyNpc;

    let maxSpeed = 5.6;
    if (this.isSliding) maxSpeed = 11.4;
    else if (this.isCrouching) maxSpeed = 3.0;
    else if (this.isSprinting) maxSpeed = 10.4;

    if (this.carryingBodyNpc) maxSpeed *= 0.72; // Carrying a body slows you down slightly
    if (this.leftLegCrippled && this.rightLegCrippled) maxSpeed *= 0.30;
    else if (this.leftLegCrippled || this.rightLegCrippled) maxSpeed *= 0.58;

    const forwardX = Math.sin(this.yaw);
    const forwardZ = Math.cos(this.yaw);
    const rightX = Math.cos(this.yaw);
    const rightZ = -Math.sin(this.yaw);

    let inputForward = (moveW ? 1 : 0) - (moveS ? 1 : 0);
    let inputStrafe = (moveD ? 1 : 0) - (moveA ? 1 : 0);

    let wishX = forwardX * inputForward + rightX * inputStrafe;
    let wishZ = forwardZ * inputForward + rightZ * inputStrafe;
    const wishLen = Math.hypot(wishX, wishZ);
    if (wishLen > 0.001) {
      wishX /= wishLen;
      wishZ /= wishLen;
    }

    const accel = this.isGrounded ? 16.0 : 7.5;
    this.vx += (wishX * maxSpeed - this.vx) * Math.min(1.0, accel * dt);
    this.vz += (wishZ * maxSpeed - this.vz) * Math.min(1.0, accel * dt);

    const nextX = this.x + this.vx * dt;
    if (!this.checkWallCollision(nextX, this.y, this.z, worldStructures)) {
      this.x = Math.max(-48, Math.min(48, nextX));
    } else {
      this.vx = 0;
    }

    const nextZ = this.z + this.vz * dt;
    if (!this.checkWallCollision(this.x, this.y, nextZ, worldStructures)) {
      this.z = Math.max(-44, Math.min(44, nextZ));
    } else {
      this.vz = 0;
    }

    // If carrying a body, keep its coordinates synced to our shoulder!
    if (this.carryingBodyNpc) {
      this.carryingBodyNpc.x = this.x - forwardX * 0.45;
      this.carryingBodyNpc.z = this.z - forwardZ * 0.45;
      this.carryingBodyNpc.y = this.y - 0.65;
      this.carryingBodyNpc.yaw = this.yaw + Math.PI * 0.5;
    }

    // Check if player is inside a Bamboo Stealth Bush
    this.isHiddenInBush = false;
    if (stealthBushes) {
      for (let i = 0; i < stealthBushes.length; i++) {
        const b = stealthBushes[i];
        if (Math.hypot(this.x - b.x, this.z - b.z) < b.radius) {
          this.isHiddenInBush = true;
          break;
        }
      }
    }

    const surfaceInfo = this.detectSurfaceBelow(worldStructures);
    this.currentSurface = surfaceInfo.surface;
    this.currentSlope = surfaceInfo.slope;

    const planarSpeed = Math.hypot(this.vx, this.vz);

    if (this.isGrounded && planarSpeed > 0.35 && !this.isSliding) {
      const stepFreq = this.isSprinting ? 5.6 : (this.isCrouching ? 2.4 : 3.6);
      this.stepPhase += dt * stepFreq * Math.PI;

      const currentHalfCycle = Math.floor(this.stepPhase / Math.PI);
      if (currentHalfCycle > this.lastStepHalfCycle) {
        this.lastStepHalfCycle = currentHalfCycle;
        KageAudio.playStep(this.currentSurface, this.isSprinting, this.isCrouching);
      }

      let targetRoll = 0;
      if (this.leftLegCrippled || this.rightLegCrippled) {
        targetRoll = Math.sin(this.stepPhase) * 0.08;
      }
      this.roll = this.roll * 0.85 + targetRoll * 0.15;

      this.evaluateSurfaceRiskAndNoise(dt, planarSpeed, onAlert, onNoise);
    } else {
      this.roll = this.roll * 0.85;
      this.currentNoiseDb = Math.max(2, this.currentNoiseDb - 22 * dt);
    }

    if (jumpHeld) {
      if (this.isGrounded && !(this.leftLegCrippled && this.rightLegCrippled)) {
        const jumpMult = (this.leftLegCrippled || this.rightLegCrippled) ? 0.65 : 1.0;
        this.vy = 8.2 * jumpMult;
        this.isGrounded = false;
        this.gripStamina = Math.max(0, this.gripStamina - 8);
        KageAudio.playJump();
        onNoise(15, { x: this.x, y: this.y, z: this.z });
      } else if (!this.isGrounded && this.gripStamina > 8 && !(this.leftArmSevered && this.rightArmSevered)) {
        const nearLedge = this.findNearbyRoofLedge(worldStructures);
        if (nearLedge) {
          const armPenalty = (this.leftArmSevered || this.rightArmSevered) ? 2.0 : 1.0;
          this.gripStamina = Math.max(0, this.gripStamina - 18 * armPenalty * dt);
          this.vy = 4.2;
          if (this.gripStamina <= 0) {
            onAlert('Grip Stamina habis saat memanjat tepian atap!');
          }
        }
      }
    }

    this.vy -= 19.6 * dt;
    this.y += this.vy * dt;

    if (this.y <= surfaceInfo.height + 1.68) {
      if (!this.isGrounded && this.vy < -3.5) {
        KageAudio.playLand(this.currentSurface);
        if (this.vy < -9.5) {
          const impact = Math.abs(this.vy);
          const safeLimit = (this.isCrouching || this.isSliding) ? 16.0 : 11.2;
          if (impact > safeLimit) {
            this.triggerStumble('Pendaratan terlalu keras tanpa tekan [Ctrl/C] (Roll)!', 65, onAlert, onNoise);
          } else {
            onNoise((this.isCrouching || this.isSliding) ? 10 : 32, { x: this.x, y: this.y, z: this.z });
          }
        }
      }
      this.y = surfaceInfo.height + 1.68;
      this.vy = 0;
      this.isGrounded = true;
    } else {
      this.isGrounded = false;
    }

    if (this.isGrounded) {
      this.gripStamina = Math.min(this.maxGripStamina, this.gripStamina + 18 * dt);
    }
  }

  evaluateSurfaceRiskAndNoise(dt, speed, onAlert, onNoise) {
    const baseNoiseMap = { Tatami: 4, Wood: 14, ClayTile: 22, WetRoof: 20, Gravel: 28, Stone: 11 };
    const baseNoise = baseNoiseMap[this.currentSurface] || 12;
    const speedRatio = speed / 10.4;
    this.currentNoiseDb = Math.round(this.isCrouching ? baseNoise * 0.20 : baseNoise * (0.45 + speedRatio));
    onNoise(this.currentNoiseDb, { x: this.x, y: this.y, z: this.z });

    if ((this.currentSurface === 'WetRoof' || this.currentSlope > 22) && !this.isCrouching && this.isSprinting) {
      const slipChance = (this.currentSurface === 'WetRoof' ? 0.25 : 0.12) * dt;
      if (Math.random() < slipChance) {
        this.triggerStumble(`Terpeleset karena berlari cepat di ${this.currentSurface} (Kemiringan ${this.currentSlope}°)!`, 62, onAlert, onNoise);
      }
    }
  }

  triggerStumble(reason, noiseDb, onAlert, onNoise) {
    this.isStumbled = true;
    this.stumbleTimer = 0.95;
    this.currentNoiseDb = noiseDb;
    KageAudio.playSlipCrash();
    onAlert(reason);
    onNoise(noiseDb, { x: this.x, y: this.y, z: this.z });
  }

  detectSurfaceBelow(structures) {
    let bestHeight = 0;
    let bestSurface = 'Stone';
    let bestSlope = 0;

    for (let i = 0; i < structures.length; i++) {
      const s = structures[i];
      if (!s.walkable) continue;
      const hx = s.w * 0.5, hz = s.d * 0.5;
      if (this.x >= s.x - hx && this.x <= s.x + hx && this.z >= s.z - hz && this.z <= s.z + hz) {
        const topY = s.y + s.h * 0.5;
        if (this.y - 1.2 >= topY - 1.1 && topY >= bestHeight) {
          bestHeight = topY;
          bestSurface = s.surface || 'Wood';
          bestSlope = s.slope || 0;
        }
      }
    }
    return { height: bestHeight, surface: bestSurface, slope: bestSlope };
  }

  checkWallCollision(nx, ny, nz, structures) {
    const footY = ny - 1.5;
    for (let i = 0; i < structures.length; i++) {
      const s = structures[i];
      if (!s.solidWall) continue;
      const topY = s.y + s.h * 0.5;
      const botY = s.y - s.h * 0.5;
      if (footY < topY - 0.25 && ny > botY) {
        const hx = s.w * 0.5 + 0.30, hz = s.d * 0.5 + 0.30;
        if (nx >= s.x - hx && nx <= s.x + hx && nz >= s.z - hz && nz <= s.z + hz) {
          return true;
        }
      }
    }
    return false;
  }

  findNearbyRoofLedge(structures) {
    for (let i = 0; i < structures.length; i++) {
      const s = structures[i];
      if (!s.climbable && !s.solidWall) continue;
      const hx = s.w * 0.5 + 1.2, hz = s.d * 0.5 + 1.2;
      if (this.x >= s.x - hx && this.x <= s.x + hx && this.z >= s.z - hz && this.z <= s.z + hz) {
        return s;
      }
    }
    return null;
  }

  getThirdPersonPlayerMeshes(disguise, weaponCtrl) {
    if (this.cameraMode !== 'THIRD_PERSON') return [];

    const meshes = [];
    const baseY = this.y - 1.68;
    const crouchDrop = this.isCrouching ? 0.34 : (this.isSliding ? 0.58 : 0);
    const cosY = Math.cos(this.yaw), sinY = Math.sin(this.yaw);

    const speed = Math.hypot(this.vx, this.vz);
    const moveFactor = Math.min(1.2, speed / 5.5);
    const swing = Math.sin(this.stepPhase) * 0.48 * moveFactor;
    const kneeL = Math.max(0.04, -Math.cos(this.stepPhase) * 0.38 * moveFactor);
    const kneeR = Math.max(0.04, Math.cos(this.stepPhase) * 0.38 * moveFactor);
    const breath = Math.sin(this.animTime * 2.6) * 0.012;

    const toWorld = (lx, ly, lz) => ({
      x: this.x + (lx * cosY + lz * sinY),
      y: baseY + ly - crouchDrop,
      z: this.z + (-lx * sinY + lz * cosY)
    });

    const outfitColor = disguise.color || '#181c26';
    const accentColor = disguise.id === 'SHINOBI' ? '#9e1b24' : (disguise.id === 'GUARD' ? '#c4a462' : '#d4a359');

    // 1. Soft V-Ray Ground Contact Shadow
    meshes.push({ shape: 'hd_shadow', x: this.x, y: baseY + 0.02, z: this.z, w: 0.95 });

    // 2. Smooth Organic Articulated LEGS
    const lHip = toWorld(-0.12, 0.84 + crouchDrop * 0.3, 0);
    const lKneeZ = Math.sin(swing) * 0.22;
    const lKnee = toWorld(-0.12, 0.46 + crouchDrop * 0.5, lKneeZ);
    const lAnkleZ = lKneeZ - Math.sin(kneeL) * 0.20;
    const lAnkle = toWorld(-0.12, 0.10 + crouchDrop * 0.8, lAnkleZ);
    const lToe = toWorld(-0.12, 0.04 + crouchDrop * 0.9, lAnkleZ + 0.14);

    meshes.push({ shape: 'hd_capsule', p1: lHip, p2: lKnee, r1: 0.095, r2: 0.072, color: '#1b1f29', material: 'cloth' });
    meshes.push({ shape: 'hd_capsule', p1: lKnee, p2: lAnkle, r1: 0.068, r2: 0.045, color: '#141720', material: 'cloth', trimColor: accentColor });
    meshes.push({ shape: 'hd_capsule', p1: lAnkle, p2: lToe, r1: 0.048, r2: 0.040, color: '#0f1117', material: 'cloth' });

    const rHip = toWorld(0.12, 0.84 + crouchDrop * 0.3, 0);
    const rKneeZ = Math.sin(-swing) * 0.22;
    const rKnee = toWorld(0.12, 0.46 + crouchDrop * 0.5, rKneeZ);
    const rAnkleZ = rKneeZ - Math.sin(kneeR) * 0.20;
    const rAnkle = toWorld(0.12, 0.10 + crouchDrop * 0.8, rAnkleZ);
    const rToe = toWorld(0.12, 0.04 + crouchDrop * 0.9, rAnkleZ + 0.14);

    meshes.push({ shape: 'hd_capsule', p1: rHip, p2: rKnee, r1: 0.095, r2: 0.072, color: '#1b1f29', material: 'cloth' });
    meshes.push({ shape: 'hd_capsule', p1: rKnee, p2: rAnkle, r1: 0.068, r2: 0.045, color: '#141720', material: 'cloth', trimColor: accentColor });
    meshes.push({ shape: 'hd_capsule', p1: rAnkle, p2: rToe, r1: 0.048, r2: 0.040, color: '#0f1117', material: 'cloth' });

    // 3. HD Contoured Torso & Haori Jacket
    meshes.push({
      shape: 'hd_torso',
      pTop: toWorld(0, 1.38 + breath, 0),
      pWaist: toWorld(0, 1.02 + breath * 0.5, 0),
      pHip: toWorld(0, 0.68, 0),
      wShoulder: 0.22,
      wWaist: 0.16,
      wHip: 0.21,
      coatColor: outfitColor,
      innerColor: disguise.id === 'SHINOBI' ? '#242936' : '#e8dfd1',
      trimColor: accentColor,
      obiColor: accentColor,
      isFemaleStyle: false
    });

    // 4. Smooth Articulated ARMS & Katana
    const lSh = toWorld(-0.22, 1.34 + breath, 0);
    const lArmSwing = -swing * 0.70;
    const lElb = toWorld(-0.25, 1.10 + breath, Math.sin(lArmSwing) * 0.12);
    const lWr = toWorld(-0.24, 0.90 + breath, Math.sin(lArmSwing) * 0.22 + 0.10);
    const lHand = toWorld(-0.23, 0.82 + breath, Math.sin(lArmSwing) * 0.25 + 0.14);
    meshes.push({ shape: 'hd_capsule', p1: lSh, p2: lElb, r1: 0.066, r2: 0.054, color: outfitColor, material: 'cloth' });
    meshes.push({ shape: 'hd_capsule', p1: lElb, p2: lWr, r1: 0.052, r2: 0.040, color: '#1b1f29', material: 'cloth', trimColor: accentColor });
    meshes.push({ shape: 'hd_capsule', p1: lWr, p2: lHand, r1: 0.040, r2: 0.032, color: '#f3cbb4', material: 'skin' });

    let rArmPitch = swing * 0.70;
    if (weaponCtrl.swingTimer > 0) {
      rArmPitch = -1.1 + (weaponCtrl.swingTimer / 0.26) * 1.4;
    } else if (weaponCtrl.hasWeapon && weaponCtrl.isWeaponDrawn) {
      rArmPitch = -0.35;
    }
    const rSh = toWorld(0.22, 1.34 + breath, 0);
    const rElb = toWorld(0.25, 1.10 + breath, Math.sin(rArmPitch) * 0.12);
    const rWr = toWorld(0.24, 0.92 + breath, Math.sin(rArmPitch) * 0.22 + 0.16);
    const rHand = toWorld(0.23, 0.84 + breath, Math.sin(rArmPitch) * 0.25 + 0.20);
    meshes.push({ shape: 'hd_capsule', p1: rSh, p2: rElb, r1: 0.066, r2: 0.054, color: outfitColor, material: 'cloth' });
    meshes.push({ shape: 'hd_capsule', p1: rElb, p2: rWr, r1: 0.052, r2: 0.040, color: '#1b1f29', material: 'cloth', trimColor: accentColor });
    meshes.push({ shape: 'hd_capsule', p1: rWr, p2: rHand, r1: 0.040, r2: 0.032, color: '#f3cbb4', material: 'skin' });

    if (weaponCtrl.hasWeapon && weaponCtrl.isWeaponDrawn) {
      const kPos = toWorld(0.27, 1.06, 0.56);
      meshes.push({
        x: kPos.x, y: kPos.y, z: kPos.z,
        w: 0.035, h: 0.045, d: 0.88,
        yaw: this.yaw, pitch: rArmPitch - 0.25,
        color: '#e2ebf5', shape: 'box'
      });
    }

    // 5. Subsurface Neck & Photorealistic Textured 3D Head ('hd_head')
    const nBot = toWorld(0, 1.36 + breath, 0);
    const nTop = toWorld(0, 1.49 + breath, 0);
    meshes.push({ shape: 'hd_capsule', p1: nTop, p2: nBot, r1: 0.062, r2: 0.072, color: '#f3cbb4', material: 'skin' });

    const hPos = toWorld(0, 1.60 + breath, 0.01);
    let hatStyle = 'NONE';
    if (disguise.id === 'PEASANT' || disguise.id === 'MONK') hatStyle = 'KASA';
    else if (disguise.id === 'GUARD') hatStyle = 'JINGASA';

    meshes.push({
      shape: 'hd_head',
      x: hPos.x, y: hPos.y, z: hPos.z,
      w: 0.23, h: 0.26,
      yaw: this.yaw,
      hairColor: '#1e1612',
      hairStyle: 'AYA_BOB',
      hatStyle,
      hatColor: hatStyle === 'KASA' ? '#c8a86b' : '#233656',
      hasMask: disguise.id === 'SHINOBI',
      maskColor: '#161922'
    });

    return meshes;
  }
}
