// ============================================================================
// KAGE-ANA v0.5 (Tahap 4): Sacred Kurama Shrine Respawn, Village Houses,
// Civilian Clue Investigation [I], Clan Conflict, Lethal Projectiles & BGM [P]
// ============================================================================

const canvas = document.getElementById('gameCanvas');
const engine = new Engine3D(canvas);

// 5-Chapter Story Campaign with Identity Clues (Players must verify targets among civilians!)
const STORY_CHAPTERS = [
  {
    id: 'CHAP_1',
    chapterNum: 1,
    title: 'Babak 1: Pajak Darah di Dermaga Selatan',
    targetName: 'Inspektur Pajak Jinbei',
    targetRole: 'Pemeras Beras Dermaga Selatan',
    districtName: 'Dermaga Nelayan Selatan',
    clueHint: 'PETUNJUK IDENTITAS: Berpakaian petani coklat di Dermaga Selatan (z = -15), tetapi membawa buku catatan upeti bersegel Laba-Laba Hitam (bukan jaring ikan). Dekati & tekan [I] untuk memastikan sebelum membunuh!',
    x: 0, z: -15,
    armor: false,
    tunic: '#7d4e1d',
    hat: 'KASA',
    disguiseType: 'PEASANT',
    dailyActivity: 'Mencatat pajak paksa di buku bersampul merah',
    secretClue: '🔍 IDENTITAS TERBUKTI [TARGET SAH]: Inspektur Pajak Jinbei! Menyembunyikan buku upeti Sindikat Kuro-no-Wa & belati pajak!',
    reward: 300
  },
  {
    id: 'CHAP_2',
    chapterNum: 2,
    title: 'Babak 2: Bisikan di Pasar Lentera Timur',
    targetName: 'Saudagar Mesiu Gendo',
    targetRole: 'Pemasok Senjata Gelap Sindikat',
    districtName: 'Pasar Lentera Timur',
    clueHint: 'PETUNJUK IDENTITAS: Mengenakan jubah ungu di Pasar Timur (x = +15, z = +4). Awas tertukar dengan Pedagang Teh yang tak bersalah! Periksa dengan [I] — Gendo membawa kantung bubuk mesiu hitam.',
    x: 15, z: 4,
    armor: false,
    tunic: '#5e2b7a',
    hat: 'KABUTO_GOLD',
    disguiseType: 'MERCHANT',
    dailyActivity: 'Memeriksa peti kayu berisi bubuk mesiu gelap',
    secretClue: '🔍 IDENTITAS TERBUKTI [TARGET SAH]: Saudagar Mesiu Gendo! Tangannya berbau belerang & membawa kontrak senjata Sindikat!',
    reward: 420
  },
  {
    id: 'CHAP_3',
    chapterNum: 3,
    title: 'Babak 3: Sumpah Palsu di Kuil Bukit Barat',
    targetName: 'Biksu Pengkhianat Ryuzen',
    targetRole: 'Informan Sindikat di Kuil Barat',
    districtName: 'Kuil Bukit & Hutan Bambu Barat',
    clueHint: 'PETUNJUK IDENTITAS: Berjubah biksu safron di Kuil Barat (x = -16, z = +8). Jangan bunuh Biksu Penjaga Kuil yang sedang menyapu! Tekan [I] — Ryuzen menyimpan surat sandi Sindikat di lengan jubahnya.',
    x: -16, z: 8,
    armor: false,
    tunic: '#9e5b16',
    hat: 'KASA',
    disguiseType: 'MONK',
    dailyActivity: 'Mengawasi gerak-gerik desa sambil menyembunyikan gulungan surat',
    secretClue: '🔍 IDENTITAS TERBUKTI [TARGET SAH]: Biksu Pengkhianat Ryuzen! Membawa daftar nama klan Shinobi untuk diserahkan ke Takamori!',
    reward: 500
  },
  {
    id: 'CHAP_4',
    chapterNum: 4,
    title: 'Babak 4: Baja Berkarat di Gerbang Barak',
    targetName: 'Kapten Garnisun Hanzaburo',
    targetRole: 'Komandan Pasukan Tombak (Nodowa Armor)',
    districtName: 'Pelataran Barak Utara',
    clueHint: 'PETUNJUK IDENTITAS: Berzirah biru tua di Pelataran Barak Utara (x = 0, z = +14) dengan pelindung leher baja Nodowa. Jangan serang Utusan Klan Hoshino di dekatnya!',
    x: 0, z: 14,
    armor: true,
    tunic: '#1c3b5e',
    hat: 'KABUTO_GOLD',
    disguiseType: 'GUARD',
    dailyActivity: 'Memberi instruksi patroli jam malam garnisun',
    secretClue: '🔍 IDENTITAS TERBUKTI [TARGET SAH]: Kapten Hanzaburo! Memakai pelindung leher Nodowa — tusuk jantungnya [Klik Kanan]!',
    reward: 650
  },
  {
    id: 'CHAP_5',
    chapterNum: 5,
    title: 'Babak 5: Bayangan Terakhir di Benteng Tenshu',
    targetName: 'Daimyo Lord Takamori',
    targetRole: 'Pemimpin Tertinggi Sindikat Kuro-no-Wa',
    districtName: 'Benteng Agung Tenshu Utara',
    clueHint: 'PETUNJUK IDENTITAS: Mengenakan jubah merah tua & Kabuto emas di depan Benteng Agung Tenshu (x = 0, z = +23). Waspadai lemparan jaring rantai & pengawalnya!',
    x: 0, z: 23,
    armor: true,
    tunic: '#8f151e',
    hat: 'KABUTO_GOLD',
    disguiseType: 'GUARD',
    dailyActivity: 'Memimpin dewan perang Sindikat Kuro-no-Wa',
    secretClue: '🔍 IDENTITAS TERBUKTI [TARGET UTAMA]: Daimyo Lord Takamori! Pemimpin tertinggi pembantaian Lembah Kurokawa!',
    reward: 1000
  }
];

// Sacred Kurama Shrine Coordinates (Respawn Sanctuary)
const KURAMA_SHRINE_SPAWN = { x: -24, y: 1.68, z: -26, yaw: 0.65 };

const worldState = {
  engine,
  parkour: new ParkourPhysicsController(),
  playerWeapon: new PlayerWeaponController(),
  currentDisguise: DISGUISES.PEASANT,
  bloodstainOnClothes: 0,
  playerBloodVolume: 100,
  playerBleedRate: 0,
  districtHeat: 10,
  clanConflict: 0, // Stage 4: Spikes if player kills innocent villagers / allied clan envoys!
  innocentsKilled: 0,
  shrineRespawnCount: 0,
  totalRyo: 0,
  bodiesHiddenCount: 0,
  currentChapterIdx: 0,
  storyCompleted: false,
  structures: [],
  stealthBushes: [],
  npcs: [],
  enemyProjectiles: [],
  droppedWeapons: [],
  bloodPools: [],
  severedParts: [],
  bloodParticles: [],
  contracts: [],
  lockedTargetNpc: null,

  showToast(msg) {
    const el = document.getElementById('combatToast');
    if (el) el.textContent = msg;
  },

  addBloodstainToClothes(amount, onToast) {
    this.bloodstainOnClothes = Math.min(100, this.bloodstainOnClothes + amount);
    if (this.bloodstainOnClothes >= 45) {
      onToast(`PERINGATAN: Pakaian samaran berlumuran darah (${Math.round(this.bloodstainOnClothes)}%)! Gunakan Cekikan Senyap [F] atau tekan [1-5] ganti baju.`);
    }
  },

  /**
   * Stage 4: Sacred Kurama Shrine Respawn System!
   * When the player is killed by lethal enemies, they awaken at the Sacred Kurama Shrine Sanctuary!
   */
  triggerPlayerDeathAndShrineRespawn(deathReason, onToast) {
    this.shrineRespawnCount++;
    KageAudio.playShrineRespawn();

    const p = this.parkour;
    p.x = KURAMA_SHRINE_SPAWN.x;
    p.y = KURAMA_SHRINE_SPAWN.y;
    p.z = KURAMA_SHRINE_SPAWN.z;
    p.yaw = KURAMA_SHRINE_SPAWN.yaw;
    p.pitch = 0;
    p.vx = 0; p.vy = 0; p.vz = 0;
    p.immobilizedTimer = 0;
    p.isStumbled = false;
    p.leftLegCrippled = false;
    p.rightLegCrippled = false;
    p.carryingBodyNpc = null;

    this.playerBloodVolume = 100;
    this.playerBleedRate = 0;
    this.bloodstainOnClothes = 0;
    this.enemyProjectiles = [];
    this.playerWeapon.recoverImpaledBlade();

    // Reset NPC combat aggro so player can regroup from the Shrine
    this.npcs.forEach(npc => {
      if (!npc.isDead && npc.aiState === 'COMBAT') {
        npc.aiState = 'PATROL';
        npc.suspicion = 20;
      }
    });

    const banner = document.getElementById('respawnBanner');
    if (banner) {
      banner.style.display = 'block';
      banner.textContent = `⛩️ GUGUR & BANGKIT KEMBALI DI KUIL SUCI KURAMA (Respawn #${this.shrineRespawnCount}) — Luka Dipulihkan oleh Biksu Kuil!`;
      setTimeout(() => { banner.style.display = 'none'; }, 5500);
    }

    onToast(`⛩️ GUGUR DALAM PERTEMPURAN (${deathReason})! Biksu menyelamatkanmu dan kamu hidup kembali (Respawn) di Pelataran Kuil Suci Kurama!`);
  },

  /**
   * Stage 4: Inspect Identity & Clues [Key I]
   */
  inspectNearestNpcIdentity(onToast) {
    const p = this.parkour;
    const fwd = p.getForwardVector();
    let best = null;
    let bestDist = 12.5;

    this.npcs.forEach(npc => {
      if (npc.isDead) return;
      const dx = npc.x - p.x;
      const dz = npc.z - p.z;
      const d = Math.hypot(dx, dz);
      const score = d + (npc.isIdentityInspected ? 6.0 : 0.0);
      if (score < bestDist) {
        const dot = (dx / (d || 1)) * fwd.x + (dz / (d || 1)) * fwd.z;
        if (dot > 0.35 || d < 5.0) {
          bestDist = score;
          best = npc;
        }
      }
    });

    if (best) {
      best.isIdentityInspected = true;
      KageAudio.playInspectClue();
      onToast(`${best.name} (${best.dailyActivity}) — ${best.secretClue}`);
      return best;
    } else {
      onToast('🔍 Periksa Identitas [I]: Dekati warga atau target (< 12m) lalu tekan [I] untuk mengamati gerak-gerik & petunjuk rahasianya!');
      return null;
    }
  },

  /**
   * Stage 4: Clan Conflict Penalty when an Innocent Civilian / Allied Clan Envoy is killed!
   */
  handleCollateralCivilianDeath(npc, onToast) {
    this.innocentsKilled++;
    this.clanConflict = Math.min(100, this.clanConflict + 35);
    this.totalRyo = Math.max(0, this.totalRyo - 150);
    this.districtHeat = Math.min(100, this.districtHeat + 25);

    // Spawn a lethal Clan Avenger Ronin near the player!
    const p = this.parkour;
    this.npcs.push(new AnatomicalNPC({
      id: 'avenger_' + Date.now(),
      name: 'Pemburu Balasan Klan Hoshino',
      role: 'Ronin Pembalas Kematian Warga',
      faction: 'CLAN_AVENGER',
      isTarget: false,
      isIdentityInspected: true,
      secretClue: '⚠️ PEMBURU BALASAN KLAN: Dikirim karena kamu membunuh warga tak bersalah!',
      x: p.x + 6.5,
      z: p.z + 6.5,
      yaw: Math.PI,
      wearsNeckArmor: true,
      tunicColor: '#a82020',
      hatStyle: 'KABUTO_GOLD',
      patrolPts: [{ x: p.x, z: p.z }]
    }));

    onToast(`🔥 KONFLIK ANTAR KLAN PECAH (${this.clanConflict}%)! Kamu membunuh [${npc.name}] yang TIDAK BERSALAH! Denda -150 Ryo & Ronin Pembalas Klan dikirim memburumu!`);
    renderContractBoardUI();
  },

  spawnBloodPool(x, z) {
    if (this.bloodPools.length > 45) this.bloodPools.shift();
    this.bloodPools.push({ x, y: 0.03, z, w: 0.65, h: 0.03, d: 0.65, color: '#6e0b0b', shape: 'cylinder' });
  },

  spawnArterialSpray(x, y, z, count) {
    for (let i = 0; i < count; i++) {
      this.bloodParticles.push({
        x, y, z,
        vx: (Math.random() - 0.5) * 5.0,
        vy: 1.5 + Math.random() * 3.4,
        vz: (Math.random() - 0.5) * 5.0,
        w: 0.09, h: 0.09, d: 0.09,
        life: 0.85,
        color: '#a81010'
      });
    }
  },

  spawnClashSparks(x, y, z, count) {
    for (let i = 0; i < count; i++) {
      this.bloodParticles.push({
        x, y, z,
        vx: (Math.random() - 0.5) * 7.5,
        vy: 1.0 + Math.random() * 4.5,
        vz: (Math.random() - 0.5) * 7.5,
        w: 0.08, h: 0.08, d: 0.08,
        life: 0.45,
        color: i % 2 === 0 ? '#ffd54f' : '#ff9100',
        emissive: true
      });
    }
  },

  spawnSeveredPart(x, y, z, color, size) {
    this.severedParts.push({
      x, y, z,
      vx: (Math.random() - 0.5) * 4.5,
      vy: 3.2,
      vz: (Math.random() - 0.5) * 4.5,
      w: size, h: size, d: size,
      color,
      shape: 'cylinder'
    });
  },

  toggleCarryOrHideBody(onToast) {
    const p = this.parkour;
    if (p.carryingBodyNpc) {
      const body = p.carryingBodyNpc;
      p.carryingBodyNpc = null;
      body.y = 0.16;

      const inRiver = Math.abs(p.z) < 2.2 || p.z < -28;
      if (p.isHiddenInBush || inRiver) {
        body.isBodyHidden = true;
        this.bodiesHiddenCount++;
        this.districtHeat = Math.max(0, this.districtHeat - 8);
        KageAudio.playBushHide();
        onToast(`🌿 MAYAT DISEMBUNYIKAN! Tubuh ${body.name} lenyap di ${inRiver ? 'arus Sungai Kurokawa' : 'Semak Bambu'}.`);
      } else {
        KageAudio.playStep('Stone');
        onToast(`Tubuh ${body.name} diletakkan di tanah. Bawa ke Semak Bambu atau Sungai lalu tekan [X] agar aman dari patroli!`);
      }
      return;
    }

    for (let i = 0; i < this.npcs.length; i++) {
      const npc = this.npcs[i];
      if (npc.isDead && !npc.isBodyHidden && Math.hypot(npc.x - p.x, npc.z - p.z) < 3.6) {
        p.carryingBodyNpc = npc;
        KageAudio.playBushHide();
        onToast(`🏋️ MENGANGKAT TUBUH: ${npc.name}. Bawa ke Semak Bambu atau Sungai lalu tekan [X] untuk menyembunyikannya!`);
        return;
      }
    }

    onToast('Tidak ada tubuh di dekatmu (< 3.6m) untuk diangkat.');
  },

  completeContractForTarget(npc, onToast) {
    if (npc.isInnocent) {
      this.handleCollateralCivilianDeath(npc, onToast);
      return;
    }

    this.contracts.forEach(c => {
      if (!c.done && npc.name.includes(c.name)) {
        c.done = true;
        this.totalRyo += c.reward;
        this.districtHeat = Math.min(100, this.districtHeat + 15);
        KageAudio.playMissionSuccess();

        if (c.isCurrentStory && !this.storyCompleted) {
          if (this.currentChapterIdx < STORY_CHAPTERS.length - 1) {
            this.currentChapterIdx++;
            const nextChap = STORY_CHAPTERS[this.currentChapterIdx];
            onToast(`🏆 BABAK ${c.chapterNum} TUNTAS (+${c.reward} Ryo)! Lanjut ke ${nextChap.title}: Cari & periksa identitas [${nextChap.targetName}] dengan [I] di ${nextChap.districtName}!`);
          } else {
            this.storyCompleted = true;
            onToast(`🎉 SELURUH 5 BABAK CERITA KAGE-ANA TAMAT! Lembah Kurokawa bebas dari Sindikat Kuro-no-Wa!`);
          }
        } else {
          onToast(`KONTRAK SELESAI: ${c.name} berhasil dieksekusi! +${c.reward} Ryo.`);
        }
        renderContractBoardUI();
      }
    });
  }
};
window.worldState = worldState;

// Patch killInstantly & applyStealthChoke so killing an innocent civilian also triggers Clan Conflict!
const origKill = AnatomicalNPC.prototype.killInstantly;
AnatomicalNPC.prototype.killInstantly = function(reason, ws, onToast) {
  const wasDead = this.isDead;
  origKill.call(this, reason, ws, onToast);
  if (!wasDead && this.isInnocent) {
    ws.handleCollateralCivilianDeath(this, onToast);
  }
};

const origChoke = AnatomicalNPC.prototype.applyStealthChoke;
AnatomicalNPC.prototype.applyStealthChoke = function(ws, onToast) {
  if (this.isInnocent) {
    // Non-lethal choke on innocent civilian steals their clothes without killing them, but warns player!
    KageAudio.playChoke();
    this.isChokedUnconscious = true;
    this.isDead = true;
    this.isIncapacitated = true;
    const stolenDisguise = DISGUISES[this.disguiseType] || DISGUISES.PEASANT;
    ws.currentDisguise = stolenDisguise;
    ws.bloodstainOnClothes = 0;
    ws.clanConflict = Math.min(100, ws.clanConflict + 10);
    onToast(`⚠️ Kamu membuat pingsan warga tak bersalah (${this.name}) untuk mengambil bajunya! Konflik Klan +10%. Sembunyikan tubuhnya dengan [X]!`);
    return;
  }
  origChoke.call(this, ws, onToast);
};

// ============================================================================
// Expanded 7-District Kurokawa Village + Sacred Kurama Shrine + 14 Village Houses
// ============================================================================
function buildExpandedKurokawaVillage() {
  const s = [];
  const bushes = [];
  const lanternGlow = engine.timeOfDay.lanternGlow;

  // 1. Ground Reference Grid across all 7 districts
  for (let gx = -38; gx <= 38; gx += 6) {
    for (let gz = -36; gz <= 36; gz += 6) {
      const isMainRoad = Math.abs(gx) <= 3 || Math.abs(gz - 4) <= 3 || (gx < -14 && gz < -16);
      s.push({
        x: gx, y: 0.02, z: gz,
        w: isMainRoad ? 3.2 : 1.8,
        h: 0.04,
        d: isMainRoad ? 3.2 : 1.8,
        color: isMainRoad ? '#4a4f59' : '#263426',
        walkable: true,
        surface: isMainRoad ? 'Stone' : 'Gravel',
        stroke: isMainRoad ? '#2a2e35' : null
      });
    }
  }

  // 2. DISTRICT 0 (SACRED KURAMA SHRINE SANCTUARY - SOUTHWEST, x = -26, z = -28): Respawn Sanctuary!
  // Sacred Stone Altar Platform
  s.push({ x: -25, y: 0.25, z: -27, w: 12, h: 0.5, d: 12, color: '#6c727f', walkable: true, surface: 'Stone', stroke: '#3a3f47', mapLabel: '⛩️ Kuil Suci Kurama (Tempat Respawn)' });
  // Main Sacred Shrine Hall (Haiden)
  s.push({ x: -27, y: 2.1, z: -31, w: 7.5, h: 3.4, d: 5.5, color: '#9e1f1f', solidWall: true, climbable: true, walkable: true, surface: 'Wood', stroke: '#4a0e0e' });
  s.push({ x: -27, y: 4.3, z: -31, w: 9.5, h: 1.1, d: 7.2, color: '#c4a462', walkable: true, surface: 'ClayTile', shape: 'cone', topScale: 0.45, botScale: 1.0 });
  // Sacred Twin Vermilion Torii Gates leading from Shrine to Village
  [[-21, -22], [-16, -19]].forEach(([tx, tz]) => {
    s.push({ x: tx - 1.8, y: 1.7, z: tz, w: 0.32, h: 3.4, d: 0.32, color: '#b82525', solidWall: true, shape: 'cylinder' });
    s.push({ x: tx + 1.8, y: 1.7, z: tz, w: 0.32, h: 3.4, d: 0.32, color: '#b82525', solidWall: true, shape: 'cylinder' });
    s.push({ x: tx, y: 3.3, z: tz, w: 4.6, h: 0.28, d: 0.42, color: '#d62828', walkable: true, surface: 'Wood' });
  });
  // Sacred Bronze Bell Pavilion (Bonsho) & Giant Sacred Sakura Tree at Shrine
  s.push({ x: -21, y: 1.6, z: -29, w: 0.9, h: 1.4, d: 0.9, color: '#b5830e', solidWall: true, shape: 'cylinder' });
  s.push({ x: -29, y: 1.5, z: -24, w: 0.65, h: 2.8, d: 0.65, color: '#4a3222', solidWall: true, shape: 'cylinder' });
  s.push({ x: -29, y: 3.4, z: -24, w: 4.2, h: 1.9, d: 4.2, color: '#ff9ebb', shape: 'cone', topScale: 0.15, botScale: 1.0 });

  // 3. RESIDENTIAL VILLAGE HOUSES (14 Rumah Warga Minka across the village!)
  const minkaHouses = [
    // South & West Residential Row
    [-11, -21, '#4a3525', '#8c734b', 'Gudang Beras'],
    [ 11, -21, '#423022', '#7a6440', 'Rumah Nelayan'],
    [-12, -13, '#4f3a28', '#6e5a3b', 'Rumah Petani Barat'],
    [ 12, -13, '#483424', '#756042', 'Rumah Petani Timur'],
    [-22, -11, '#3d2c1e', '#635136', 'Rumah Perajin Bambu'],
    [ 22, -11, '#463222', '#705b3d', 'Rumah Penenun Sutra'],
    // Central & East Market Row
    [ 11,   3, '#543b26', '#9e2a2b', 'Kios Teh Timur'],
    [ 11,   9, '#543b26', '#2a6f97', 'Kios Kain Pasar'],
    [ 22,   6, '#3b281d', '#1d3647', 'Kedai Teh & Pasar Timur'],
    [ 22,  16, '#422e20', '#5c4730', 'Rumah Saudagar Kaya'],
    // West Shrine & Bamboo Row
    [-23,   8, '#422f22', '#2b303a', 'Aula Dojo & Kuil Barat'],
    [-23,  18, '#3d2b1f', '#52412c', ' Pondok Biksu Barat'],
    // North Garrison Outskirts
    [-15,  21, '#3b2d22', '#222730', 'Barak Penjaga Barat'],
    [ 15,  21, '#3b2d22', '#222730', 'Barak Penjaga Timur']
  ];

  minkaHouses.forEach(([hx, hz, wallCol, roofCol, label]) => {
    const isLarge = label.includes('Kedai') || label.includes('Aula');
    const w = isLarge ? 7.2 : 5.2;
    const d = isLarge ? 10.0 : 5.2;
    const h = isLarge ? 3.5 : 2.7;
    s.push({
      x: hx, y: h * 0.5, z: hz,
      w, h, d,
      color: wallCol,
      solidWall: true,
      climbable: true,
      walkable: true,
      surface: 'Wood',
      mapLabel: label
    });
    s.push({
      x: hx, y: h + 0.42, z: hz,
      w: w + 1.4, h: 0.85, d: d + 1.4,
      color: roofCol,
      walkable: true,
      surface: roofCol === '#1d3647' ? 'WetRoof' : 'ClayTile',
      slope: isLarge ? 22 : 16,
      shape: 'cone',
      topScale: 0.42,
      botScale: 1.0
    });
  });

  // 4. South Lake, Pier & Central Torii Gate
  s.push({ x: 0, y: 0.01, z: -31, w: 36, h: 0.03, d: 6, color: '#133246', walkable: true, surface: 'WetRoof', mapLabel: 'Dermaga Nelayan Selatan' });
  s.push({ x: 0, y: 0.08, z: -24, w: 7.5, h: 0.12, d: 8.5, color: '#6b4c30', walkable: true, surface: 'Wood', stroke: '#3d2715', mapLabel: 'Safehouse Dermaga' });

  s.push({ x: -2.9, y: 1.9, z: -11, w: 0.40, h: 3.8, d: 0.40, color: '#9e1f1f', solidWall: true, shape: 'cylinder' });
  s.push({ x:  2.9, y: 1.9, z: -11, w: 0.40, h: 3.8, d: 0.40, color: '#9e1f1f', solidWall: true, shape: 'cylinder' });
  s.push({ x:  0.0, y: 3.65, z: -11, w: 7.0, h: 0.32, d: 0.50, color: '#b82525', walkable: true, surface: 'Wood', mapLabel: 'Gerbang Torii Desa' });
  s.push({ x: -5.5, y: 0.45, z: -7, w: 1.6, h: 0.9, d: 1.6, color: '#555b66', solidWall: true, shape: 'cylinder', mapLabel: 'Sumur Desa' });

  // 5. Kurokawa River & 3 Bridges (z = 0)
  s.push({ x: 0, y: 0.01, z: 0, w: 84, h: 0.03, d: 3.4, color: '#16384c', walkable: true, surface: 'WetRoof' });
  s.push({ x: 0, y: 0.16, z: 0, w: 5.4, h: 0.20, d: 4.2, color: '#6b472a', walkable: true, surface: 'Wood', stroke: '#3d2715', mapLabel: 'Jembatan Utama' });
  s.push({ x: -18, y: 0.14, z: 0, w: 3.8, h: 0.18, d: 4.0, color: '#593a22', walkable: true, surface: 'Wood' });
  s.push({ x:  18, y: 0.14, z: 0, w: 4.2, h: 0.18, d: 4.0, color: '#6b472a', walkable: true, surface: 'Wood' });

  // 6. North Multi-Tiered Tenshu Castle Keep (z = 31)
  s.push({ x: 0, y: 2.4, z: 31, w: 16, h: 4.8, d: 8.5, color: '#dcd8ce', solidWall: true, climbable: true, walkable: true, surface: 'Stone', stroke: '#444', mapLabel: 'Benteng Agung Tenshu' });
  s.push({ x: 0, y: 5.2, z: 31, w: 18, h: 0.95, d: 10.2, color: '#242933', walkable: true, surface: 'ClayTile', slope: 22, shape: 'cone', topScale: 0.65, botScale: 1.0 });
  s.push({ x: 0, y: 6.9, z: 31, w: 10, h: 2.5, d: 5.8, color: '#e6e2d8', solidWall: true, walkable: true, surface: 'Wood' });
  s.push({ x: 0, y: 8.6, z: 31, w: 12, h: 1.2, d: 7.5, color: '#c4a462', shape: 'cone', topScale: 0.15, botScale: 1.0 });

  // 7. Stealth Bushes (Semak Bambu)
  const bushCoords = [
    [-3.5, -17], [3.8, -14], [-18, -23], [-4.5, -5], [4.5, -5],
    [11, 6], [18, 9], [-12, 7], [-15, 11],
    [-4.5, 13], [4.5, 16], [-4.5, 22], [4.5, 22]
  ];
  bushCoords.forEach(([bx, bz]) => {
    bushes.push({ x: bx, z: bz, radius: 1.8 });
    s.push({ x: bx, y: 0.55, z: bz, w: 2.1, h: 1.1, d: 2.1, color: '#1b4332', shape: 'cone', topScale: 0.35, botScale: 1.0 });
    s.push({ x: bx, y: 0.95, z: bz, w: 1.6, h: 0.8, d: 1.6, color: '#2d6a4f', shape: 'cone', topScale: 0.2, botScale: 1.0 });
  });

  // 8. Toro Stone Lanterns
  [[-4.5, -19], [4.5, -19], [-21, -25], [-4.5, -8], [4.5, -8], [-4.5, 6], [4.5, 6], [-4.5, 18], [4.5, 18]].forEach(([lx, lz]) => {
    s.push({ x: lx, y: 0.65, z: lz, w: 0.42, h: 1.3, d: 0.42, color: '#5c616b', solidWall: true, shape: 'cylinder' });
    s.push({ x: lx, y: 1.45, z: lz, w: 0.55, h: 0.32, d: 0.55, color: lanternGlow ? '#ffcf5c' : '#d8d2c5', emissive: lanternGlow, shape: 'cylinder' });
    s.push({ x: lx, y: 1.72, z: lz, w: 0.78, h: 0.22, d: 0.78, color: '#434750', shape: 'cone' });
  });

  worldState.structures = s;
  worldState.stealthBushes = bushes;
}

function spawnStoryAndVillageNPCs() {
  worldState.contracts = [];
  worldState.npcs = [];
  worldState.enemyProjectiles = [];
  worldState.playerWeapon.recoverImpaledBlade();
  worldState.parkour.carryingBodyNpc = null;

  // 1. Spawn the 5 Story Chapter Syndicate Targets (Hidden among villagers until inspected with [I]!)
  STORY_CHAPTERS.forEach((chap, idx) => {
    const isDone = idx < worldState.currentChapterIdx || worldState.storyCompleted;
    const isCurrent = idx === worldState.currentChapterIdx && !worldState.storyCompleted;

    worldState.contracts.push({
      chapterNum: chap.chapterNum,
      title: chap.title,
      name: chap.targetName,
      role: `${chap.districtName} • ${chap.targetRole}`,
      wearsArmor: chap.armor,
      reward: chap.reward,
      done: isDone,
      isCurrentStory: isCurrent
    });

    if (!isDone) {
      worldState.npcs.push(new AnatomicalNPC({
        id: chap.id,
        name: chap.targetName,
        publicRole: 'Warga Mencurigakan [Tekan I Periksa]',
        role: chap.targetRole,
        faction: 'SYNDICATE_TARGET',
        isTarget: true,
        isIdentityInspected: false,
        dailyActivity: chap.dailyActivity,
        secretClue: chap.secretClue,
        storyChapterId: chap.id,
        disguiseType: chap.disguiseType,
        x: chap.x,
        z: chap.z,
        yaw: Math.PI,
        wearsNeckArmor: chap.armor,
        tunicColor: chap.tunic,
        hatStyle: chap.hat,
        patrolPts: [
          { x: chap.x, z: chap.z },
          { x: chap.x + 2.2, z: chap.z },
          { x: chap.x + 2.2, z: chap.z + 1.8 },
          { x: chap.x, z: chap.z + 1.8 }
        ]
      }));
    }
  });

  // 2. Spawn Innocent Civilians & Allied Clan Envoys doing normal daily activities right near the targets!
  const civilians = [
    {
      id: 'civ_aya_ref',
      name: 'Nona Aya (Putri Bangsawan Desa)',
      publicRole: 'Gadis Berjaket Toska [Tekan I Periksa]',
      role: 'Warga Kehormatan Desa Kurokawa',
      faction: 'INNOCENT_CIVILIAN',
      disguise: 'MERCHANT',
      x: 1.8, z: -19.5,
      tunic: '#5bc0be', hat: 'NONE',
      activity: 'Menikmati angin sore dengan kardigan biru toska & gaun bunga',
      clue: '🕊️ NONA AYA (WARGA TAK BERSALAH): Putri bangsawan desa dengan kardigan toska & gaun bunga putih. JANGAN DISERANG!',
      pts: [{ x: 1.8, z: -19.5 }, { x: 2.2, z: -17.5 }]
    },
    {
      id: 'civ_fisherman',
      name: 'Pak Tua Kenji (Nelayan Desa)',
      publicRole: 'Warga Dermaga [Tekan I Periksa]',
      role: 'Nelayan Tak Bersalah',
      faction: 'INNOCENT_CIVILIAN',
      disguise: 'PEASANT',
      x: 3.2, z: -16.5,
      tunic: '#4a5d4e', hat: 'KASA',
      activity: 'Memperbaiki jaring ikan & menjemur tangkapan',
      clue: '🕊️ WARGA TAK BERSALAH: Pak Tua Kenji hanya membawa jaring ikan & keranjang bambu. JANGAN DIBUNUH!',
      pts: [{ x: 3.2, z: -16.5 }, { x: 5.5, z: -19.0 }]
    },
    {
      id: 'civ_well_woman',
      name: 'Bibi Hana (Petani Sumur)',
      publicRole: 'Warga Alun-Alun [Tekan I Periksa]',
      role: 'Warga Desa Kurokawa',
      faction: 'INNOCENT_CIVILIAN',
      disguise: 'PEASANT',
      x: -4.2, z: -7.5,
      tunic: '#6e473b', hat: 'KASA',
      activity: 'Menimba air bersih di Sumur Tua untuk memasak',
      clue: '🕊️ WARGA TAK BERSALAH: Bibi Hana sedang menimba air sumur desa. Membunuhnya akan memicu kemarahan warga!',
      pts: [{ x: -4.2, z: -7.5 }, { x: -7.5, z: -10.5 }]
    },
    {
      id: 'civ_tea_merchant',
      name: 'Pedagang Teh Taro (Klan Hoshino)',
      publicRole: 'Pedagang Pasar Timur [Tekan I Periksa]',
      role: 'Pedagang Teh Hijau Jujur',
      faction: 'ALLIED_CLAN',
      disguise: 'MERCHANT',
      x: 13.5, z: 6.5,
      tunic: '#3b6e52', hat: 'KASA',
      activity: 'Menyeduh teh hijau hangat untuk warga pasar',
      clue: '🕊️ SEKUTU KLAN HOSHINO: Pedagang Teh Taro membawa daun teh & lencana Klan Sekutu. JANGAN DIBUNUH (Memicu Perang Klan)!',
      pts: [{ x: 13.5, z: 6.5 }, { x: 17.5, z: 8.5 }]
    },
    {
      id: 'civ_shrine_monk',
      name: 'Biksu Penjaga Kuil Kurama (Soshin)',
      publicRole: 'Biksu Kuil [Tekan I Periksa]',
      role: 'Tabib & Penjaga Kuil Suci',
      faction: 'ALLIED_CLAN',
      disguise: 'MONK',
      x: -22.5, z: -24.5,
      tunic: '#b57c2e', hat: 'KASA',
      activity: 'Menyapu daun Sakura & mendoakan arwah leluhur di Kuil Kurama',
      clue: '🕊️ BIKSU PELINDUNG KUIL: Biksu Soshin yang menyembuhkan lukamu saat Respawn di Kuil. JANGAN DISERANG!',
      pts: [{ x: -22.5, z: -24.5 }, { x: -25.0, z: -26.5 }]
    },
    {
      id: 'civ_west_monk',
      name: 'Biksu Muda Kukai (Kuil Barat)',
      publicRole: 'Biksu Bukit Barat [Tekan I Periksa]',
      role: 'Murid Kuil Tak Bersalah',
      faction: 'INNOCENT_CIVILIAN',
      disguise: 'MONK',
      x: -14.0, z: 10.5,
      tunic: '#8c6228', hat: 'KASA',
      activity: 'Menyalakan dupa doa di halaman Kuil Barat',
      clue: '🕊️ BIKSU TAK BERSALAH: Biksu Kukai hanya membawa tasbih kayu & dupa, bukan pengkhianat Ryuzen!',
      pts: [{ x: -14.0, z: 10.5 }, { x: -18.0, z: 12.0 }]
    },
    {
      id: 'civ_clan_envoy',
      name: 'Utusan Damai Klan Takeda',
      publicRole: 'Samurai Utusan [Tekan I Periksa]',
      role: 'Diplomat Klan Tetangga',
      faction: 'ALLIED_CLAN',
      disguise: 'GUARD',
      x: -3.5, z: 12.5,
      tunic: '#2e5eaa', hat: 'JINGASA',
      activity: 'Menunggu perundingan damai di dekat Barak Utara',
      clue: '🕊️ DIPLOMAT KLAN TAKEDA: Membawa bendera perdamaian antar klan. Membunuhnya akan langsung memicu Konflik Antar Klan!',
      pts: [{ x: -3.5, z: 12.5 }, { x: -6.0, z: 14.5 }]
    }
  ];

  civilians.forEach(c => {
    worldState.npcs.push(new AnatomicalNPC({
      id: c.id,
      name: c.name,
      publicRole: c.publicRole,
      role: c.role,
      faction: c.faction,
      isTarget: false,
      hasWeapon: false,
      isIdentityInspected: false,
      dailyActivity: c.activity,
      secretClue: c.clue,
      disguiseType: c.disguise,
      x: c.x,
      z: c.z,
      yaw: 0,
      wearsNeckArmor: false,
      tunicColor: c.tunic,
      hatStyle: c.hat,
      patrolPts: c.pts
    }));
  });

  // 3. Spawn Lethal Syndicate Guards (Throw Torinawa Nets & Poison Kunai!)
  const guards = [
    { id: 'g_pier', name: 'Pemburu Jaring Kuro-no-Wa (Dermaga)', role: 'Penjaga Bersenjata Jaring', x: -3.2, z: -18, disguise: 'PEASANT', tunic: '#2b3a4a', hat: 'JINGASA' },
    { id: 'g_bridge', name: 'Samurai Penjaga Jembatan', role: 'Patroli Sungai Kurokawa', x: 2.5, z: -3, disguise: 'GUARD', tunic: '#22385c', hat: 'JINGASA' },
    { id: 'g_market', name: 'Pengawal Saudagar Timur', role: 'Penjaga Pasar Lentera', x: 11.5, z: 2, disguise: 'MERCHANT', tunic: '#3b2d54', hat: 'JINGASA' },
    { id: 'g_shrine', name: 'Ronin Bayaran Hutan Bambu', role: 'Penjaga Kuil Barat', x: -12.5, z: 4, disguise: 'MONK', tunic: '#4f3b22', hat: 'JINGASA' },
    { id: 'g_keep', name: 'Samurai Elit Pelindung Daimyo', role: 'Pengawal Benteng Tenshu', x: 3.5, z: 19, disguise: 'GUARD', tunic: '#1b263b', hat: 'KABUTO_GOLD', armor: true }
  ];

  guards.forEach(g => {
    worldState.npcs.push(new AnatomicalNPC({
      id: g.id,
      name: g.name,
      publicRole: 'Penjaga Bersenjata Sindikat',
      role: g.role,
      faction: 'SYNDICATE_GUARD',
      isTarget: false,
      hasWeapon: true,
      isIdentityInspected: true,
      dailyActivity: 'Berpatroli dengan Katana & Jaring Torinawa',
      secretClue: '⚔️ PENJAGA SINDIKAT: Bersenjata Katana, Kunai Beracun & Jaring Pengikat Kaki!',
      disguiseType: g.disguise,
      x: g.x,
      z: g.z,
      yaw: Math.PI,
      wearsNeckArmor: !!g.armor,
      tunicColor: g.tunic,
      hatStyle: g.hat,
      patrolPts: [{ x: g.x, z: g.z }, { x: g.x + 2.5, z: g.z + 1.5 }]
    }));
  });

  renderContractBoardUI();
}

function renderContractBoardUI() {
  const chapBox = document.getElementById('storyChapterBox');
  if (chapBox) {
    if (worldState.storyCompleted) {
      chapBox.innerHTML = `
        <div class="story-chapter-title">🏆 CERITA UTAMA TAMAT: LEMBAH KUROKAWA BEBAS!</div>
        <div class="story-chapter-desc">Kelima pemimpin Sindikat telah tumbang. Tekan [N] untuk mengulang kampanye!</div>
      `;
    } else {
      const chap = STORY_CHAPTERS[worldState.currentChapterIdx];
      chapBox.innerHTML = `
        <div class="story-chapter-title">📜 ${chap.title}</div>
        <div class="story-chapter-desc">${chap.clueHint}</div>
        <div class="story-chapter-obj">🔍 Cari di ${chap.districtName} & Tekan [I] Periksa Identitas!</div>
      `;
    }
  }

  const listEl = document.getElementById('contractList');
  if (!listEl) return;
  listEl.innerHTML = '';
  worldState.contracts.forEach((c, idx) => {
    const isCurrent = idx === worldState.currentChapterIdx && !worldState.storyCompleted && !c.done;
    const div = document.createElement('div');
    div.className = 'contract-card' + (c.done ? ' done' : '');
    if (isCurrent) div.style.borderColor = '#ffd54f';
    const armorBadge = c.wearsArmor ? '🛡️ Nodowa' : '🔍 Periksa [I]';
    div.innerHTML = `<strong>Babak ${c.chapterNum}: ${c.name}</strong> (${c.reward} Ryo)<br/><span>${c.role} • ${armorBadge}</span>`;
    listEl.appendChild(div);
  });
}

const TIME_ORDER = ['PAGI', 'SIANG', 'SORE', 'MALAM'];
function setTimeOfDay(key) {
  const preset = TIME_PRESETS[key];
  if (!preset) return;
  engine.timeOfDay = preset;
  buildExpandedKurokawaVillage();
  KageAudio.playTimeBell(preset.ambientFreq);
  worldState.showToast(`WAKTU BERUBAH: ${preset.label} — Visibilitas Penjaga ${(preset.visionMult * 100).toFixed(0)}%.`);

  TIME_ORDER.forEach(k => {
    const btn = document.getElementById('btnTime_' + k);
    if (btn) btn.classList.toggle('active', k === key);
  });
}

function cycleTimeOfDay() {
  const curIdx = TIME_ORDER.indexOf(engine.timeOfDay.id);
  const nextKey = TIME_ORDER[(curIdx + 1) % TIME_ORDER.length];
  setTimeOfDay(nextKey);
}

function lockAndFaceNearestNPC() {
  const p = worldState.parkour;
  const curChap = STORY_CHAPTERS[worldState.currentChapterIdx];
  let best = null;
  let bestDist = Infinity;

  worldState.npcs.forEach(npc => {
    if (npc.isDead) return;
    const d = Math.hypot(npc.x - p.x, npc.z - p.z);
    if (curChap && npc.storyChapterId === curChap.id && d < 32) {
      best = npc;
      bestDist = d;
    } else if (!best && d < bestDist) {
      bestDist = d;
      best = npc;
    }
  });

  if (best) {
    worldState.lockedTargetNpc = best;
    p.yaw = Math.atan2(best.x - p.x, best.z - p.z);
    p.pitch = 0;
    worldState.showToast(`🎯 MENGHADAP KE: ${best.isIdentityInspected ? best.name : best.publicRole} (Jarak: ${bestDist.toFixed(1)}m). Dekati & tekan [I] untuk cek petunjuk identitas!`);
  }
}

// ============================================================================
// Tactical Minimap Radar & Full Expanded Map Modal [Key M]
// ============================================================================
const minimapCanvas = document.getElementById('minimapCanvas');
const minimapCtx = minimapCanvas ? minimapCanvas.getContext('2d') : null;
const fullMapCanvas = document.getElementById('fullMapCanvas');
const fullMapCtx = fullMapCanvas ? fullMapCanvas.getContext('2d') : null;

function drawTacticalMapOnCanvas(ctx, w, h, isFullMap) {
  if (!ctx) return;
  const p = worldState.parkour;
  ctx.clearRect(0, 0, w, h);

  ctx.fillStyle = '#0c121c';
  ctx.fillRect(0, 0, w, h);

  ctx.strokeStyle = 'rgba(196, 164, 98, 0.14)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= w; i += w / 6) {
    ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, h); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0, i); ctx.lineTo(w, i); ctx.stroke();
  }

  const toMap = (wx, wz) => ({
    x: w * 0.5 + (wx / 82) * w,
    y: h * 0.52 - (wz / 82) * h
  });

  // River & South Lake
  const rLeft = toMap(-38, 0), rRight = toMap(38, 0);
  ctx.fillStyle = 'rgba(28, 92, 135, 0.55)';
  ctx.fillRect(rLeft.x, rLeft.y - 4, rRight.x - rLeft.x, 8);

  // Sacred Kurama Shrine Sanctuary Highlight (Gold-Red Torii Square at -25, -27)
  const shPt = toMap(-25, -27);
  ctx.fillStyle = 'rgba(214, 40, 40, 0.45)';
  ctx.fillRect(shPt.x - 10, shPt.y - 10, 20, 20);
  ctx.strokeStyle = '#ffd54f';
  ctx.strokeRect(shPt.x - 10, shPt.y - 10, 20, 20);

  // Stealth Bushes
  worldState.stealthBushes.forEach(b => {
    const pt = toMap(b.x, b.z);
    ctx.fillStyle = 'rgba(45, 106, 79, 0.65)';
    ctx.beginPath(); ctx.arc(pt.x, pt.y, isFullMap ? 5.5 : 3.2, 0, Math.PI * 2); ctx.fill();
  });

  // Structures
  worldState.structures.forEach(s => {
    if (!s.solidWall && !s.mapLabel) return;
    const pt = toMap(s.x, s.z);
    const sw = Math.max(4, (s.w / 82) * w);
    const sd = Math.max(4, (s.d / 82) * h);
    ctx.fillStyle = s.mapLabel ? 'rgba(196, 164, 98, 0.35)' : 'rgba(120, 130, 145, 0.40)';
    ctx.fillRect(pt.x - sw * 0.5, pt.y - sd * 0.5, sw, sd);
    if (isFullMap && s.mapLabel) {
      ctx.fillStyle = '#e5c378';
      ctx.font = 'bold 9.5px Segoe UI';
      ctx.textAlign = 'center';
      ctx.fillText(s.mapLabel, pt.x, pt.y - sd * 0.5 - 3);
    }
  });

  // NPCs (Uninspected civilians & targets appear as neutral Mystery Question Marks / Yellow dots until inspected!)
  const curChap = STORY_CHAPTERS[worldState.currentChapterIdx];
  worldState.npcs.forEach(npc => {
    if (npc.isBodyHidden) return;
    const pt = toMap(npc.x, npc.z);
    if (npc.isDead) {
      ctx.fillStyle = '#666';
      ctx.beginPath(); ctx.arc(pt.x, pt.y, 3.2, 0, Math.PI * 2); ctx.fill();
      return;
    }

    let dotColor = '#4ea8de'; // Guard
    if (!npc.isIdentityInspected) {
      dotColor = '#e0c078'; // Uninspected villager/suspect (must check clue with [I]!)
    } else if (npc.isTarget) {
      dotColor = '#ff3b3b'; // Confirmed Target!
    } else if (npc.isInnocent) {
      dotColor = '#80ed99'; // Confirmed Innocent Civilian / Allied Clan!
    }

    ctx.fillStyle = dotColor;
    ctx.beginPath();
    ctx.arc(pt.x, pt.y, (npc.isIdentityInspected && npc.isTarget) ? 6.0 : 4.2, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fff';
    ctx.lineWidth = 1;
    ctx.stroke();

    if (isFullMap) {
      const dist = Math.hypot(npc.x - p.x, npc.z - p.z).toFixed(0);
      const dispName = npc.isIdentityInspected ? npc.name : `❔ ${npc.publicRole}`;
      ctx.fillStyle = dotColor;
      ctx.font = '9.5px Segoe UI';
      ctx.textAlign = 'center';
      ctx.fillText(`${dispName} (${dist}m)`, pt.x, pt.y + 12);
    }
  });

  // Player Position
  const pPt = toMap(p.x, p.z);
  const pAngle = -Math.PI * 0.5 + p.yaw;
  ctx.fillStyle = 'rgba(100, 255, 160, 0.24)';
  ctx.beginPath();
  ctx.moveTo(pPt.x, pPt.y);
  ctx.arc(pPt.x, pPt.y, isFullMap ? 34 : 20, pAngle - 0.55, pAngle + 0.55);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = '#00e676';
  ctx.beginPath();
  ctx.arc(pPt.x, pPt.y, 5.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = '#fff';
  ctx.lineWidth = 1.5;
  ctx.stroke();
}

function toggleModal(modalId) {
  const el = document.getElementById(modalId);
  if (!el) return;
  const isHidden = el.style.display === 'none' || !el.style.display;
  el.style.display = isHidden ? 'flex' : 'none';
  if (!isHidden && canvas.focus) canvas.focus();
}

// ============================================================================
// Keyboard, Mouse & Button Bindings
// ============================================================================
const keys = {};
window.keys = keys;

function dismissOverlayIfVisible() {
  const ov = document.getElementById('startOverlay');
  if (ov && ov.style.display !== 'none') {
    KageAudio.init();
    KageAudio.startBGM();
    ov.style.display = 'none';
  }
}

function handleKeyDown(e) {
  if (e.code) keys[e.code] = true;
  if (e.key) {
    keys[e.key] = true;
    keys[e.key.toLowerCase()] = true;
  }

  if (['KeyW', 'KeyA', 'KeyS', 'KeyD', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code) ||
      ['w', 'a', 's', 'd', ' '].includes((e.key || '').toLowerCase())) {
    dismissOverlayIfVisible();
  }

  if (['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Tab', 'F1'].includes(e.code)) {
    e.preventDefault();
  }

  // If player is immobilized by an enemy net/chain, pressing Space or Q struggles to break free!
  if (worldState.parkour.immobilizedTimer > 0 && (e.code === 'Space' || e.code === 'KeyQ')) {
    if (worldState.parkour.struggleBreakFree()) {
      worldState.showToast('💥 IKATAN JARING TERPUTUS! Kamu berhasil membebaskan diri!');
    } else {
      worldState.showToast(`⛓️ Meronta melepaskan jaring... (${worldState.parkour.immobilizedTimer.toFixed(1)} dtk tersisa) — Tekan [Space]/[Q] lagi atau [L] Kaginawa!`);
    }
    return;
  }

  // [P] Toggle Japanese BGM
  if (e.code === 'KeyP') {
    const on = KageAudio.toggleBGM();
    const btnBgm = document.getElementById('btnBgmToggle');
    if (btnBgm) {
      btnBgm.textContent = on ? '🎵 [P] BGM: ON' : '🔇 [P] BGM: OFF';
      btnBgm.classList.toggle('active', on);
    }
    worldState.showToast(on ? '🎵 Musik Latar Jepang (Shamisen & Taiko BGM) Diaktifkan!' : '🔇 Musik Latar (BGM) Dimatikan.');
  }

  // [I] Inspect Identity & Clues of Nearest Person
  if (e.code === 'KeyI') {
    worldState.inspectNearestNpcIdentity(msg => worldState.showToast(msg));
  }

  // [L] Launch Kaginawa Grappling Hook onto Rooftops!
  if (e.code === 'KeyL') {
    worldState.parkour.launchKaginawaGrapple(worldState.structures, msg => worldState.showToast(msg));
  }

  if (e.code === 'KeyV') {
    const mode = worldState.parkour.toggleCameraMode();
    const btnCam = document.getElementById('btnCameraMode');
    if (btnCam) {
      btnCam.textContent = mode === 'THIRD_PERSON' ? '🎥 [V] 3rd Person' : '👁️ [V] 1st Person';
      btnCam.classList.toggle('active', mode === 'THIRD_PERSON');
    }
    worldState.showToast(mode === 'THIRD_PERSON'
      ? 'KAMERA 3RD-PERSON AKTIF: Menampilkan karakter Shinobi Ren secara utuh!'
      : 'KAMERA 1ST-PERSON AKTIF: Pandangan mata langsung.');
  }

  if (e.code === 'KeyT') cycleTimeOfDay();
  if (e.code === 'KeyM') toggleModal('mapModal');
  if (e.code === 'KeyJ') toggleModal('storyModal');
  if (e.code === 'KeyH' || e.code === 'Slash' || e.code === 'F1') toggleModal('helpModal');

  if (e.code === 'CapsLock') {
    worldState.parkour.sprintToggleLock = !worldState.parkour.sprintToggleLock;
    const btnSprint = document.getElementById('btnSprintToggle');
    if (btnSprint) btnSprint.classList.toggle('active', worldState.parkour.sprintToggleLock);
    worldState.showToast(worldState.parkour.sprintToggleLock
      ? '🏃 MODE LARI OTOMATIS (SPRINT LOCK) AKTIF!'
      : 'Mode Jalan Normal aktif.');
  }

  if (e.code === 'Tab') lockAndFaceNearestNPC();

  if (e.code === 'Digit1') { worldState.currentDisguise = DISGUISES.SHINOBI; worldState.bloodstainOnClothes = 0; worldState.showToast('Pakaian: Shinobi Hitam.'); }
  if (e.code === 'Digit2') { worldState.currentDisguise = DISGUISES.PEASANT; worldState.bloodstainOnClothes = 0; worldState.showToast('Menyamar sebagai: Nelayan / Petani Desa.'); }
  if (e.code === 'Digit3') { worldState.currentDisguise = DISGUISES.MERCHANT; worldState.bloodstainOnClothes = 0; worldState.showToast('Menyamar sebagai: Saudagar Pasar Timur.'); }
  if (e.code === 'Digit4') { worldState.currentDisguise = DISGUISES.MONK; worldState.bloodstainOnClothes = 0; worldState.showToast('Menyamar sebagai: Biksu Kuil Suci Kurama.'); }
  if (e.code === 'Digit5') { worldState.currentDisguise = DISGUISES.GUARD; worldState.bloodstainOnClothes = 0; worldState.showToast('Menyamar sebagai: Samurai Garnisun.'); }

  if (e.code === 'KeyB') {
    worldState.playerWeapon.isWeaponDrawn = !worldState.playerWeapon.isWeaponDrawn;
    worldState.showToast(worldState.playerWeapon.isWeaponDrawn ? 'Katana dihunus!' : 'Katana disembunyikan di sarung pinggang.');
  }
  if (e.code === 'KeyQ') {
    worldState.playerWeapon.performParryOrJujutsuDisarm(worldState, msg => worldState.showToast(msg));
  }
  if (e.code === 'KeyE') {
    worldState.playerWeapon.throwMetsubushi(worldState, msg => worldState.showToast(msg));
  }
  if (e.code === 'KeyK') {
    worldState.playerWeapon.throwKunai(worldState, window.lastNpcHitboxes || [], msg => worldState.showToast(msg));
  }
  if (e.code === 'KeyG') {
    worldState.playerWeapon.tryPickupDroppedWeapon(worldState, msg => worldState.showToast(msg));
  }
  if (e.code === 'KeyF') {
    worldState.playerWeapon.tryStealthChokeOrRipBlade(worldState, msg => worldState.showToast(msg));
  }
  if (e.code === 'KeyX') {
    worldState.toggleCarryOrHideBody(msg => worldState.showToast(msg));
  }
  if (e.code === 'KeyR') {
    worldState.playerBleedRate = 0;
    worldState.playerBloodVolume = Math.min(100, worldState.playerBloodVolume + 35);
    worldState.parkour.leftLegCrippled = false;
    worldState.parkour.rightLegCrippled = false;
    worldState.showToast('Luka pendarahan dibalut & darah pulih +35%!');
  }
  if (e.code === 'KeyN') {
    worldState.currentChapterIdx = 0;
    worldState.storyCompleted = false;
    worldState.clanConflict = 0;
    spawnStoryAndVillageNPCs();
    worldState.showToast('Kampanye Cerita, Warga Desa & Target Sindikat telah di-reset ulang!');
  }
}

function handleKeyUp(e) {
  if (e.code) keys[e.code] = false;
  if (e.key) {
    keys[e.key] = false;
    keys[e.key.toLowerCase()] = false;
  }
}

window.addEventListener('keydown', handleKeyDown, true);
window.addEventListener('keyup', handleKeyUp, true);

[
  ['keyVisW', 'KeyW'],
  ['keyVisA', 'KeyA'],
  ['keyVisS', 'KeyS'],
  ['keyVisD', 'KeyD'],
  ['keyVisShift', 'ShiftLeft'],
  ['keyVisSpace', 'Space']
].forEach(([elemId, keyCode]) => {
  const el = document.getElementById(elemId);
  if (!el) return;
  el.addEventListener('mousedown', e => { e.stopPropagation(); dismissOverlayIfVisible(); keys[keyCode] = true; });
  el.addEventListener('mouseup', e => { e.stopPropagation(); keys[keyCode] = false; });
  el.addEventListener('mouseleave', () => { keys[keyCode] = false; });
});

let isMouseDragging = false;
let lastClientX = null;
let lastClientY = null;

window.addEventListener('mousemove', e => {
  let dx = e.movementX || 0;
  let dy = e.movementY || 0;

  if (document.pointerLockElement !== canvas) {
    if (!isMouseDragging) {
      lastClientX = e.clientX;
      lastClientY = e.clientY;
      return;
    }
    if (lastClientX !== null && lastClientY !== null) {
      dx = e.clientX - lastClientX;
      dy = e.clientY - lastClientY;
    }
    lastClientX = e.clientX;
    lastClientY = e.clientY;
  }

  worldState.parkour.yaw += dx * 0.0028;
  worldState.parkour.pitch = Math.max(-1.35, Math.min(1.25, worldState.parkour.pitch - dy * 0.0026));
  worldState.playerWeapon.recordMouseMovement(dx, dy);
});

canvas.addEventListener('mousedown', e => {
  dismissOverlayIfVisible();
  isMouseDragging = true;
  lastClientX = e.clientX;
  lastClientY = e.clientY;

  if (document.pointerLockElement !== canvas && canvas.requestPointerLock) {
    try { canvas.requestPointerLock(); } catch (err) {}
  }

  if (e.button === 0) {
    worldState.playerWeapon.performPrimaryAttack(worldState, msg => worldState.showToast(msg));
  } else if (e.button === 2) {
    worldState.playerWeapon.performSecondaryPierce(worldState, msg => worldState.showToast(msg));
  }
});

window.addEventListener('mouseup', () => { isMouseDragging = false; });
window.addEventListener('contextmenu', e => e.preventDefault());

document.getElementById('btnStartGame').addEventListener('click', () => {
  dismissOverlayIfVisible();
  canvas.focus();
  if (canvas.requestPointerLock) {
    try { canvas.requestPointerLock(); } catch (err) {}
  }
});

document.getElementById('btnCameraMode').addEventListener('click', e => { e.stopPropagation(); handleKeyDown({ code: 'KeyV' }); });
document.getElementById('btnBgmToggle').addEventListener('click', e => { e.stopPropagation(); handleKeyDown({ code: 'KeyP' }); });
document.getElementById('btnInspectClue').addEventListener('click', e => { e.stopPropagation(); handleKeyDown({ code: 'KeyI' }); });
document.getElementById('btnGrappleHook').addEventListener('click', e => { e.stopPropagation(); handleKeyDown({ code: 'KeyL' }); });
document.getElementById('btnSprintToggle').addEventListener('click', e => { e.stopPropagation(); handleKeyDown({ code: 'CapsLock' }); });
document.getElementById('btnTargetLock').addEventListener('click', e => { e.stopPropagation(); lockAndFaceNearestNPC(); });
document.getElementById('btnOpenStory').addEventListener('click', e => { e.stopPropagation(); toggleModal('storyModal'); });
document.getElementById('btnOpenMap').addEventListener('click', e => { e.stopPropagation(); toggleModal('mapModal'); });
document.getElementById('btnOpenHelp').addEventListener('click', e => { e.stopPropagation(); toggleModal('helpModal'); });
if (minimapCanvas) {
  minimapCanvas.addEventListener('click', e => { e.stopPropagation(); toggleModal('mapModal'); });
}
TIME_ORDER.forEach(k => {
  const btn = document.getElementById('btnTime_' + k);
  if (btn) btn.addEventListener('click', e => { e.stopPropagation(); setTimeOfDay(k); });
});

window.teleportPlayerTo = function(tx, tz, label) {
  worldState.parkour.x = tx;
  worldState.parkour.y = 1.68;
  worldState.parkour.z = tz;
  worldState.parkour.immobilizedTimer = 0;
  document.getElementById('mapModal').style.display = 'none';
  document.getElementById('storyModal').style.display = 'none';
  worldState.showToast(`📍 Berpindah cepat ke: ${label} (${tx}, ${tz}).`);
};

buildExpandedKurokawaVillage();
spawnStoryAndVillageNPCs();

let lastTime = performance.now();

function gameLoop(now) {
  try {
    const dt = Math.min(0.05, Math.max(0.001, (now - lastTime) / 1000));
    lastTime = now;

    const parkour = worldState.parkour;
    const pw = worldState.playerWeapon;

    parkour.update(
      dt,
      keys,
      worldState.structures,
      worldState.stealthBushes,
      alertMsg => worldState.showToast(alertMsg),
      (noiseDb, origin) => {
        if (noiseDb >= 28) {
          worldState.npcs.forEach(npc => {
            if (!npc.isDead && !npc.isInnocent && Math.hypot(npc.x - origin.x, npc.z - origin.z) < noiseDb * 0.42) {
              npc.suspicion = Math.min(100, npc.suspicion + 32 * dt);
            }
          });
        }
      }
    );

    // Player arterial bleeding can also cause death & Shrine Respawn if untreated!
    if (worldState.playerBleedRate > 0) {
      worldState.playerBloodVolume = Math.max(0, worldState.playerBloodVolume - worldState.playerBleedRate * dt);
      if (worldState.playerBloodVolume <= 0) {
        worldState.triggerPlayerDeathAndShrineRespawn('Kehabisan darah akibat luka terbuka yang tidak diperban [R]!', msg => worldState.showToast(msg));
      }
    } else {
      worldState.playerBloodVolume = Math.min(100, worldState.playerBloodVolume + 2.2 * dt);
    }

    worldState.severedParts.forEach(sp => {
      if (sp.y > 0.14) {
        sp.vy -= 18 * dt;
        sp.x += sp.vx * dt;
        sp.y = Math.max(0.14, sp.y + sp.vy * dt);
        sp.z += sp.vz * dt;
      }
    });

    for (let i = worldState.bloodParticles.length - 1; i >= 0; i--) {
      const bp = worldState.bloodParticles[i];
      bp.life -= dt;
      if (bp.life <= 0) {
        worldState.bloodParticles.splice(i, 1);
        continue;
      }
      bp.vy -= 14 * dt;
      bp.x += bp.vx * dt;
      bp.y = Math.max(0.05, bp.y + bp.vy * dt);
      bp.z += bp.vz * dt;
    }

    const allShapes = [
      ...worldState.structures,
      ...worldState.bloodPools,
      ...worldState.severedParts,
      ...worldState.bloodParticles
    ];

    // Render 3D Incoming Enemy Projectiles (Torinawa Snare Nets & Poison Kunai)
    worldState.enemyProjectiles.forEach(proj => {
      if (proj.type === 'TORINAWA_NET') {
        allShapes.push({
          x: proj.x, y: proj.y, z: proj.z,
          w: 0.65, h: 0.15, d: 0.65,
          yaw: proj.yaw + now * 0.01,
          color: '#ffd54f',
          shape: 'cylinder',
          emissive: true
        });
      } else {
        allShapes.push({
          x: proj.x, y: proj.y, z: proj.z,
          w: 0.08, h: 0.08, d: 0.55,
          yaw: proj.yaw,
          color: '#ff4d4d',
          shape: 'box',
          emissive: true
        });
      }
    });

    // Render Kaginawa Grapple Rope if active
    if (parkour.activeGrappleLine) {
      const gl = parkour.activeGrappleLine;
      allShapes.push({
        x: (gl.x1 + gl.x2) * 0.5,
        y: (gl.y1 + gl.y2) * 0.5,
        z: (gl.z1 + gl.z2) * 0.5,
        w: 0.06, h: Math.abs(gl.y2 - gl.y1), d: 0.06,
        color: '#e5c378',
        emissive: true
      });
    }

    const playerMeshes = parkour.getThirdPersonPlayerMeshes(worldState.currentDisguise, pw);
    playerMeshes.forEach(pm => allShapes.push(pm));

    const npcHitboxes = [];
    const billboards = [];

    // Sacred Kurama Shrine Sanctuary Billboard
    billboards.push({
      x: -25, y: 4.8, z: -27,
      text: '⛩️ KUIL SUCI KURAMA (Tempat Respawn & Pemulihan)',
      subtext: 'Titik Kebangkitan Shinobi',
      color: '#ff9ebb'
    });

    worldState.droppedWeapons.forEach(dw => {
      allShapes.push({
        x: dw.x, y: dw.y, z: dw.z,
        w: 0.10, h: 0.06, d: 0.92,
        yaw: dw.yaw,
        color: '#ffe082',
        emissive: true
      });
      billboards.push({
        x: dw.x, y: dw.y + 0.55, z: dw.z,
        text: '⚔️ KATANA JATUH',
        subtext: 'Tekan [G] Pungut',
        color: '#ffe082'
      });
    });

    worldState.npcs.forEach(npc => {
      if (npc.isBodyHidden) return;
      const built = npc.buildCharacterMeshesAndHitboxes();
      built.hitboxes.forEach(hb => npcHitboxes.push(hb));
      built.visualMeshes.forEach(vm => allShapes.push(vm));

      const distToPlayer = Math.hypot(npc.x - parkour.x, npc.z - parkour.z).toFixed(1);

      if (npc.isDead) {
        if (parkour.carryingBodyNpc !== npc && distToPlayer < 9.0) {
          billboards.push({
            x: npc.x, y: 0.75, z: npc.z,
            text: npc.isChokedUnconscious ? `💤 ${npc.name} (Pingsan)` : `💀 Mayat ${npc.name}`,
            subtext: `Tekan [X] Angkat & Sembunyikan (${distToPlayer}m)`,
            color: '#b7efc5'
          });
        }
        return;
      }

      // Identity Mystery System: Until inspected with [I] (or close observation), targets & civilians show their public role & daily activity!
      let topTitle = '';
      let subLine = '';
      let tagColor = '#e8e6df';
      let isBeacon = false;

      if (!npc.isIdentityInspected) {
        topTitle = `❔ ${npc.publicRole} (${distToPlayer}m)`;
        subLine = `Aktivitas: ${npc.dailyActivity} • [Tekan I Selidiki]`;
        tagColor = '#f4d48c';
      } else if (npc.isInnocent) {
        topTitle = `🕊️ [WARGA TAK BERSALAH] ${npc.name} (${distToPlayer}m)`;
        subLine = `${npc.dailyActivity} • JANGAN DIBUNUH (Konflik Klan!)`;
        tagColor = '#80ed99';
      } else if (npc.isTarget) {
        topTitle = `🎯 [TARGET SINDIKAT TERBUKTI] ${npc.name} (${distToPlayer}m)`;
        subLine = `${npc.role}` + (npc.wearsNeckArmor ? ' [Nodowa Armor]' : ' [Bisa Cekik F / Tebas]');
        tagColor = '#ff5252';
        isBeacon = true;
      } else {
        topTitle = `⚔️ ${npc.name} (${distToPlayer}m)`;
        subLine = npc.aiState === 'COMBAT' ? '🕸️ MENYERANG & MELEMPAR JARING!' : npc.dailyActivity;
        tagColor = npc.aiState === 'COMBAT' ? '#ff5252' : '#90caf9';
      }

      if (npc.hasImpaledKatanaStuck) {
        subLine = `🗡️ PEDANG MENANCAP! (${distToPlayer}m) [Klik Kanan/F Cabut]`;
        tagColor = '#ffeb3b';
      }

      billboards.push({
        x: npc.x,
        y: npc.y + 2.18,
        z: npc.z,
        text: topTitle,
        subtext: subLine,
        color: tagColor,
        isStoryBeacon: isBeacon
      });
    });

    window.lastNpcHitboxes = npcHitboxes;

    const activeCam = parkour.getCameraState();
    const eyeOrigin = parkour.getEyePositionForRaycast();
    const fwd = parkour.getForwardVector();
    pw.update(dt, eyeOrigin, fwd, npcHitboxes, worldState.npcs);

    updateAllNPCs(dt, worldState, msg => worldState.showToast(msg));

    engine.renderScene(activeCam, allShapes, billboards);
    pw.drawFirstPersonViewmodel(engine.ctx, engine.width, engine.height, parkour, worldState.currentDisguise.color);

    drawTacticalMapOnCanvas(minimapCtx, 182, 182, false);
    if (document.getElementById('mapModal').style.display === 'flex') {
      drawTacticalMapOnCanvas(fullMapCtx, 480, 430, true);
    }

    updateHUD(parkour, pw);
  } catch (err) {
    console.error('Frame error recovered:', err);
  }
  requestAnimationFrame(gameLoop);
}

function updateHUD(parkour, pw) {
  let weaponText = `⚠️ TANGAN KOSONG! ([Q] Rebut Pedang / [G] Pungut)`;
  if (pw.impaledTargetNPC) {
    weaponText = `🗡️ MENANCAP DI ${pw.impaledTargetNPC.name.toUpperCase()} ([F] Cabut)`;
  } else if (pw.hasWeapon) {
    weaponText = pw.isWeaponDrawn
      ? `Katana (Grip: ${Math.round(pw.gripStability)}%) • Kunai [K]: ${pw.kunaiCount} • Kaginawa [L]`
      : `Katana Disimpan [B] • Kunai [K]: ${pw.kunaiCount} • Kaginawa [L]`;
  }
  document.getElementById('valWeapon').textContent = weaponText;
  document.getElementById('barGrip').style.width = `${pw.hasWeapon ? pw.gripStability : 0}%`;

  const speed = Math.hypot(parkour.vx, parkour.vz).toFixed(1);
  const immobBadge = parkour.immobilizedTimer > 0 ? `⛓️ TERIKAT JARING (${parkour.immobilizedTimer.toFixed(1)}s) • ` : '';
  const bushBadge = parkour.isHiddenInBush ? '🌿 SEMAK • ' : '';
  document.getElementById('valParkour').textContent = `${immobBadge}${bushBadge}${parkour.currentSurface} • ${speed} m/s`;
  document.getElementById('barStamina').style.width = `${parkour.gripStamina}%`;

  document.getElementById('valBlood').textContent = `Darah: ${Math.round(worldState.playerBloodVolume)}% | Respawn Kuil: ${worldState.shrineRespawnCount}x`;
  document.getElementById('barBlood').style.width = `${worldState.playerBloodVolume}%`;

  document.getElementById('valDisguise').textContent = `${worldState.currentDisguise.name}`;
  document.getElementById('valBloodstain').textContent = `Konflik Klan: ${worldState.clanConflict}% | Noda Darah: ${Math.round(worldState.bloodstainOnClothes)}% | ${worldState.totalRyo} Ryo`;

  document.getElementById('sprintLines').style.opacity = parkour.isSprinting ? '1' : '0';
  document.getElementById('bushStealthOverlay').style.opacity = parkour.isHiddenInBush ? '1' : '0';

  const immobBanner = document.getElementById('immobilizeBanner');
  if (immobBanner) {
    if (parkour.immobilizedTimer > 0) {
      immobBanner.style.display = 'block';
      immobBanner.textContent = `⛓️ ${parkour.immobilizedReason.toUpperCase()} (${parkour.immobilizedTimer.toFixed(1)} dtk) — Tekan [Space] / [Q] Berulang-ulang atau [L] Kaginawa untuk Lepas!`;
    } else {
      immobBanner.style.display = 'none';
    }
  }

  const setKeyClass = (id, active) => {
    const el = document.getElementById(id);
    if (el) el.classList.toggle('active', !!active);
  };
  setKeyClass('keyVisW', parkour.isKeyPressed(keys, ['KeyW', 'ArrowUp', 'w', 'W']));
  setKeyClass('keyVisA', parkour.isKeyPressed(keys, ['KeyA', 'a', 'A']));
  setKeyClass('keyVisS', parkour.isKeyPressed(keys, ['KeyS', 'ArrowDown', 's', 'S']));
  setKeyClass('keyVisD', parkour.isKeyPressed(keys, ['KeyD', 'd', 'D']));
  setKeyClass('keyVisShift', parkour.isSprinting);
  setKeyClass('keyVisSpace', !parkour.isGrounded);

  const promptEl = document.getElementById('anatomyPrompt');
  const stealthEl = document.getElementById('stealthPrompt');
  const impaleEl = document.getElementById('impaleBanner');
  const reticleEl = document.getElementById('crosshairReticle');

  if (pw.impaledTargetNPC) {
    impaleEl.style.display = 'block';
    impaleEl.textContent = `🗡️ PEDANG MENANCAP DI ${pw.impaledTargetNPC.name.toUpperCase()} — Tekan [Klik Kanan] atau [F] Cabut Paksa!`;
  } else {
    impaleEl.style.display = 'none';
  }

  if (pw.stealthChokeCandidate) {
    const cand = pw.stealthChokeCandidate;
    stealthEl.style.display = 'block';
    if (!cand.isIdentityInspected) {
      stealthEl.textContent = `🔍 [Tekan I] PERIKSA PETUNJUK IDENTITAS DULU (Jangan salah bunuh warga!)`;
    } else if (cand.isInnocent) {
      stealthEl.textContent = `🕊️ WARGA TAK BERSALAH (${cand.name}) — JANGAN DIBUNUH!`;
    } else {
      stealthEl.textContent = `🤫 [Tekan F] CEKIK SENYAP TARGET SAH: ${cand.name}`;
    }
  } else if (parkour.carryingBodyNpc) {
    stealthEl.style.display = 'block';
    stealthEl.textContent = parkour.isHiddenInBush
      ? `🌿 [Tekan X] SEMBUNYIKAN TUBUH ${parkour.carryingBodyNpc.name.toUpperCase()} DI SEMAK BAMBU!`
      : `🏋️ Membawa Tubuh ${parkour.carryingBodyNpc.name} — Bawa ke Semak Bambu / Sungai lalu tekan [X]`;
  } else {
    stealthEl.style.display = 'none';
  }

  if (pw.targetedHitbox) {
    promptEl.style.display = 'block';
    const d = Math.hypot(pw.targetedHitbox.x - parkour.x, pw.targetedHitbox.z - parkour.z).toFixed(1);
    promptEl.textContent = `🎯 [${d}m] ${pw.targetedHitbox.label}`;
    reticleEl.style.color = '#ff4d4d';
  } else {
    promptEl.style.display = 'none';
    reticleEl.style.color = 'rgba(240,240,240,0.88)';
  }

  const bloodAlpha = Math.max(0, (100 - worldState.playerBloodVolume) / 100) * 0.68;
  document.getElementById('bloodVignette').style.background =
    `radial-gradient(circle, transparent 45%, rgba(165, 10, 10, ${bloodAlpha.toFixed(2)}) 100%)`;
}

requestAnimationFrame(gameLoop);
