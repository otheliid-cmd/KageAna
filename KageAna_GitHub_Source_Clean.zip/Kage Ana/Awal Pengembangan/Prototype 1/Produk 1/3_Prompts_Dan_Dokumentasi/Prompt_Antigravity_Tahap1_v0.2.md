# Prompt Google Antigravity VS Code — Tahap 1 (v0.2): WASD 360°, Skeletal IK & Blade Impale

Salin prompt di bawah ini ke panel **Google Antigravity** di VS Code (gunakan perintah `/plan` dengan model **Gemini 4 Argon**):

```markdown
/plan Kita sekarang masuk ke Tahap 1 (v0.2) pengembangan game 3D First-Person Ninja "KAGE-ANA".
Tolong perbarui dan tingkatkan modul pergerakan WASD serta sistem visual/pertarungan anatomis dengan spesifikasi berikut:

1. Pergerakan WASD 360° & Parkour Taktis (`FirstPersonParkourController`):
   - Pastikan vektor pergerakan W (maju), S (mundur), A (kiri), dan D (kanan) dihitung secara presisi dari matriks yaw kamera dengan akselerasi/deselerasi mulus dan resolusi tabrakan terpisah pada sumbu X dan Z (wall-sliding agar karakter tidak tersangkut saat berjalan serong di dinding).
   - Tambahkan mekanik Shinobi Slide (Shift + Ctrl saat berlari) dan Tactical Corner Peeking (Z untuk miring intip kiri, X untuk miring intip kanan).

2. Visual Skeletal IK & Reaksi Anatomis (`AnatomicalDamageSystem`):
   - Tambahkan animasi prosedural tulang anggota tubuh (ayunan lengan & kaki saat patroli, kuda-kuda pedang saat bertarung).
   - Ketika lengan kanan musuh putus (`RightArm` severed), jalankan pose IK di mana lengan kiri musuh memegang tunggul bahu kanannya yang berdarah sambil melarikan diri.

3. Directional Slash & Pedang Menancap di Dada (`WeaponCombatAndDisarmController`):
   - Baca vektor gerakan mouse (`Mouse X`, `Mouse Y`) saat pemain menekan Klik Kiri untuk menentukan sudut tebasan (Horizontal, Diagonal, Vertikal) beserta efek jejak ayunan pedang.
   - Saat pemain melakukan Tusukan Tembus (Klik Kanan / Pierce) ke `ThoraxHeart` atau `Abdomen`, buat pedang menancap (`IsBladeImpaledInTarget = true`) di dada target. Pemain harus menekan Klik Kanan atau tombol `F` di dekat target untuk mencabut paksa pedang tersebut (yang langsung memicu semburan darah arteri dan kematian target).
```
