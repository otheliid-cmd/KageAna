using UnityEngine;
using System.Collections.Generic;
using KageAna.Core;
using KageAna.Combat;
using KageAna.Sandbox;
using KageAna.AI;
using KageAna.UI;

namespace KageAna.Bootstrap
{
    /// <summary>
    /// Otomatis membangun seluruh dunia 3D Feudal Sandbox, karakter Ninja First-Person,
    /// serta musuh dengan 8 hitbox anatomis begitu tombol Play ditekan di Unity!
    /// </summary>
    public static class KageAnaAutoSceneBootstrapper
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        private static void AutoBuildPlayableSandboxOnStart()
        {
            if (Object.FindObjectOfType<FirstPersonParkourController>() != null) return;

            // Hapus kamera bawaan agar tidak bentrok dengan Eye-Tracked First-Person Camera
            foreach (var cam in Object.FindObjectsOfType<Camera>())
            {
                Object.Destroy(cam.gameObject);
            }

            BuildFeudalSandboxEnvironment();
            var sandboxMgr = CreateSandboxManager();
            var player = CreateFirstPersonPlayerNinja();
            SpawnEnemiesAndTargets(sandboxMgr);

            var hudObj = new GameObject("KageAna_DiegeticHUD");
            var hud = hudObj.AddComponent<DiegeticFeedbackHUD>();
            hud.PlayerParkour = player.GetComponent<FirstPersonParkourController>();
            hud.PlayerAnatomy = player.GetComponent<AnatomicalDamageSystem>();
            hud.PlayerWeapon = player.GetComponent<WeaponCombatAndDisarmController>();
            hud.SandboxManager = sandboxMgr;
        }

        private static void BuildFeudalSandboxEnvironment()
        {
            GameObject envRoot = new GameObject("FeudalDistrict_Environment");

            // Pencahayaan Malam/Senja Feodal
            if (Object.FindObjectOfType<Light>() == null)
            {
                GameObject lightObj = new GameObject("Moonlight_Directional");
                Light l = lightObj.AddComponent<Light>();
                l.type = LightType.Directional;
                l.color = new Color(0.75f, 0.82f, 0.95f);
                l.intensity = 1.1f;
                lightObj.transform.rotation = Quaternion.Euler(45f, -35f, 0f);
            }

            // Lantai Dasar Kerikil & Batu
            CreateSurfaceBlock("Ground_GravelCourtyard", new Vector3(0f, -0.5f, 0f), new Vector3(90f, 1f, 90f), new Color(0.24f, 0.24f, 0.26f), envRoot.transform);
            CreateSurfaceBlock("Path_TatamiSafehouse", new Vector3(0f, 0.02f, -12f), new Vector3(8f, 0.1f, 8f), new Color(0.45f, 0.42f, 0.25f), envRoot.transform);

            // Bangunan Kayu & Atap Genteng Miring untuk Parkour Berhitung
            CreateBuildingWithRoof("WestHouse", new Vector3(-12f, 0f, 8f), new Vector3(8f, 4.2f, 12f), false, envRoot.transform);
            CreateBuildingWithRoof("EastHouse_WetRoof", new Vector3(12f, 0f, 8f), new Vector3(8f, 4.2f, 12f), true, envRoot.transform);
            CreateBuildingWithRoof("InnerKeep_Watchtower", new Vector3(0f, 0f, 22f), new Vector3(14f, 6.0f, 10f), false, envRoot.transform);

            // Jembatan Kayu & Balok Parkour
            CreateSurfaceBlock("ParkourBeam_Wood", new Vector3(0f, 4.1f, 8f), new Vector3(16f, 0.25f, 1.2f), new Color(0.38f, 0.25f, 0.15f), envRoot.transform);
            CreateSurfaceBlock("SteppingWall_Wood", new Vector3(-6f, 1.5f, 0f), new Vector3(1.5f, 3.0f, 4f), new Color(0.35f, 0.24f, 0.14f), envRoot.transform);
        }

        private static void CreateBuildingWithRoof(string name, Vector3 pos, Vector3 size, bool isWetRoof, Transform parent)
        {
            CreateSurfaceBlock($"{name}_WoodWalls", pos + new Vector3(0f, size.y * 0.5f, 0f), size, new Color(0.32f, 0.22f, 0.14f), parent);

            string roofSurfaceTag = isWetRoof ? "WetRoof" : "ClayTile";
            Color roofColor = isWetRoof ? new Color(0.15f, 0.22f, 0.28f) : new Color(0.22f, 0.22f, 0.25f);

            GameObject roofLeft = CreateSurfaceBlock($"{name}_{roofSurfaceTag}_SlopeL", pos + new Vector3(-size.x * 0.28f, size.y + 0.8f, 0f), new Vector3(size.x * 0.65f, 0.25f, size.z + 1.2f), roofColor, parent);
            roofLeft.transform.rotation = Quaternion.Euler(0f, 0f, 24f);

            GameObject roofRight = CreateSurfaceBlock($"{name}_{roofSurfaceTag}_SlopeR", pos + new Vector3(size.x * 0.28f, size.y + 0.8f, 0f), new Vector3(size.x * 0.65f, 0.25f, size.z + 1.2f), roofColor, parent);
            roofRight.transform.rotation = Quaternion.Euler(0f, 0f, -24f);
        }

        private static GameObject CreateSurfaceBlock(string name, Vector3 pos, Vector3 scale, Color color, Transform parent)
        {
            GameObject block = GameObject.CreatePrimitive(PrimitiveType.Cube);
            block.name = name;
            block.transform.SetParent(parent);
            block.transform.position = pos;
            block.transform.localScale = scale;
            Renderer r = block.GetComponent<Renderer>();
            if (r != null) r.material.color = color;
            return block;
        }

        private static SocialStealthAndSandboxManager CreateSandboxManager()
        {
            GameObject obj = new GameObject("KageAna_SandboxAndStealthManager");
            return obj.AddComponent<SocialStealthAndSandboxManager>();
        }

        private static GameObject CreateFirstPersonPlayerNinja()
        {
            GameObject player = new GameObject("PlayerNinja_FirstPerson");
            player.transform.position = new Vector3(0f, 1.1f, -12f);

            CharacterController cc = player.AddComponent<CharacterController>();
            cc.height = 1.8f;
            cc.radius = 0.38f;
            cc.center = new Vector3(0f, 0.9f, 0f);

            GameObject headBone = new GameObject("HeadBone");
            headBone.transform.SetParent(player.transform);
            headBone.transform.localPosition = new Vector3(0f, 1.65f, 0f);

            GameObject camObj = new GameObject("FirstPersonEyeCamera");
            camObj.transform.SetParent(player.transform);
            camObj.transform.localPosition = new Vector3(0f, 1.65f, 0f);
            Camera cam = camObj.AddComponent<Camera>();
            cam.fieldOfView = 78f;
            cam.nearClipPlane = 0.08f;

            // Visual Katana di tangan kanan First-Person
            GameObject handSocket = new GameObject("RightHandWeaponSocket");
            handSocket.transform.SetParent(camObj.transform);
            handSocket.transform.localPosition = new Vector3(0.32f, -0.26f, 0.55f);

            GameObject katanaMesh = GameObject.CreatePrimitive(PrimitiveType.Cube);
            katanaMesh.name = "EquippedKatanaMesh";
            Object.Destroy(katanaMesh.GetComponent<Collider>());
            katanaMesh.transform.SetParent(handSocket.transform);
            katanaMesh.transform.localPosition = new Vector3(0f, 0f, 0.35f);
            katanaMesh.transform.localScale = new Vector3(0.04f, 0.04f, 0.85f);
            katanaMesh.GetComponent<Renderer>().material.color = new Color(0.85f, 0.88f, 0.92f);

            var parkour = player.AddComponent<FirstPersonParkourController>();
            parkour.CameraMount = camObj.transform;
            parkour.HeadBone = headBone.transform;

            var anatomy = player.AddComponent<AnatomicalDamageSystem>();
            foreach (BodyPartType part in System.Enum.GetValues(typeof(BodyPartType)))
            {
                anatomy.BodyZones.Add(new AnatomicalZoneState { Part = part });
            }

            var weaponCtrl = player.AddComponent<WeaponCombatAndDisarmController>();
            weaponCtrl.EquippedWeaponObject = katanaMesh;
            weaponCtrl.WeaponHandSocket = handSocket.transform;
            weaponCtrl.EyeCameraTransform = camObj.transform;
            weaponCtrl.IsPlayerControlled = true;

            return player;
        }

        private static void SpawnEnemiesAndTargets(SocialStealthAndSandboxManager sandboxMgr)
        {
            SpawnAnatomicalNPC("Lord Takamori (Target Kontrak)", new Vector3(0f, 0f, 14f), true, false);
            SpawnAnatomicalNPC("Magistrate Gendo (Target Kontrak)", new Vector3(-9f, 0f, 5f), true, false);
            SpawnAnatomicalNPC("Captain Hanzaburo (Target Pelindung Leher)", new Vector3(9f, 0f, 12f), true, true);

            SpawnAnatomicalNPC("Penjaga Samurai #1", new Vector3(-4f, 0f, 3f), false, false);
            SpawnAnatomicalNPC("Penjaga Samurai #2", new Vector3(5f, 0f, 4f), false, false);
        }

        private static GameObject SpawnAnatomicalNPC(string npcName, Vector3 pos, bool isTarget, bool hasNeckArmor)
        {
            GameObject npc = new GameObject(npcName);
            npc.transform.position = pos;

            var anatomy = npc.AddComponent<AnatomicalDamageSystem>();
            var weaponCtrl = npc.AddComponent<WeaponCombatAndDisarmController>();
            weaponCtrl.IsPlayerControlled = false;

            Color tunicColor = isTarget ? new Color(0.55f, 0.15f, 0.18f) : new Color(0.18f, 0.25f, 0.42f);
            Color skinColor = new Color(0.85f, 0.72f, 0.6f);

            // Rakit 8 Zona Hitbox Anatomis 3D yang bisa ditebas/ditusuk/diputus
            CreateHitboxPart(npc, anatomy, BodyPartType.ThoraxHeart, new Vector3(0f, 1.25f, 0f), new Vector3(0.46f, 0.45f, 0.26f), tunicColor, false);
            CreateHitboxPart(npc, anatomy, BodyPartType.Abdomen, new Vector3(0f, 0.88f, 0f), new Vector3(0.42f, 0.32f, 0.24f), tunicColor, false);
            CreateHitboxPart(npc, anatomy, BodyPartType.Neck, new Vector3(0f, 1.54f, 0f), new Vector3(0.18f, 0.14f, 0.18f), hasNeckArmor ? Color.gray : skinColor, hasNeckArmor);
            CreateHitboxPart(npc, anatomy, BodyPartType.Head, new Vector3(0f, 1.74f, 0f), new Vector3(0.28f, 0.28f, 0.28f), skinColor, false);

            GameObject rightArm = CreateHitboxPart(npc, anatomy, BodyPartType.RightArm, new Vector3(0.36f, 1.2f, 0.1f), new Vector3(0.16f, 0.55f, 0.16f), skinColor, false);
            CreateHitboxPart(npc, anatomy, BodyPartType.LeftArm, new Vector3(-0.36f, 1.2f, 0f), new Vector3(0.16f, 0.55f, 0.16f), skinColor, false);
            CreateHitboxPart(npc, anatomy, BodyPartType.RightLeg, new Vector3(0.14f, 0.42f, 0f), new Vector3(0.18f, 0.75f, 0.18f), new Color(0.15f, 0.15f, 0.18f), false);
            CreateHitboxPart(npc, anatomy, BodyPartType.LeftLeg, new Vector3(-0.14f, 0.42f, 0f), new Vector3(0.18f, 0.75f, 0.18f), new Color(0.15f, 0.15f, 0.18f), false);

            // Pedang di tangan kanan NPC
            GameObject npcSword = GameObject.CreatePrimitive(PrimitiveType.Cube);
            npcSword.name = "GuardKatana";
            Object.Destroy(npcSword.GetComponent<Collider>());
            npcSword.transform.SetParent(rightArm.transform);
            npcSword.transform.localPosition = new Vector3(0f, -0.35f, 0.45f);
            npcSword.transform.localScale = new Vector3(0.3f, 0.12f, 3.2f);
            npcSword.GetComponent<Renderer>().material.color = new Color(0.85f, 0.85f, 0.9f);

            weaponCtrl.EquippedWeaponObject = npcSword;
            weaponCtrl.WeaponHandSocket = rightArm.transform;

            var ai = npc.AddComponent<TacticalGuardAIController>();
            ai.CharacterDisplayName = npcName;
            ai.IsAssassinationTarget = isTarget;
            ai.PatrolWaypoints = new Vector3[]
            {
                pos,
                pos + new Vector3(4f, 0f, 0f),
                pos + new Vector3(4f, 0f, 4f),
                pos + new Vector3(0f, 0f, 4f)
            };

            return npc;
        }

        private static GameObject CreateHitboxPart(
            GameObject parentNpc,
            AnatomicalDamageSystem anatomy,
            BodyPartType partType,
            Vector3 localPos,
            Vector3 scale,
            Color color,
            bool hasArmor)
        {
            PrimitiveType prim = partType == BodyPartType.Head ? PrimitiveType.Sphere : PrimitiveType.Cube;
            GameObject partObj = GameObject.CreatePrimitive(prim);
            partObj.name = $"Hitbox_{partType}";
            partObj.transform.SetParent(parentNpc.transform);
            partObj.transform.localPosition = localPos;
            partObj.transform.localScale = scale;

            Renderer r = partObj.GetComponent<Renderer>();
            if (r != null) r.material.color = color;

            var hb = partObj.AddComponent<AnatomicalHitboxCollider>();
            hb.ZoneType = partType;
            hb.ParentAnatomy = anatomy;

            anatomy.BodyZones.Add(new AnatomicalZoneState
            {
                Part = partType,
                VisualBone = partObj.transform,
                HasArmorProtection = hasArmor,
                ArmorHardness = hasArmor ? 9.5f : 0f
            });

            return partObj;
        }
    }
}
