using UnityEngine;
using System;
using System.Collections.Generic;

namespace KageAna.Sandbox
{
    [Serializable]
    public class StoryChapterMission
    {
        public int ChapterNumber;
        public string ChapterTitle;
        public string TargetName;
        public string DistrictName;
        public string NarrativeBriefing;
        public Vector3 TargetSpawnPosition;
        public bool TargetWearsNodowaArmor;
        public int RewardRyo;
        public bool IsCompleted;
    }

    public class StealthTakedownAndStoryManager : MonoBehaviour
    {
        [Header("Stage 3: Stealth Choke, Corpse Hiding & Bush Cover")]
        public Transform PlayerTransform;
        public float StealthChokeRange = 3.2f;
        public float CorpseCarrySpeedMultiplier = 0.72f;
        public bool IsPlayerHiddenInBambooBush = false;
        public GameObject CarriedCorpseObject = null;
        public int TotalBodiesHidden = 0;

        [Header("Stage 3: 5-Chapter Kurokawa Village Story Campaign")]
        public int CurrentChapterIndex = 0;
        public List<StoryChapterMission> CampaignChapters = new List<StoryChapterMission>
        {
            new StoryChapterMission {
                ChapterNumber = 1,
                ChapterTitle = "Babak 1: Pajak Darah di Dermaga Selatan",
                TargetName = "Inspektur Pajak Jinbei",
                DistrictName = "Dermaga Nelayan Selatan",
                NarrativeBriefing = "Lumpuhkan Inspektur Jinbei di Dermaga Selatan dan sembunyikan jasadnya di Semak Bambu.",
                TargetSpawnPosition = new Vector3(0f, 0f, -15f),
                TargetWearsNodowaArmor = false,
                RewardRyo = 300
            },
            new StoryChapterMission {
                ChapterNumber = 2,
                ChapterTitle = "Babak 2: Bisikan di Pasar Lentera Timur",
                TargetName = "Saudagar Mesiu Gendo",
                DistrictName = "Pasar Lentera Timur",
                NarrativeBriefing = "Menyamarlah masuk ke Pasar Lentera Timur untuk menghentikan pemasok mesiu Sindikat Kuro-no-Wa.",
                TargetSpawnPosition = new Vector3(15f, 0f, 4f),
                TargetWearsNodowaArmor = false,
                RewardRyo = 420
            },
            new StoryChapterMission {
                ChapterNumber = 3,
                ChapterTitle = "Babak 3: Sumpah Palsu di Kuil Bukit Barat",
                TargetName = "Biksu Pengkhianat Ryuzen",
                DistrictName = "Kuil Bukit & Hutan Bambu Barat",
                NarrativeBriefing = "Menyelinap melewati Hutan Bambu Barat dan bungkam informan sindikat di Kuil Bukit.",
                TargetSpawnPosition = new Vector3(-16f, 0f, 8f),
                TargetWearsNodowaArmor = false,
                RewardRyo = 500
            },
            new StoryChapterMission {
                ChapterNumber = 4,
                ChapterTitle = "Babak 4: Baja Berkarat di Gerbang Barak",
                TargetName = "Kapten Garnisun Hanzaburo",
                DistrictName = "Pelataran Barak Utara",
                NarrativeBriefing = "Hanzaburo memakai pelindung leher Nodowa. Tusuk jantungnya atau tebas lengan kanannya.",
                TargetSpawnPosition = new Vector3(0f, 0f, 14f),
                TargetWearsNodowaArmor = true,
                RewardRyo = 650
            },
            new StoryChapterMission {
                ChapterNumber = 5,
                ChapterTitle = "Babak 5: Bayangan Terakhir di Benteng Tenshu",
                TargetName = "Daimyo Lord Takamori",
                DistrictName = "Benteng Agung Tenshu Utara",
                NarrativeBriefing = "Infiltrasi puncak ke Benteng Agung Tenshu untuk menumbangkan pemimpin tertinggi Sindikat Kuro-no-Wa.",
                TargetSpawnPosition = new Vector3(0f, 0f, 23f),
                TargetWearsNodowaArmor = true,
                RewardRyo = 1000
            }
        };

        public event Action<string> OnNarrativeNotification;

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.X))
            {
                ToggleCarryOrHideCorpse();
            }
        }

        public void ToggleCarryOrHideCorpse()
        {
            if (CarriedCorpseObject != null)
            {
                if (IsPlayerHiddenInBambooBush)
                {
                    CarriedCorpseObject.SetActive(false);
                    CarriedCorpseObject = null;
                    TotalBodiesHidden++;
                    OnNarrativeNotification?.Invoke("Mayat berhasil disembunyikan di dalam Semak Bambu! Aman dari patroli penjaga.");
                }
                else
                {
                    CarriedCorpseObject.transform.SetParent(null);
                    CarriedCorpseObject = null;
                    OnNarrativeNotification?.Invoke("Tubuh diletakkan di tanah. Bawa ke Semak Bambu atau Sungai untuk menyembunyikannya.");
                }
            }
        }

        public void AdvanceStoryChapter(string eliminatedTargetName)
        {
            if (CurrentChapterIndex < CampaignChapters.Count)
            {
                var current = CampaignChapters[CurrentChapterIndex];
                if (eliminatedTargetName.Contains(current.TargetName))
                {
                    current.IsCompleted = true;
                    CurrentChapterIndex++;
                    OnNarrativeNotification?.Invoke($"Misi Selesai: {current.ChapterTitle}!");
                }
            }
        }
    }
}
