using UnityEngine;
using KageAna.Core;
using KageAna.Combat;
using KageAna.Sandbox;

namespace KageAna.UI
{
    public class DiegeticFeedbackHUD : MonoBehaviour
    {
        public FirstPersonParkourController PlayerParkour;
        public AnatomicalDamageSystem PlayerAnatomy;
        public WeaponCombatAndDisarmController PlayerWeapon;
        public SocialStealthAndSandboxManager SandboxManager;

        private string _lastCombatAlert = "Siap menyusup. Bidik bagian tubuh spesifik (Kepala, Dada, Tangan, Kaki).";
        private float _alertTimer = 8f;

        private void Start()
        {
            if (PlayerParkour != null)
            {
                PlayerParkour.OnParkourRiskTriggered += ShowAlert;
            }
            if (PlayerAnatomy != null)
            {
                PlayerAnatomy.OnAnatomicalTrauma += (part, strike, msg) => ShowAlert($"[TRAUMA TUBUH] {msg}");
                PlayerAnatomy.OnLethalElimination += (msg) => ShowAlert($"[GUGUR] {msg}");
            }
            if (PlayerWeapon != null)
            {
                PlayerWeapon.OnCombatLogMessage += ShowAlert;
            }
            if (SandboxManager != null)
            {
                SandboxManager.OnSandboxNotification += ShowAlert;
            }
        }

        private void ShowAlert(string msg)
        {
            _lastCombatAlert = msg;
            _alertTimer = 6.5f;
        }

        private void Update()
        {
            if (_alertTimer > 0f) _alertTimer -= Time.deltaTime;
        }

        private void OnGUI()
        {
            // Crosshair Presisi & Indikator Target Anatomis di tengah layar
            float cx = Screen.width * 0.5f;
            float cy = Screen.height * 0.5f;
            GUI.color = (PlayerWeapon != null && PlayerWeapon.HasValidAnatomicalTarget) ? Color.red : new Color(0.9f, 0.9f, 0.9f, 0.8f);
            GUI.Label(new Rect(cx - 8, cy - 10, 40, 25), "[ + ]");

            if (PlayerWeapon != null && PlayerWeapon.HasValidAnatomicalTarget)
            {
                GUIStyle targetStyle = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, fontSize = 14 };
                GUI.Label(new Rect(cx + 18, cy - 10, 320, 30), $"BIDIK ANATOMI: {PlayerWeapon.CurrentlyAimedBodyPart}", targetStyle);
            }

            // Panel Status Diegetik (Tanpa HP Bar tradisional)
            GUI.color = new Color(0f, 0f, 0f, 0.72f);
            GUI.Box(new Rect(16, 16, 430, 195), "");
            GUI.color = Color.white;

            GUIStyle header = new GUIStyle(GUI.skin.label) { fontStyle = FontStyle.Bold, fontSize = 14 };
            GUI.Label(new Rect(28, 22, 400, 24), "KAGE-ANA | SIMULASI ANATOMI, PARKOUR & STEALTH", header);

            if (PlayerAnatomy != null && PlayerParkour != null && PlayerWeapon != null && SandboxManager != null)
            {
                string weaponState = PlayerWeapon.HasWeaponEquipped
                    ? $"Katana Siap (Grip Stability: {PlayerWeapon.CurrentGripStability:F0}%)"
                    : "TANGAN KOSONG / DARURAT (Tekan [G] Pungut / [E] Metsubushi)";

                GUI.Label(new Rect(28, 48, 400, 22), $"Senjata: {weaponState}");
                GUI.Label(new Rect(28, 70, 400, 22), $"Parkour Grip Stamina: {PlayerParkour.CurrentGripStamina:F0}% | Permukaan: {PlayerParkour.CurrentSurface} ({PlayerParkour.CurrentNoiseDb:F0} dB)");
                GUI.Label(new Rect(28, 92, 400, 22), $"Volume Darah Sirkulasi: {PlayerAnatomy.TotalBloodVolume:F0}% (Bukan HP Bar)");
                GUI.Label(new Rect(28, 114, 400, 22), $"Penyamaran [1-4]: {SandboxManager.CurrentDisguise} | Noda Darah Baju: {SandboxManager.BloodstainLevelOnClothes:F0}%");
                GUI.Label(new Rect(28, 136, 400, 22), $"District Heat: {SandboxManager.DistrictAlertHeat:F0}% | Ryo: {SandboxManager.TotalRyoEarned} | Metsubushi [E]: {PlayerWeapon.MetsubushiSmokeCharges}");
                GUI.Label(new Rect(28, 160, 400, 40), "[LMB] Tebas (Penggal/Putus Tangan) | [RMB] Tusuk Dada/Jantung | [Q] Tangkis | [H] Sembunyikan Pedang");
            }

            // Papan Kontrak Sandbox di Kanan Atas
            if (SandboxManager != null)
            {
                GUI.color = new Color(0f, 0f, 0f, 0.72f);
                GUI.Box(new Rect(Screen.width - 350, 16, 334, 150), "");
                GUI.color = new Color(1f, 0.85f, 0.4f);
                GUI.Label(new Rect(Screen.width - 338, 22, 310, 24), "KONTRAK SANDBOX AKTIF (NON-STORY):", header);
                GUI.color = Color.white;

                int y = 48;
                foreach (var c in SandboxManager.ActiveBoardContracts)
                {
                    string status = c.IsCompleted ? "[TEWAS]" : "[TARGET]";
                    string armor = c.TargetWearsNeckArmor ? "(Pelindung Leher)" : "(Tanpa Pelindung)";
                    GUI.Label(new Rect(Screen.width - 338, y, 320, 22), $"{status} {c.TargetName} - {armor} [{c.RewardRyo} Ryo]");
                    y += 24;
                }
                if (GUI.Button(new Rect(Screen.width - 338, 128, 220, 26), "Ambil Kontrak Baru (Prosedural)"))
                {
                    SandboxManager.GenerateProceduralContractBatch(3);
                }
            }

            // Notifikasi Dampak Serangan / Parkour di Bawah Layar
            if (_alertTimer > 0f)
            {
                GUI.color = new Color(0.15f, 0.02f, 0.02f, 0.85f);
                GUI.Box(new Rect(Screen.width * 0.5f - 310, Screen.height - 75, 620, 45), "");
                GUI.color = new Color(1f, 0.75f, 0.3f);
                GUIStyle alertStyle = new GUIStyle(GUI.skin.label) { alignment = TextAnchor.MiddleCenter, fontStyle = FontStyle.Bold, fontSize = 13 };
                GUI.Label(new Rect(Screen.width * 0.5f - 300, Screen.height - 72, 600, 40), _lastCombatAlert, alertStyle);
            }
        }
    }
}
