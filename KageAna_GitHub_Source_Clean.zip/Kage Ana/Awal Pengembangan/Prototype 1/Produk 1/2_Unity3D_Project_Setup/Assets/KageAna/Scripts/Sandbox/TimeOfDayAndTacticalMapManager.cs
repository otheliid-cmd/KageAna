using UnityEngine;

namespace KageAna.Sandbox
{
    public enum TimeOfDayPreset { Pagi, Siang, Sore, Malam }

    public class TimeOfDayAndTacticalMapManager : MonoBehaviour
    {
        public Light DirectionalSunLight;
        public TimeOfDayPreset CurrentTime = TimeOfDayPreset.Sore;
        public bool IsMapOpen = false;
        public bool IsHelpOverlayOpen = false;

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.T))
            {
                CycleTimeOfDay();
            }
            if (Input.GetKeyDown(KeyCode.M))
            {
                IsMapOpen = !IsMapOpen;
            }
            if (Input.GetKeyDown(KeyCode.H) || Input.GetKeyDown(KeyCode.F1))
            {
                IsHelpOverlayOpen = !IsHelpOverlayOpen;
            }
        }

        public void CycleTimeOfDay()
        {
            CurrentTime = (TimeOfDayPreset)(((int)CurrentTime + 1) % 4);
            ApplyLightingPreset();
        }

        private void ApplyLightingPreset()
        {
            if (DirectionalSunLight == null) return;
            switch (CurrentTime)
            {
                case TimeOfDayPreset.Pagi:
                    DirectionalSunLight.color = new Color(1.0f, 0.85f, 0.65f);
                    DirectionalSunLight.intensity = 0.9f;
                    DirectionalSunLight.transform.rotation = Quaternion.Euler(22f, 45f, 0f);
                    break;
                case TimeOfDayPreset.Siang:
                    DirectionalSunLight.color = new Color(1.0f, 0.98f, 0.90f);
                    DirectionalSunLight.intensity = 1.25f;
                    DirectionalSunLight.transform.rotation = Quaternion.Euler(68f, 15f, 0f);
                    break;
                case TimeOfDayPreset.Sore:
                    DirectionalSunLight.color = new Color(1.0f, 0.52f, 0.28f);
                    DirectionalSunLight.intensity = 0.8f;
                    DirectionalSunLight.transform.rotation = Quaternion.Euler(14f, -55f, 0f);
                    break;
                case TimeOfDayPreset.Malam:
                    DirectionalSunLight.color = new Color(0.55f, 0.68f, 0.95f);
                    DirectionalSunLight.intensity = 0.35f;
                    DirectionalSunLight.transform.rotation = Quaternion.Euler(42f, -120f, 0f);
                    break;
            }
        }
    }
}
