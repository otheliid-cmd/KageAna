using UnityEngine;
using System;
using KageAna.Sandbox;

namespace KageAna.Combat
{
    public enum CombatStance { ArmedBlade, UnarmedGrapple, EscapePanic }

    public class WeaponCombatAndDisarmController : MonoBehaviour
    {
        [Header("Equipped Weapon & Grip Physics")]
        public GameObject EquippedWeaponObject;
        public Transform WeaponHandSocket;
        public float WeaponSharpness = 1.65f;
        public float MaxGripStability = 100f;
        public float CurrentGripStability = 100f;
        public int MetsubushiSmokeCharges = 3;

        [Header("Combat Reach & Detection")]
        public Transform EyeCameraTransform;
        public float BladeReach = 2.35f;
        public float UnarmedReach = 1.65f;
        public bool IsPlayerControlled = true;

        public CombatStance CurrentStance { get; private set; } = CombatStance.ArmedBlade;
        public bool HasWeaponEquipped => EquippedWeaponObject != null && EquippedWeaponObject.activeSelf;
        public BodyPartType CurrentlyAimedBodyPart { get; private set; }
        public bool HasValidAnatomicalTarget { get; private set; }

        public event Action<string> OnWeaponDisarmed;
        public event Action<CombatStance> OnStanceChanged;
        public event Action<string> OnCombatLogMessage;

        private AnatomicalDamageSystem _selfAnatomy;
        private SocialStealthAndSandboxManager _stealthManager;
        private float _swingAnimTimer;

        private void Awake()
        {
            _selfAnatomy = GetComponent<AnatomicalDamageSystem>();
            _stealthManager = FindObjectOfType<SocialStealthAndSandboxManager>();
            if (_selfAnatomy != null)
            {
                _selfAnatomy.OnForceDropWeapon += () => ForceDisarmWeapon(transform.forward * 2.2f, "Tangan terluka/putus! Senjata terlepas dari genggaman.");
            }
        }

        private void Update()
        {
            if (_selfAnatomy != null && _selfAnatomy.IsDead) return;

            RecoverGripStability();

            if (!IsPlayerControlled) return;

            UpdateTargetedAnatomyPreview();
            AnimateFirstPersonWeapon();

            if (HasWeaponEquipped)
            {
                // Klik Kiri: Tebasan (Slash) untuk memenggal kepala atau memutus lengan/kaki
                if (Input.GetMouseButtonDown(0))
                {
                    _swingAnimTimer = 0.25f;
                    Vector3 slashDir = EyeCameraTransform.right + Vector3.up * -0.2f;
                    ExecuteWeaponStrike(StrikeType.Slash, 4.8f, slashDir.normalized);
                }
                // Klik Kanan: Tusukan Presisi (Pierce) untuk melubangi dada/jantung atau leher
                else if (Input.GetMouseButtonDown(1))
                {
                    _swingAnimTimer = 0.25f;
                    ExecuteWeaponStrike(StrikeType.Pierce, 5.4f, EyeCameraTransform.forward);
                }
                // Tombol Q: Tangkisan Aktif / Deflect
                else if (Input.GetKeyDown(KeyCode.Q))
                {
                    _swingAnimTimer = 0.2f;
                    CurrentGripStability = Mathf.Min(MaxGripStability, CurrentGripStability + 15f);
                    OnCombatLogMessage?.Invoke("Kuda-kuda Tangkisan (Deflect Stance) siap menahan tebasan lawan.");
                }
            }
            else
            {
                // Mode Tangan Kosong saat senjata terbuang
                if (Input.GetMouseButtonDown(0))
                {
                    ExecuteUnarmedEmergencyMove();
                }
            }

            // Tombol E: Lempar bubuk pembuta mata (Metsubushi) untuk melarikan diri
            if (Input.GetKeyDown(KeyCode.E) && MetsubushiSmokeCharges > 0)
            {
                MetsubushiSmokeCharges--;
                OnCombatLogMessage?.Invoke($"Metsubushi dilempar! (Sisa: {MetsubushiSmokeCharges}) Musuh di sekitar buta sesaat—segera kabur atau pungut senjata!");
                BlindNearbyGuards();
            }

            // Tombol G: Pungut senjata yang jatuh di lantai
            if (!HasWeaponEquipped && Input.GetKeyDown(KeyCode.G))
            {
                TryPickupNearbyWeapon();
            }
        }

        private void UpdateTargetedAnatomyPreview()
        {
            HasValidAnatomicalTarget = false;
            if (EyeCameraTransform == null) return;

            Ray ray = new Ray(EyeCameraTransform.position, EyeCameraTransform.forward);
            if (Physics.Raycast(ray, out RaycastHit hit, BladeReach * 1.3f))
            {
                if (hit.collider.TryGetComponent<AnatomicalHitboxCollider>(out var hitbox))
                {
                    HasValidAnatomicalTarget = true;
                    CurrentlyAimedBodyPart = hitbox.ZoneType;
                }
            }
        }

        private void AnimateFirstPersonWeapon()
        {
            if (EquippedWeaponObject == null || !EquippedWeaponObject.activeSelf) return;

            if (_swingAnimTimer > 0f)
            {
                _swingAnimTimer -= Time.deltaTime;
                EquippedWeaponObject.transform.localRotation = Quaternion.Euler(45f, -35f, 20f);
            }
            else
            {
                EquippedWeaponObject.transform.localRotation = Quaternion.Lerp(
                    EquippedWeaponObject.transform.localRotation,
                    Quaternion.Euler(12f, -8f, 0f),
                    Time.deltaTime * 12f
                );
            }
        }

        public void ExecuteWeaponStrike(StrikeType strikeType, float baseMomentum, Vector3 strikeVector)
        {
            if (EyeCameraTransform == null) return;
            if (_stealthManager != null && IsPlayerControlled)
            {
                _stealthManager.IsWeaponVisiblyDrawn = true;
            }

            Ray ray = new Ray(EyeCameraTransform.position, EyeCameraTransform.forward);

            if (Physics.Raycast(ray, out RaycastHit hit, BladeReach))
            {
                // Cek benturan senjata jika lawan sedang menangkis
                if (hit.collider.TryGetComponent<WeaponCombatAndDisarmController>(out var enemyWeapon) && enemyWeapon.HasWeaponEquipped)
                {
                    if (UnityEngine.Random.value < 0.35f)
                    {
                        ResolveWeaponClash(enemyWeapon, baseMomentum);
                        return;
                    }
                }

                if (hit.collider.TryGetComponent<AnatomicalHitboxCollider>(out var hitbox) && hitbox.ParentAnatomy != _selfAnatomy)
                {
                    hitbox.ParentAnatomy.ApplyAnatomicalStrike(
                        hitbox.ZoneType,
                        strikeType,
                        baseMomentum,
                        WeaponSharpness,
                        hit.point,
                        strikeVector
                    );

                    // Cipratan darah ke pakaian samaran pemain jika membunuh dari jarak sangat dekat
                    if (IsPlayerControlled && _stealthManager != null && hit.distance < 1.9f)
                    {
                        _stealthManager.AddBloodSplatterOnDisguise(28f);
                    }
                }
            }
        }

        public void ResolveWeaponClash(WeaponCombatAndDisarmController opponent, float incomingForce)
        {
            float gripLossSelf = incomingForce * 18f;
            float gripLossOpponent = incomingForce * 26f;

            CurrentGripStability -= gripLossSelf;
            opponent.ReceiveBladeImpactOnWeapon(gripLossOpponent, (opponent.transform.position - transform.position).normalized);

            OnCombatLogMessage?.Invoke($"BENTURAN PEDANG! Grip Stability: {Mathf.Max(0f, CurrentGripStability):F0}%");

            if (CurrentGripStability <= 0f)
            {
                ForceDisarmWeapon(-transform.forward + Vector3.up, "Pedang terpental akibat benturan keras! Kamu terpaksa tangan kosong atau kabur!");
            }
        }

        public void ReceiveBladeImpactOnWeapon(float stabilityDamage, Vector3 knockDirection)
        {
            CurrentGripStability -= stabilityDamage;
            if (CurrentGripStability <= 0f && HasWeaponEquipped)
            {
                ForceDisarmWeapon(knockDirection + Vector3.up * 0.7f, "Tangkisan jebol! Senjata terpental ke tanah.");
            }
        }

        public void ForceDisarmWeapon(Vector3 throwImpulse, string reason)
        {
            if (!HasWeaponEquipped) return;

            EquippedWeaponObject.SetActive(false);

            // Spawn objek fisik pedang di dunia 3D yang bisa diambil kembali
            GameObject droppedSword = GameObject.CreatePrimitive(PrimitiveType.Cube);
            droppedSword.name = "DroppedKatana";
            droppedSword.tag = "Respawn"; // Digunakan untuk deteksi pickup
            droppedSword.transform.position = (WeaponHandSocket != null ? WeaponHandSocket.position : transform.position + Vector3.up) + transform.forward * 0.4f;
            droppedSword.transform.localScale = new Vector3(0.06f, 0.06f, 0.95f);

            Renderer r = droppedSword.GetComponent<Renderer>();
            if (r != null) r.material.color = new Color(0.82f, 0.85f, 0.9f);

            Rigidbody rb = droppedSword.AddComponent<Rigidbody>();
            rb.mass = 1.2f;
            rb.AddForce(throwImpulse * 3.5f, ForceMode.Impulse);
            rb.AddTorque(UnityEngine.Random.insideUnitSphere * 7f, ForceMode.Impulse);

            CurrentStance = CombatStance.UnarmedGrapple;
            OnWeaponDisarmed?.Invoke(reason);
            OnCombatLogMessage?.Invoke(reason + " [Tekan G di dekat pedang untuk memungut, atau E untuk lempar Metsubushi & lari!]");
            OnStanceChanged?.Invoke(CurrentStance);
        }

        private void ExecuteUnarmedEmergencyMove()
        {
            if (EyeCameraTransform == null) return;
            Ray ray = new Ray(EyeCameraTransform.position, EyeCameraTransform.forward);
            if (Physics.Raycast(ray, out RaycastHit hit, UnarmedReach))
            {
                if (hit.collider.TryGetComponent<AnatomicalHitboxCollider>(out var hitbox) && hitbox.ParentAnatomy != _selfAnatomy)
                {
                    hitbox.ParentAnatomy.ApplyAnatomicalStrike(
                        BodyPartType.ThoraxHeart,
                        StrikeType.Blunt,
                        2.2f,
                        0.4f,
                        hit.point,
                        EyeCameraTransform.forward
                    );
                    OnCombatLogMessage?.Invoke("Dorongan Jujutsu Tangan Kosong! Lawan terdorong mundur—gunakan kesempatan untuk kabur atau rebut pedang!");
                }
            }
        }

        private void BlindNearbyGuards()
        {
            var guards = FindObjectsOfType<KageAna.AI.TacticalGuardAIController>();
            foreach (var g in guards)
            {
                if (Vector3.Distance(transform.position, g.transform.position) < 7.5f)
                {
                    g.ApplyBlindStun(5.0f);
                }
            }
        }

        private void TryPickupNearbyWeapon()
        {
            Collider[] cols = Physics.OverlapSphere(transform.position, 2.6f);
            foreach (var c in cols)
            {
                if (c.gameObject.name.Contains("DroppedKatana"))
                {
                    Destroy(c.gameObject);
                    EquippedWeaponObject.SetActive(true);
                    CurrentGripStability = MaxGripStability * 0.7f;
                    CurrentStance = CombatStance.ArmedBlade;
                    OnCombatLogMessage?.Invoke("Katana berhasil dipungut kembali!");
                    OnStanceChanged?.Invoke(CurrentStance);
                    return;
                }
            }
        }

        private void RecoverGripStability()
        {
            if (HasWeaponEquipped && CurrentGripStability < MaxGripStability)
            {
                CurrentGripStability = Mathf.MoveTowards(CurrentGripStability, MaxGripStability, 12f * Time.deltaTime);
            }
        }
    }

    public class AnatomicalHitboxCollider : MonoBehaviour
    {
        public BodyPartType ZoneType;
        public AnatomicalDamageSystem ParentAnatomy;
    }
}
