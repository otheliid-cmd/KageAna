using UnityEngine;
using System;
using System.Collections.Generic;

namespace KageAna.Sandbox
{
    public enum NpcFactionType { SyndicateTarget, SyndicateGuard, InnocentCivilian, AlliedClanEnvoy, ClanAvenger }

    [Serializable]
    public class VillagerIdentityProfile
    {
        public string CharacterName;
        public string PublicAppearance;
        public string NormalDailyActivity;
        public string HiddenClueDescription;
        public NpcFactionType Faction;
        public bool IsIdentityInspected;
    }

    public class ShrineRespawnAndClanConflictManager : MonoBehaviour
    {
        [Header("Sacred Kurama Shrine Respawn System")]
        public Transform PlayerTransform;
        public Transform SacredKuramaShrineSpawnPoint;
        public int ShrineRespawnCount = 0;

        [Header("Clan Conflict & Innocent Civilian Protection")]
        [Range(0f, 100f)] public float ClanConflictTension = 0f;
        public int InnocentsKilledCount = 0;
        public GameObject ClanAvengerRoninPrefab;

        [Header("Stage 4: Player Immobilization (Torinawa Net / Kusarigama Snare)")]
        public float ImmobilizedRemainingTime = 0f;
        public string ImmobilizedSourceReason = string.Empty;

        public event Action<string> OnGameEventToast;

        private void Update()
        {
            if (ImmobilizedRemainingTime > 0f)
            {
                ImmobilizedRemainingTime -= Time.deltaTime;
                if (Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.Q))
                {
                    ImmobilizedRemainingTime = Mathf.Max(0f, ImmobilizedRemainingTime - 0.65f);
                }
            }
        }

        public void ApplyEnemyImmobilizeSnare(float duration, string reason)
        {
            ImmobilizedRemainingTime = Mathf.Max(ImmobilizedRemainingTime, duration);
            ImmobilizedSourceReason = reason;
            OnGameEventToast?.Invoke($"TERIKAT! {reason} — Tekan [Space]/[Q] untuk meronta lepas!");
        }

        public void TriggerPlayerDeathAndRespawnAtShrine(string causeOfDeath)
        {
            ShrineRespawnCount++;
            ImmobilizedRemainingTime = 0f;
            if (PlayerTransform != null && SacredKuramaShrineSpawnPoint != null)
            {
                PlayerTransform.position = SacredKuramaShrineSpawnPoint.position;
                PlayerTransform.rotation = SacredKuramaShrineSpawnPoint.rotation;
            }
            OnGameEventToast?.Invoke($"Gugur ({causeOfDeath}). Bangkit kembali di Kuil Suci Gunung Kurama (Respawn #{ShrineRespawnCount})!");
        }

        public void RegisterNpcEliminated(VillagerIdentityProfile profile)
        {
            if (profile.Faction == NpcFactionType.InnocentCivilian || profile.Faction == NpcFactionType.AlliedClanEnvoy)
            {
                InnocentsKilledCount++;
                ClanConflictTension = Mathf.Clamp(ClanConflictTension + 35f, 0f, 100f);
                if (ClanAvengerRoninPrefab != null && PlayerTransform != null)
                {
                    Instantiate(ClanAvengerRoninPrefab, PlayerTransform.position + PlayerTransform.forward * 6f, Quaternion.identity);
                }
                OnGameEventToast?.Invoke($"KONFLIK ANTAR KLAN ({ClanConflictTension}%)! Kamu membunuh {profile.CharacterName} yang tidak bersalah!");
            }
        }
    }
}
