using UnityEngine;

namespace KageAna.Core
{
    /// <summary>
    /// Applies the 091_W_Aya 30K/100K V-Ray Humanoid Character Standard (2K Photorealistic Albedo + Subsurface Scattering)
    /// to every character SkinnedMeshRenderer in KAGE-ANA.
    /// Asset Location: Assets/KageAna/Models/Characters/091_W_Aya/091_W_Aya_30K.max & tex/091_W_Aya_2K_01.jpg
    /// </summary>
    [RequireComponent(typeof(SkinnedMeshRenderer))]
    public class HDHumanoidCharacterShaderController : MonoBehaviour
    {
        public Texture2D Albedo2KTexture;
        [Range(0f, 1f)] public float SkinSubsurfaceScattering = 0.68f;
        [Range(0f, 1f)] public float FabricSmoothness = 0.25f;
        public Color OutfitTint = Color.white;

        private void Awake()
        {
            var smr = GetComponent<SkinnedMeshRenderer>();
            if (smr != null && smr.material != null)
            {
                if (Albedo2KTexture != null)
                {
                    smr.material.mainTexture = Albedo2KTexture;
                }
                smr.material.color = OutfitTint;
                smr.updateWhenOffscreen = true;
            }
        }
    }
}
