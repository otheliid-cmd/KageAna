using UnityEngine;
using System;
using System.Collections.Generic;

namespace KageAna.Combat
{
    public enum BodyPartType
    {
        Head,
        Neck,
        ThoraxHeart,
        Abdomen,
        RightArm,
        LeftArm,
        RightLeg,
        LeftLeg
    }

    public enum StrikeType { Pierce, Slash, Blunt }

    [Serializable]
    public class AnatomicalZoneState
    {
        public BodyPartType Part;
        public bool IsSevered;
        public bool IsImpaled;
        public bool IsCrippled;
        public bool HasArmorProtection;
        public float ArmorHardness = 0f;
        public float BleedRatePerSecond = 0f;
        public Transform VisualBone;
    }

    public class AnatomicalDamageSystem : MonoBehaviour
    {
        [Header("Anatomical Zones & Arterial Blood System (No HP Bar)")]
        public List<AnatomicalZoneState> BodyZones = new List<AnatomicalZoneState>();
        public float TotalBloodVolume = 100f;
        public float ConsciousnessThreshold = 35f;
        public bool IsDead { get; private set; }
        public bool IsIncapacitated { get; private set; }

        public event Action<BodyPartType, StrikeType, string> OnAnatomicalTrauma;
        public event Action<BodyPartType> OnLimbSevered;
        public event Action OnForceDropWeapon;
        public event Action<Vector3> OnBloodDripSpawned;
        public event Action<string> OnLethalElimination;

        private float _bloodDripTimer;

        private void Update()
        {
            if (IsDead) return;
            ProcessArterialBleeding();
        }

        public void ApplyAnatomicalStrike(
            BodyPartType targetPart,
            StrikeType strikeType,
            float strikeMomentum,
            float bladeSharpness,
            Vector3 impactPoint,
            Vector3 strikeDirection)
        {
            if (IsDead) return;

            AnatomicalZoneState zone = BodyZones.Find(z => z.Part == targetPart);
            if (zone == null || zone.IsSevered) return;

            float effectiveForce = strikeMomentum * bladeSharpness;
            if (zone.HasArmorProtection && effectiveForce < zone.ArmorHardness)
            {
                OnAnatomicalTrauma?.Invoke(targetPart, strikeType, $"Serangan tertahan pelindung besi ({targetPart})! Pedang bergetar keras.");
                return;
            }

            SpawnBloodBurstEffect(impactPoint, 10);

            switch (targetPart)
            {
                case BodyPartType.Head:
                case BodyPartType.Neck:
                    if (strikeType == StrikeType.Slash && effectiveForce >= 5.5f)
                    {
                        SeverBodyPart(zone, impactPoint, strikeDirection);
                        TriggerInstantDeath($"KEPALA TERPENGGAL oleh tebasan pada {targetPart}!");
                    }
                    else if (strikeType == StrikeType.Pierce && effectiveForce >= 4.2f)
                    {
                        zone.IsImpaled = true;
                        TriggerInstantDeath($"TUSUKAN TEMBUS mematikan pada {targetPart}!");
                    }
                    else
                    {
                        zone.BleedRatePerSecond += 18f;
                        OnAnatomicalTrauma?.Invoke(targetPart, strikeType, "Arteri leher/kepala robek parah! Pendarahan kritis.");
                    }
                    break;

                case BodyPartType.ThoraxHeart:
                    if (strikeType == StrikeType.Pierce && effectiveForce >= 4.5f)
                    {
                        zone.IsImpaled = true;
                        CreateChestHoleVisual(impactPoint);
                        TriggerInstantDeath("DADA BOLONG TERTUSUK TEMBUS mengenai jantung!");
                    }
                    else if (strikeType == StrikeType.Slash)
                    {
                        zone.BleedRatePerSecond += 12f;
                        zone.IsCrippled = true;
                        OnAnatomicalTrauma?.Invoke(targetPart, strikeType, "Tebasan dalam di dada! Stamina dan napas rusak.");
                    }
                    break;

                case BodyPartType.RightArm:
                case BodyPartType.LeftArm:
                    if (strikeType == StrikeType.Slash && effectiveForce >= 5.0f)
                    {
                        SeverBodyPart(zone, impactPoint, strikeDirection);
                        if (targetPart == BodyPartType.RightArm)
                        {
                            OnForceDropWeapon?.Invoke();
                        }
                        OnAnatomicalTrauma?.Invoke(targetPart, strikeType, $"{targetPart} PUTUS TERTEBAS! Senjata langsung jatuh ke tanah.");
                    }
                    else
                    {
                        zone.IsCrippled = true;
                        zone.BleedRatePerSecond += 5f;
                        if (targetPart == BodyPartType.RightArm)
                        {
                            OnForceDropWeapon?.Invoke();
                        }
                        OnAnatomicalTrauma?.Invoke(targetPart, strikeType, $"Tendon {targetPart} robek! Senjata terlepas dari tangan.");
                    }
                    break;

                case BodyPartType.RightLeg:
                case BodyPartType.LeftLeg:
                    if (strikeType == StrikeType.Slash && effectiveForce >= 5.5f)
                    {
                        SeverBodyPart(zone, impactPoint, strikeDirection);
                        IsIncapacitated = true;
                        OnAnatomicalTrauma?.Invoke(targetPart, strikeType, $"{targetPart} PUTUS! Target roboh ke tanah.");
                    }
                    else
                    {
                        zone.IsCrippled = true;
                        zone.BleedRatePerSecond += 6f;
                        OnAnatomicalTrauma?.Invoke(targetPart, strikeType, $"Otot {targetPart} terpotong! Jalan pincang & gagal melompat.");
                    }
                    break;

                case BodyPartType.Abdomen:
                    if (strikeType == StrikeType.Pierce && effectiveForce >= 4.2f)
                    {
                        zone.IsImpaled = true;
                        zone.IsCrippled = true;
                        zone.BleedRatePerSecond += 15f;
                        IsIncapacitated = true;
                        OnAnatomicalTrauma?.Invoke(targetPart, strikeType, "Perut tertusuk tembus! Target ambruk karena syok organ.");
                    }
                    else
                    {
                        zone.BleedRatePerSecond += 8f;
                        OnAnatomicalTrauma?.Invoke(targetPart, strikeType, "Luka robek di perut! Pendarahan aktif.");
                    }
                    break;
            }
        }

        private void SeverBodyPart(AnatomicalZoneState zone, Vector3 impactPoint, Vector3 direction)
        {
            zone.IsSevered = true;
            zone.IsCrippled = true;
            zone.BleedRatePerSecond += 16f;

            if (zone.VisualBone != null)
            {
                // Lepaskan bagian tubuh secara fisik sebagai objek Rigidbody di dunia 3D
                GameObject detachedLimb = GameObject.CreatePrimitive(zone.Part == BodyPartType.Head ? PrimitiveType.Sphere : PrimitiveType.Cylinder);
                detachedLimb.name = $"Severed_{zone.Part}";
                detachedLimb.transform.position = zone.VisualBone.position;
                detachedLimb.transform.localScale = zone.VisualBone.lossyScale;
                Renderer r = detachedLimb.GetComponent<Renderer>();
                if (r != null) r.material.color = new Color(0.65f, 0.12f, 0.12f);

                Rigidbody rb = detachedLimb.AddComponent<Rigidbody>();
                rb.mass = 1.5f;
                rb.AddForce((direction.normalized + Vector3.up * 0.4f) * 5.2f, ForceMode.Impulse);
                rb.AddTorque(UnityEngine.Random.insideUnitSphere * 8f, ForceMode.Impulse);
                Destroy(detachedLimb, 20f);

                zone.VisualBone.gameObject.SetActive(false);
            }

            OnLimbSevered?.Invoke(zone.Part);
        }

        private void CreateChestHoleVisual(Vector3 impactPoint)
        {
            GameObject wound = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            wound.name = "ChestImpaleWound";
            Destroy(wound.GetComponent<Collider>());
            wound.transform.SetParent(transform);
            wound.transform.position = impactPoint;
            wound.transform.localScale = new Vector3(0.18f, 0.18f, 0.18f);
            Renderer r = wound.GetComponent<Renderer>();
            if (r != null) r.material.color = new Color(0.45f, 0.02f, 0.02f);
        }

        private void SpawnBloodBurstEffect(Vector3 pos, int droplets)
        {
            for (int i = 0; i < droplets; i++)
            {
                GameObject drop = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                Destroy(drop.GetComponent<Collider>());
                drop.transform.position = pos + UnityEngine.Random.insideUnitSphere * 0.15f;
                drop.transform.localScale = Vector3.one * 0.06f;
                Renderer r = drop.GetComponent<Renderer>();
                if (r != null) r.material.color = new Color(0.75f, 0.05f, 0.05f);
                Rigidbody rb = drop.AddComponent<Rigidbody>();
                rb.AddForce(UnityEngine.Random.insideUnitSphere * 3.5f, ForceMode.Impulse);
                Destroy(drop, 2.5f);
            }
        }

        private void ProcessArterialBleeding()
        {
            float totalBleed = 0f;
            foreach (var zone in BodyZones)
            {
                totalBleed += zone.BleedRatePerSecond;
            }

            if (totalBleed <= 0f) return;

            TotalBloodVolume -= totalBleed * Time.deltaTime;
            _bloodDripTimer += Time.deltaTime;

            if (_bloodDripTimer >= 1.2f)
            {
                _bloodDripTimer = 0f;
                SpawnBloodTrailDecal(transform.position);
                OnBloodDripSpawned?.Invoke(transform.position);
            }

            if (TotalBloodVolume <= ConsciousnessThreshold && !IsIncapacitated)
            {
                IsIncapacitated = true;
                OnAnatomicalTrauma?.Invoke(BodyPartType.ThoraxHeart, StrikeType.Slash, "Kehilangan banyak darah! Tubuh ambruk lemas.");
            }

            if (TotalBloodVolume <= 0f)
            {
                TriggerInstantDeath("Tewas akibat kehabisan darah dari luka arteri.");
            }
        }

        private void SpawnBloodTrailDecal(Vector3 worldPos)
        {
            GameObject pool = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            pool.name = "BloodTrailDecal";
            Destroy(pool.GetComponent<Collider>());
            pool.transform.position = new Vector3(worldPos.x, 0.02f, worldPos.z);
            pool.transform.localScale = new Vector3(0.35f, 0.01f, 0.35f);
            Renderer r = pool.GetComponent<Renderer>();
            if (r != null) r.material.color = new Color(0.55f, 0.03f, 0.03f);
            Destroy(pool, 35f);
        }

        private void TriggerInstantDeath(string cause)
        {
            if (IsDead) return;
            IsDead = true;
            IsIncapacitated = true;
            OnForceDropWeapon?.Invoke();
            OnLethalElimination?.Invoke(cause);
        }
    }
}
