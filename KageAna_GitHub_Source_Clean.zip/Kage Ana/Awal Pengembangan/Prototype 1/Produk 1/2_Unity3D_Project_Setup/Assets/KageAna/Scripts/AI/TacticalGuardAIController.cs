using UnityEngine;
using KageAna.Combat;
using KageAna.Core;
using KageAna.Sandbox;

namespace KageAna.AI
{
    public enum GuardAIState { Patrol, SuspiciousInspect, CombatEngage, DisarmedPanicFlee, BlindedStun }

    public class TacticalGuardAIController : MonoBehaviour
    {
        public string CharacterDisplayName = "Samurai Guard";
        public bool IsAssassinationTarget = false;
        public GuardAIState CurrentState = GuardAIState.Patrol;
        public Vector3[] PatrolWaypoints;
        public float MoveSpeed = 2.6f;
        public float ChaseSpeed = 4.8f;

        [HideInInspector] public float SuspicionMeter = 0f;

        private int _waypointIndex;
        private Transform _playerTransform;
        private FirstPersonParkourController _playerParkour;
        private AnatomicalDamageSystem _playerAnatomy;
        private WeaponCombatAndDisarmController _playerWeapon;
        private SocialStealthAndSandboxManager _stealthManager;

        private AnatomicalDamageSystem _selfAnatomy;
        private WeaponCombatAndDisarmController _selfWeapon;
        private float _attackCooldown;
        private float _blindTimer;
        private Vector3 _investigatePosition;

        private void Start()
        {
            _selfAnatomy = GetComponent<AnatomicalDamageSystem>();
            _selfWeapon = GetComponent<WeaponCombatAndDisarmController>();
            _stealthManager = FindObjectOfType<SocialStealthAndSandboxManager>();

            var playerObj = FindObjectOfType<FirstPersonParkourController>();
            if (playerObj != null)
            {
                _playerParkour = playerObj;
                _playerTransform = playerObj.transform;
                _playerAnatomy = playerObj.GetComponent<AnatomicalDamageSystem>();
                _playerWeapon = playerObj.GetComponent<WeaponCombatAndDisarmController>();

                _playerParkour.OnNoiseGenerated += OnHeardNoise;
            }

            if (_selfAnatomy != null)
            {
                _selfAnatomy.OnLimbSevered += OnSelfLimbSevered;
                _selfAnatomy.OnLethalElimination += OnSelfDied;
            }

            if (_selfWeapon != null)
            {
                _selfWeapon.OnWeaponDisarmed += (reason) =>
                {
                    if (!_selfAnatomy.IsDead) CurrentState = GuardAIState.DisarmedPanicFlee;
                };
            }
        }

        private void Update()
        {
            if (_selfAnatomy == null || _selfAnatomy.IsDead || _selfAnatomy.IsIncapacitated) return;
            if (_playerTransform == null) return;

            if (_blindTimer > 0f)
            {
                _blindTimer -= Time.deltaTime;
                CurrentState = GuardAIState.BlindedStun;
                return;
            }
            else if (CurrentState == GuardAIState.BlindedStun)
            {
                CurrentState = _selfWeapon != null && !_selfWeapon.HasWeaponEquipped
                    ? GuardAIState.DisarmedPanicFlee
                    : GuardAIState.CombatEngage;
            }

            EvaluatePlayerSightAndDisguise();

            switch (CurrentState)
            {
                case GuardAIState.Patrol:
                    UpdatePatrol();
                    break;
                case GuardAIState.SuspiciousInspect:
                    UpdateSuspiciousInspect();
                    break;
                case GuardAIState.CombatEngage:
                    UpdateCombatEngage();
                    break;
                case GuardAIState.DisarmedPanicFlee:
                    UpdatePanicFlee();
                    break;
            }
        }

        private void EvaluatePlayerSightAndDisguise()
        {
            float dist = Vector3.Distance(transform.position, _playerTransform.position);
            if (dist > 18f) return;

            Vector3 dirToPlayer = (_playerTransform.position - transform.position).normalized;
            float angle = Vector3.Angle(transform.forward, dirToPlayer);

            if (angle < 65f && _stealthManager != null)
            {
                _stealthManager.IsPerformingParkourOrSprinting = _playerParkour.IsSprinting || !_playerParkour.GetComponent<CharacterController>().isGrounded;
                float suspicionRate = _stealthManager.EvaluateSuspicionRatePerSecond(dist);

                if (suspicionRate > 0f)
                {
                    SuspicionMeter = Mathf.Clamp(SuspicionMeter + suspicionRate * Time.deltaTime, 0f, 100f);
                    if (SuspicionMeter >= 100f && CurrentState != GuardAIState.CombatEngage && CurrentState != GuardAIState.DisarmedPanicFlee)
                    {
                        CurrentState = GuardAIState.CombatEngage;
                    }
                    else if (SuspicionMeter >= 45f && CurrentState == GuardAIState.Patrol)
                    {
                        _investigatePosition = _playerTransform.position;
                        CurrentState = GuardAIState.SuspiciousInspect;
                    }
                }
                else
                {
                    SuspicionMeter = Mathf.MoveTowards(SuspicionMeter, 0f, 10f * Time.deltaTime);
                }
            }
        }

        private void OnHeardNoise(float decibels, Vector3 noiseOrigin)
        {
            if (_selfAnatomy.IsDead || CurrentState == GuardAIState.CombatEngage) return;
            float dist = Vector3.Distance(transform.position, noiseOrigin);
            if (decibels >= 25f && dist <= decibels * 0.65f)
            {
                _investigatePosition = noiseOrigin;
                SuspicionMeter = Mathf.Max(SuspicionMeter, 60f);
                CurrentState = GuardAIState.SuspiciousInspect;
            }
        }

        private void UpdatePatrol()
        {
            if (PatrolWaypoints == null || PatrolWaypoints.Length == 0) return;
            Vector3 target = PatrolWaypoints[_waypointIndex];
            MoveTowardsPoint(target, MoveSpeed);

            if (Vector3.Distance(transform.position, target) < 0.8f)
            {
                _waypointIndex = (_waypointIndex + 1) % PatrolWaypoints.Length;
            }
        }

        private void UpdateSuspiciousInspect()
        {
            MoveTowardsPoint(_investigatePosition, MoveSpeed * 0.9f);
            if (Vector3.Distance(transform.position, _investigatePosition) < 1.5f)
            {
                SuspicionMeter -= 15f * Time.deltaTime;
                if (SuspicionMeter <= 10f)
                {
                    CurrentState = GuardAIState.Patrol;
                }
            }
        }

        private void UpdateCombatEngage()
        {
            if (_selfWeapon != null && !_selfWeapon.HasWeaponEquipped)
            {
                CurrentState = GuardAIState.DisarmedPanicFlee;
                return;
            }

            float dist = Vector3.Distance(transform.position, _playerTransform.position);
            if (dist > 1.85f)
            {
                MoveTowardsPoint(_playerTransform.position, ChaseSpeed);
            }
            else
            {
                Vector3 lookPos = new Vector3(_playerTransform.position.x, transform.position.y, _playerTransform.position.z);
                transform.LookAt(lookPos);

                _attackCooldown -= Time.deltaTime;
                if (_attackCooldown <= 0f)
                {
                    _attackCooldown = UnityEngine.Random.Range(1.1f, 1.8f);
                    PerformGuardAttackOnPlayer();
                }
            }
        }

        private void PerformGuardAttackOnPlayer()
        {
            if (_playerAnatomy == null || _playerAnatomy.IsDead) return;

            // Cek apakah pemain menangkis atau pedang beradu
            if (_playerWeapon != null && _playerWeapon.HasWeaponEquipped && UnityEngine.Random.value < 0.45f)
            {
                _playerWeapon.ResolveWeaponClash(_selfWeapon, 3.8f);
                return;
            }

            // Serang bagian tubuh pemain secara taktis (Lengan Kanan agar senjata pemain jatuh, atau Torso/Kaki)
            BodyPartType[] possibleTargets = { BodyPartType.RightArm, BodyPartType.ThoraxHeart, BodyPartType.LeftLeg };
            BodyPartType chosen = possibleTargets[UnityEngine.Random.Range(0, possibleTargets.Length)];

            _playerAnatomy.ApplyAnatomicalStrike(
                chosen,
                StrikeType.Slash,
                3.6f,
                1.2f,
                _playerTransform.position + Vector3.up * 1.2f,
                transform.forward
            );
        }

        private void UpdatePanicFlee()
        {
            // Melarikan diri menjauhi pemain karena tangan putus atau senjata terpental
            Vector3 fleeDir = (transform.position - _playerTransform.position).normalized;
            Vector3 fleeTarget = transform.position + fleeDir * 8f;
            MoveTowardsPoint(fleeTarget, ChaseSpeed * 0.85f);
        }

        private void MoveTowardsPoint(Vector3 destination, float speed)
        {
            // Penalti jalan pincang jika kaki terluka
            bool legCrippled = _selfAnatomy.BodyZones.Exists(z => (z.Part == BodyPartType.LeftLeg || z.Part == BodyPartType.RightLeg) && z.IsCrippled);
            if (legCrippled) speed *= 0.42f;

            Vector3 flatDest = new Vector3(destination.x, transform.position.y, destination.z);
            Vector3 dir = (flatDest - transform.position).normalized;
            if (dir.sqrMagnitude > 0.01f)
            {
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), Time.deltaTime * 7f);
                transform.position += dir * speed * Time.deltaTime;
            }
        }

        public void ApplyBlindStun(float duration)
        {
            _blindTimer = duration;
            CurrentState = GuardAIState.BlindedStun;
        }

        private void OnSelfLimbSevered(BodyPartType severedPart)
        {
            if (severedPart == BodyPartType.RightArm || severedPart == BodyPartType.LeftArm)
            {
                CurrentState = GuardAIState.DisarmedPanicFlee;
            }
        }

        private void OnSelfDied(string cause)
        {
            // Rebahkan tubuh ke lantai
            transform.rotation = Quaternion.Euler(88f, transform.eulerAngles.y, 0f);
            transform.position = new Vector3(transform.position.x, 0.25f, transform.position.z);

            if (IsAssassinationTarget && _stealthManager != null)
            {
                _stealthManager.CompleteContract(CharacterDisplayName);
            }
        }
    }
}
