using UnityEngine;
using System;

namespace KageAna.Core
{
    public enum SurfaceType { Tatami, Wood, ClayTile, Gravel, WetRoof, Stone }
    public enum CameraViewMode { FirstPersonEye, ThirdPersonAction }

    [RequireComponent(typeof(CharacterController))]
    [RequireComponent(typeof(AudioSource))]
    public class FirstPersonParkourController : MonoBehaviour
    {
        [Header("1st & 3rd Person Camera Settings [Press V]")]
        public Transform CameraMount;
        public Transform HeadBone;
        public CameraViewMode CurrentCameraMode = CameraViewMode.FirstPersonEye;
        public Vector3 ThirdPersonOffset = new Vector3(0.45f, 0.55f, -3.35f);
        public float MouseSensitivity = 2.0f;

        [Header("Subtle Forward-Back Step Bob (No Dizzying Shake)")]
        public float StepBobFrequency = 3.6f;
        public float ForwardBackBobAmplitude = 0.042f;
        public float MicroVerticalBobAmplitude = 0.008f;

        [Header("Locomotion & Sprint [Shift / CapsLock]")]
        public float WalkSpeed = 5.5f;
        public float SprintSpeed = 10.2f;
        public float CrouchSpeed = 2.8f;
        public float JumpForce = 8.2f;
        public float Gravity = -19.62f;
        public bool SprintToggleLock = false;

        [Header("Calculated Parkour Parameters")]
        public float MaxGripStamina = 100f;
        public float CurrentGripStamina = 100f;
        public LayerMask EnvironmentMask = ~0;

        public bool IsLeftLegCrippled { get; set; }
        public bool IsRightLegCrippled { get; set; }
        public bool IsLeftArmSevered { get; set; }
        public bool IsRightArmSevered { get; set; }

        private CharacterController _controller;
        private AudioSource _audioSource;
        private Vector3 _velocity;
        private float _pitch;
        private float _stepPhase;
        private int _lastHalfCycle;

        public event Action<float, Vector3> OnNoiseGenerated;
        public event Action<string> OnParkourRiskTriggered;

        private void Awake()
        {
            Time.timeScale = 1f;
            _controller = GetComponent<CharacterController>();
            _audioSource = GetComponent<AudioSource>();
            if (EnvironmentMask == 0) EnvironmentMask = ~0;
            Cursor.lockState = CursorLockMode.Locked;
        }

        private void Update()
        {
            if (Input.GetKeyDown(KeyCode.V))
            {
                CurrentCameraMode = CurrentCameraMode == CameraViewMode.FirstPersonEye
                    ? CameraViewMode.ThirdPersonAction
                    : CameraViewMode.FirstPersonEye;
            }

            if (Input.GetKeyDown(KeyCode.CapsLock))
            {
                SprintToggleLock = !SprintToggleLock;
            }

            HandleMovementAndFootsteps();
            UpdateCameraTransform();
        }

        private void HandleMovementAndFootsteps()
        {
            bool wasGrounded = _controller.isGrounded;
            if (wasGrounded && _velocity.y < 0f) _velocity.y = -2f;

            float inputX = 0f;
            float inputZ = 0f;
            if (Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.RightArrow)) inputX += 1f;
            if (Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.LeftArrow)) inputX -= 1f;
            if (Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow)) inputZ += 1f;
            if (Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.DownArrow)) inputZ -= 1f;

            Vector3 moveDir = (transform.right * inputX + transform.forward * inputZ).normalized;
            bool isCrouching = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.C);
            bool isSprinting = (Input.GetKey(KeyCode.LeftShift) || SprintToggleLock) && !isCrouching && moveDir.sqrMagnitude > 0.01f;

            float targetSpeed = isCrouching ? CrouchSpeed : (isSprinting ? SprintSpeed : WalkSpeed);
            if (IsLeftLegCrippled || IsRightLegCrippled) targetSpeed *= 0.58f;

            if (wasGrounded && Input.GetKeyDown(KeyCode.Space))
            {
                _velocity.y = JumpForce;
            }

            _velocity.y += Gravity * Time.deltaTime;
            Vector3 finalDisplacement = (moveDir * targetSpeed) + new Vector3(0f, _velocity.y, 0f);
            _controller.Move(finalDisplacement * Time.deltaTime);

            float planarSpeed = new Vector3(_controller.velocity.x, 0f, _controller.velocity.z).magnitude;
            if (wasGrounded && planarSpeed > 0.35f)
            {
                float cadence = isSprinting ? 5.6f : (isCrouching ? 2.4f : StepBobFrequency);
                _stepPhase += Time.deltaTime * cadence * Mathf.PI;
                int halfCycle = Mathf.FloorToInt(_stepPhase / Mathf.PI);
                if (halfCycle > _lastHalfCycle)
                {
                    _lastHalfCycle = halfCycle;
                    PlayProceduralTapFootstep(isSprinting, isCrouching);
                }
            }
        }

        private void UpdateCameraTransform()
        {
            float mouseX = Input.GetAxis("Mouse X") * MouseSensitivity;
            float mouseY = Input.GetAxis("Mouse Y") * MouseSensitivity;

            _pitch = Mathf.Clamp(_pitch - mouseY, -80f, 75f);
            transform.Rotate(Vector3.up * mouseX);

            if (CameraMount == null) return;

            float planarSpeed = new Vector3(_controller.velocity.x, 0f, _controller.velocity.z).magnitude;
            float speedNorm = Mathf.Clamp01(planarSpeed / SprintSpeed);

            // Subtle forward-backward bob (zero roll shake)
            float forwardBob = Mathf.Sin(_stepPhase * 2f) * ForwardBackBobAmplitude * speedNorm;
            float verticalBob = Mathf.Sin(_stepPhase * 2f) * MicroVerticalBobAmplitude * speedNorm;

            Vector3 baseEyePos = HeadBone != null ? HeadBone.position : (transform.position + Vector3.up * 1.65f);
            Vector3 bobOffset = transform.forward * forwardBob + Vector3.up * verticalBob;

            if (CurrentCameraMode == CameraViewMode.FirstPersonEye)
            {
                CameraMount.position = baseEyePos + bobOffset;
                CameraMount.localRotation = Quaternion.Euler(_pitch, 0f, 0f);
            }
            else
            {
                Quaternion rot = Quaternion.Euler(_pitch, transform.eulerAngles.y, 0f);
                CameraMount.position = baseEyePos + rot * ThirdPersonOffset + bobOffset;
                CameraMount.rotation = rot;
            }
        }

        private void PlayProceduralTapFootstep(bool isSprinting, bool isCrouching)
        {
            if (_audioSource == null) return;
            int sampleRate = 44100;
            int samples = sampleRate / 18; // 55ms crisp 'tap'
            AudioClip clip = AudioClip.Create("TapStep", samples, 1, sampleRate, false);
            float[] data = new float[samples];
            float vol = isCrouching ? 0.25f : (isSprinting ? 0.85f : 0.55f);
            for (int i = 0; i < samples; i++)
            {
                float t = (float)i / sampleRate;
                float env = Mathf.Exp(-t * 65f);
                data[i] = Mathf.Sin(2f * Mathf.PI * (820f - t * 9000f) * t) * env * vol;
            }
            clip.SetData(data, 0);
            _audioSource.PlayOneShot(clip);
        }
    }
}
