using UnityEngine;
using System;
using System.Collections.Generic;

namespace KageAna.Sandbox
{
    public enum DisguiseRole { NoneShinobiGarb, Peasant, Merchant, CastleGuard, Monk }
    public enum ZoneSecurityLevel { PublicStreet, RestrictedCourtyard, InnerKeep }

    [Serializable]
    public class AssassinationContract
    {
        public string ContractId;
        public string TargetName;
        public string TargetRoleDescription;
        public ZoneSecurityLevel TargetLocationZone;
        public bool TargetWearsNeckArmor;
        public int GuardCount;
        public int RewardRyo;
        public bool IsCompleted;
    }

    public class SocialStealthAndSandboxManager : MonoBehaviour
    {
        [Header("Player Disguise & Suspicion State")]
        public DisguiseRole CurrentDisguise = DisguiseRole.Peasant;
        public ZoneSecurityLevel CurrentZone = ZoneSecurityLevel.PublicStreet;
        [Range(0f, 100f)] public float BloodstainLevelOnClothes = 0f;
        public bool IsWeaponVisiblyDrawn = false;
        public bool IsPerformingParkourOrSprinting = false;
        public int TotalRyoEarned = 0;
        public int ContractsCompletedCount = 0;

        [Header("Sandbox World Heat & Procedural Contracts")]
        [Range(0f, 100f)] public float DistrictAlertHeat = 10f;
        public List<AssassinationContract> ActiveBoardContracts = new List<AssassinationContract>();

        public event Action<string> OnSandboxNotification;

        private readonly string[] _feudalNames = { "Lord Takamori", "Magistrate Gendo", "Captain Hanzaburo", "Treasurer Kurosawa", "General Akamatsu", "Merchant Jinbei" };
        private readonly string[] _roles = { "Inspektur Pajak Korup", "Komandan Garnisun Kastil", "Pedagang Senjata Gelap", "Utusan Klan Saingan" };

        private void Start()
        {
            GenerateProceduralContractBatch(3);
        }

        private void Update()
        {
            // Tombol cepat 1-4 untuk berganti penyamaran atau menyarungkan pedang (H)
            if (Input.GetKeyDown(KeyCode.Alpha1)) ChangeDisguise(DisguiseRole.NoneShinobiGarb);
            if (Input.GetKeyDown(KeyCode.Alpha2)) ChangeDisguise(DisguiseRole.Peasant);
            if (Input.GetKeyDown(KeyCode.Alpha3)) ChangeDisguise(DisguiseRole.Monk);
            if (Input.GetKeyDown(KeyCode.Alpha4)) ChangeDisguise(DisguiseRole.CastleGuard);

            if (Input.GetKeyDown(KeyCode.H))
            {
                IsWeaponVisiblyDrawn = !IsWeaponVisiblyDrawn;
                OnSandboxNotification?.Invoke(IsWeaponVisiblyDrawn ? "Pedang dihunus (Terlihat oleh penjaga!)." : "Pedang disembunyikan di balik pakaian samaran.");
            }
        }

        public float EvaluateSuspicionRatePerSecond(float distanceToGuard)
        {
            float suspicionRate = 0f;

            if (CurrentDisguise == DisguiseRole.NoneShinobiGarb)
            {
                suspicionRate += 65f;
            }

            if (CurrentZone == ZoneSecurityLevel.RestrictedCourtyard && CurrentDisguise == DisguiseRole.Peasant)
            {
                suspicionRate += 32f;
            }
            else if (CurrentZone == ZoneSecurityLevel.InnerKeep && CurrentDisguise != DisguiseRole.CastleGuard)
            {
                suspicionRate += 55f;
            }

            if (IsWeaponVisiblyDrawn && CurrentDisguise != DisguiseRole.CastleGuard)
            {
                suspicionRate += 85f;
            }
            if (IsPerformingParkourOrSprinting)
            {
                suspicionRate += 45f;
            }

            if (BloodstainLevelOnClothes > 15f && distanceToGuard < 9f)
            {
                suspicionRate += (BloodstainLevelOnClothes * 0.85f);
            }

            float proximityMultiplier = Mathf.Clamp(14f / Mathf.Max(1.2f, distanceToGuard), 0.4f, 3.0f);
            return suspicionRate * proximityMultiplier * (1f + (DistrictAlertHeat / 100f));
        }

        public void AddBloodSplatterOnDisguise(float amount)
        {
            BloodstainLevelOnClothes = Mathf.Clamp(BloodstainLevelOnClothes + amount, 0f, 100f);
            if (BloodstainLevelOnClothes >= 40f)
            {
                OnSandboxNotification?.Invoke($"PERINGATAN: Pakaian samaran terkena cipratan darah ({BloodstainLevelOnClothes:F0}%)! Penjaga akan curiga.");
            }
        }

        public void ChangeDisguise(DisguiseRole newRole)
        {
            CurrentDisguise = newRole;
            BloodstainLevelOnClothes = 0f;
            IsWeaponVisiblyDrawn = false;
            OnSandboxNotification?.Invoke($"Menyamar sebagai: {newRole} (Noda darah dibersihkan, senjata disembunyikan).");
        }

        public void CompleteContract(string targetName)
        {
            foreach (var c in ActiveBoardContracts)
            {
                if (!c.IsCompleted && targetName.Contains(c.TargetName))
                {
                    c.IsCompleted = true;
                    TotalRyoEarned += c.RewardRyo;
                    ContractsCompletedCount++;
                    DistrictAlertHeat = Mathf.Clamp(DistrictAlertHeat + 18f, 0f, 100f);
                    OnSandboxNotification?.Invoke($"KONTRAK SELESAI: {c.TargetName} tewas! +{c.RewardRyo} Ryo. District Heat naik ke {DistrictAlertHeat:F0}%!");
                    return;
                }
            }
        }

        public void GenerateProceduralContractBatch(int count)
        {
            ActiveBoardContracts.Clear();
            for (int i = 0; i < count; i++)
            {
                bool highHeat = DistrictAlertHeat >= 50f;
                AssassinationContract contract = new AssassinationContract
                {
                    ContractId = Guid.NewGuid().ToString().Substring(0, 5).ToUpper(),
                    TargetName = _feudalNames[i % _feudalNames.Length],
                    TargetRoleDescription = _roles[i % _roles.Length],
                    TargetLocationZone = (ZoneSecurityLevel)(i % 3),
                    TargetWearsNeckArmor = highHeat || (i == 2),
                    GuardCount = 2 + i + Mathf.RoundToInt(DistrictAlertHeat / 30f),
                    RewardRyo = 200 + (i * 150),
                    IsCompleted = false
                };

                ActiveBoardContracts.Add(contract);
            }
        }
    }
}
