# KAGE-ANA (影穴) — Audit Kritis, Saran Pengembangan & Instruksi Master untuk AI

> Dasar audit: `KageAna_PC_Game_Setup_Sengoku_v0.7.zip`. Saya membaca kode (±24.000 baris), membuka game di browser headless, mengambil screenshot di beberapa waktu hari, dan memeriksa isi folder Unity.
> Catatan metode: FPS dan screenshot diambil di Chromium headless dengan renderer software, jadi angka FPS hanya indikatif (±40 FPS pada 1280×720). File Unity C# tidak saya kompilasi.

---

## BAGIAN 0 — Ringkasan Eksekutif

**Anda benar bahwa grafisnya jauh dari layak komersial. Tapi ini bukan soal "kurang dipoles": akarnya ada pada fondasi teknis.**

Game ini dirender oleh *software 3D renderer buatan sendiri di atas Canvas 2D* (`engine3d.js`, `getContext('2d')`). Tidak ada WebGL, tidak ada shader, tidak ada depth buffer, tidak ada tekstur pada dunia, tidak ada bayangan nyata, dan tidak ada pencahayaan. Setiap frame, semua kotak dan silinder dibongkar menjadi poligon, diurutkan berdasarkan jarak (painter's algorithm), lalu digambar satu per satu dengan warna datar. Karakter "HD" sebenarnya adalah elips, kapsul, dan gradien 2D yang ditempel di posisi proyeksi.

Konsekuensinya:

1. **Plafon visual rendah dan permanen.** Memoles lebih lanjut di fondasi ini tidak akan pernah menghasilkan tampilan komersial. Ini penyebab terbesar kesan "sangat buruk" yang Anda rasakan.
2. **Klaim "photorealistic / V-Ray / subsurface scattering / HD" di kode dan judul menyesatkan.** Itu gradien linear lima warna. Hentikan memakai istilah itu, karena membuat AI Anda dan Anda sendiri merasa grafis sudah maju padahal belum.
3. **Prioritas pengembangan terbalik.** Versi 0.2–0.7 menambah sistem (mutilasi anatomis, pedang menancap, deduksi petunjuk, respawn kuil, BGM, 6 distrik) di atas dunia yang secara visual belum meyakinkan. Fitur sudah banyak, tapi *rasa bermain* (game feel) dan *tampilan* belum ada.

**Rekomendasi inti:** jangan lanjutkan di engine Canvas 2D ini. Pindahkan ke engine sungguhan (Unity URP direkomendasikan, karena Anda sudah punya skrip C#), pakai arah seni bergaya (stylized), bukan fotorealistis, dan gunakan prototipe JS ini hanya sebagai *dokumen desain hidup* (greybox/referensi mekanik).

---

## BAGIAN 1 — Temuan Audit (bukti konkret)

### 1.1 Isi paket

| Item | Temuan |
|---|---|
| Engine render | Canvas 2D software renderer (`class Engine3D`), tanpa WebGL |
| Ukuran kode | `main_sandbox.js` 1.496 baris, `engine3d.js` 946, `parkour_physics.js` 593, `anatomical_combat.js` 477, `weapon_disarm.js` 460, `stealth_and_ai.js` 369; `index.html` 6.203 baris (semua digabung inline) |
| Duplikasi file | `index.html` identik byte-per-byte dengan `KageAna_Langsung_Main_PC.html`. `KageAna_3D_Playable.html` adalah versi lama. Folder `js/` **tidak dipakai** oleh `index.html` (tidak ada tag `<script src>`) dan **sudah berbeda** isinya dari skrip inline |
| Kekacauan versi | Nama zip: v0.7. Judul `<title>`: v0.6. Launcher `.bat`: v0.4 (Tahap 3). Header kode: v0.4 / v0.5. Dokumen prompt: v0.2. Tidak ada sumber kebenaran tunggal |
| Proyek Unity | Hanya `Scripts/` dan satu model. **Tidak ada Scene, prefab, material, Animator, `.meta`, ataupun `.cs` yang terbukti kompil.** `Packages/manifest.json` tanpa render pipeline (URP/HDRP), tanpa Input System, tanpa Cinemachine |
| Aset model | Satu karakter `091_W_Aya` berformat `.max` (3ds Max + V-Ray). **Unity tidak bisa mengimpor `.max` secara andal tanpa 3ds Max terpasang.** Kemungkinan besar aset dari toko/scan pihak ketiga, **lisensi dan hak atas rupa tidak terdokumentasi** |
| Wajah NPC | Foto wajah Aya (base64 PNG/JPEG besar) dilekatkan sebagai *decal* ke elips kepala semua NPC |
| Hasil jalan | Tidak ada error JS. ±40 FPS pada render software 720p |

### 1.2 Yang terlihat di screenshot

- Dunia terdiri dari balok dan kerucut berwarna datar. Tanah adalah gradien vertikal dengan petak warna. Tidak ada tekstur, normal, atau detail permukaan.
- Karakter berbentuk boneka kardus: badan elips/kapsul gradien, kepala elips dengan foto wajah yang tidak menempel pada bentuk 3D, pedang sebagai batang abu-abu yang **melayang di samping tubuh, tidak tergenggam tangan**.
- Bayangan hanya berupa bercak radial gelap di bawah kaki; bangunan tidak menjatuhkan bayangan sama sekali.
- Langit gradien datar plus bola matahari radial; pegunungan hanya siluet sinus.
- Pergantian waktu (pagi/siang/sore/malam) hanya menukar warna dan pengali kecerahan, bukan pencahayaan dinamis.
- **HUD terlalu penuh dan saling menimpa**: panel kiri-atas menabrak bar tombol tengah (teks "BGM & RESPAWN" terpotong), panel misi kanan-atas menumpuk, ditambah bar tombol, daftar target, minimap, pad WASD virtual, dan bar kunci bawah. Label interaksi besar di tengah layar menutupi karakter yang sedang Anda lihat.

---

## BAGIAN 2 — Kritik Menyeluruh per Aspek

Tingkat: **[KRITIS]** menghalangi tujuan komersial · **[BESAR]** merusak kualitas jelas · **[SEDANG]** perlu diperbaiki

### A. Teknologi render

1. **[KRITIS] Canvas 2D painter's algorithm.** Tanpa depth buffer, poligon yang saling memotong akan salah urut (flicker/popping). Objek besar dan kecil sulit diurutkan benar hanya dengan jarak titik tengah. Ini tidak dapat ditambal, hanya diganti.
2. **[KRITIS] Tidak ada GPU rendering.** Semua geometri dihitung di CPU JavaScript tiap frame. Jumlah objek akan mentok cepat. Menambah detail = FPS jatuh.
3. **[KRITIS] Tidak ada pencahayaan nyata.** "Shade" per sisi hanyalah pengali konstanta (0.55–1.06). Tidak ada arah matahari yang memengaruhi permukaan, tidak ada bayangan, tidak ada lampu titik (lentera hanya mengubah satu flag).
4. **[BESAR] Tidak ada tekstur/material.** Kayu, batu, genteng tanah liat, tatami, kain, kulit: semuanya warna rata. Ini alasan dunia terasa "mainan".
5. **[BESAR] Tidak ada post-processing.** Tanpa bloom, color grading, ambient occlusion, kabut volumetrik, depth of field, tone mapping. Fotorealisme maupun gaya stylized sama-sama bergantung pada ini.
6. **[BESAR] Kabut jarak sekadar pengali kecerahan.** Tidak ada kabut atmosferik berwarna, jadi kedalaman datar.
7. **[BESAR] Tidak ada LOD, culling frustum, atau batching.** Seluruh `structures` + darah + bagian tubuh digabung dengan spread (`[...a, ...b]`) dan dialokasikan ulang tiap frame, memicu beban garbage collector.
8. **[SEDANG] Resolusi kanvas mengikuti `innerWidth/innerHeight` tanpa `devicePixelRatio`**, jadi buram di layar HiDPI dan tidak punya pilihan skala render.

### B. Karakter dan animasi

1. **[KRITIS] Karakter bukan model 3D.** Mereka gambar 2D yang dirakit dari kapsul (anggota badan), torso poligon kurva, dan elips kepala. Dari samping/belakang tampak sebagai bentuk yang tidak masuk akal. Tidak ada volume, tidak ada siluet yang bisa "dibaca" sebagai ninja atau samurai.
2. **[KRITIS] Wajah foto ditempel (decal) pada elips.** Ini menciptakan *uncanny valley* terburuk: wajah fotografis di badan kartun. Ditambah **semua NPC berbagi wajah yang sama** (turunan Aya), sehingga samurai pria, biksu, dan pedagang berwajah satu orang. Ada juga isu hak atas rupa: lihat Bagian 2.J.
3. **[BESAR] Tidak ada rig dan skeletal animation.** Gerak anggota badan dihitung prosedural sederhana. Tidak ada blending, root motion, foot IK sungguhan, atau retargeting. Janji "Skeletal IK" di dokumen prompt v0.2 belum ada.
4. **[BESAR] Pedang tidak tergenggam.** Senjata tidak punya titik pegang (socket), tidak ada pose genggaman, tidak ada jejak bilah (trail) yang bermakna, tidak ada kilap logam.
5. **[BESAR] Tidak ada siluet karakter yang khas.** Ninja, penjaga, biksu, pedagang: pembedanya hanya warna kostum dan topi. Game stealth-aksi butuh *identifikasi dari siluet* dalam sepersekian detik.
6. **[BESAR] Tidak ada kain, rambut, atau fisika sekunder.** Haori, obi, rambut, selempang tidak bergerak.
7. **[SEDANG] Tidak ada ekspresi atau animasi wajah, tatapan, atau gerak bibir**; dialog "bersuara bahasa Jepang" tidak disinkronkan dengan apa pun.

### C. Lingkungan dan level

1. **[KRITIS] "Desa" adalah kumpulan balok.** Bangunan tidak punya struktur Jepang yang kredibel: tidak ada atap melengkung (irimoya/kirizuma), bargeboard (hafu), shoji, engawa, pilar-balok (hashira/nuki), pagar bambu, batu pijakan, lentera batu (tōrō), sumur, gerobak. Atap berupa kerucut.
2. **[BESAR] Tanah adalah 169 ubin kotak (13×13) berwarna rata** dengan cap `y = 0.02`. Tidak ada medan, kemiringan, jalan tanah, rumput, lumpur, genangan, jejak.
3. **[BESAR] Tidak ada vegetasi bermakna.** Pohon sakura = silinder + kerucut pink. Tidak ada rumput, semak bergerak, bambu, kelopak jatuh, atau tanaman sawah.
4. **[BESAR] Tidak ada atmosfer hidup.** Tidak ada asap dapur, kabut pagi, api lentera berkedip, kunang-kunang, hujan, angin, burung gagak, serangga malam, ombak sungai.
5. **[BESAR] Tata ruang tanpa narasi lingkungan.** Distrik tidak punya identitas visual (pasar vs kuil vs benteng vs pelabuhan), tidak ada alur sudut pandang (vista), tidak ada landmark yang memandu pemain.
6. **[SEDANG] Peta 90×82 meter dengan 6 distrik** terlalu padat tanpa ruang bernapas, dan terlalu kecil untuk memberi rasa "lembah" Sengoku.

### D. Pencahayaan, warna, dan arah seni

1. **[KRITIS] Tidak ada *art direction*.** Tidak ada dokumen gaya, palet, bahasa bentuk, atau referensi tertulis. Warna dipilih per objek (`#9e1f1f`, `#c4a462`, ...) tanpa sistem.
2. **[KRITIS] Ambisi "fotorealistis" tidak realistis untuk tim solo + AI.** Fotorealisme butuh aset scan/PBR, pipeline pencahayaan, dan tim seniman. Jalur yang bisa dimenangkan: **gaya terarah (stylized)** seperti cel-shaded ukiyo-e, cat air/sumi-e, atau low-poly bercahaya dengan pencahayaan kuat.
3. **[BESAR] Tidak ada *value structure*.** Gambar akhir abu-abu-gelap tanpa titik fokus, kontras fokal, atau rim light. Pemain tidak tahu ke mana harus melihat.
4. **[BESAR] Time-of-day tidak mengubah suasana secara nyata**: tidak ada cahaya hangat miring saat sore, bulan yang menjatuhkan bayangan biru, lampu minyak yang menjadi sumber cahaya utama di malam hari.

### E. Efek, gore, dan "juice"

1. **[BESAR] Darah = partikel dan genangan yang digambar sebagai kotak/poligon.** Tidak ada decal di tanah/dinding, tidak ada cipratan di kain, tidak ada variasi viskositas. (Catatan: kekerasan eksplisit bisa menjadi identitas game, tapi harus *diarahkan*, bukan menjadi banjir partikel. Lihat Bagian 4.)
2. **[BESAR] Tebasan tidak punya impact.** Tidak ada hit-stop, camera shake terukur, slow-motion kill-cam, flash bilah, percikan baja, hentakan musuh, atau suara benturan berlapis.
3. **[BESAR] Tidak ada VFX**: jejak tebasan, debu langkah, percikan saat parkour, asap, ledakan bom asap, lampu kilat shuriken.
4. **[SEDANG] Bagian tubuh terpotong** tampak sebagai balok yang jatuh, tanpa penampang luka dan tanpa fisika benda tegar yang meyakinkan.

### F. UI/UX/HUD

1. **[BESAR] HUD berlebihan dan bertabrakan** (lihat 1.2). Hirarki visual tidak ada. Semua elemen berbobot sama.
2. **[BESAR] Gaya UI generik** (kotak gelap transparan + border emas) yang tidak membawa identitas Sengoku (tidak ada *kamon*, tekstur washi, kaligrafi, cap tinta/hanko, garis sapuan kuas).
3. **[BESAR] Prompt interaksi dan label target ditumpuk di tengah layar** serta memakai teks panjang berbahasa campuran. Aturan: satu prompt kontekstual, singkat, di posisi tetap.
4. **[BESAR] Overlay judul memuat tembok teks.** Tutorial seharusnya diajarkan lewat permainan (*show, don't tell*), bukan paragraf.
5. **[SEDANG] Tombol HUD diberi fokus mouse** padahal game memakai pointer lock untuk first-person; potensi konflik input.
6. **[SEDANG] Ukuran font 10–12 px** terlalu kecil untuk layar 1080p/4K dan tidak ada skala UI.
7. **[SEDANG] Tidak ada menu utama, pengaturan (grafis, audio, kontrol, subtitle, aksesibilitas), jeda, atau penyimpanan.**

### G. Audio

1. **[BESAR] Semua suara adalah osilator Web Audio** (`playTone`, nada segitiga). BGM "Kuno Biwa & Shakuhachi" disintesis, bukan rekaman instrumen. Pada kenyataannya akan terdengar elektronik/chiptune, jauh dari *biwa* dan *shakuhachi* asli.
2. **[BESAR] Suara dialog "bahasa Jepang" memakai `speechSynthesis` bawaan browser** (terverifikasi di kode; tidak ada satu pun berkas audio `.mp3/.ogg/.wav`). Suaranya bergantung pada mesin pemain, robotik, dan tidak layak komersial. Gunakan aktor suara sungguhan atau, minimal, teks + gumaman (barks) rekaman.
3. **[SEDANG] Tidak ada mixing, audio 3D/oklusi, reverb ruangan, ambience berlapis, atau musik adaptif** (stealth → waspada → tempur).

### H. Gameplay, sistem, dan desain

1. **[BESAR] Kebanyakan sistem, sedikit *inti*.** Tidak ada *core loop* yang jelas dan memikat dalam 30 detik pertama. Daftar fitur (cekik senyap, disarm, bush stealth, jaring torinawa, kunai racun, deduksi petunjuk, respawn kuil, konflik klan, kontrak, minimap, 5 bab) terlalu lebar untuk kualitas yang dangkal.
2. **[BESAR] AI musuh sederhana.** Patroli titik-ke-titik, ambang kecurigaan linear, tembak proyektil dengan peluang acak (`Math.random() < 0.45`). Tidak ada *behavior tree*, persepsi pandang dan suara yang berlapis, kerja sama kelompok, atau pencarian cerdas.
3. **[BESAR] Kontrol serangan** (Klik Kiri/Kanan, F, Q, Z, X, Shift, Ctrl, E, B, L, K, R, N, M, P, V, H, I, J, Tab...) terlalu banyak tombol. Tidak ada kurva belajar.
4. **[BESAR] First-person tanpa *tubuh* dan tanpa *tangan***. Dalam game bertema ninja/samurai, rasa dari tangan, bilah, dan tubuh adalah segalanya. Saat ini tidak ada *viewmodel* yang meyakinkan.
5. **[SEDANG] Level umum tidak mengajarkan ritme** (intro → tantangan → crescendo → hadiah).
6. **[SEDANG] Penentuan "benar-salah" pada bunuh NPC** (warga tak bersalah vs target) belum punya konsekuensi sistemik yang menarik.
7. **[SEDANG] Tidak ada progres meta**: peningkatan, peralatan, pohon kemampuan, ekonomi (Ryo) yang berarti.

### I. Arsitektur kode dan proses

1. **[KRITIS] Satu sumber kebenaran tidak ada**: tiga HTML + folder JS yang sudah divergen + proyek Unity yang tidak lengkap.
2. **[BESAR] Base64 gambar tertanam di dalam JS/HTML** (±300 KB per HTML). Sulit dikelola, tidak bisa dikompresi atau diganti.
3. **[BESAR] Data level hard-coded sebagai ratusan literal objek** dalam fungsi (`buildExpandedKurokawaVillage`). Tidak ada editor level, tidak ada format data.
4. **[BESAR] Variabel global dan modul tidak terisolasi** (`worldState`, `engine`, `KageAudio` global). Perubahan kecil dapat merusak yang lain.
5. **[BESAR] Tidak ada tes, tidak ada pengukuran performa, tidak ada tolok ukur.** Tidak ada *definition of done* yang dapat diverifikasi.
6. **[SEDANG] Penamaan campur Indonesia–Inggris**, sebagian komentar berlebihan/hiperbolik ("Zero faceted polygon edges!", "V-Ray SSS Shader") yang tidak sesuai kenyataan kode. Komentar menjanjikan lebih dari yang ada.
7. **[SEDANG] Proses prompt AI terlalu lebar sekali jalan.** Dokumen Tahap 1 meminta WASD 360°, slide, peeking, IK, slash direksional, pedang menancap, dan semburan arteri dalam satu `/plan`. Itu menghasilkan banyak kode tak teruji, bukan hasil yang terasa baik.

### J. Aset, hukum, dan kelayakan komersial

1. **[KRITIS] Lisensi aset `091_W_Aya`.** Nama dan format menunjukkan model/scan dari toko aset. Periksa lisensi (apakah mengizinkan penggunaan komersial dalam game, redistribusi sumber `.max`, dan modifikasi). Jika **berbasis pemindaian orang nyata**, perlu persetujuan/model release; memakai wajah fotografis nyata pada NPC berisiko hukum (hak atas rupa/privasi) dan reputasi. **Jangan kirim `.max` dan tekstur ke publik atau Steam sebelum lisensi jelas.**
2. **[BESAR] Ketidakcocokan karakter.** Model wanita modern/scan dipakai sebagai "standar" untuk samurai, biksu, dan pedagang Sengoku.
3. **[BESAR] Konten kekerasan eksplisit** (mutilasi, pedang menancap di dada, arteri) memengaruhi rating usia (IARC/ESRB/PEGI/Steam mature), kebijakan toko, dan segmen pasar. Rancang sejak awal dan siapkan opsi (misalnya toggle gore).
4. **[SEDANG] Nama dan IP**: periksa kemiripan nama "Kage-Ana", "Kuro-no-Wa", dan nama klan/tokoh dengan merek/judul yang ada. Gunakan nama klan yang asli-ciptaan, bukan yang bertabrakan dengan sejarah sensitif.
5. **[SEDANG] Distribusi**: `.bat`/`.sh` yang membuka HTML bukan produk. Produk komersial butuh build terkemas, pembaruan, crash reporting, dan telemetri izin.

---

## BAGIAN 3 — Segudang Saran Pengembangan

### 3.1 Keputusan terbesar: engine

| Opsi | Cocok jika | Kelebihan | Kekurangan |
|---|---|---|---|
| **A. Unity 6 LTS + URP (direkomendasikan)** | Ingin game PC komersial; sudah punya C# | Ekosistem terbesar, Cinemachine, Input System, VFX Graph, Shader Graph, Animation Rigging (IK), Timeline, banyak aset toko | Perlu belajar editor; aset berbayar |
| B. Godot 4 | Ingin gratis/ringan, kontrol penuh | Open source, ringan, GDScript/C# | Ekosistem aset dan efek kurang kaya untuk 3D tinggi |
| C. Unreal 5 | Ingin kualitas visual tertinggi | Lumen/Nanite, material kuat | Berat; kurva belajar curam; sulit untuk solo dengan AI |
| D. Three.js / Babylon.js (web) | Ingin tetap di browser | Cepat iterasi; mudah dibagikan | Batas performa; distribusi komersial lebih sulit |

Rekomendasi: **A (Unity 6 LTS + URP)**. Folder Unity Anda saat ini nyaris kosong (tanpa scene dan `.meta`), jadi tidak ada yang "hilang" bila dimulai ulang bersih.

### 3.2 Arah seni yang realistis dan kuat (pilih satu, tulis dalam Art Bible)

1. **"Ukiyo-e Noir" (cel-shaded + garis tinta)**: bidang warna datar bersih, garis kontur tebal-tipis ala kuas, tekstur washi, langit gradien bergaya cetak kayu, bayangan keras. Murah diproduksi, sangat khas, ramah aset sedikit.
2. **"Sumi-e Cahaya" (kabut tinta + satu warna aksen)**: monokrom tinta dengan merah sebagai aksen (darah, torii, kamon). Sinematik dan memudahkan *readability* stealth.
3. **"Stylized PBR" ala *Ghost of Tsushima* ringan**: PBR sederhana, vegetasi bergerak angin, kabut volumetrik, warna musim. Butuh lebih banyak aset.

Saran saya: **No. 1 atau 2.** Untuk solo, gaya yang kuat menutupi keterbatasan aset dan menjadi identitas dagang.

### 3.3 Pilar visual yang wajib dibangun (urut prioritas)

1. Pencahayaan terarah + bayangan nyata + kabut warna (langsung mengubah 70% kesan).
2. Material + tekstur bergaya (kayu, tatami, genteng, kain).
3. Bangunan modular Jepang yang benar (kit modular: pilar, dinding shoji, atap lengkung, engawa).
4. Karakter 3D ber-rig dengan siluet khas per peran.
5. Animasi (locomotion, serangan, finisher) dengan IK kaki/tangan.
6. VFX (tebasan, debu, asap, kelopak, kunang-kunang, hujan).
7. Post-processing (tone mapping, bloom halus, color grading per waktu, AO, vignette halus).
8. UI diegetik dan minimalis.
9. Audio rekaman sungguhan, ambience berlapis, musik adaptif.

### 3.4 Karakter

- Buat **model orisinal** (atau lisensi jelas) untuk: Pemain (shinobi), Penjaga samurai, Petani, Pedagang, Biksu, Penari festival, Bos. Silhouette test: isi hitam solid harus bisa dibedakan.
- Rig humanoid standar (Unity Humanoid/Mixamo hanya jika lisensi cocok). Tambah **Animation Rigging** untuk IK kaki, tatapan kepala, dan pegangan senjata.
- Berikan **variasi** (tinggi, bobot, wajah, rambut, pakaian) dengan sedikit parameter agar kerumunan tidak kembar.
- Kain: gunakan bone chain/Cloth sederhana untuk haori, obi, dan ekor kain.
- Wajah: gunakan *stylized face* (tekstur gambar tangan), bukan foto. Ini menyelesaikan uncanny valley dan hak atas rupa.

### 3.5 Lingkungan

- Bangun **kit modular** dan tata dengan **ProBuilder + Terrain**. Tambah medan, jalan tanah, genangan, jembatan kayu, sawah berundak.
- Tentukan **identitas visual per distrik** (palet + props + bunyi): Pasar (kain warna-warni, lentera kertas), Kuil (kayu merah tua, tangga batu, kabut), Benteng (kayu gelap, bendera klan), Pelabuhan (tali, jaring, ombak), Permukiman (atap jerami, asap dapur).
- **Narasi lingkungan:** tanda perang, kontrak pajak yang ditempel, ladang rusak. Pemain harus bisa "membaca" cerita dari adegan.
- **Vista dan landmark**: menara benteng atau pagoda dapat dilihat dari mana pun sebagai kompas visual.
- **Verticality untuk stealth**: atap, balok, tali jemuran, kanal air. Tandai jalur dengan bahasa visual konsisten (misalnya kain putih = bisa dipanjat).

### 3.6 Pencahayaan dan waktu

- Lampu terarah (matahari/bulan) dengan **bayangan cascade**, *baked GI* untuk interior, **lampu titik emisif** untuk lentera dengan flicker.
- **Preset suasana (Volume profile)** per waktu: warna kabut, tone mapping, saturasi, intensitas bloom.
- Mekanik: **cahaya memengaruhi gameplay** (area terang = mudah terlihat; padamkan lentera dengan shuriken/tiupan).

### 3.7 Efek dan *game feel*

- **Hit-stop** 40–80 ms saat tebasan mengenai, **camera shake** terukur, **zoom-in** halus saat finisher, **kill-cam** opsional.
- Tebasan: *trail* berbentuk bilah (VFX Graph/Trail Renderer) + *smear frame*.
- Darah: **decal dinamis**, percikan berbasis sprite sheet + partikel, kain ternoda; atur intensitas (opsi gore).
- Debu langkah, kerikil, cipratan genangan, bunga jatuh, kunang-kunang, asap dapur, kabut tanah.
- Suara berlapis untuk setiap benturan (logam, kain, daging, tulang), dengan variasi acak.

### 3.8 UI/UX

- Targetkan **HUD minimal**: bilah nyawa/stamina tipis, indikator kebisingan dan terlihat (ikon mata/telinga), satu prompt interaksi, kompas ringan. Segala yang lain disembunyikan sampai dibutuhkan atau ditampilkan diegetik (mata musuh berubah, tinta di gulungan).
- **Identitas Sengoku**: tekstur washi, cap hanko, kamon klan, sapuan kuas, font kaligrafi/serif tegas untuk judul + sans bersih untuk isi.
- **Tutorial lewat level**: ajarkan satu hal per area (jongkok, gantung di atap, cekik, lempar kunai).
- Tambah **menu utama, pengaturan, jeda, simpan/muat, pelokalan (ID/EN/JP), subtitle, opsi aksesibilitas (ukuran teks, mode buta warna, remap tombol)**.
- Kurangi tombol: kelompokkan aksi ke konteks (satu tombol "Aksi" yang berubah menurut target).

### 3.9 Gameplay dan desain

- **Definisikan core loop satu kalimat**, misalnya: *"Amati pola patroli → pilih jalur bayangan → eliminasi senyap atau kabur → ambil bukti → hilang sebelum alarm."*
- Buat **satu level sempurna (vertical slice 10–15 menit)** daripada enam distrik setengah matang. Jadikan itu demo/trailer/halaman Steam Anda.
- **AI musuh**: *behavior tree* atau *utility AI* + sensor pandang (kerucut, jarak, cahaya) + sensor suara (kebisingan per permukaan) + status (curiga, mencari, bertempur, kembali), kerja sama kelompok (memanggil bala bantuan, mengepung), rasa takut/terkejut saat rekan tewas.
- **Pertempuran**: pilih identitas. Contoh *Sekiro*-like (parry/postur) atau *Tenchu*-like (stealth kill dominan). Jangan campur dua tanpa alasan.
- **Progres meta**: peralatan, kemampuan, kerajinan, reputasi klan, konsekuensi membunuh warga tak bersalah yang terasa di dunia.
- **Keseimbangan dan kejelasan**: tiap kematian harus terasa "adil dan bisa dipelajari".

### 3.10 Performa dan kualitas teknis

- Anggaran awal (PC menengah): **60 FPS pada 1080p** di kelas GTX 1060/RX 580; ≤ 2.000 draw call setelah batching; ≤ 30 NPC aktif dengan LOD; memori < 4 GB.
- Pakai **Profiler**, **Frame Debugger**, dan **tolok ukur otomatis** (fly-through) di tiap rilis.
- Terapkan **LOD**, **occlusion culling**, **GPU instancing**, **atlas tekstur**, **object pooling** (partikel, proyektil, darah).

### 3.11 Komersialisasi

- **Kelayakan bisnis**: tentukan target (Steam, indie PC), harga, dan ruang lingkup realistis. Solo dev idealnya merilis *demo* dulu (Steam Next Fest) dan memakai umpan balik.
- **Aset legal bersih**: dokumentasikan setiap aset (sumber, lisensi, bukti beli) dalam `ASSETS_LICENSE.md`.
- **Rating dan kebijakan**: siapkan kuesioner IARC; sediakan opsi gore; periksa kebijakan Steam tentang kekerasan dan konten.
- **Pemasaran**: trailer 60–90 detik dari vertical slice, GIF pendek, halaman Steam dengan kata kunci (ninja, stealth, Sengoku, Jepang feodal), *wishlist* sejak dini.
- **Kualitas**: crash reporting, simpan otomatis, kontrol gamepad, remap tombol, uji pada beberapa spesifikasi.

---

## BAGIAN 4 — Rencana Fase (ringkas)

| Fase | Tujuan | Keluaran yang dapat diverifikasi |
|---|---|---|
| **0. Fondasi & keputusan** | Pilih engine, rapikan repositori, bekukan fitur baru | Repo git bersih, satu sumber kebenaran, `ART_BIBLE.md`, `ASSETS_LICENSE.md`, `ARCHITECTURE.md` |
| **1. Vertical Slice – Blockout** | Satu area (±60×60 m) dengan greybox jalan, atap, titik stealth | Dapat dimainkan 10 menit dengan kontrol dasar tanpa error |
| **2. Look Dev** | Pencahayaan, material, post-FX, kabut, satu waktu (sore) | 3 screenshot acuan disetujui; ≥ 60 FPS |
| **3. Karakter & animasi** | Pemain + 3 tipe NPC ber-rig + locomotion + serangan dasar + IK | Video 30 detik tiap karakter bergerak |
| **4. Game feel & VFX** | Hit-stop, trail, darah decal, debu, audio nyata | A/B video "sebelum/sesudah" |
| **5. AI & stealth** | Sensor pandang/suara, status, alarm | Skenario uji otomatis: lewat/tertangkap/kabur |
| **6. UI/UX & menu** | HUD minimal bergaya Sengoku + menu + pengaturan | Uji pemain baru: paham tanpa teks panjang |
| **7. Konten & polesan** | Perluas ke 2–3 distrik, misi, waktu lain | Build kandidat demo |
| **8. Rilis demo** | Packaging, QA, rating, halaman toko | Build terpasang; checklist rilis lengkap |

---

## BAGIAN 5 — INSTRUKSI MASTER UNTUK AI ANDA

> Salin seluruh Bagian 5 ini sebagai berkas `AGENTS.md` / `CLAUDE.md` / "Rules" di akar repositori game, atau tempel sebagai prompt pembuka. Kemudian berikan prompt fase satu per satu (5.8).

### 5.1 Peran dan konteks

Kamu adalah **lead technical artist + gameplay engineer** untuk game aksi-stealth orang pertama bertema ninja Sengoku Jepang, **KAGE-ANA (影穴)**. Tujuan akhir: **game PC yang layak dijual (Steam)**, dengan grafis yang konsisten, terarah, dan stabil 60 FPS.

Kondisi saat ini (jangan bantah, ini hasil audit):
- Prototipe v0.7 berjalan di **Canvas 2D software renderer** buatan sendiri. Itu **bukan** fondasi yang layak komersial dan **tidak akan dilanjutkan**.
- Folder Unity yang ada belum berisi scene, prefab, material, animator, atau `.meta`. Anggap **belum ada proyek Unity yang berfungsi**.
- Prototipe JS dipertahankan hanya sebagai **referensi mekanik** (aturan, angka, alur), **bukan basis kode**.
- Aset `091_W_Aya` **tidak boleh dipakai** sampai lisensi dan hak rupanya terbukti jelas. Jangan memakai foto wajah nyata pada karakter.

### 5.2 Aturan tak boleh dilanggar

1. **Jujur soal kualitas.** Dilarang menulis "photorealistic", "V-Ray", "subsurface scattering", "HD", "AAA" pada kode, komentar, nama berkas, atau laporan kecuali benar-benar diimplementasikan dan terbukti lewat screenshot. Laporan menjelaskan apa yang ada, bukan apa yang diharapkan.
2. **Satu fase, satu fokus.** Kerjakan hanya fase yang diminta. **Jangan menambah fitur baru** (sistem, senjata, mekanik, misi) di luar permintaan. Dilarang menumpuk beberapa fitur besar dalam satu iterasi.
3. **Bukti wajib.** Setiap pekerjaan visual harus diakhiri dengan **screenshot atau rekaman nyata** dari game yang berjalan (bukan mockup), disertai angka performa (FPS rata-rata, 1% low, draw call, memori). Jika tidak bisa menjalankan game, **katakan tidak bisa**, jangan mengarang hasil.
4. **Satu sumber kebenaran.** Tidak ada duplikat berkas, tidak ada HTML/skrip salinan, tidak ada versi yang berbeda di tempat berbeda. Satu repo git, satu `VERSION`, satu `CHANGELOG.md`.
5. **Tidak ada base64 atau aset tertanam di kode.** Semua aset berada di folder aset dan diimpor lewat pipeline engine.
6. **Data bukan kode.** Konfigurasi level, NPC, dialog, kontrak, nilai keseimbangan disimpan di data (ScriptableObject/JSON), bukan literal yang tersebar.
7. **Lisensi dulu.** Sebelum memakai aset apa pun, catat di `ASSETS_LICENSE.md`: nama, sumber/URL, penulis, lisensi, bukti, boleh-komersial (Y/N). Tanpa catatan = jangan pakai.
8. **Konsisten gaya.** Setiap aset/efek/UI harus mengikuti `ART_BIBLE.md`. Jika ada konflik, hentikan dan tanyakan.
9. **Jangan menimpa pekerjaan yang berjalan.** Gunakan cabang git per tugas, commit kecil dengan pesan jelas. Jangan menghapus berkas pengguna tanpa persetujuan.
10. **Bertanya bila ambigu pada keputusan besar** (engine, gaya, ruang lingkup). Untuk hal kecil, ambil keputusan terbaik, catat asumsinya.
11. **Bahasa:** komunikasi dengan pengguna dalam Bahasa Indonesia; identifier, komentar kode, dan nama berkas dalam Bahasa Inggris.

### 5.3 Fase 0 — Fondasi (kerjakan lebih dulu, sebelum visual apa pun)

**Tugas:**
1. **Audit dan bekukan.** Buat cabang `legacy-js-prototype`; pindahkan seluruh prototipe JS ke `/legacy/` sebagai referensi saja. Hapus duplikat (`KageAna_Langsung_Main_PC.html`, `index.html`, `KageAna_3D_Playable.html`, folder `js/` yang divergen) dari proyek aktif.
2. **Ekstrak "spesifikasi mekanik" dari prototipe** ke `docs/DESIGN_REFERENCE.md`: daftar aksi pemain, nilai gerak (kecepatan jalan/lari/jongkok), stamina, kebisingan per permukaan, ambang kecurigaan AI, struktur 5 bab dan target, sistem kontrak/Ryo. Tuliskan **apa yang terbukti menyenangkan** dan **apa yang berlebihan**.
3. **Buat proyek baru: Unity 6 LTS + URP** (atau 2022.3 LTS bila Unity 6 tidak tersedia). Aktifkan: Input System, Cinemachine, Animation Rigging, Shader Graph, VFX Graph, Post Processing (Volume), Probuilder, Timeline. Atur Color Space = Linear.
4. **Struktur folder dan standar kode:** `Assets/_Project/{Art,Audio,Prefabs,Scenes,Scripts,Settings,UI,Data}`, assembly definition per modul, namespace `KageAna.*`, tanpa singleton liar (gunakan service locator/event channel sederhana).
5. **Dokumen wajib:** `ART_BIBLE.md` (lihat 5.4), `ASSETS_LICENSE.md`, `ARCHITECTURE.md`, `CHANGELOG.md`, `VERSION`, `README.md`.
6. **Tahap pengaman:** `.gitignore` Unity, Git LFS untuk aset biner besar, pengaturan Editor yang konsisten.

**Definition of Done Fase 0:** Proyek terbuka tanpa error; scene kosong dapat di-build ke Windows; repositori bersih; semua dokumen ada; tidak ada aset berlisensi tidak jelas.

### 5.4 `ART_BIBLE.md` (isi minimum yang harus kamu tulis dan minta persetujuan)

- **Gaya terpilih** (usulan default: *Ukiyo-e Noir cel-shaded + garis tinta* atau *Sumi-e + aksen merah*; minta pengguna memilih satu).
- **Palet** (maks. 12 warna utama + 3 aksen) dengan nilai HEX dan aturan penggunaan (60/30/10).
- **Bahasa bentuk**: karakter (proporsi, siluet), arsitektur (atap lengkung, proporsi pilar), prop.
- **Pencahayaan per waktu** (pagi/siang/sore/malam): warna matahari/bulan, kabut, intensitas, suasana.
- **Referensi visual**: 8–12 gambar/lukisan referensi (ukiyo-e Hiroshige/Hokusai, sinema Kurosawa, *Sekiro*, *Tenchu*, *Ghost of Tsushima*) dengan catatan apa yang ditiru dan apa yang tidak.
- **Aturan keterbacaan**: kontras fokal, warna musuh vs lingkungan, penandaan jalur stealth.
- **Aturan UI**: palet, font, tekstur washi, kamon.
- **Aturan kekerasan**: tingkat eksplisit, opsi gore, rating target.
- **Anggaran teknis**: poligon karakter (maks. 30–40 ribu tris pemain, 15–25 ribu NPC), ukuran tekstur (2K karakter, 1K–2K props), draw call, memori.

### 5.5 Standar kualitas yang harus dicapai (acceptance)

Tampilan:
- Ada pencahayaan terarah dengan **bayangan nyata** pada bangunan dan karakter.
- Ada **kabut atmosferik** berwarna dan **color grading** per waktu.
- Semua permukaan memakai **material bergaya** (bukan warna datar tanpa tekstur).
- Karakter adalah **model 3D ber-rig**, siluet jelas dibedakan peran dalam uji siluet hitam.
- Pedang berada di **tangan/sarung** lewat socket, dengan trail pada tebasan.
- HUD **maksimum 4 elemen** tampil sekaligus pada kondisi normal; tidak ada elemen yang saling menimpa pada 1280×720 hingga 3840×2160.

Performa (PC menengah, 1080p, preset Medium):
- **≥ 60 FPS rata-rata**, 1% low ≥ 45 FPS di area padat.
- Tidak ada alokasi memori per-frame yang berulang di jalur panas (periksa Profiler).
- Waktu muat scene ≤ 15 detik.

Kode:
- Tidak ada variabel global mutabel yang tidak perlu; setiap sistem punya satu tanggung jawab.
- Kompil tanpa peringatan; tes unit untuk logika murni (kecurigaan AI, stamina, kerusakan).
- Setiap PR menyertakan: ringkasan perubahan, screenshot sebelum/sesudah, angka performa.

### 5.6 Aturan kerja visual (wajib dipatuhi setiap tugas grafis)

1. Mulai dari **referensi**: sebutkan gambar referensi yang dipakai dari Art Bible.
2. Kerjakan berurutan: **blockout → pencahayaan → material → detail → VFX → post-FX**. Jangan memoles detail sebelum pencahayaan benar.
3. **Uji siluet** (render hitam solid) dan **uji nilai** (grayscale) untuk karakter dan komposisi.
4. Hasilkan **3 screenshot standar**: (a) pandangan pemain di awal, (b) pandangan jarak jauh/vista, (c) adegan aksi dengan NPC. Ulangi pada sore dan malam.
5. Sertakan **tabel perbandingan** sebelum/sesudah dan pengukuran FPS.
6. Jika hasil terlihat buruk, **katakan terus terang** dan jelaskan langkah perbaikan, bukan membela.

### 5.7 Kendali ruang lingkup (anti-"fitur berlebih")

Hingga vertical slice selesai, **dibekukan** (dilarang dibangun): konflik klan kompleks, deduksi petunjuk berlapis, 5 bab cerita, 6 distrik, ekonomi Ryo, jaring/kunai racun, kerja sama NPC lanjutan, mutilasi per anggota tubuh dengan IK reaksi. Semua itu ditunda sampai fondasi visual dan *game feel* terbukti memuaskan. Bila pengguna meminta fitur beku, ingatkan aturan ini dan tawarkan versi minimal.

### 5.8 Prompt per fase (berikan satu per satu)

**Prompt Fase 1 — Blockout Vertical Slice**
```
Fase 1. Buat satu area uji (±60×60 m) di Unity: jalan utama, 6–8 bangunan greybox
dengan atap bisa dipanjat, 2 jalur stealth (bayangan/atap), 1 area terbuka, 1 pos
penjaga. Pemain: kontrol orang pertama (jalan, lari, jongkok, lompat, panjat),
kamera Cinemachine halus. Tanpa musuh dulu. Hasilkan: build yang bisa dimainkan,
daftar kontrol, 3 screenshot greybox, laporan FPS. Jangan menambah fitur lain.
```

**Prompt Fase 2 — Look Dev**
```
Fase 2. Baca ART_BIBLE.md. Terapkan pencahayaan sore: matahari terarah dengan
bayangan cascade, kabut berwarna, post-processing (tone mapping, bloom halus,
color grading, AO). Buat 5 material bergaya (kayu, batu, genteng, kertas shoji,
tanah) dengan Shader Graph. Ganti blockout dengan kit modular sementara. Hasilkan
3 screenshot standar + FPS + daftar masalah visual yang tersisa. Jangan membuat
karakter di fase ini.
```

**Prompt Fase 3 — Karakter & Animasi**
```
Fase 3. Buat/impor karakter berlisensi bersih (catat di ASSETS_LICENSE.md): Pemain
dan 3 NPC (penjaga, petani, biksu) dengan rig humanoid. Siluet harus berbeda.
Implementasikan locomotion (idle/jalan/lari/jongkok), tebasan dasar, genggaman
pedang lewat socket, foot IK. Hasilkan video/screenshot uji siluet + 30 dtk gerak
tiap karakter + FPS dengan 20 NPC.
```

**Prompt Fase 4 — Game Feel & VFX**
```
Fase 4. Tambahkan hit-stop 40–80 ms, camera shake terukur, trail tebasan, percikan
logam, debu langkah, decal darah dengan opsi intensitas (Off/Rendah/Tinggi), suara
berlapis (logam, kain, daging). Sediakan perbandingan sebelum/sesudah dan toggle
gore. Jaga ≥ 60 FPS.
```

**Prompt Fase 5 — AI & Stealth**
```
Fase 5. Implementasikan AI penjaga dengan behavior tree/utility AI: sensor pandang
(kerucut + jarak + cahaya), sensor suara (kebisingan per permukaan), status
Patrol/Curiga/Cari/Tempur/Kembali, alarm dan panggilan bantuan. Buat 5 skenario
uji otomatis (lewat tak terdeteksi, terdeteksi, dicari, dibunuh senyap, kabur).
Laporkan hasil uji dan angka performa.
```

**Prompt Fase 6 — UI/UX**
```
Fase 6. Rancang HUD minimal bergaya Sengoku (washi, hanko, kamon, sapuan kuas):
bilah nyawa/stamina tipis, indikator terlihat/bising, satu prompt kontekstual.
Buat menu utama, jeda, pengaturan (grafis, audio, kontrol/remap, subtitle,
aksesibilitas), pelokalan ID/EN. Uji pada 1280×720, 1920×1080, 3840×2160 tanpa
elemen bertumpuk.
```

### 5.9 Format laporan untuk setiap penyelesaian tugas

```
## Ringkasan
(2–3 kalimat jujur: apa yang dibuat, apa yang belum)
## Bukti
- Screenshot/rekaman: (lampirkan)
- FPS rata-rata / 1% low / draw call / memori:
- Spesifikasi mesin uji:
## Perubahan
- Berkas/aset yang ditambah/diubah:
- Lisensi aset baru (ASSETS_LICENSE.md): ya/tidak
## Masalah yang masih ada
(daftar jujur, termasuk yang terlihat jelek)
## Rekomendasi langkah berikutnya
(maks. 3 butir, satu prioritas utama)
```

### 5.10 Daftar periksa "Definition of Done" tiap fase

- [ ] Proyek dibuka & di-build tanpa error/peringatan baru
- [ ] Bukti visual dan angka performa dilampirkan
- [ ] Tidak ada fitur di luar permintaan
- [ ] Tidak ada duplikasi berkas / base64 / skrip salinan
- [ ] Semua aset tercatat lisensinya
- [ ] `CHANGELOG.md` & `VERSION` diperbarui
- [ ] Masalah yang tersisa dijabarkan jujur

---

## BAGIAN 6 — Langkah Segera yang Saya Sarankan (minggu ini)

1. **Putuskan engine** (rekomendasi: Unity 6 LTS + URP) dan **gaya seni** (rekomendasi: Ukiyo-e Noir atau Sumi-e).
2. **Verifikasi lisensi `091_W_Aya`.** Jika tidak jelas, singkirkan dari proyek dan jangan didistribusikan.
3. **Bekukan fitur baru.** Tulis `DESIGN_REFERENCE.md` dari prototipe, lalu arsipkan JS.
4. **Bangun satu vertical slice 10 menit**, lalu uji kepada 5 orang asing. Mereka akan menunjukkan apa yang sebenarnya menyenangkan.
5. Gunakan Bagian 5 sebagai instruksi tetap untuk AI Anda, dan beri **satu prompt fase per sesi**.

---

## Penutup: penilaian jujur

Prototipe ini menunjukkan **imajinasi dan ambisi desain yang jelas**: dunia Sengoku, stealth sosial, deduksi identitas, respawn kuil, sistem kombat anatomis. Itu aset berharga, dan sebagian besar dapat dipindahkan sebagai desain. Namun sebagai produk visual, fondasinya tidak dapat dibawa ke level komersial; memperbaikinya berarti **mengganti fondasi, bukan menambal**. Keputusan memulai ulang dengan engine yang tepat dan satu irisan vertikal yang sungguh bagus adalah jalan tercepat menuju game yang layak jual.
