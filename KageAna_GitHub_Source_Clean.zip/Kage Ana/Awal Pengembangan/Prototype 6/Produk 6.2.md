# KAGE-ANA (影穴) — KITAB DUNIA & INSTRUKSI MAHA LENGKAP
### Satu dokumen untuk AI pengembang: dunia, jiwa, sistem, konten, standar seni, arsitektur, dan cara bekerja

> **Versi dokumen:** 3.0 · **Menggantikan:** `AGENTS.md` v2, Bagian 7 dokumen audit lama, dan Bagian 12 dokumen "Visi Ulang".
> **Dasar:** paket v2.0 yang dikirim pengguna (standar seni yang harus dilanjutkan), tambalan v2.0.1 (arah mouse), dan visi "simulasi kehidupan ganda shinobi".
> **Cara membaca:** Bagian 0 dan 1 wajib dibaca penuh sebelum menyentuh berkas apa pun. Bagian 2–7 adalah **kanon dunia dan pemeran**. Bagian 8 adalah **spesifikasi sistem**. Bagian 9 adalah **konten**. Bagian 10 adalah **standar seni**. Bagian 11–13 adalah **arsitektur, verifikasi, keputusan terbuka**. Bagian 14 adalah **rencana dan prompt**.

---

## BAGIAN 0 — PROMPT PEMBUKA (tempel ini ke AI pada awal setiap sesi baru)

```
Kamu adalah lead systems designer + gameplay engineer + technical artist untuk KAGE-ANA (影穴).
Baca SELURUH berkas KITAB DUNIA ini sebelum melakukan apa pun. Setelah itu, JANGAN langsung
menulis kode. Balas dulu dengan:
  (1) Ringkasan pemahamanmu tentang jiwa game dalam maksimal 12 baris (dengan kata-katamu sendiri),
  (2) Daftar maksimal 8 hal yang kamu anggap ambigu atau bertentangan di dokumen,
  (3) Rencana tugas pertama yang akan kamu kerjakan (sesuai fase di Bagian 14), beserta bukti
      yang akan kamu berikan di akhir.
Tunggu persetujuan saya sebelum mengerjakan. Selama bekerja, patuhi Bagian 1 (Aturan) tanpa kecuali.
Jika ada konflik antara permintaan saya dan Bagian 1, tunjukkan konfliknya dan tanya.
```

---

## BAGIAN 1 — JIWA GAME & ATURAN KERJA (tidak dapat ditawar)

### 1.1 Jiwa game (satu paragraf yang tidak boleh dilupakan)

**KAGE-ANA bukan game tentang menyelesaikan stage. Ini game tentang menjalani *kehidupan* seorang manusia yang kebetulan shinobi.** Siang hari ia adalah tetangga yang dikenal semua orang di desa: punya pekerjaan sampul, kamar sewa, utang, kebiasaan, dan wajah. Malam hari ia melakukan hal-hal gila yang tidak boleh diketahui siapa pun. **Makna, ketegangan, dan humor game ada di *sambungan* antara dua kehidupan itu.** Padanan terdekat: Assassin's Creed yang **sandbox** (dunia yang bernapas, menyamar di keramaian, pekerjaan sampingan) dengan **ritme hidup harian** ala Shenmue/Yakuza/Stardew dan **kebebasan sistemik** ala Hitman. **Tidak story-driven**: cerita *muncul dari sistem* dan kisah-kisah kecil.

### 1.2 Tiga pertanyaan "Uji Hidup" (jawab tertulis di setiap tugas)

1. **Dunia dihuni?** Apakah ini membuat dunia terasa dihuni orang yang punya hidup, jadwal, dan ingatan?
2. **Kisah tak terduga?** Apakah ini menambah kemungkinan **kejadian yang tidak kita rancang secara langsung**?
3. **Sambungan dua wajah?** Apakah ini memperkuat ketegangan antara hidup siang dan hidup malam?

Jika ketiganya "tidak", **usulkan penundaan**; jangan kerjakan.

### 1.3 Aturan wajib

1. **Sistem dulu, seni belakangan.** Sebelum **Gerbang 1 (Uji Anekdot)** lolos, dilarang memoles visual, menambah efek, atau membuat aset final. *Greybox/kapsul sah.* Setelah lolos, standar seni Bagian 10 menjadi **wajib dan tidak boleh mundur**.
2. **Simulasi terpisah dari tampilan.** Logika dunia tidak boleh bergantung pada objek render. Simulasi harus bisa berjalan **headless** dengan seed tetap.
3. **Semua konten berbasis data** (ScriptableObject/JSON + validator). Dilarang menaruh literal konten (nama, jadwal, harga, dialog) di kode.
4. **Tidak ada layar "menang/peringkat misi".** Penutupan berbentuk *Nisshi* (Bagian 8.10). Tidak ada kondisi menang tunggal.
5. **Kekerasan punya harga.** Setiap kekerasan meninggalkan jejak sistemik (saksi, noda, bau, desas-desus, Hati bergeser Dingin, riak sosial). Tidak ada kekerasan "gratis".
6. **Rutinitas harus pendek, bermakna, dan dapat dilewati.** Setiap rutinitas memberi minimal satu: informasi, akses, hubungan, atau kejutan.
7. **Jujur.** Dilarang menulis "authentic", "AAA", "rigged", "photorealistic", "ready-to-open", "100%" tanpa bukti. Komentar kode menjelaskan **apa yang dilakukan kode**, bukan memuji. Laporan selalu menyebut apa yang **belum** jadi atau **gagal**.
8. **Satu basis kode produk (Unity 6 + URP).** Prototipe WebGL = **laboratorium tampilan yang dibekukan** (hanya perbaikan bug dan eksperimen shader yang ditandai `LAB_`). Tidak ada logika/data ganda. Berkas turunan (misal `data_bundle.js`, `KageAna_Langsung_Main_PC.html`) **dihasilkan skrip**, tidak diedit tangan.
9. **Bukti wajib.** Tiap tugas diakhiri: (a) **laporan simulasi headless** (seed, N hari, daftar kejadian) bila menyentuh sistem; (b) **klip/screenshot dari build nyata** bila menyentuh tampilan; (c) angka FPS **hanya** dari GPU nyata dengan spesifikasi disebut. Angka dari renderer software harus dilabeli "**software, bukan kinerja nyata**".
10. **Aset bersih & tercatat** di `ASSETS_LICENSE.md` **sebelum** dipakai. Tidak ada foto wajah nyata, tidak ada pemindaian orang nyata, tidak ada aset "free for non-commercial". Prosedural sementara wajib berlabel `TEMP_`.
11. **Konvensi koordinat & arah (WAJIB, sumber bug sebelumnya).** Dunia memakai **sistem tangan-kiri**: `+X` = kanan layar, `+Y` = atas, `+Z` = depan saat `yaw = 0`. `forward = (sin yaw, cos yaw)`, `right = (cos yaw, -sin yaw)`. **Mouse kanan = putar kanan; mouse atas = lihat atas (kecuali opsi invert).** Unity memakai konvensi yang sama (tangan-kiri). Di renderer WebGL, `Mat4.lookAt` bersifat tangan-kanan sehingga proyeksi **dimirror di X** dan winding **CW** (lihat v2.0.1). **Dilarang** mengubah salah satu dari ini tanpa menambah/menjalankan **tes arah otomatis** (Bagian 12.6).
12. **Cabang kecil, commit jelas.** Satu fitur per cabang. Jangan menghapus berkas pengguna tanpa persetujuan.
13. **Tanya sebelum keputusan besar** (sudut pandang, nada, rating, mengganti pilar). Hal kecil: putuskan, catat asumsi di `DECISIONS.md`.
14. **Bahasa:** komunikasi dengan pengguna dalam **Bahasa Indonesia**; identifier, komentar, nama berkas dalam **Bahasa Inggris**; teks dalam game: **ID** (utama), EN, JP (istilah budaya tetap Jepang, lihat Glosarium 1.6).
15. **Jangan membuat fitur di luar fase yang diminta.** Jika menemukan ide bagus, tulis di `IDEAS.md`, jangan dibangun.
16. **Regresi seni dilarang.** Setelah Gerbang 1, setiap perubahan visual diuji terhadap **galeri acuan** (3 screenshot standar × 4 waktu). Jika terlihat lebih buruk, batalkan.

### 1.4 Hierarki otoritas dokumen

1. Instruksi langsung pengguna di sesi ini (kecuali bertentangan dengan 1.3 → tanya).
2. **Bagian 1 (Aturan)** dokumen ini.
3. Bagian 2–9 (kanon dunia, sistem, konten) dan 10 (standar seni).
4. Bagian 11–13 (arsitektur, verifikasi, keputusan) dan 14 (rencana).
5. `DESIGN_REFERENCE.md`, `ART_BIBLE.md`, `ARCHITECTURE.md` lama: hanya sejauh tidak bertentangan; **sinkronkan** dengan dokumen ini di Fase 0.

### 1.5 Prinsip desain (jadikan filter keputusan)

- **Dalam, bukan luas.** Satu desa yang padat mengalahkan kota luas yang kosong.
- **Orang di atas mekanik.** Mekanik melayani hubungan, bukan sebaliknya.
- **Setiap aksi punya gema.** Tidak ada tindakan tanpa konsekuensi yang terlihat (paling lambat esok pagi).
- **Rahasia adalah mata uang.** Informasi bernilai lebih daripada koin.
- **Hangat dan dingin harus sama-sama menggoda.** Tidak ada ujung "benar".
- **Humor gelap, bukan kekejaman kosong.** Kegilaan itu lucu *karena* dunianya terasa nyata.
- **Bisa dilewati, bisa diulang, bisa dipelajari.** Hormati waktu pemain.
- **Keterbacaan stealth adalah hukum.** Pemain harus selalu bisa menjawab: *"Kenapa aku terlihat/terdengar/dicurigai?"*

### 1.6 Glosarium (istilah tetap Jepang, jangan diterjemahkan sembarangan)

| Istilah | Arti | Istilah | Arti |
|---|---|---|---|
| **Omote (表)** | wajah luar/siang | **Ura (裏)** | wajah dalam/malam |
| **Shinobi** | mata-mata/pembunuh bayangan | **Kage-Ana (影穴)** | "lubang bayangan"; nama game, jaringan, dan teknik |
| **Washi** | kertas tradisional | **Sumi** | tinta hitam |
| **Shōji** | pintu geser kertas | **Engawa** | beranda kayu |
| **Irimoya / Kirizuma** | gaya atap | **Kawara** | genteng tanah liat |
| **Andon / Chōchin / Tōrō** | lentera kertas / gantung / batu | **Torii** | gerbang kuil |
| **Nagaya** | rumah baris | **Minka** | rumah rakyat |
| **Kosode / Hakama / Haori** | busana | **Menpō** | topeng wajah samurai |
| **Sashimono** | panji punggung | **Kabuto / Kuwagata** | helm / tanduk helm |
| **Kaginawa** | tali berkait | **Kuji-in** | segel tangan |
| **Iai** | tebasan dari sarung | **Saya / Tsuba** | sarung / pelindung tangan pedang |
| **Hanko** | stempel | **Nisshi** | buku harian |
| **Otona** | tetua desa | **Daikan** | pejabat pajak/intendan |
| **Mon / Ryō** | koin kecil / koin besar | **Matsuri** | festival |
| **Komusō** | biksu pengembara bertopi keranjang | **Miko** | gadis kuil |

---

## BAGIAN 2 — DUNIA: PREMIS, SEJARAH, DAN NADA

### 2.1 Premis dunia

**Lembah Kurokawa (黒川谷)** adalah lembah sempit di provinsi fiksi **Tsukumo**, terjepit antara dua klan yang saling mengincar. Era: **Sengoku "rasa ukiyo-e"**: bukan dokumenter sejarah, tetapi dunia bergaya cetak kayu di mana detail budaya Jepang abad pertengahan terasa benar, sementara tokoh dan klan **fiktif** (menghindari bentrok dengan tokoh sejarah nyata dan hak merek).

Di dasar lembah mengalir **Sungai Kurokawa**; di tepinya tumbuh **Desa Kurokawa** (±300 jiwa di slice; ±600 di versi penuh). Di ujung utara berdiri **Benteng Kurokawa** milik Klan Kuzuryu. Di kaki bukit barat berdiri **Kuil Kurama**. Di tikungan sungai selatan ada dermaga kecil yang menghidupi pedagang, penyelundup, dan gosip.

### 2.2 Nada (tone)

- **Siang: hangat, jenaka, sederhana.** Aroma sup miso, anak-anak berlari, penjual tahu berteriak, orang tua mengeluh soal pajak.
- **Malam: dingin, sunyi, tegang.** Lentera berkedip, langkah di atap, napas ditahan.
- **Kontras itu adalah jiwa visual dan emosional.** Transisi senja dirancang sebagai **momen ritual** (lonceng kuil, lentera dinyalakan, pemain berganti pakaian).
- **Humor:** absurd, kering, manusiawi. Ketakutan dan tawa hidup berdampingan.
- **Kekerasan:** diperlakukan serius dan berat; gaya visual cetak tinta; konsekuensi nyata (Bagian 1.3 #5).
- **Hindari:** parodi murahan, eksotisme Jepang klise, ninja "sihir". Shinobi adalah **orang biasa dengan keterampilan luar biasa dan rahasia**.

### 2.3 Sejarah singkat (latar; sebarkan lewat dunia, bukan layar teks)

| Tahun lalu | Peristiwa | Jejak yang bisa ditemukan pemain |
|---|---|---|
| ±40 | Kurokawa makmur di bawah Klan Asagiri; jalan dagang utama | Rumah-rumah pedagang tua, batu sumpah |
| ±8 | **Perang Kabut**: Kuzuryu menyerbu lembah di musim kabut; Asagiri runtuh, banyak warga tewas | Makam tua, bekas hangus di gudang, ucapan lirih para tetua |
| ±8–3 | Kuzuryu memasang garnisun dan menaikkan pajak; Sindikat Kuro-no-Wa tumbuh sebagai peminjam uang | Catatan utang, penagih, bendera klan di mana-mana |
| ±3 | **Sensei Muraku**, guru pemain, menghilang setelah mengirim surat terakhir | Surat tersembunyi, simbol rahasia di kuil, hasil bumi yang tak masuk akal |
| Sekarang | Tahun pertama pemain tinggal sendirian di desa; ketegangan dengan Shirahane meningkat | — |

### 2.4 Legenda inti: "Kage-Ana" (bahan desas-desus dan lore)

> *Di lembah ini dipercaya ada "lubang" tempat bayangan jatuh dan tidak kembali. Seorang pendekar tua menyelam ke bayangannya sendiri untuk menyelamatkan desa dari api, dan tak pernah muncul lagi. Orang menyebut tempat-tempat gelap di bawah atap tua sebagai **kage-ana**: "lubang bayangan". Anak-anak dilarang berdiri di sana saat senja.*

Legenda ini **memiliki kebenaran mekanik**: teknik Shadow-Meld adalah tradisi rahasia yang diwariskan di jaringan shinobi yang menamai diri **Ryū Kage-Ana** (rumah-rumah rahasia, simbol bayangan, surat kode). Pemain adalah **murid terakhir yang tersisa di lembah**.

### 2.5 Folklor sebagai alat desas-desus (gunakan di Papan Tinta & rekayasa rumor)

| Folklor | Arti dalam desa | Pemakaian gameplay |
|---|---|---|
| **Kitsune** (rubah kuil) | Pembawa pesan dewa Inari; rubah yang menipu | Pemain bisa "menjadi kitsune" di festival (topeng) |
| **Nopperabō** (hantu tanpa wajah) | Hantu penakut anak-anak | Rumor "wajah tanpa rupa" menakuti penagih pajak |
| **Yūrei** (arwah) | Arwah korban Perang Kabut | Efek Obon; pemain menyamar sebagai arwah sebagai taktik |
| **Tanuki** | Makhluk jenaka penipu | Julukan untuk pedagang licik |
| **Oni** | Setan penolak bala saat Setsubun | Topeng oni = penyamaran sempurna |

---

## BAGIAN 3 — GEOGRAFI: LEMBAH KUROKAWA DAN DESA

### 3.1 Skala dan struktur

- **Peta penuh (target pasca-demo):** ±400 m × 400 m inti desa + lembah, hutan bambu, ladang berundak, jalan raya ke kota benteng, kaki Gunung Kurama.
- **Slice "Satu Hari, Dua Wajah":** **3 distrik inti** (Nagaya, Pasar Timur, Dermaga) + sepenggal jalan ke Benteng. Cukup ±150 × 150 m.
- **Waktu tempuh jalan kaki:** gerbang selatan → pasar ±90 dtk; pasar → dermaga ±60 dtk; nagaya → kuil ±150 dtk; nagaya → benteng ±200 dtk. (Hitung dalam **waktu nyata**; 1 hari game = 18 mnt nyata.)

### 3.2 Tata letak (diagram konseptual, utara di atas)

```
                         ▲ UTARA
        Hutan Bambu      │       Jalan Raya ke Kota Benteng (kaido)
   ┌───────────────┐     │   ┌──────────────────────────────┐
   │ Gunung Kurama │     │   │  BENTENG KUROKAWA (D7)        │
   │ Kuil Kurama   │     │   │  Menara Utara · Pelataran     │
   │   (D4)        │     │   │  Barak Garnisun               │
   └───────┬───────┘     │   └───────────────┬──────────────┘
           │ tangga batu │                   │ jalan samurai
   ┌───────┴───────┐  ┌──┴───────────────┐   │
   │  NAGAYA (D1)  │  │ PASAR TIMUR (D2) │───┘
   │ Rumah pemain  │  │ Lapak · Rumah teh│
   │ Rumah Ohana   │  │ Klinik Sōan      │
   └───────┬───────┘  └────────┬─────────┘
           │                   │
   ┌───────┴───────┐  ┌────────┴─────────┐   ┌────────────────┐
   │ LADANG (D6)   │  │ KURA / GUDANG(D5)│───│ DUNIA BAWAH(D8)│
   │ Penggilingan  │  │ Rentenir Kurobē  │   │ Rumah judi     │
   └───────────────┘  └────────┬─────────┘   └────────────────┘
                               │
                    ┌──────────┴─────────┐
                    │ DERMAGA (D3)       │   ~~~~ Sungai Kurokawa ~~~~
                    │ Perahu · Pelabuhan │
                    └────────────────────┘
                         ▼ SELATAN (Gerbang Selatan, jalan hutan)
```

*(Posisi relatif; AI boleh menyesuaikan di greybox selama hubungan antar distrik, waktu tempuh, dan tiga lapis rute dipertahankan.)*

### 3.3 Prinsip tata ruang (wajib di setiap distrik)

1. **Tiga lapis rute:** **tanah** (ramai, terang, sosial), **atap** (cepat, licin, sepi, ada kaginawa), **bawah/saluran/kolong** (sempit, gelap, bau).
2. **Satu landmark vertikal per distrik** yang terlihat dari mana pun (menara, pagoda kecil, pohon kuil, cerobong asap).
3. **Satu "ruang bernapas"**: halaman/lapangan kecil untuk interaksi sosial, festival, atau duel.
4. **Satu rahasia tata ruang** per distrik: pintu tersembunyi, kolong, lubang bayangan (*kage-ana*) yang dapat ditemukan.
5. **Identitas visual** (palet turunan, bahan, suara, aroma) berbeda per distrik.
6. **Penanda jalur Ura konsisten:** **kain putih (sarashi)** = bisa dipanjat; **simbol bayangan kecil** = rumah rahasia; **lentera padam** = area gelap aktif.
7. **Ruang interior** bisa dimasuki di setiap distrik (minimal 2 bangunan) untuk kehidupan nyata, bukan hanya fasad.

### 3.4 Rincian distrik

#### D1 — NAGAYA (長屋) · Permukiman Rakyat · *Rumah pemain*
- **Identitas:** deretan rumah baris kayu beratap papan/jerami, gang sempit, sumur bersama, jemuran, kucing.
- **Palet turunan:** krem kusam, cokelat jerami, biru indigo pudar pada kain, **aksen jemuran putih**.
- **Bangunan kunci:** **Kamar sewa pemain** (lantai atas rumah Ohana; ±3 × 4 m, tatami 6 mat, jendela shōji menghadap atap), **Rumah Ohana (pemilik)**, Rumah Tsuru & Mio, Sumur Bersama, Bengkel Genta (tukang kayu), kuil kecil Jizō.
- **Suara:** ayam, anak-anak, sapu, ember di sumur, percakapan tetangga, lonceng kuil.
- **Ura:** atap rendah berurutan (jalan mulus di atas desa), kolong rumah, ruang rahasia di bawah lantai kamar.
- **Fungsi sistemik:** pusat **gosip rakyat**, **rumah** (tidur/simpan), tempat **sewa** ditagih, tempat tetangga **melihat** kondisi pemain tiap pagi/malam.

#### D2 — PASAR TIMUR (東市) · Pusat Ekonomi & Informasi
- **Identitas:** jalan lebar, lapak kain, ikan, sayur, tahu, obat; rumah teh; papan pengumuman; spanduk Za (serikat pedagang).
- **Palet turunan:** krem terang, biru-hitam sumi, **aksen kain berwarna** (satu-satunya area warna jenuh lebih tinggi), **kuning lentera** sore hari.
- **Bangunan kunci:** **Lapak penjual obat** (cover job pemain, disewa), **Rumah Teh Okiku**, **Klinik Tabib Sōan**, Gudang Za Haruki, Papan Pengumuman (sumber **gig** dan pajak), Menara Lonceng kecil.
- **Suara:** teriakan pedagang, tawar-menawar, wajan, anak-anak, sarugaku jalanan pada festival.
- **Ura:** atap pasar yang bersambung, keranjang dan peti sebagai penutup, keramaian sebagai tempat sembunyi.
- **Fungsi sistemik:** **hub informasi terbesar**; zona dengan **pengawasan sosial tertinggi** (banyak saksi) namun **kamuflase keramaian** terbaik.

#### D3 — DERMAGA (川端, Kawabata) · Sungai & Perdagangan
- **Identitas:** tiang kayu, perahu, jaring, tali, bau ikan dan lumpur, gudang apung, jembatan kayu.
- **Palet turunan:** biru-hijau sungai (turunan indigo), cokelat basah, **kabut pagi** tebal.
- **Bangunan kunci:** **Pos perahu Sabu**, **Gudang Perahu**, Rumah Ine (serikat perahu), Pos Pemeriksa Pajak Sungai (kecil), Jembatan Gantung.
- **Suara:** air, kayu berderit, camar, dayung, bel perahu.
- **Ura:** kolong jembatan, perahu sebagai transport tak terpantau, jalur air ke Kura.
- **Fungsi sistemik:** penyelundupan, gosip pelayar, **jalur kabur**, area **licin** dan **sunyi malam**.

#### D4 — KUIL KURAMA (鞍馬社) · Spiritual & Netral
- **Identitas:** tangga batu panjang, torii merah berderet, pohon kamper raksasa, lonceng perunggu, kebun batu.
- **Palet turunan:** **cinnabar** dominan pada torii, hijau lumut gelap, krem batu.
- **Bangunan kunci:** **Aula utama (Haiden)**, **Rumah Pendeta Jikai**, Paviliun lonceng, **Kebun Obat Kuil**, **Makam tua** (di belakang).
- **Suara:** lonceng, doa, kerikil, angin di pohon.
- **Ura:** **tanah netral** (kekerasan di sini menyebabkan pelanggaran berat), tempat **penyembuhan** dan **pengakuan**, **gudang rahasia Ryū Kage-Ana** di bawah lantai.
- **Fungsi sistemik:** penyembuhan luka, **pengurangan Dingin**, informasi spiritual/rumor, titik **hidup kembali** (bangkit di Kuburan Tua → Kuil, dari v0.7, versi terkendali).

#### D5 — KURA (蔵) · Gudang & Rentenir
- **Identitas:** gudang bata/kayu berdinding putih, besi, tali, timbangan, tumpukan karung beras dan sake.
- **Palet turunan:** putih plester, hitam sumi, **kuning lentera** terbatas.
- **Bangunan kunci:** **Gudang Kurobē (rentenir)**, Gudang Beras Desa (pajak), Gudang Sake, Pos Jaga Gudang.
- **Suara:** timbangan, peti, penjaga mengobrol, tikus.
- **Ura:** sasaran utama pencurian, sabotase, pembakaran, pencurian catatan utang.
- **Fungsi sistemik:** **ekonomi gelap**, **utang rakyat**, **titik ledak** konflik Kuro-no-Wa × Kuzuryu.

#### D6 — LADANG & PENGGILINGAN (田畑) · Hamlet Petani
- **Identitas:** sawah berundak, saluran air, kincir air, rumah jerami, orang-orangan sawah.
- **Palet turunan:** hijau musim, emas panen, hitam lumpur.
- **Bangunan kunci:** **Penggilingan air Sakubei**, Rumah Petani, Gudang Padi, Jalan Tanggul.
- **Suara:** air, serangga, kincir, nyanyian kerja.
- **Ura:** pertemuan rahasia petani pemberontak (lumbung), jalan tanggul sebagai jalur kabur, hamparan sawah = tanpa bayangan (sulit).
- **Fungsi sistemik:** **siklus panen & pajak**, **kelaparan**, **sekutu rakyat**.

#### D7 — BENTENG KUROKAWA (黒川城) · Kekuasaan
- **Identitas:** dinding batu rendah, gerbang kayu besar, **Menara Utara** (landmark), pelataran, barak, taman dalam.
- **Palet turunan:** **Ai-Zome Indigo** (zirah dan panji), hitam sumi, cinnabar pada panji.
- **Bangunan kunci:** **Gerbang Benteng**, **Pelataran (slice v2.0)**, **Menara Utara** (Komandan Gen'emon), Barak, Kantor Daikan, Penjara Kecil, Taman dalam, Rumah Tuan.
- **Suara:** langkah sepatu, baju zirah, perintah singkat, genderang.
- **Ura:** infiltrasi (inti kemampuan stealth lama), dokumen, penyelamatan tahanan.
- **Fungsi sistemik:** sumber **patroli**, **pajak**, **hukuman**; reaksi terkeras terhadap pelanggaran. **Akses sipil terbatas** (hanya dengan izin, pakaian, atau alasan).

#### D8 — DUNIA BAWAH (裏町, Uramachi) · Kuro-no-Wa
- **Identitas:** gang gelap di belakang gudang, rumah minum, rumah judi, lorong lentera merah redup.
- **Palet turunan:** **cinnabar redup**, hitam, **kuning lentera** minim.
- **Bangunan kunci:** **Rumah Judi Oryū**, **Izakaya Kobushi**, Gudang Barang Selundupan, Pintu Rahasia ke Kura.
- **Suara:** dadu, tawa serak, musik shamisen pelan, rumor.
- **Ura:** pasar gelap, kontak, info, pekerjaan berisiko.
- **Fungsi sistemik:** **pemberi gig besar**, **pasar alat**, tempat **reputasi dunia bawah**; berbahaya bagi yang tidak dikenal.

### 3.5 Di luar desa (konten pasca-demo)

- **Hutan Bambu:** jalur sembunyi, bandit, latihan rahasia, kuburan lama.
- **Gunung Kurama:** kuil tua, gua guru (**Gua Kage-Ana**), jalur ke provinsi lain.
- **Kaido (Jalan Raya):** ke kota benteng; pos pemeriksaan; pedagang keliling; pasukan lewat.
- **Hulu Sungai:** bendungan dan bendungan runtuh (peristiwa banjir).
- **Desa Tetangga (Shirahane):** konflik klan dan pembukaan wilayah baru.

### 3.6 Hubungan dengan slice v2.0

Peta v2.0 ("Benteng Luar Kurokawa — 60×60 m") = **bagian dari D7 (Pelataran + Menara Utara)**. Aset, shader, tata letak torii/lentera/shoji, dan siluet penjaga **dipertahankan** sebagai **sektor Benteng**, bukan sebagai level mandiri. Menara Utara adalah **satu lokasi pekerjaan bayangan** dari banyak, bukan klimaks.

---

## BAGIAN 4 — FAKSI & KEKUASAAN

### 4.1 Daftar faksi

| Faksi | Wajah publik | Wajah rahasia | Mau apa | Ancaman/peluang bagi pemain |
|---|---|---|---|---|
| **Klan Kuzuryu (九頭龍)** | Penguasa sah lembah; pajak & ketertiban | Haus perang, menekan, korup di tingkat bawah | Pajak, tentara, kendali jalan raya | Patroli, hukuman, pangkat; target & klien |
| **Klan Shirahane (白羽)** | Tetangga dagang yang sopan | Jaringan mata-mata, ingin merebut lembah | Informasi, titik lemah, sekutu lokal | Rival shinobi (Hisame), tawaran gelap |
| **Sisa Klan Asagiri (朝霧)** | Dikenang oleh orang tua | Pemberontakan senyap | Pembalasan, pemulihan | Sekutu emosional; sumber sejarah |
| **Kuro-no-Wa (黒ノ輪)** | Peminjam uang & pedagang "jasa" | Penyelundupan, judi, pemerasan | Utang, kendali dermaga/kura | Pemberi gig besar; pembunuh bila dikhianati |
| **Kuil Kurama** | Spiritual, penyembuh, netral | Menyembunyikan jaringan Kage-Ana | Keseimbangan, melindungi warga | Pembimbing, rem moral, tempat aman |
| **Za Pasar (座)** | Serikat pedagang | Penjual info, pengatur harga | Pasar tertib, laba | Akses, harga, saksi |
| **Serikat Perahu** | Pelayar | Penyelundup, mata-mata sungai | Upah adil, bebas tarif | Sekutu logistik |
| **Para Petani & Otona** | Rakyat bekerja | Kelompok protes pajak | Panen cukup, pajak ringan | Basis rakyat; yang paling pantas dilindungi |
| **Ryū Kage-Ana** | — | Jaringan shinobi (tinggal pemain & beberapa kontak) | Bertahan, melindungi lembah | Guru, teknik, tanggung jawab |

### 4.2 Peta pengaruh (nilai awal, 0–100; berubah oleh tindakan pemain dan peristiwa)

| Distrik | Kuzuryu | Kuro-no-Wa | Rakyat | Shirahane (rahasia) |
|---|---|---|---|---|
| D1 Nagaya | 25 | 15 | 60 | 0 |
| D2 Pasar | 35 | 20 | 35 | 10 |
| D3 Dermaga | 20 | 40 | 30 | 10 |
| D4 Kuil | 5 | 0 | 90 | 5 |
| D5 Kura | 30 | 55 | 10 | 5 |
| D6 Ladang | 40 | 10 | 50 | 0 |
| D7 Benteng | 100 | 0 | 0 | 0 |
| D8 Dunia Bawah | 10 | 80 | 5 | 5 |

**Efek:** pengaruh Kuzuryu tinggi → patroli lebih banyak, razia, hukuman keras. Pengaruh Kuro-no-Wa tinggi → utang menjerat, gig besar, kekerasan jalanan. Pengaruh Rakyat tinggi → informasi mengalir, penyamaran lebih mudah, sewa lebih ramah. **Pemain tidak "mengambil alih"**; ia **menggeser keseimbangan**.

### 4.3 Hubungan antar faksi (grafik ringkas)

- Kuzuryu ↔ Kuro-no-Wa: **simbiosis tegang** (Kuzuryu menutup mata, Kuro-no-Wa membayar "uang aman"; Komandan Gen'emon berutang pada Kurobē).
- Kuzuryu ↔ Shirahane: **permusuhan dingin**; mata-mata di desa.
- Kuzuryu ↔ Rakyat: **penindasan pajak**.
- Kuro-no-Wa ↔ Rakyat: **menjerat lewat utang**, tapi juga **memberi pinjaman saat panen gagal**.
- Kuil ↔ semua: **netral**, memihak yang lemah.
- Shirahane ↔ Kuro-no-Wa: **transaksi informasi** (sembunyi).

---

## BAGIAN 5 — MASYARAKAT, ETIKET, DAN BUDAYA SEHARI-HARI

### 5.1 Lapisan sosial (dan cara mereka memperlakukan pemain)

| Lapisan | Contoh di desa | Perilaku ke pemain |
|---|---|---|
| **Bushi (samurai)** | Garnisun, Daikan | Mengharapkan penghormatan; curiga pada senjata sipil |
| **Hyakusho (petani)** | Sakubei, Tsuru | Hangat tapi hati-hati; takut pajak |
| **Shokunin (pengrajin)** | Genta, pembuat lentera | Menghargai kerja; solid |
| **Shōnin (pedagang)** | Haruki, Okiku | Transaksional; menghargai informasi |
| **Sō (pendeta/biksu)** | Jikai, Sayo, Tengai | Dihormati; netral |
| **Orang pinggir / rantau** | Pekerja dermaga, pelayar, pengembara | Terbuka pada yang jujur; sumber rumor |

*(Perlakukan semua lapisan dengan martabat. Jangan memakai stereotip atau istilah merendahkan.)*

### 5.2 Etiket (sumber kecurigaan lunak dan kejutan komedi)

Pelanggaran etiket menambah **Kecurigaan Sosial** kecil. Ini **membuat penyamaran terasa nyata**.

| Pelanggaran | Penambahan (awal) | Catatan |
|---|---|---|
| Tidak membungkuk kepada samurai | +8 | Tidak berlaku bila bersembunyi |
| Berlari di pasar/dalam rumah | +6 | Kecuali darurat (terlihat panik) |
| Masuk rumah dengan alas kaki / menginjak tatami berkasut | +12 | Pemain harus melepas sandal |
| Menginjak ambang pintu | +4 | |
| Menatap samurai langsung | +5 | |
| Membawa pedang terlihat sebagai rakyat biasa | +25 | Zona sipil |
| Memakai topeng di siang hari (di luar festival) | +15 | |
| Salah gerakan tarian festival | +6 | Kejutan komedi |
| Aksen/ungkapan tidak cocok dengan "asal-usul" cover | +4–10 | Berbasis riwayat palsu |
| Datang terlambat ke pekerjaan sampul | +5 (per jam) | Memicu pertanyaan |

### 5.3 Salam, sapaan, dan bahasa

- **Sapaan:** *-san* (umum), *-sama* (hormat tinggi), *-dono* (samurai), *-sensei* (guru/tabib), *-obaa/-ojii* (kakek-nenek).
- **Dialog dalam game:** Bahasa Indonesia yang hidup dan singkat, diselipi istilah Jepang untuk rasa. **Suara:** gumaman singkat bahasa Jepang (barks) rekaman nyata; teks ID/EN.
- **Gaya penulisan:** kalimat pendek, konkret, sedikit humor kering; hindari eksposisi panjang. **Setiap NPC punya satu "kebiasaan bicara"** (mis. Ohana selalu menghitung uang, Gonzō selalu berteriak).

### 5.4 Pakaian dan identitas (rangkuman; matriks lengkap di 9.6)

Pakaian adalah **bahasa sosial**. Ia menentukan zona yang boleh dimasuki, kecurigaan, dan cara NPC menyapa. Jenis: kosode petani, hakama pedagang, jubah biksu, pakaian tukang, pakaian penjual obat (cover), yukata santai, haori pelayan teh, zirah ringan (hasil curian), **shōzoku shinobi** (hitam; hanya wajar di Ura/malam).

### 5.5 Makanan, bau, dan benda sehari-hari (detail yang membuat dunia nyata)

- **Makanan:** nasi, miso, acar (tsukemono), tahu, ikan bakar, mochi, sake, teh. Setiap rumah makan punya aroma khas yang memengaruhi **bau** pemain.
- **Bau:** lumpur sungai, darah, asap, obat, sake, ikan. NPC dengan **penciuman tajam** (anjing, tabib) dapat mendeteksinya.
- **Benda sehari-hari:** sapu, ember, tikar, jemuran, arang, sandal jerami, payung kertas. Ini juga **alat sistemik** (menjatuhkan ember = suara, jemuran = penutup visual, payung = penyamaran dalam hujan).

---

## BAGIAN 6 — KALENDER, EKONOMI, DAN ATURAN DUNIA

### 6.1 Waktu

- **1 hari game = 18 menit nyata (default; dapat diubah di data).** 1 jam game = 45 detik nyata.
- **7 hari = 1 musim; 4 musim = 1 tahun (28 hari ≈ 8,4 jam nyata).**
- **Segmen hari (jam game):** Fajar 05–07 · Pagi 07–11 · Siang 11–15 · Sore 15–18 · Senja 18–20 · Malam 20–01 · Dini 01–05.
- **Lonceng kuil:** berbunyi saat 06:00 (bangun), 12:00 (siang), 18:00 (senja), 22:00 (jaga malam). Penanda waktu **diegetik**.
- **Tidur:** dapat melewati waktu (maks. setara 8 jam game), tetapi peristiwa tetap berjalan; tidur di tempat tak aman berisiko.

### 6.2 Musim dan cuaca (pengaruh gameplay)

| Musim | Hari | Cuaca khas | Dampak |
|---|---|---|---|
| **Semi (Haru)** | 1–7 | Cerah-berkabut, hujan ringan | Hanami (H3); orang di luar; jalan basah; kabut pagi (jarak pandang ↓) |
| **Panas (Natsu)** | 8–14 | Panas, badai sore | Obon (H11); malam pendek; serangga; air sungai tinggi |
| **Gugur (Aki)** | 15–21 | Sejuk, berangin | **Pajak & Panen (H19)**; daun kering = suara langkah ↑ |
| **Dingin (Fuyu)** | 22–28 | Dingin, salju | Setsubun (H26); jejak kaki terlihat di salju; napas beruap; lentera lebih penting |

**Cuaca (dapat acak per hari, bobot musim):** cerah, mendung, kabut, hujan, badai, salju, angin kencang. **Dampak:** *hujan* meredam suara langkah di atap (−30%), memperlicin genteng, mematikan lentera terbuka, menurunkan keramaian pasar; *kabut* memangkas jarak pandang dua arah; *angin* menutupi suara (+) tetapi memadamkan lentera acak; *salju* meninggalkan jejak; *badai* menunda pekerjaan sampul.

### 6.3 Peristiwa terjadwal (tahun pertama)

| Hari | Peristiwa | Efek sistemik |
|---|---|---|
| 3 | **Hanami** (festival bunga) | Keramaian, sake, penjaga lengah, tontonan sarugaku, kesempatan menyamar |
| 7 | **Jatuh tempo sewa pertama** (juga setiap 7 hari) | Tekanan ekonomi |
| 11 | **Obon** (menyambut arwah; lentera di sungai) | **Kekerasan dilarang tabu** (penalti sosial ×3), penjaga berkurang, ritual keluarga |
| 14 | **Kedatangan rombongan Shirahane** (pedagang) | Mata-mata masuk; peluang gig |
| 19 | **Pajak & Panen Raya** (Aki-matsuri) | Pasar penuh; **Daikan** mengambil beras; ketegangan puncak |
| 22 | **Inspeksi Kuzuryu** | Patroli ×2, razia rumah acak |
| 26 | **Setsubun** (topeng oni, pengusiran setan) | Topeng di mana-mana = **penyamaran sempurna** |
| 28 | **Akhir tahun** | **Nisshi** (Bagian 8.10) |

**Kolam peristiwa acak (bobot musiman):** wabah demam, kebakaran rumah, banjir sungai, perampok gunung, rombongan hiburan, pasukan lewat, panen gagal, kelahiran, kematian tokoh, penangkapan, razia pajak, pedagang hilang, kunjungan Komusō.

### 6.4 Ekonomi

- **Mata uang:** **Mon** (harian) dan **Ryō** (besar). Disederhanakan: **1 Ryō = 1.000 Mon**.
- **Harga awal (dapat diubah, bergantung panen dan peristiwa):**

| Barang/jasa | Mon |
|---|---|
| Semangkuk nasi + acar | 12 |
| Makan di rumah teh | 30 |
| Cawan sake | 10 · Botol sake 40 |
| Obat dasar | 25 · Obat kuat/racun halus 80–200 |
| Perban + ramuan luka | 35 |
| Sewa kamar (per 7 hari) | 350 |
| Pajak rumah tangga (hari 19) | 600 |
| Suap kecil (penjaga) | 50–150 |
| Alat (kunai/tali/bom asap) | 40–180 |
| Pakaian (cover/pinjam) | 150–500 |

- **Pendapatan:** pekerjaan sampul **60–120 Mon/hari** (stabil), pekerjaan bayangan **300–1.500 Mon** (berisiko), pencurian (cepat, ketahuan).
- **Mencuci uang & menjelaskan kekayaan:** pendapatan besar yang tak sesuai pekerjaan sampul menambah **Kecurigaan Sosial**. Cara menjelaskan: pekerjaan sampul bagus, "warisan", "pinjaman", investasi di lapak, sumbangan kuil.
- **Utang:** pemain bisa berutang pada Kuro-no-Wa (bunga tinggi, risiko kekerasan) atau pada tetangga (hubungan).
- **Harga bergerak:** panen buruk → beras ↑ → rakyat lapar → gig lebih banyak → Kuro-no-Wa kuat. Perang/kunjungan → harga senjata ↑.

### 6.5 Hukum dan hukuman (di bawah Kuzuryu)

| Pelanggaran | Konsekuensi |
|---|---|
| Mencuri kecil | Denda; reputasi ↓; ditahan jika tertangkap |
| Menyerang penjaga | Kejaran; hadiah kepala |
| Membunuh warga | Razia; pengawasan; hukuman berat bila terbukti |
| Membunuh samurai | **Perburuan besar**; patroli ×3; hadiah |
| Melanggar tabu festival | Penalti sosial besar |
| Kekerasan di tanah Kuil | Pelanggaran spiritual; kehilangan tempat aman; Jikai berpaling |

---

## BAGIAN 7 — PEMERAN: 26 PENDUDUK LEMBAH KUROKAWA

> Setiap NPC adalah **entri data** (Bagian 11.3), bukan skrip. Kolom "Kebiasaan bicara" dan "Rahasia" wajib ada. **Setiap NPC punya jadwal, ingatan, dan sifat** yang berubah oleh tindakan pemain. Usia/peran boleh disesuaikan; hubungan dan fungsi sistemik harus dipertahankan.

### 7.1 Tabel pemeran

| # | ID | Nama & peran | Distrik | Sifat (0–10: ramah/curiga/berani) | Kebiasaan bicara | Rahasia | Fungsi sistemik |
|---|---|---|---|---|---|---|---|
| 1 | `ohana` | **Ohana**, pemilik rumah sewa, janda 50-an | D1 | 7/6/4 | Menghitung uang sambil bicara | Menyimpan surat Sensei Muraku | Menagih sewa, mengamati kondisi pemain tiap pagi |
| 2 | `tsuru` | **Tsuru**, petani tua tetangga | D1/D6 | 8/3/3 | Mengeluh soal punggung & pajak | Menyembunyikan beras dari Daikan | Sekutu rakyat, sumber rumor panen |
| 3 | `mio` | **Mio**, cucu Tsuru, 9 tahun | D1 | 9/2/6 | Bertanya "kenapa?" | Pernah melihat sosok di atap | **Saksi paling polos**; bisa membocorkan tanpa sadar |
| 4 | `genta` | **Genta**, tukang kayu | D1 | 6/4/5 | Menepuk kayu sebelum menjawab | Membuat peti rahasia untuk Kurobē | Pengrajin (alat, perbaikan), sumber info jalur |
| 5 | `okiku` | **Okiku**, pemilik rumah teh | D2 | 8/7/3 | Memanggil semua orang "sayang" | Mendengar semua; menjual info ke Za | **Hub gosip**; pekerjaan sampul (pelayan) |
| 6 | `soan` | **Tabib Sōan**, dokter desa | D2 | 5/8/4 | Menciumi luka dan tangan | Pernah merawat Sensei Muraku | **Mengenali bau/luka**; memberi penyembuhan, risiko kecurigaan |
| 7 | `haruki` | **Haruki**, ketua Za Pasar | D2 | 4/6/4 | Menyebut harga sebelum sapaan | Membayar Kurobē | Harga, akses, informasi pasar |
| 8 | `gonzo` | **Gonzō**, penjual ikan | D2 | 7/4/7 | Berteriak | Mantan prajurit Asagiri | Keramaian, informasi tentang tentara |
| 9 | `fumie` | **Fumie**, penjual obat (pemilik lapak yang disewa pemain) | D2 | 7/5/4 | Mengutip peribahasa | Menjual racun diam-diam | **Pekerjaan sampul** pemain; sumber bahan |
| 10 | `sabu` | **Sabu**, pemilik perahu | D3 | 6/5/6 | Menggerutu pada sungai | Menyelundupkan untuk Kuro-no-Wa | Transport, jalur kabur |
| 11 | `ine` | **Ine**, pemimpin serikat perahu | D3 | 6/6/8 | Berbicara pelan, tajam | Menyembunyikan buronan | Sekutu logistik; konflik tarif |
| 12 | `jikai` | **Pendeta Jikai** | D4 | 8/5/5 | Menjawab dengan pertanyaan | Mengetahui jaringan Kage-Ana | **Rem moral**, penyembuhan, pengurangan Dingin |
| 13 | `sayo` | **Sayo**, miko muda | D4 | 8/4/6 | Bernyanyi pelan | Menyukai seseorang di garnisun | Pesan, ritual, festival |
| 14 | `tengai` | **Tengai**, Komusō pengembara | D4/D7 | 5/6/7 | Diam, memainkan seruling | **Mata-mata Shirahane yang ragu** | Pembawa pesan, tawaran gelap |
| 15 | `kurobe` | **Kurobē**, rentenir (Kuro-no-Wa) | D5 | 3/8/6 | Tersenyum sebelum mengancam | Menyimpan catatan utang Komandan | Pemberi utang & gig besar |
| 16 | `oryu` | **Oryū**, pemilik rumah judi | D8 | 5/7/7 | Suara serak, memanggil "tamu" | Mantan penari istana | Pasar gelap, informasi dunia bawah |
| 17 | `kobushi` | **Kobushi**, pemilik izakaya | D8 | 6/6/6 | Mengelap gelas tanpa henti | Menyembunyikan kurir | Rumor malam, tempat bertemu |
| 18 | `sakubei` | **Sakubei**, pemilik penggilingan | D6 | 6/5/4 | Menghitung karung | Menyimpan lumbung rahasia | Siklus panen; gerakan protes pajak |
| 19 | `genemon` | **Komandan Gen'emon**, Menara Utara | D7 | 2/6/9 | Perintah dua kata | Berutang pada Kurobē | Patroli, pangkat, target |
| 20 | `daikan` | **Daikan Matsuzaemon**, pejabat pajak | D7/D2 | 2/9/2 | Mencatat segalanya | Menggelapkan pajak | Pajak, razia, **target moral** |
| 21 | `guard_a` | **Penjaga Gerbang (Ryōta)** | D7 | 4/6/6 | Menguap, mengeluh shift | Berutang judi pada Oryū | **Penjaga dapat disuap/dipermalukan** |
| 22 | `guard_b` | **Penjaga Patroli (Jūbei)** | D2/D7 | 5/7/7 | Bersiul | Menyukai Sayo | Patroli pasar; kelemahan sosial |
| 23 | `hisame` | **Hisame**, shinobi Shirahane (samaran: pedagang kain) | D2/D3 | 6/9/8 | Sopan berlebihan | Mengincar pemain | **Rival** pencarian informasi |
| 24 | `kaede` | **Kaede**, pemuda teman masa kecil pemain; kini pelayan di benteng | D7 | 7/5/4 | Bercanda canggung | Terpaksa menjadi informan Daikan | Hubungan emosional; dilema |
| 25 | `muraku` | **Sensei Muraku** (menghilang) | — | — | — | Nasibnya adalah **misteri jangka panjang** | Surat, petunjuk; **bukan misi utama** |
| 26 | `neko` | **Kucing Kuro** (kucing nagaya) | D1 | — | — | — | **Detektor** saksi; mengikuti pemain; menyingkap tempat sembunyi |

**Kebutuhan sistemik:** minimal **6 NPC** punya **rahasia yang dapat diketahui lewat observasi** (bukan dialog); minimal **4** punya **kelemahan yang dapat dieksploitasi dengan cara berbeda** (hutang judi, cinta, takut hantu, takut Daikan, dst.).

### 7.2 Jaringan hubungan (kunci; gunakan di Papan Tinta)

```
Ohana — (menyimpan surat) — Sensei Muraku — (dirawat) — Sōan
Ohana — (tetangga) — Tsuru — (kakek) — Mio
Okiku — (jual info) — Haruki ——(bayar)——> Kurobē ——(piutang)——> Gen'emon
Gen'emon — (komando) — Ryōta, Jūbei
Jūbei — (suka) — Sayo — (guru) — Jikai
Ryōta — (utang judi) — Oryū — (Kuro-no-Wa) — Kurobē
Sabu — (selundup) — Kurobē ; Ine — (sembunyi buronan) — Jikai
Hisame — (selidik) — Pemain ; Tengai — (ragu) — Hisame
Kaede — (informan paksa) — Daikan ; Kaede — (teman masa kecil) — Pemain
```

### 7.3 Contoh data NPC (format acuan; AI harus mengikuti skema ini)

```json
{
  "id": "ohana",
  "displayName": { "id": "Ohana", "jp": "お花" },
  "role": "landlady",
  "home": "D1_nagaya_house_ohana",
  "traits": { "friendliness": 7, "suspicion": 6, "courage": 4, "gossip": 7, "greed": 6 },
  "speechHabit": "counts_coins_while_talking",
  "schedule": [
    { "from": "05:30", "to": "07:00", "activity": "sweep_yard",   "place": "D1_yard",          "interruptible": true },
    { "from": "07:00", "to": "08:00", "activity": "breakfast",    "place": "D1_house_ohana",   "interruptible": true },
    { "from": "08:00", "to": "11:30", "activity": "market_buy",   "place": "D2_market",        "interruptible": true },
    { "from": "11:30", "to": "13:00", "activity": "chat_well",    "place": "D1_well",          "interruptible": true },
    { "from": "13:00", "to": "16:00", "activity": "sew",          "place": "D1_house_ohana",   "interruptible": true },
    { "from": "16:00", "to": "18:00", "activity": "collect_rent", "place": "D1_alley",         "interruptible": true, "condition": "rentDueToday" },
    { "from": "18:00", "to": "21:00", "activity": "dinner_visit", "place": "D1_house_tsuru",   "interruptible": true },
    { "from": "21:00", "to": "05:30", "activity": "sleep",        "place": "D1_house_ohana",   "interruptible": false, "wakeOnNoise": 0.35 }
  ],
  "memoryDecayPerDay": 0.08,
  "keyBeliefsSeed": [ { "subject": "player", "claim": "quiet_good_tenant", "confidence": 0.6 } ],
  "secrets": [ { "id": "muraku_letter", "discoverBy": ["observe_hide_spot", "bribe", "persuade_warm"] } ],
  "reactions": { "seeBlood": "scream_call_guard", "smellSmoke": "investigate", "findStolenGoods": "ask_then_tell_neighbors" }
}
```

*(Skema final dan validator di Bagian 11.3. Semua jam dalam format 24 jam game.)*

### 7.4 Jadwal "hari biasa" ringkas untuk lima NPC kunci (untuk pengujian)

| Jam | Ohana | Okiku | Ryōta (penjaga gerbang) | Jikai | Kurobē |
|---|---|---|---|---|---|
| 06 | menyapu | buka rumah teh | bangun/barak | doa pagi | tidur |
| 09 | belanja pasar | melayani | jaga gerbang | kebun obat | menghitung catatan |
| 12 | sumur/gosip | makan siang | makan | pelayanan warga | makan di Kura |
| 15 | menjahit | gosip sore | patroli | meditasi | menagih utang |
| 18 | menagih sewa | ramai | ganti shift | lonceng senja | ke izakaya |
| 21 | makan malam | tutup | jaga malam / minum diam-diam | tidur | rumah judi |
| 00 | tidur | tidur | **berjudi di D8 jika libur** | tidur | rapat |

---

## BAGIAN 8 — SISTEM: SPESIFIKASI DETAIL & ANGKA AWAL

> **Semua angka di bawah adalah *nilai awal* untuk tuning**, harus disimpan di `Data/tuning/*.json` dan dapat diubah tanpa kompilasi. Setiap sistem harus punya **debug overlay** dan **uji headless**.

### 8.1 Jam dunia & cuaca

- `World.Clock`: tick tetap **10 Hz simulasi**; 1 detik nyata = 1,33 menit game (1 hari = 18 menit nyata).
- Pemicu terjadwal: `OnHour`, `OnDayStart`, `OnSeasonChange`, `OnFestival(id)`.
- Cuaca: ditarik per pagi dengan `Random(seed, day)`, bobot musiman di `weather.json`; transisi mulus 60 dtk game.
- **Penerangan:** `LightingPreset` per *(segmen waktu × cuaca)* (Bagian 10.6) mengatur sun, ambient, fog, lantern intensity.

### 8.2 NPC: jadwal, persepsi, ingatan

**Jadwal (Schedule):** daftar blok (7.3). Tiap tick, NPC memilih blok aktif → menuju `place` memakai NavMesh → menjalankan `activity` (animasi + interaksi). Blok dapat **diinterupsi** (`interruptible`) oleh peristiwa; setelah selesai, NPC kembali ke blok atau **menyesuaikan** (terlambat, pulang cepat).

**Persepsi:**
| Parameter | Nilai awal |
|---|---|
| Jarak lihat (siang, cerah) | 22 m |
| Jarak lihat (malam, tanpa lentera) | 9 m · dengan lentera di dekat target: 16 m |
| Sudut pandang | 110° (penjaga 90°; anak 130°) |
| Kabut | ×0,5 |
| Hujan | ×0,8 (suara ×0,7) |
| Dengar langkah (berjalan) | 6 m · jongkok 2 m · lari 14 m · lompat mendarat 18 m |
| Dengar benda jatuh | 15 m (ember kaleng 25 m) |
| Cium (anjing/tabib) | 5 m, melawan arah angin ×0,3 |
| Waktu kenal (visual penuh) | 1,2 dtk; 0,6 dtk bila dekat, 2,5 dtk bila jauh |

**Tingkat kesadaran (per NPC per target):** `Unaware → Curious → Suspicious → Alerted → Hostile`. Naik cepat bila melihat darah/mayat/senjata/wajah dikenal; turun lambat (15–40 dtk per tingkat; lebih lama untuk penjaga). **Selalu tampilkan penanda di atas kepala NPC** (ikon tanda tanya/!, mengikuti gaya cap hanko).

**Ingatan (Memory):**
```
MemoryEntry {
  id, subject (npcId/player/object), event (typed), place, time,
  confidence 0..1, source: Saw | Heard | Told | Inferred,
  emotion: Fear | Anger | Joy | Trust | Disgust,
  tellable: bool, decay 0..1/day
}
```
- Kejadian saksi → `confidence 0.9`; kabar dari orang → `0.4–0.6`; kesimpulan → `0.3`.
- **Ingatan memudar** (`decay` default 0,08/hari; kejadian emosional kuat 0,03/hari).
- **Keyakinan (Belief)** dibentuk dari ingatan: contoh `"player_is_dangerous": 0.35`. Keyakinan memengaruhi perilaku (sapaan, harga, kerja sama, laporan).
- **Hukum "tidak ada pengetahuan gratis":** NPC **tidak mengetahui apa pun** yang tidak pernah dialami/diberitahu melalui jalur nyata. Dilarang memberi NPC akses ke kebenaran dunia.

### 8.3 Grafik Rumor

- Satuan: `Rumor { id, claim (typed), originNpc, truth: bool|partial, strength 0..1, tags[] }`.
- **Penyebaran:** saat dua NPC berinteraksi (percakapan, sumur, rumah teh, izakaya), peluang menularkan rumor = `gossip(A) × relasi(A,B) × strength × (1 − skeptisisme(B))` dengan `strength` berkurang 15% per lompatan dan terdistorsi 10% (detail berubah: jumlah, wajah, tempat).
- **Distorsi (daftar):** *membesar-besarkan* (1 orang → 3 orang), *salah orang* (target tertukar), *salah tempat*, *kehilangan detail penting*, *tambahan bumbu*.
- **Kecepatan kasar:** dari rumah teh ke seluruh pasar ±1 hari game; ke seluruh desa ±2–3 hari.
- **Pemain dapat:** (a) **menanam rumor** (bayar Okiku, tinggalkan petunjuk, mengucapkan di tempat tepat), (b) **membungkam** (menyuap, mengancam, membuktikan sebaliknya), (c) **membaca** lewat **Papan Tinta** (peta rumor: node = NPC, garis = penyebaran).
- **Papan Tinta:** UI washi di rumah; hanya menampilkan **rumor yang diketahui pemain** (ia harus mendengarnya). Kualitas kepastian ditampilkan sebagai **ketebalan tinta**.

### 8.4 Identitas ganda: Kecurigaan Sosial & Jejak

**Kecurigaan Sosial (per NPC dan global per distrik), 0–100:**
| Sumber | Tambah |
|---|---|
| Luka terlihat (tanpa penjelasan) | +10…+25 |
| Bau darah/asap/obat | +8…+15 |
| Uang tak wajar | +10 per 500 Mon tak dijelaskan |
| Absen dari kerja sampul tanpa alasan | +6 per absen |
| Terlihat memakai shōzoku di siang hari | +40 |
| Pelanggaran etiket (5.2) | +4…+25 |
| Melihat pemain di dua tempat tidak mungkin | +20 |
| Kebohongan terbongkar | +15 |
| Rumor terkait | + (strength × 20) |

| Penurun | Kurang |
|---|---|
| Alibi/saksi yang kredibel | −15 |
| Membantu warga di depan umum | −5 per tindakan |
| Hari tenang | −3/hari |
| Sumbangan kuil | −8 |
| Rumor tandingan | −(strength × 15) |

**Ambang & dampak:** `<30` normal · `30–59` bisikan, harga naik 10%, NPC menatap · `60–79` ditanyai penjaga/tetangga, bisa digeledah · `≥80` **penggerebekan**, hukuman, kehilangan pekerjaan sampul (konsekuensi bertahap, bukan *game over*).

**Jejak fisik:** noda darah (ditempel di pakaian & lantai), bau, benda berharga curian, jejak kaki di salju/lumpur, pakaian robek, barang hilang di lokasi. Semuanya **entitas dunia** yang dapat ditemukan NPC; pemain dapat membersihkan dengan **tindakan**, bukan menu.

### 8.5 Hati: Hangat ↔ Dingin

- Skala `-100 (Dingin) … +100 (Hangat)`; awal **0**.
- **Pergeseran:** membantu warga (+2…+8), menyelamatkan nyawa (+10), hadir festival (+3), kebaikan kecil harian (+1); membunuh warga (−25), menghabisi tak berdaya (−15), kekerasan di tanah kuil (−30), menjebak orang tak bersalah (−12), mengabaikan orang yang minta tolong (−2); tidak ada pergeseran untuk membunuh **penjaga yang menyerang** (netral, tetapi tetap berkonsekuensi sosial).
- **Efek (bukan buff kosong, melainkan *perubahan dunia*):**
  - **Hangat tinggi:** NPC menawarkan bantuan sukarela, lebih toleran, rumor positif, sewa dapat ditunda, ritual kuil terbuka; tetapi **tawaran gelap/gig besar berkurang**, pemain dianggap "lunak".
  - **Dingin tinggi:** gig besar & dunia bawah terbuka, penjaga segan, harga info turun; tetapi **tetangga menghindar**, anak-anak lari, **Mio berhenti menyapa**, sewa dinaikkan, dukungan kuil hilang.
  - **Seimbang:** campuran; penggunaan terbaik "dua wajah". Tidak ada ujung yang *benar*.
- **Visual (diegetik):** warna lentera kamar pemain (hangat↔pucat), tanaman di jendela (hidup/layu), sapaan, bayangan pemain (tajam/lembut).

### 8.6 Kekerasan, luka, dan konsekuensi

- **Mode kekerasan (opsi pengguna):** Off (hanya melumpuhkan) / Low (noda minimal) / High (cipratan tinta penuh).
- **Luka:** `Light / Medium / Heavy`; memengaruhi **kecepatan, suara, noda, bau**; sembuh dengan waktu/obat/tabib/kuil. Luka **terlihat** → Kecurigaan Sosial.
- **Mayat:** entitas yang dapat ditemukan (waktu temuan acak 1–30 mnt game tergantung rute patroli); dapat disembunyikan (peti, sungai, kolong) dengan risiko; **menemukan mayat memicu rumor + razia**.
- **Pembunuhan senyap** vs **gaduh**: perbedaan **suara 4 m vs 20 m**; saksi menambah rumor; tidak ada "bar alarm global" tunggal, **informasi menyebar secara fisik** (NPC berlari memberi tahu, lonceng dibunyikan).
- **Nonmematikan adalah pilihan nyata**: pingsan (durasi 30–120 dtk), ikat, sembunyikan; membangun **jejak** berbeda.

### 8.7 Pekerjaan sampul & ekonomi pribadi

- **Pekerjaan sampul (pilih 1 di Hari 1):** Penjual Obat (lapak Fumie), Pelayan Rumah Teh (Okiku), Kuli Dermaga (Sabu), Asisten Tukang Kayu (Genta). Masing-masing punya **jam kerja**, **peluang informasi unik**, **bonus kamuflase**, dan **risiko**.
- **Shift:** 2–3 jam game, dapat **dilewati** (hasil singkat/tanpa bonus) atau **dimainkan** (mini-aksi ringan: melayani, menimbang, mengangkat; ±45 dtk nyata per shift jika dimainkan).
- **Konsekuensi absen:** reputasi kerja turun, Kecurigaan Sosial naik, upah hilang.
- **Pengeluaran wajib:** sewa (350/7 hari), makan (≈36/hari), pajak (600 pada H19). Jika uang kurang: utang → tekanan → gig mendesak (mendorong **pilihan moral**, bukan *fail state*).

### 8.8 Gig (pekerjaan bayangan) sistemik

**Sumber gig:** Papan Pengumuman (sah), Okiku (gosip), Kurobē/Oryū (gelap), Jikai (moral), Tengai (Shirahane), Kaede (pribadi), peristiwa dunia.

**Struktur data gig:**
```
Gig {
  id, giver, title, brief, targetType (item|person|info|sabotage|rescue),
  locations[], timeWindow, rewardMon, rewardOther (relasi/akses/info),
  approaches[] (tag), requirements[], consequencesOnSuccess[], consequencesOnFail[],
  rippleTemplates[], moralWeight (−1..+1), visibility (Omote|Ura)
}
```
**Tag pendekatan wajib ≥3 per gig:** `Quiet` (senyap) · `Social` (menyamar/bujuk/suap) · `Loud` (gaduh) · `Clever` (alat/lingkungan/rumor) · `Merciful` (tanpa korban) · `Cruel`.
**Riak (ripple):** setiap gig menghasilkan **efek 1–3 hari kemudian** yang terlihat pemain (mis. mencuri lonceng kuil → Sayo menangis, Jikai bertanya, anak-anak ketakutan, harga lilin naik).
**Gagal ≠ mengulang level:** gagal memicu **konsekuensi** (dikenali, luka, utang, hubungan rusak) dan **jalan lanjut**.

### 8.9 Aspirasi (tujuan jangka panjang buatan pemain)

Pemain memilih/menulis **1–3 aspirasi** di Hari 1–3, bukan tujuan wajib. Contoh: **Pelunasan** (lunasi utang Tsuru), **Pelindung** (jaga Mio aman), **Hantu** (jadi legenda yang tak pernah tertangkap), **Pengusaha** (kuasai lapak pasar), **Pencari** (temukan nasib Sensei Muraku), **Penyeimbang** (hapus pengaruh Kuro-no-Wa), **Pemberontak** (bantu petani menolak pajak). Aspirasi memicu **kisah kecil** dan **catatan Nisshi**; tidak ada layar "tercapai".

### 8.10 Nisshi (penutup tahun)

Pada Hari 28, game menyusun **gulungan Nisshi** (washi yang terbentang): 12–20 butir catatan, ditulis dari **peristiwa nyata** tahun itu (tiga kali kamu dipergoki; tetangga yang mati; utang terbayar; siapa yang berhenti menyapa; berapa rumor tentangmu yang benar). Tidak ada nilai/peringkat. Pemain boleh **menyimpan salinan** (screenshot/ekspor) dan **memulai Tahun Kedua** dengan dunia yang membawa akibat.

### 8.11 Kisah muncul dari sistem (Uji Anekdot)

Daftar **jenis kejadian yang harus bisa muncul** (bukan skrip): salah tangkap karena rumor; tetangga menutupi pemain; penjaga berutang disuap; anak melihat atap; tabib mengendus luka; penagih pajak diserang bandit & pemain ada di dekatnya; kucing membocorkan tempat sembunyi; festival kacau karena pembunuhan; panen gagal memicu pemberontakan kecil; Hisame menjebak pemain dengan rumor. **Gerbang 1** menguji bahwa ≥3 dari 5 orang asing dapat menceritakan **anekdot spesifik tak dirancang**.

### 8.12 Level-of-detail simulasi (kinerja)

| Tingkat | Siapa | Frekuensi | Isi |
|---|---|---|---|
| **L0 Penuh** | NPC dalam 40 m dari pemain | 10 Hz | Persepsi, nav, animasi, interaksi |
| **L1 Ringan** | 40–120 m | 2 Hz | Jadwal, nav kasar, tanpa animasi detail |
| **L2 Abstrak** | >120 m / luar layar | 1 per menit game | Hanya posisi tempat & status; **rumor dan ingatan tetap diperbarui** |
**Tidak boleh** ada kebohongan lintas LOD: ketika NPC L2 berubah ke L0, posisi harus konsisten dengan jadwalnya.

### 8.13 Penyimpanan & debug

- **Simpan:** seluruh status serializable (waktu, NPC, ingatan, rumor, ekonomi, pemain, flag peristiwa, seed). Versi skema + migrasi.
- **Debug (wajib sebelum Gerbang 1):** percepatan waktu (×1/×10/×60), teleport, pemeriksa NPC (jadwal, ingatan, keyakinan, rumor yang diketahui), graf rumor, **simulasi 28 hari headless dengan seed dan laporan kejadian**, pencatat metrik anekdot.

---

## BAGIAN 9 — KONTEN: KISAH KECIL, GIG, PAKAIAN, FESTIVAL, 7 HARI PERTAMA

### 9.1 Dua puluh empat "Kisah Kecil" (Small Stories)

> **Kisah Kecil = kejadian bersyarat berbasis sistem**, bukan cutscene. Setiap kisah: **pemicu** (kondisi dunia) → **pengembangan** (NPC bertindak sesuai sifat) → **pilihan pemain** (≥3 jalan) → **riak**. Dibangun sebagai data (`StoryBeat`), 2–6 menit bermain. Wajib: tiap kisah dapat **dilewati tanpa menghentikan dunia**, dan dapat **gagal secara menarik**.

| # | Judul | Pemicu | Inti | Pilihan khas |
|---|---|---|---|---|
| 1 | **Ember di Pagi Hari** | Hari 1–2, pemain pulang pagi | Ohana mendapati pemain pulang saat fajar | Bohong (ibadah), jujur sebagian, bayar diam |
| 2 | **Kucing Kuro Tahu** | Pemain menyembunyikan barang di nagaya | Kucing menggali/menyeret barang ke depan Ohana | Ambil kembali, alihkan kecurigaan, beri ikan |
| 3 | **Mio dan Orang di Atap** | Mio melihat pemain di atap (saksi anak) | Mio bertanya polos di depan banyak orang | Mengaku "kucing besar", janji kembang gula, ajak ia jadi "penjaga rahasia" |
| 4 | **Pajak Tsuru** | Hari 17–19, Tsuru kurang beras | Daikan akan menyita rumah Tsuru | Curi beras Daikan, bayar sendiri, laporkan ke Kuil, biarkan |
| 5 | **Luka yang Berbau** | Luka Medium/Heavy dan bertemu Sōan | Sōan mengenali bau luka senjata | Ceritakan separuh, bayar tutup mulut, kabur, jadi pasien resmi |
| 6 | **Rumor Wajah Kosong** | Pemain bertopeng terlihat | Desa menyebarkan "nopperabō" | Perkuat (takuti penagih), bantah, ikuti rumor ke sumbernya |
| 7 | **Penjaga yang Berutang** | Ryōta kalah judi | Oryū menekan Ryōta | Bantu lunasi, beri dia dosa untuk dipakai, biarkan |
| 8 | **Cinta di Garnisun** | Jūbei sering lewat kuil | Sayo & Jūbei saling suka; Gen'emon melarang | Bantu surat, menjebak Jūbei, melindungi dari Gen'emon |
| 9 | **Barang Pesanan Kurobē** | Genta membuat peti tak biasa | Isi peti: catatan utang desa | Curi untuk membakar, curi untuk memeras, kembalikan |
| 10 | **Obon: Lentera untuk Siapa?** | Hari 11 | Setiap NPC melepas lentera untuk seseorang | Menyalakan lentera untuk Sensei? untuk korban sendiri? ikut ritual atau menyabotase |
| 11 | **Hisame Tersenyum** | Hisame sering di pasar | Hisame menukar info dengan pemain | Terima, palsu, singkirkan, laporkan ke Gen'emon |
| 12 | **Tengai dan Seruling** | Tengai muncul malam | Pesan kode dalam melodi | Terjemahkan, curi pesan, bunuh, lindungi |
| 13 | **Mayat di Sungai** | Pemain menyembunyikan mayat | Sabu menemukan di jaringnya | Suap Sabu, tuduh orang lain, ambil jalan jujur |
| 14 | **Sake Hanami** | Hari 3 | Penjaga mabuk, anak-anak berlari | Mencuri kunci, jadi penari, menjaga anak Mio |
| 15 | **Surat dari Kamar Ohana** | Surat Sensei dijaga Ohana | Surat terselip, petunjuk ke gua | Curi, bujuk, bantu Ohana lunas utang |
| 16 | **Wabah Demam** | Acak musim panas | Sōan butuh ramuan dari gunung | Ambil ramuan, jual, curi dari Daikan |
| 17 | **Kebakaran di Kura** | Pemain/peristiwa | Api menjalar ke nagaya | Selamatkan, biarkan gudang Kurobē terbakar, padamkan rahasia |
| 18 | **Banjir Hulu** | Hari 12–13 hujan lebat | Sungai naik; dermaga terancam | Selamatkan perahu Ine, ambil kargo, bantu warga |
| 19 | **Kaede Mengintip** | Kaede bekerja di benteng | Kaede memata-matai atas perintah Daikan | Beri info palsu, ungkap, selamatkan ia |
| 20 | **Utang Sendiri** | Uang pemain < 0 | Kurobē menawarkan jalan keluar | Terima gig, lunasi dengan kerja sampul, rampok balik |
| 21 | **Penagih Pajak Dirampok** | Hari 19–20 | Bandit menyerang Daikan | Selamatkan (hangat), biarkan, ikut merampok |
| 22 | **Pelayat di Makam** | Pembunuhan warga | Keluarga korban berduka di kuil | Mengakui, menyamar sebagai pelayat, menghilang |
| 23 | **Setsubun, Topeng Oni** | Hari 26 | Semua orang bertopeng | Membunuh tanpa dikenali? mencuri? melindungi? festival tetap berjalan |
| 24 | **Surat Terakhir Sensei** | Aspirasi "Pencari" | Petunjuk menuju Gua Kage-Ana | Teruskan, hentikan, jangan ungkap |

### 9.2 Dua belas templat Gig (data yang harus tersedia di slice)

| # | Gig | Pemberi | Tipe | Lokasi | Pendekatan | Imbalan | Riak |
|---|---|---|---|---|---|---|---|
| G1 | **Catatan Utang Kurobē** | Jikai (moral) / Kaede | Info | D5 Kura | Quiet / Clever / Cruel | 600 Mon + Hangat | Utang warga hilang; Kurobē curiga ke Haruki |
| G2 | **Pesan untuk Tengai** | Tengai | Item | D4→D7 | Quiet / Social | 300 Mon | Rumor mata-mata; Gen'emon waspada |
| G3 | **Lonceng Kuil** | Oryū | Item | D4 | Loud / Cruel | 900 Mon, Dingin | Jikai berpaling, desa takut |
| G4 | **Hilang di Pasar** | Okiku | Orang (cari) | D2 | Social / Clever | 150 Mon + info | Orang selamat; penculik bangkit |
| G5 | **Cap Daikan** | Kurobē | Item | D7 kantor | Quiet / Clever | 1.200 Mon | Pajak palsu; Daikan menuduh pegawai |
| G6 | **Kargo Sabu** | Sabu | Item | D3 | Clever / Loud | 500 Mon | Pos pajak sungai diperketat |
| G7 | **Tabib Dibungkam** | Haruki | Orang | D2 | Cruel / Social | 800 Mon, Dingin | Sōan hilang; wabah memburuk |
| G8 | **Antar Surat Cinta** | Sayo | Info | D4→D7 | Social / Quiet | 100 Mon + Hangat | Jūbei berubah; Gen'emon marah |
| G9 | **Pengawal Daikan** | Daikan | Rescue | D2→D7 | Loud / Social | 700 Mon, Dingin | Pemain terlihat bersama pejabat |
| G10 | **Beras Rahasia** | Tsuru | Item | D6→D1 | Quiet / Merciful | 200 Mon + Hangat | Daikan menyidik; Sakubei tegang |
| G11 | **Tahanan Penjara Kecil** | Ine | Rescue | D7 | Quiet / Clever / Loud | 1.000 Mon | Perburuan; buronan di rumah Ine |
| G12 | **Pembakar Gudang** | Hisame | Sabotase | D5 | Loud / Clever | 1.500 Mon, risiko Shirahane | Kura terbakar; harga meroket |

### 9.3 Template aspirasi → rantai kisah (contoh)

- **Pelindung (Mio):** Kisah 3 → 4 → 17 → 22 → (opsional) Mio kelak ikut latihan.
- **Pencari (Sensei):** Kisah 15 → 12 → 24 → akses Gua Kage-Ana (konten pasca-demo).
- **Pemberontak:** Kisah 4 → 21 → G10 → pertemuan rahasia petani (D6) → pembukaan jalur Shirahane.
- **Hantu:** Kisah 6 → 11 → G1/G5 → desas-desus legenda; pemain jadi "Kage-Ana" yang diceritakan anak-anak.

### 9.4 Festival (cetak biru acara)

| Festival | Hari | Aktivitas | Aturan sistemik |
|---|---|---|---|
| **Hanami** | 3 | Bawah pohon sakura di kuil; sarugaku; sake | Penjaga mabuk, kerumunan, **penalti kekerasan ×2** |
| **Obon** | 11 | Lentera di sungai, tarian bon, ziarah makam | **Kekerasan tabu ×3**; arwah (yūrei) dipakai sebagai kedok |
| **Aki-matsuri** | 19 | Pajak, panen, pasar besar | Daikan hadir; konflik puncak |
| **Setsubun** | 26 | Topeng oni, lempar kacang, pengusiran setan | **Topeng sah di siang hari**; penyamaran maksimal |

*Tiap festival punya **minigame ringan opsional** (tari bon, lempar kacang, sarugaku) berdurasi ≤90 dtk dan memberi **kenalan/pengurangan kecurigaan**.*

### 9.5 Rumah & kamar pemain (ruang paling penting)

- **Kamar sewa:** tatami 6 mat, futon, meja rendah, tempat sembunyi lantai, jendela shōji → atap, **Papan Tinta** di dinding, kotak alat, gantungan pakaian.
- **Fungsi:** tidur, simpan, ganti pakaian (Omote ↔ Ura), membaca rumor, membersihkan luka, merawat tanaman jendela (indikator Hati).
- **Ritual masuk/keluar:** melepas sandal, menutup shōji; suara pintu memengaruhi Ohana (0,3 peluang bangun).
- **Ruang rahasia:** di bawah tatami; dapat diretas oleh Ohana/Hisame bila kecurigaan tinggi.

### 9.6 Matriks pakaian (identitas)

| Pakaian | Zona wajar | Kecurigaan (di luar zona) | Efek |
|---|---|---|---|
| Kosode petani | D1, D6, D2 | +0 | Kamuflase rakyat |
| Pakaian pekerjaan sampul | Zona kerja | +0 | Akses lapak/rumah teh |
| Yukata/haori santai | D1, D2, D4 | +0 | Bonus keramahan |
| Jubah biksu/Komusō | D4, D7 (luar) | +0 | Hormat, tak diganggu; tidak boleh membawa senjata |
| Zirah ringan curian | D7 | +10 di luar | Akses benteng, **mudah ketahuan bila wajah dikenal** |
| Topeng oni/kitsune | Festival | +15 di luar | Anonim |
| Shōzoku shinobi | Malam/Ura | +40 di siang | Stealth ↑, **suara kain ↓** |

### 9.7 Tujuh Hari Pertama (onboarding tanpa tutorial layar)

| Hari | Fokus | Hal yang dipelajari pemain (tanpa teks panjang) |
|---|---|---|
| **1** | Bangun; sapaan Ohana; pilih pekerjaan sampul; keliling nagaya | Dunia berjalan sendiri; kamu punya rumah |
| **2** | Hari kerja; pasar; rumah teh; dengarkan gosip | **Informasi = mata uang**; jadwal NPC |
| **3** | **Hanami** (festival); malam pertama keluar | Keramaian = kamuflase; pertama kali Ura |
| **4** | Utang kecil; gig kecil (G4/G8); luka kecil | Konsekuensi; Sōan mengenali bau |
| **5** | Papan Tinta pertama; rumor tentangmu | Rumor adalah sistem; reputasi |
| **6** | Pilih aspirasi; pertemuan Hisame (kerabat/rival) | Tujuan sendiri; saingan |
| **7** | **Sewa jatuh tempo**; ringkasan pekan | Ritme pekan; pilihan keuangan |

**Aturan:** tidak ada tutorial modal. Panduan lewat **NPC, benda, dan petunjuk diegetik**; tombol bantuan opsional ([F1]) menampilkan gulungan ringkas.

---

## BAGIAN 10 — STANDAR SENI (kelanjutan v2.0; WAJIB setelah Gerbang 1)

> **Prinsip utama:** *Ukiyo-e yang bergerak.* Kita **tidak** mengejar fotorealisme. Kita mengejar **identitas visual yang tak salah dikenali dalam satu screenshot**: tinta, washi, siluet jelas, satu warna aksen.

### 10.1 Palet & aturan warna (dipertahankan dari v2.0)

| Token | Hex | Peran |
|---|---|---|
| Washi Cream | `#EAE0C8` | Terang, kertas, langit siang, shōji |
| Sumi Blue-Black | `#101622` | Gelap utama, siluet, outline |
| Ai-Zome Indigo | `#1F3A60` | Warna dasar kain/rakyat, bayangan sejuk |
| Cinnabar | `#C8232C` | **Satu-satunya aksen** (torii, panji, hanko, bahaya) |
| Lantern Gold | `#F5B041` | **Satu-satunya cahaya hangat** |

- **Aturan 60/30/10:** 60% netral (washi/sumi), 30% indigo, 10% aksen (cinnabar + emas).
- **Per distrik:** turunan palet (3.4) dalam **±12% saturasi/hue**, **tidak melanggar token inti**.
- **Aksen terbatas:** cinnabar muncul pada ≤8% piksel layar (kecuali Kuil D4: ≤14%).
- **Warna jenuh tinggi** hanya di Pasar (kain), bunga hanami, dan topeng festival.

### 10.2 Hierarki nilai tiga bidang (dipertahankan; diuji dengan F4 grayscale)

1. **Latar:** nilai paling terang/gelap, gradien kabut (bokashi).
2. **Tengah:** bangunan/NPC, kontras sedang, outline tebal.
3. **Depan:** siluet gelap dengan kontras tinggi (tiang, tanaman, tangan pemain).
**Gerbang F4:** pada mode grayscale, **siluet NPC & jalur utama harus terbaca di ketiga bidang**. Jika tidak, ubah nilai, bukan menambah efek.

### 10.3 Garis, bayangan, dan langit

- **Outline inverted-hull:** luar 0,022 m, dalam 0,009 m, menipis dengan jarak (fade 40–90 m); jangan menebal di bawah 0,005 m.
- **Bayangan:** shadow map 2048 dengan PCF; **kolam bayangan "arsiran"** (hatching) untuk area stealth yang terbaca dengan jelas; bayangan wajah/halus tidak boleh "kotor".
- **Cel shading:** 3 band + rim indigo; pencahayaan lentera sebagai **kolam emas** (bukan gradien halus).
- **Langit bokashi:** gradien horizontal; matahari/bulan **disk datar**; awan = siluet washi tipis.
- **Kabut:** eksponensial, berwarna indigo-krem; kabut pagi di dermaga lebih tebal.
- **Tekstur:** prosedural/tangan, LINEAR_MIPMAP_LINEAR; **tidak boleh** NEAREST pada permukaan terlihat. **Dilarang** tekstur foto tanpa lisensi.

### 10.4 Anggaran (budget)

| Aset | Batas |
|---|---|
| Viewmodel (tangan + senjata) | ≤ 18k tri |
| NPC | ≤ 10k tri (LOD1 4k, LOD2 1,5k) |
| Modul bangunan | ≤ 4k tri |
| Prop kecil | ≤ 800 tri |
| Draw call | ≤ 600 (laboratorium WebGL) / ≤ 1.500 (Unity) |
| Tekstur | 1024 px NPC; 2048 px modul; atlas bersama |
| Memori (Unity, target PC) | ≤ 3 GB |

### 10.5 Library aset yang harus dibuat (daftar kerja)

**Arsitektur (modul bisa digabung):** atap kirizuma/irimoya/yosemune (tiga varian warna kawara), dinding papan, dinding plester putih, shōji, fusuma, engawa, tangga, pagar bambu, pintu gerbang, **kura** (gudang berdinding plester), **torii** (3 ukuran), tōrō batu, lonceng, sumur, jembatan kayu, dermaga, perahu (2 tipe), kincir air, menara jaga, dinding benteng (batu bata), panji, kolong rumah, atap berserak.
**Alam:** pohon kamper, sakura, bambu (rumpun, bisa bergoyang), pinus, rumput (billboard bergaya tinta), batu sungai, lumut, daun jatuh (partikel), kabut volumetrik palsu (kartu), padi berundak.
**Prop kehidupan:** ember, sapu, tikar, jemuran (kain), payung kertas, keranjang, peti, karung beras, guci sake, timbangan, lapak, papan pengumuman, lentera (andon/chōchin), arang, panci, sandal, futon, meja rendah, **Papan Tinta**.
**Karakter:** 26 NPC (Bagian 7) dengan **siluet unik per sosok**; 6 basis tubuh (anak, perempuan tua, laki-laki tua, dewasa laki/perempuan, tegap), **modular pakaian** (kosode, hakama, haori, jubah biksu, zirah ringan, shōzoku), 12 wajah gaya cetak (tidak foto), rambut modular (chonmage, ikat, panjang, botak).
**Hewan:** kucing Kuro (animasi lengkap), anjing penjaga, ayam, kuda, burung gagak/camar, ikan, kunang-kunang.
**Viewmodel/pemain:** tangan, katana, tanto, kunai, kaginawa, bom asap, shuriken, tali, lentera tangan, obat; **animasi iai**, parry, lempar, panjat, gantung, jongkok.

### 10.6 Preset pencahayaan: Waktu × Cuaca (WAJIB data, bukan hard-code)

| Segmen | Matahari/Bulan | Ambient | Fog (warna/kerapatan) | Lentera | Catatan visual |
|---|---|---|---|---|---|
| **Fajar 05–07** | Disk datar rendah, jingga muda | Indigo lembut | Krem-indigo, **tebal** | Padam bertahap | Kabut dermaga; kokok ayam |
| **Pagi 07–11** | Putih krem, bayangan panjang | Krem hangat | Tipis | Padam | Palet terang; warna jenuh pasar |
| **Siang 11–15** | Putih tinggi, bayangan pendek | Netral | Minimal | Padam | Kontras tertinggi; sunyi suara |
| **Sore 15–18** | Emas rendah, bayangan panjang | Emas-indigo | Hangat sedang | **Mulai menyala** | Jam "emas" tempat percakapan |
| **Senja 18–20** | Disk merah-jingga; bulan muncul | Indigo-ungu | Indigo | **Menyala (kolam emas)** | **Ritual senja (lonceng, ganti pakaian)** |
| **Malam 20–01** | Bulan disk krem | Sumi-indigo gelap | Indigo gelap | Kolam emas terbatas | Kontras stealth; bayangan hatch |
| **Dini 01–05** | Bulan rendah | Hampir gelap | Biru-hitam | Hanya sedikit | **Paling sunyi; risiko tertinggi** |

**Variasi cuaca:** *mendung* (kontras −30%, tanpa bayangan keras), *hujan* (streak tinta, genangan memantulkan lentera, suara langkah teredam), *kabut* (jarak pandang −50%, siluet + lentera tetap terbaca), *salju* (putih menambah luminansi; jejak kaki jadi bahasa), *badai* (kilat sebagai flash putih-sumi sekali).

### 10.7 UI & HUD (empat elemen)

- **4 elemen HUD:** (1) **penanda kesadaran** NPC (ikon cap), (2) **indikator suara** (riak tinta melingkar), (3) **jam/segmen hari** (disk matahari/bulan di sudut), (4) **Hati** (nyala lentera kecil; hanya saat berubah).
- **Tidak ada** minimap penuh, bar HP/mana klasik, atau teks panjang. Info lain diegetik (Papan Tinta, gulungan, Nisshi).
- **Mata Telinga (listen mode):** washi yang menutup tepi layar; sumber suara = riak tinta; durasi 5 dtk; cooldown 12 dtk.
- **Menu:** gulungan; tombol = hanko; transisi = tinta mengalir; font: **serif tegas** + kaligrafi JP untuk judul (lisensi OFL).
- **Aksesibilitas:** teks bisa diperbesar; kontras ≥4,5:1; mode buta warna (cinnabar ↔ pola); subtitel; opsi tanpa darah; remap; kekerasan Off/Low/High.

### 10.8 Animasi & VFX (daftar)

**Pemain:** jalan, lari, jongkok, merayap, panjat, gantung, lompat atap, mendarat (tiga kekuatan), iai, tebas ringan/berat, parry, lempar, tembak asap, **Shadow-Meld** (menyatu bayangan: pemain menjadi siluet datar), kaginawa, minum obat, membungkuk, bicara, memberi barang, membuka shōji.
**NPC:** jalan/ide/duduk/tidur, bekerja (menyapu, menimbang, menjahit, memasak), ngobrol (gestur 3 variasi), terkejut, panik, curiga, mengejar, jatuh, pingsan, **berlutut**, berdoa, menari.
**VFX:** noda tinta (darah), cipratan air, debu, percikan, asap, api (lidah kertas), lentera berkedip, kunang-kunang, daun, salju, hujan streak, riak suara, **cap hanko** (kesadaran/konsekuensi), robekan washi (transisi).
**Aturan:** setiap aksi bermakna punya **telegraf** (≥0,25 dtk), **dampak**, dan **pemulihan**; tidak ada VFX tanpa makna sistemik.

### 10.9 Audio (daftar & aturan)

- **Musik adaptif (3 lapisan):** siang (shamisen/koto lembut), senja (taiko pelan), malam (nyaris sunyi; shakuhachi tunggal), bahaya (taiko & senar). Transisi musikal pada beat lonceng.
- **Ambien per distrik:** suara pasar, sungai, kuil (angin/lonceng), nagaya (anak/ayam), benteng (langkah/baju zirah), dunia bawah (dadu/tawa).
- **Foley:** langkah per material (tatami, kayu, genteng, tanah, salju, air), kain, senjata, benda jatuh.
- **Barks NPC:** gumaman Jepang pendek + teks ID/EN; **tidak memakai TTS peramban** di build komersial; rekaman asli/berlisensi (catat di `ASSETS_LICENSE.md`).
- **Aturan:** suara pemain terlihat (riak); **musik tidak boleh menutupi isyarat stealth**.

### 10.10 Galeri acuan (anti-regresi)

Tiga screenshot standar **wajib** dihasilkan skrip pada tiap rilis: (1) **Pasar Timur siang** dari pandangan pemain; (2) **Atap Nagaya senja**; (3) **Pelataran Benteng malam**. Masing-masing diambil di **4 waktu** (fajar/siang/senja/malam) → 12 gambar. Perubahan visual harus **dibandingkan** dengan galeri sebelum digabung; jika terlihat lebih buruk, batalkan.

---

## BAGIAN 11 — ARSITEKTUR TEKNIS (Unity 6 + URP)

### 11.1 Struktur proyek

```
unity_project/
  Assets/_Project/
    Data/                 # SUMBER KEBENARAN (JSON / ScriptableObject)
      npcs/*.json  places/*.json  gigs/*.json  stories/*.json  rumors/*.json
      items/*.json  clothing/*.json  festivals/*.json  tuning/*.json  lighting/*.json
    Runtime/
      Sim/                # TANPA UnityEngine.GameObject (headless-able)
        Clock/ Npc/ Memory/ Rumor/ Suspicion/ Economy/ Gig/ Story/ Weather/ Save/
      View/               # Menyajikan status Sim (NPC view, UI, VFX)
      Player/             # Input, kontrol, kamera, aksi
      World/              # Streaming distrik, nav, prop
      UI/ Audio/ Debug/
    Art/                  # aset final (setelah Gerbang 1)
    Tests/EditMode/ Tests/PlayMode/
  tools/                  # sync_data.py, validate_data.py, run_headless_sim.py, build_standalone.py
  webgl_vertical_slice/   # LAB tampilan (dibekukan; derivatif dihasilkan skrip)
  docs/ DECISIONS.md IDEAS.md ASSETS_LICENSE.md ART_BIBLE.md ARCHITECTURE.md
```

### 11.2 Aturan arsitektur

1. **Sim terpisah dari View.** `Sim` hanya bergantung pada C# murni + data; `View` membaca `SimState` dan mengirim **perintah**. Uji `Sim` di EditMode/dotnet tanpa render.
2. **Seed & determinisme:** semua acak lewat `SimRandom(seed, stream)`; **dilarang** `UnityEngine.Random` di Sim. Sim 28 hari dengan seed yang sama = hasil sama.
3. **Event bus bertipe** (struct events): `NpcSawEvent`, `RumorHeardEvent`, `ViolenceEvent`, `GigStateChanged`, dst. Logging semua event ke `sim_log.jsonl`.
4. **Data-driven:** tak ada literal konten di kode; validator (`validate_data.py`) memeriksa referensi silang (ID tempat/NPC/barang), jadwal tumpang-tindih, jam tak terjangkau, gig tanpa ≥3 pendekatan, rumor tak berasal.
5. **Save penuh serializable** (JSON terkompresi), versi skema, migrasi.
6. **LOD simulasi** (8.12).
7. **Streaming distrik** (additive scene per distrik; loading senyap; transisi menutup mata di pintu).
8. **Input:** Unity Input System; **keyboard/mouse dan gamepad**; semua dapat dipetakan ulang.
9. **Kamera:** **pilihan rekomendasi = orang ketiga** dengan **opsi intip orang pertama**; kolisi & bidik; **FOV 62–70°**; **tanpa mouse terbalik** (lihat 1.3 #11).
10. **Build:** CI memulai build otomatis, menjalankan **tes arah**, **sim 28 hari**, **validator data**, dan **galeri acuan**.

### 11.3 Skema data (ringkas; fail validasi bila tidak sesuai)

```jsonc
// places/*.json
{ "id": "D2_market", "district": "D2", "type": "outdoor|interior|roof|underground",
  "anchors": [ {"id":"stall_01","pos":[x,y,z],"facing":deg,"use":["work","browse"]} ],
  "witnessDensity": 0..1, "lightProfile": "market_day", "tags": ["crowd","gossip"] }

// gigs/*.json  (lihat 8.8)
// stories/*.json
{ "id":"S_bucket_morning","trigger":{"all":[{"dayRange":[1,2]},{"playerSeenByNpc":"ohana","hourRange":[4,6]}]},
  "beats":[{"npc":"ohana","say":"line_id","choices":[{"id":"lie","reqs":[],"effects":[]}, ...]}],
  "ripples":[{"after":"1d","effect":"suspicion+8@D1"}] }

// tuning/*.json  — semua angka 8.2–8.8 (jarak lihat, kenaikan kecurigaan, harga, dll.)
// rumors/*.json  — template rumor & distorsi
```
*(Skema JSON Schema lengkap diwajibkan di `docs/schemas/`. Validator wajib dijalankan di CI.)*

### 11.4 Mekanik pemain (target kendali; "terasa mahal")

- **Gerak:** jalan (4,0 m/s), lari (6,8), jongkok (1,8), merayap (0,9); akselerasi/dekselerasi halus; **tidak ada input lag > 1 frame**.
- **Atap/panjat:** titik pegang otomatis pada **sarashi putih**; lompat kontekstual; **kaginawa** (jangkauan 12 m); mendarat bersuara (11/15/18 m).
- **Shadow-Meld:** bertahan di kolam bayangan ≥0,6 s → pemain menjadi siluet; tak terlihat bila NPC >3 m; keluar bila bergerak cepat/disorot lentera.
- **Interaksi diegetik:** menekan [E] menampilkan **satu pilihan kontekstual** (bukan menu panjang); bicara memunculkan **2–3 opsi pendek**.
- **Pertarungan:** **sedikit, mematikan, jelas**: 1–2 pukulan fatal bagi pemain & lawan biasa; **parry** adalah keterampilan; pelarian adalah solusi sah. Satu serangan harus bisa menjadi **pembuka konsekuensi** (saksi/suara), bukan "level kemenangan".
- **Inventaris:** ≤12 slot; benda memiliki **bau/suara/ukuran** sistemik.

### 11.5 Navigasi & ruang interior

NavMesh per distrik + **NavMeshLink** (pintu, tangga, atap). Interior ≥2 per distrik dapat dimasuki; pintu geser memiliki suara & waktu animasi; interior memakai **portal culling**. NPC menggunakan **smart object** (anchors) untuk aktivitas (duduk, menimbang, memasak).

---

## BAGIAN 12 — VERIFIKASI & BUKTI

### 12.1 Jenis tes wajib

| Tingkat | Isi | Kapan |
|---|---|---|
| **Unit (Sim)** | Persepsi, ingatan, rumor, kecurigaan, ekonomi, gig; seed tetap | Tiap commit |
| **Data** | Validator referensi silang, jadwal, tuning rentang | Tiap commit |
| **Headless 28 hari** | Seed 1..20; laporan: jumlah rumor, saksi, kejadian tak terduga, utang, pelanggaran | Tiap cabang fitur sistem |
| **PlayMode** | Alur Hari 1–7, tidur/bangun, simpan/muat | Tiap rilis |
| **Visual** | Galeri 12 gambar + F4 grayscale | Tiap perubahan visual |
| **Kinerja** | GPU nyata, spesifikasi disebut; FPS 1% low | Per milestone |
| **Arah** | Tes handedness (12.6) | Tiap perubahan kamera/render |

### 12.2 Laporan simulasi headless (format wajib)

```
SIM REPORT  seed=7  days=28  npcs=26
events: saw=412  rumor_spawned=63  rumor_spread=311  discovered_bodies=2
suspicion_p95(player)=71  raids=1
gigs: offered=34 accepted=9 completed=6 failed=2 abandoned=1
emergent_anecdotes_candidates=17 (lihat daftar)
violations: 0 (NPC tahu hal yang tak pernah dialami)  ← harus 0
```

### 12.3 Metrik Uji Anekdot (Gerbang 1)

Lima penguji asing memainkan 45 menit; sesudahnya diminta: *"Ceritakan satu kejadian yang kamu ingat."* **Lolos jika ≥3 dari 5 menceritakan kejadian spesifik yang tak dirancang secara langsung** (dikonfirmasi lewat log). Catat video.

### 12.4 Daftar periksa "Pasti Ada" per rilis

- [ ] Sim 28 hari tanpa crash, `violations: 0`.
- [ ] Setiap NPC dapat dijelaskan: *"Mengapa ia berada di sini sekarang?"* (debug).
- [ ] Setiap gig punya ≥3 pendekatan & riak bertanggal.
- [ ] Tak ada tutorial modal.
- [ ] Semua dialog ID punya teks; EN/JP tidak boleh kosong (dapat `TODO` berlabel).
- [ ] `ASSETS_LICENSE.md` lengkap.
- [ ] Galeri acuan tidak regresi.
- [ ] Tes arah hijau.

### 12.5 Daftar "Dilarang" (red flags otomatis)

Teks "AAA/authentic/photorealistic" di kode atau dokumen; NPC mengakses `GameObject.Find` untuk mengetahui pemain; konten di C# bukan data; `Random` tanpa seed di Sim; tekstur NEAREST pada permukaan terlihat; mengubah `projMat[0]`/`frontFace` tanpa tes arah; layar "mission complete".

### 12.6 Tes arah (handedness regression) — WAJIB

**Tujuan:** mencegah terulangnya bug "mouse kiri → pandangan ke kanan".
1. **Uji matematis (Sim):** `yaw += +dx` → `forward = (sin yaw, cos yaw)` bergeser ke **kanan layar** (komponen `+X` bertambah untuk yaw kecil positif).
2. **Uji proyeksi (render):** titik dunia `P = player + forward·10 + right·3` harus memiliki **NDC x > 0**; `P' = ... − right·3` → **NDC x < 0**.
3. **Uji input:** simulasikan `movementX = +50` → `yaw` naik; `movementX = −50` → turun; `movementY = −50` (mouse ke atas) → `pitch` naik (kecuali invert).
4. **Uji visual:** objek bertanda "R" di kanan pemain harus tampil di **kanan layar** (screenshot dibandingkan).
5. Jalankan di CI setiap perubahan kamera/render/input; gagal = blokir gabung.

*(Rujukan: `test_fix.js` pada v2.0.1 sudah memuat tiga dari empat uji ini untuk lab WebGL.)*

---

## BAGIAN 13 — KEPUTUSAN TERBUKA (default AI = rekomendasi; tunggu persetujuan pengguna)

| # | Keputusan | Rekomendasi | Alasan | Biaya bila salah |
|---|---|---|---|---|
| D1 | Sudut pandang | **Orang ketiga + intip orang pertama** | Wajah/identitas/pakaian pemain terlihat (inti "dua wajah"); NPC bereaksi pada tubuh | Rework kamera & animasi |
| D2 | Skala dunia | **Satu desa padat**, bukan kota luas | Kedalaman > lebar; produksi terukur | Konten kosong |
| D3 | Nada | **Hangat-jenaka siang, dingin-sunyi malam** | Kontras = jiwa | Salah ritme emosi |
| D4 | Kekerasan | **Gaya tinta + konsekuensi sosial + toggle** | Berani tapi bertanggung jawab; rating | Rating/kesan |
| D5 | Mode multiplayer | **Tidak** (1 pemain) | Sim berat; fokus kedalaman | — |
| D6 | Mesin | **Unity 6 URP**; WebGL = lab | Sudah diputuskan di v2.0 | Migrasi |
| D7 | Bahasa suara | JP barks + teks ID/EN | Keaslian & biaya | Biaya lokal |
| D8 | Model komersial | **Premium sekali beli**; tanpa live-service | Sesuai game "kehidupan" | — |
| D9 | Durasi tahun | **28 hari = ±8,4 jam**; mode berulang | Siklus yang memuaskan | Pacing |
| D10 | Akses benteng | **Terbatas via penyamaran/izin** | Menjaga "dekat masyarakat" | Fokus bergeser ke stealth |

---

## BAGIAN 14 — RENCANA, GERBANG, DAN PROMPT

### 14.1 Fase & Gerbang

| Fase | Isi | Keluaran | Gerbang |
|---|---|---|---|
| **F0 Sinkron** | Baca Kitab; sinkron `AGENTS/ART_BIBLE/ARCHITECTURE`; ganti `AGENTS.md` v3; buat `DECISIONS/IDEAS`; validator & CI; tes arah | Repo selaras, tes hijau | **G0:** dokumen & tes berjalan |
| **F1 Inti Sim (L0–L3)** | Jam, cuaca, NPC jadwal, nav, persepsi, ingatan, rumor | Sim headless 28 hari; debug overlay | **G0.5:** laporan sim `violations 0` |
| **F2 Dua Wajah (L4–L6)** | Kecurigaan, pekerjaan sampul, kamar, Hati, jejak, pakaian | Hari 1–7 playable (greybox) | **G1: Uji Anekdot (≥3/5)** |
| **F3 Konten (L7–L8)** | 26 NPC, 12 gig, 24 kisah, aspirasi, Nisshi | Tahun penuh greybox | **G2:** 28 hari tanpa jalan buntu |
| **F4 Seni (L9)** | Aset final bertahap, lighting, UI, audio, animasi, VFX | Galeri 12 gambar lulus | **G3:** Uji visual (F4 grayscale + galeri) |
| **F5 Polesan (L10)** | Kinerja, aksesibilitas, lokalisasi, QA | Build kandidat rilis | **G4:** demo publik |

### 14.2 Prompt tugas berurutan (tempel satu per satu setelah persetujuan)

**L0 — Sinkron & Fondasi.**
```
Tugas L0: (1) Baca Kitab. (2) Tulis ulang AGENTS.md sebagai ringkasan Bagian 1 + 14 Kitab, tidak
bertentangan. (3) Buat DECISIONS.md (isi Bagian 13 sebagai "diusulkan"), IDEAS.md, ASSETS_LICENSE.md.
(4) Buat tools/validate_data.py (skema + referensi silang) dan tools/run_headless_sim.py (kerangka).
(5) Pasang CI yang menjalankan validator, tes arah (12.6), dan sim headless dummy.
Bukti: output CI hijau + daftar berkas. Jangan membuat konten/aset.
```
**L1 — Jam, Cuaca, Dunia Data.**
```
Tugas L1: Implementasikan World.Clock (10 Hz), segmen hari, kalender 28 hari, cuaca berbobot dari
weather.json, dan LightingPreset (Bagian 10.6) sebagai data. Tanpa visual final. Uji unit + laporan
sim 28 hari yang mencatat cuaca per hari. Bukti: laporan + tes.
```
**L2 — NPC: Jadwal & Navigasi.**
```
Tugas L2: Implementasikan skema NPC (7.3), jadwal blok, pemilihan blok aktif, interupsi, NavMesh
(greybox D1+D2), dan LOD simulasi (8.12). Buat 6 NPC greybox: ohana, okiku, ryota, jikai, kurobe, tsuru.
Bukti: laporan sim 3 hari; debug "mengapa ia di sini sekarang?" untuk 6 NPC.
```
**L3 — Persepsi, Ingatan, Rumor.**
```
Tugas L3: Implementasikan persepsi (8.2), tingkat kesadaran, MemoryEntry, Belief, dan Grafik Rumor
(8.3) termasuk distorsi. Sertakan aturan "tidak ada pengetahuan gratis" + deteksi pelanggaran.
Bukti: sim 28 hari seed 1..5 dengan `violations: 0`, 3 contoh rantai rumor dengan distorsi.
```
**L4 — Identitas Ganda.**
```
Tugas L4: Kecurigaan Sosial (8.4), jejak fisik (noda/bau/luka), pakaian (9.6), kamar pemain (9.5),
tidur/bangun. Hari 1–3 playable greybox. Bukti: klip + sim yang menunjukkan kecurigaan naik/turun.
```
**L5 — Pekerjaan Sampul & Ekonomi.**
```
Tugas L5: Empat pekerjaan sampul (8.7), shift (lewati/mainkan), sewa/pajak/utang, harga dinamis.
Bukti: sim 28 hari: ekonomi tanpa runaway; tabel pendapatan/pengeluaran per pekerjaan.
```
**L6 — Hati, Kekerasan, Mayat.**
```
Tugas L6: Hati Hangat↔Dingin (8.5), luka, mayat, penemuan, razia, mode kekerasan Off/Low/High.
Bukti: tiga skenario skrip (pembunuhan senyap; gaduh; nonmematikan) dengan laporan jejak & riak.
```
**L7 — Gig & Kisah Kecil.**
```
Tugas L7: Sistem gig (8.8) + 12 gig 9.2 + 12 kisah pertama dari 9.1 sebagai data. Setiap gig ≥3
pendekatan & riak. Bukti: 5 sim seed berbeda menunjukkan hasil berbeda untuk gig yang sama.
```
**L8 — Aspirasi, Festival, Nisshi.**
```
Tugas L8: Aspirasi (8.9), 4 festival (9.4), Nisshi (8.10) dari log nyata; 12 kisah sisanya.
Bukti: Nisshi dari 3 sim berbeda berisi butir yang berbeda & benar.
```
**G1 — UJI ANEKDOT (jeda wajib).** Berhenti. Siapkan build untuk 5 penguji; sediakan log & rekam. Jangan lanjut ke seni sebelum lolos.
**L9 — Seni (setelah G1).**
```
Tugas L9: Bangun aset final secara bertahap mengikuti Bagian 10 (urut: D1 Nagaya, D2 Pasar, lalu
NPC kunci, viewmodel). Tiap iterasi: galeri 12 gambar + F4 grayscale. Jika regresi, batalkan.
```
**L10 — Polesan & Rilis.**
```
Tugas L10: Kinerja (GPU nyata), aksesibilitas, lokalisasi, audio final, build kandidat. Bukti: laporan
kinerja dengan spesifikasi perangkat, daftar bug yang tersisa jujur.
```

### 14.3 Risiko & mitigasi

| Risiko | Dampak | Mitigasi |
|---|---|---|
| Sim terlalu rumit & tak terprediksi | Kisah tidak menarik/bug | Sim headless + metrik anekdot; tuning dari data |
| Cakupan membengkak | Tidak selesai | Satu desa; IDEAS.md; fase terkunci |
| Seni mengalahkan sistem | Terulang "karya kosong makna" | Aturan 1.3 #1 + G1 |
| NPC terasa robot | Dunia "mati" | Kebiasaan bicara, rahasia, jadwal tak sempurna, kesalahan |
| Kekerasan menyebabkan rating/penolakan | Hambatan rilis | Toggle, gaya tinta, konsekuensi |
| Lisensi aset | Tuntutan | `ASSETS_LICENSE.md` sebelum pakai |
| Kinerja Unity pada PC menengah | Lag | LOD sim, budget 10.4, profil GPU nyata |
| AI melaporkan klaim kosong | Ketidakjujuran | Aturan 1.3 #7, #9; bukti wajib |

### 14.4 Penutup untuk AI

Tugas Anda **bukan menambah kilau**, tetapi membuat **seseorang tinggal di dunia ini**. Jika setelah satu jam bermain pemain *ingin tahu apa yang dilakukan Ohana besok*, kita menang. Bila setelah satu jam ia hanya *melihat efek*, kita telah gagal, secantik apa pun.

**Akhir Kitab.**
