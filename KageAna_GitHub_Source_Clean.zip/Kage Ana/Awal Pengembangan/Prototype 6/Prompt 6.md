baik, sebagai balasan untuk itu dari lanjutan gameplay tadi (sama tolong itu dibenarkan dong, saya resah mouse ke kiri pandangan gerak ke kanan dan sebaliknya), Anda bangunlah seluruh dunia dari KageAna ini dan jadikan instruksi Maha Lengkap yang akan kukirimkan ke AI ku untuk melanjutkan standar seni yang telah ditunjukkan karya kosong makna itu

