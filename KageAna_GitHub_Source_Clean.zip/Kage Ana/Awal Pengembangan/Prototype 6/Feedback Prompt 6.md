Akar masalah mouse sudah ketemu: gambar di layar ter-mirror horizontal, bukan sekadar tanda sensitivitas yang terbalik. Sekarang saya menambal dan mengujinya sebelum membangun dunia lengkapnya.



Sedang merapikan rujukan antar-bagian di Kitab, lalu mengirimkannya.



Kitab Dunia sudah jadi dalam satu file markdown, dan perbaikan arah mouse sudah terkirim di zip `KageAna\_PC\_Game\_Setup\_v2.0.1\_MouseFix.zip`. Aku belum menjalankan atau menguji isi Kitab; hanya nomor bagian dan rujukan antar-bagiannya yang kucek.



\*\*Isi Kitab\*\*

\- \*\*Prompt pembuka:\*\* AI-mu wajib membaca semuanya dulu, lalu membalas dengan ringkasan pemahaman, daftar hal yang ambigu, dan rencana tugas pertama. Ia tidak boleh langsung menulis kode.

\- \*\*Jiwa game dan 16 aturan wajib:\*\* termasuk "sistem dulu, seni belakangan" dan larangan klaim kosong seperti "AAA" tanpa bukti.

\- \*\*Dunia:\*\* Lembah Kurokawa dengan 8 distrik, 9 faksi, etiket, kalender 28 hari, festival, ekonomi, dan hukum.

\- \*\*Pemeran:\*\* 26 penduduk dengan jadwal, rahasia, dan kebiasaan bicara.

\- \*\*Sistem:\*\* spesifikasi lengkap dengan angka awal untuk tuning.

\- \*\*Konten:\*\* 24 Kisah Kecil, 12 gig, 4 festival, dan 7 hari pertama tanpa tutorial.

\- \*\*Standar seni:\*\* kelanjutan v2.0 (palet, outline tinta, preset cahaya waktu × cuaca, HUD 4 elemen, daftar aset, animasi, audio), wajib setelah Gerbang 1.

\- \*\*Teknis dan rencana:\*\* arsitektur Unity 6, skema data, tes arah, 6 fase dengan gerbang, dan prompt L0–L10.

\- \*\*Jeda wajib:\*\* setelah sistem hidup, ada Uji Anekdot (Gerbang 1) sebelum AI-mu boleh memoles seni. Itu untuk mencegah terulangnya hasil yang cantik tapi kosong makna.



\*\*Dua hal yang perlu kamu cek\*\*

1\. \*\*Mouse:\*\* tes arah hanya kujalankan secara otomatis di Chromium tanpa GPU. Mohon coba dengan mouse dan GPU sungguhan, terutama kunci kursor saat klik pertama dan menu jeda dengan Esc.

2\. \*\*Keputusan di Bagian 13:\*\* ini rekomendasiku (sudut pandang orang ketiga, satu desa padat, nada hangat-jenaka siang dan dingin-sunyi malam, kekerasan bergaya tinta dengan toggle, dll). Ubah dulu kalau tidak cocok sebelum dikirim ke AI-mu.



File ada di `/tmp/claude-0/-home-claude/d3699750-dfe4-51ba-ab27-530ba09e3f0d/scratchpad/KageAna\_Kitab\_Dunia\_dan\_Instruksi\_Maha\_Lengkap.md`.



Langkah berikutnya: kirim file ini ke AI-mu bersama prompt di Bagian 0, lalu kirim balasannya (ringkasan pemahaman dan daftar ambiguitas) ke sini supaya bisa kunilai sebelum ia mulai bekerja.

