# KAGE-ANA (影穴) — Visi Ulang: Simulasi Hidup Seorang Shinobi di Tengah Masyarakat

> Dokumen ini **menggantikan arah** pada `KageAna_Audit_v1_dan_Strategi_Kompetitif.md` (terutama Bagian 3, 5, dan 7). Isi teknis, aset, dan pelajaran visual dari dokumen lama tetap berlaku bila tidak bertentangan.
> Dasar: pesan Anda tentang "jiwa game", balasan AI Anda untuk v2.0, dan pemeriksaan paket `KageAna_PC_Game_Setup_v2.0_Installer.zip`.

---

## BAGIAN 0 — Apakah Saya Menangkapnya? Ya. Ini Rumusannya.

**Game ini bukan tentang menyelesaikan stage. Ini tentang menjalani *kehidupan* seorang manusia yang kebetulan shinobi.** Siangnya ia orang biasa di desa: punya pekerjaan sampul, kamar sewa, tetangga, utang, kebiasaan, wajah yang dikenal. Malamnya ia melakukan hal-hal gila yang tak bisa diceritakan kepada siapa pun. **Ketegangan, humor, dan makna game ada di *sambungan* antara dua kehidupan itu**, bukan di dalam satu misi.

Padanan terdekat: **Assassin's Creed, tetapi sandbox** (dunia yang bernapas, penyamaran di keramaian, pekerjaan sampingan), dengan bobot pada **ritme hidup sehari-hari** ala *Shenmue / Yakuza (kisah sampingan) / Stardew Valley*, dan **kebebasan sistemik ala Hitman**, bukan rel cerita.

### Pengakuan yang perlu saya sampaikan

Anda menilai "kualitas produksi bagus tapi tujuannya tidak ada". **Itu benar, dan sebagian besar kesalahannya ada pada arahan saya.** Di dokumen sebelumnya saya menjadikan *"momen klip 3 detik"* sebagai ukuran utama dan **membekukan** hal-hal yang justru jiwa game Anda: kontrak sosial, penyamaran, moralitas, ekonomi, dan hidup warga. AI Anda patuh dengan sangat baik, dan hasilnya persis seperti yang saya instruksikan: pilar efek (bayangan, tinta, tebasan), layar kemenangan berperingkat, dan **nol sistem kehidupan**. Pencarian kata `schedule, rumor, reputation, economy, job, sleep, hunger, home, season, festival, memory, relationship` pada kode v2.0 menghasilkan **nol** berkas yang relevan. Game v2.0 adalah *arena infiltrasi yang indah*, bukan *dunia untuk ditinggali*.

Saya mengoreksi arah di sini, dan menjelaskan kenapa ukuran keberhasilan harus berubah (Bagian 1).

---

## BAGIAN 1 — Diagnosis: Kenapa v2.0 Terasa "Buat Apa Main Ini?"

| Gejala | Penyebab sebenarnya |
|---|---|
| Bagus tapi tanpa tujuan | Satu halaman misi: "capai menara" → layar Rank S/A/B. Tujuan **dipinjam dari game stealth**, bukan dari fantasi Anda |
| "Lebih baik tidak main game" | Tidak ada **dunia yang peduli**. Tidak ada orang yang akan merindukan, menagih, atau mencurigaimu |
| Fitur keren tapi hampa | Bayangan/tinta/tebasan adalah **alat**. Alat tanpa **kebutuhan** terasa seperti mainan, bukan hidup |
| Tidak ada yang diceritakan ke teman | Tidak ada **dilema**, **konsekuensi**, atau **kejadian tak terduga** yang bisa diceritakan |
| Setelah 15 menit selesai | Tidak ada **ritme harian** yang membuat pemain kembali besok |

**Ukuran keberhasilan lama (dibuang):** "apakah ini membuat klip 3 detik yang keren?"
**Ukuran keberhasilan baru:** *"Apakah pemain menceritakan **kisah hidupnya** kepada orang lain setelah bermain?"* (disebut **Uji Anekdot**, Bagian 9).

---

## BAGIAN 2 — Visi Baru

### 2.1 Pernyataan visi

> **KAGE-ANA adalah simulasi kehidupan ganda seorang shinobi di sebuah desa Sengoku yang hidup. Siang hari kamu adalah tetangga yang dikenal semua orang; malam hari kamu adalah sesuatu yang tidak boleh diketahui siapa pun. Tak ada jalan cerita yang harus ditamatkan. Ada hidup yang harus kamu jaga tetap utuh, dan dunia yang akan mengingat semua yang kamu lakukan.**

### 2.2 Kalimat hook (pilih/ubah)

- *"Kamu penjual obat di siang hari. Kamu hantu di malam hari. Desa tidak boleh tahu."*
- *"Hidupi dua kehidupan sebelum salah satunya membunuh yang lain."*
- Judul toko: **"Kage-Ana — Dua Wajah, Satu Desa"**

### 2.3 Alasan bermain (jawaban atas "kenapa tidak tidak main saja?")

1. **Fantasi rahasia:** menjadi orang yang kuat dan berbahaya *tanpa meninggalkan dunia orang biasa*. Kekuatan yang harus disembunyikan lebih menarik daripada kekuatan yang dipamerkan.
2. **Kisah yang kamu tulis sendiri:** sistem yang saling bersilang menghasilkan kejadian yang tak ditulis siapa pun ("tetanggaku melihat darah di lengan bajuku saat aku menjual obat padanya").
3. **Dunia yang peduli:** orang punya jadwal, ingatan, dan pendapat tentangmu. Mereka menyapa, curiga, berutang, berterima kasih.
4. **Dilema kecil yang berat:** menyelamatkan petani dari rentenir berarti merugikan pelanggan tetap tokomu. Tidak ada pilihan "benar".
5. **Ritme yang menenangkan sekaligus mendebarkan:** pagi yang hangat (rutinitas), malam yang dingin (bahaya), dan **kegelisahan di antara keduanya**.
6. **Penguasaan:** pelan-pelan mahir **berpindah wajah** tanpa retak.
7. **Sebuah hidup yang berakhir dan diceritakan kembali** (Bagian 5.13): setiap tahun menutup dengan *nisshi* (buku harian) bergaya gulungan ukiyo-e tentang siapa dirimu.

### 2.4 Anti-visi (game ini BUKAN)

- Bukan game misi berstruktur *pilih level → selesaikan → peringkat*.
- Bukan *story-driven*: tidak ada naskah panjang yang harus diikuti. Cerita **muncul dari sistem**, ditambah kisah-kisah kecil.
- Bukan dunia terbuka luas yang kosong: **satu desa yang dalam dan padat** mengalahkan kota luas yang dangkal.
- Bukan simulasi pekerjaan membosankan: rutinitas harus **pendek, bermakna, dan bisa dilewati** (Bagian 11).
- Bukan "pembunuh tanpa beban": kekerasan punya harga.

### 2.5 Posisi terhadap game lain

| Game | Yang kita ambil | Yang kita bedakan |
|---|---|---|
| Assassin's Creed | Menyamar di keramaian, pekerjaan sampingan, dunia yang bergerak | Skala kecil tapi padat; **hidup sipil adalah setengah game**, bukan latar |
| Hitman | Sandbox kreatif, banyak cara, tawa gelap | Dunia berlanjut setelah misi; konsekuensi lintas hari |
| Yakuza / Like a Dragon | Kisah sampingan absurd + kehidupan kota | Fondasi sistemik, bukan hanya kisah tersusun |
| Shenmue | Rutinitas kota Jepang, rasa hidup | Ada bahaya dan kebebasan taktis |
| Stardew Valley | Kalender, musim, hubungan, kepuasan rutinitas | Rutinitas menutupi rahasia berbahaya |
| Persona | Kalender sosial dua kehidupan | Real-time dunia terbuka kecil, bukan menu |
| Kingdom Come: Deliverance | Simulasi hidup abad pertengahan, reputasi, pakaian | Ninja, bukan ksatria; lebih jenaka-gelap |
| Thief / Dishonored | Cahaya, bayangan, kecurigaan | Pemain punya rumah dan tetangga yang dipertaruhkan |
| Papers, Please | Dilema moral kecil | Tidak terpisah dari dunia 3D |
| RimWorld / Dwarf Fortress | Cerita muncul (emergent) | Fokus pada **satu orang** dan relasinya |

**Ruang kosong yang realistis:** *"Hitman-sandbox × Yakuza-kehidupan × Stardew-rutinitas, dengan satu tokoh yang menyembunyikan rahasia dari tetangganya"*, di setting Sengoku bergaya ukiyo-e. Belum banyak (jika ada) game yang menggabungkan tiga hal itu dengan serius. Verifikasi ketersediaan pesaing di Steam/SteamDB sebelum menulis halaman toko.

---

## BAGIAN 3 — Pilar Baru (menggantikan "Bayangan / Tinta / Satu Tebasan")

Maksimal empat. Semua fitur lain harus melayani salah satunya.

| # | Pilar | Inti |
|---|---|---|
| 1 | **Omote (表) — Wajah Siang** | Kamar, pekerjaan sampul, uang, tetangga, rutinitas, musim, festival |
| 2 | **Ura (裏) — Wajah Malam** | Pekerjaan bayangan sistemik, penyamaran, "kegilaan", cara-cara bebas |
| 3 | **Desa yang Mengingat** | NPC berjadwal, ingatan, hubungan, desas-desus yang menyebar, reputasi |
| 4 | **Sambungan Dua Wajah** | Titik rapuh antara dua hidup: luka, uang aneh, absen kerja, mata dingin, ketahuan |

Mekanik v2.0 **tidak dibuang**, tapi **dipindahkan menjadi alat** di dalam pilar ini (Bagian 7).

---

## BAGIAN 4 — Loop Permainan pada Empat Skala

| Skala | Durasi | Apa yang dilakukan pemain | Perasaan |
|---|---|---|---|
| **Menit** | 1–5 mnt | Menjual obat, menguping, menyelinap, mengelabui satu penjaga, menolong tetangga | Fokus, kejutan kecil |
| **Hari** | ±18 mnt (waktu nyata) | Bangun → kerja siang → urusan sore → pekerjaan malam → pulang → tidur | Ritme, rencana |
| **Musim** | ±7 hari game (±2 jam) | Peristiwa desa: panen, pajak, festival, kedatangan klan lain | Perubahan, konsekuensi |
| **Tahun** | 28 hari game (±8 jam) | Aspirasi pemain bergerak; akhir tahun = *nisshi* | Makna, penutupan |

*(Angka dapat diubah di data; yang penting struktur empat skala ada.)*

### Contoh sehari (ini yang harus terasa dalam game)

> **Pagi.** Kamu bangun di kamar sewa dengan perut lapar dan luka di bahu dari semalam. Nyonya pemilik rumah mengetuk: sewa jatuh tempo lusa. Kamu membalut luka dan mengenakan lengan baju panjang agar tak terlihat.
> **Siang.** Kamu membuka lapak obat di pasar. Seorang nenek membeli ramuan dan menyebut cucunya hilang sejak semalam. Seorang penjaga lewat dan melirik lenganmu. Kamu tersenyum dan menjual obat batuk kepadanya.
> **Sore.** Kamu mendengar dari tukang perahu bahwa penagih pajak akan menggeledah gudang rentenir malam ini. Kamu tahu rentenir itu menjerat keluarga si nenek.
> **Malam.** Kamu mengganti pakaian, mematikan tiga lentera, menyelinap lewat atap gudang, mencuri catatan utang, dan hampir tertangkap oleh penjaga yang tidak pernah kamu lihat. Kamu kabur lewat kolong jembatan, tubuhmu basah dan berbau lumpur.
> **Fajar.** Kamu tiba di kamar tepat saat nyonya pemilik rumah membuka pintu geser untuk menyiram taman. "Kamu bau sungai," katanya. Kamu menjawab, "Aku ke ladang cari akar." Ia mengangguk, tapi menatap sedetik lebih lama.
> **Esoknya.** Desa heboh: catatan utang hilang. Cucu si nenek pulang. Rentenir menuduh pesaingnya. Penjaga menambah patroli di pasar, **tepat di dekat lapak obatmu**.

Satu hari itu **tidak ditulis sebagai misi**. Ia dihasilkan oleh sistem. Itulah target.

---

## BAGIAN 5 — Sistem Inti (Rancangan Rinci)

### 5.1 Waktu, kalender, cuaca
- Siklus: fajar / siang / sore / malam, **musim** (semi, panas, gugur, dingin), **peristiwa terjadwal** (festival kuil, Obon, panen, penagihan pajak, hanami, kedatangan rombongan klan), dan **cuaca** (hujan, kabut, salju) yang berdampak ke gameplay (jejak, suara, licin, pasar sepi).
- **Tidur** melewatkan waktu (dengan konsekuensi: peristiwa tetap berjalan).
- Seluruh jadwal dan peristiwa **berbasis data**, bukan kode.

### 5.2 Identitas, penyamaran, dan zona sosial
- Setiap pemain punya **Wajah Siang** (nama, pekerjaan, riwayat palsu) dan **Wajah Malam** (anonim).
- **Pakaian = identitas.** Pakaian membuka atau menutup zona: pasar, kuil, kediaman samurai, dermaga, dunia bawah.
- **Kecurigaan berbasis perilaku**, bukan hanya cahaya: berlari di keramaian, membawa senjata terlihat, noda darah, bau (lumpur, darah, asap), berada di tempat yang tidak masuk akal pada jam itu, mengenakan pakaian yang salah.
- **Berbaur dengan keramaian** sebagai tempat sembunyi (gaya AC), selain bayangan literal.
- Prototipe v0.7 sudah memiliki sketsa sistem penyamaran/zona. Arsipnya ada di `legacy/KageAna_v0.7_Legacy_Mechanics_Archive.zip`: **keluarkan dari pembekuan** dan jadikan fondasi.

### 5.3 Pekerjaan sampul (Omote)
Pekerjaan bukan sekadar sumber uang. **Tiap pekerjaan memberi akses, informasi, dan alat untuk Ura.**

| Pekerjaan | Rutinitas (ringkas & menyenangkan) | Hadiah bagi Ura |
|---|---|---|
| **Penjual obat keliling** | Meracik, menjual, mendengar keluhan | Racun/penawar, kabar kesehatan para tokoh, akses ke rumah orang sakit |
| **Juru tulis surat** | Menulis surat untuk warga buta huruf | Rahasia keluarga, **pemalsuan surat**, kenal tulisan tangan |
| **Pembuat lentera** | Membuat dan memperbaiki lentera desa | Kendali cahaya (G1), akses kunci pembakaran |
| **Pengayuh perahu** | Mengantar penumpang | Gosip, jalur sungai tak terpantau, kenal dermaga |
| **Pelayan rumah teh / penjual sake** | Melayani tamu | Gosip pejabat, mabuk sebagai alat |
| **Tukang atap / kayu** | Memperbaiki bangunan | Peta atap dan kolong, jalur masuk |

Untuk slice, **cukup 1–2 pekerjaan**, tapi dikerjakan dalam.

### 5.4 Rumah dan kehidupan harian
- **Kamar sewa** di rumah milik tuan rumah yang punya kepribadian dan jam tidur.
- **Ruang rahasia** (lantai berongga, langit-langit) untuk menyimpan alat, uang, bukti.
- **Peningkatan rumah:** tatami, kebun kecil, kucing, lentera yang menenangkan. **Rumah adalah jangkar emosi** dan juga **titik rawan** (penggeledahan, kebakaran, penggusuran, tamu tak diundang).
- Kebutuhan: **lapar, lelah, luka, kebersihan** (bau!). Kebutuhan **ringan dan bermakna**, bukan hukuman.

### 5.5 Ekonomi
- Uang (Ryo/mon): sewa, makanan, obat, perawatan alat, suap, utang, pajak.
- **Pemasukan:** pekerjaan sampul (stabil, kecil), pekerjaan bayangan (besar, berisiko), pencurian (cepat, ketahuan).
- **Menjelaskan kekayaan:** uang yang tiba-tiba banyak memicu pertanyaan. Pemain perlu "mencuci" lewat pekerjaan sampul atau pembelian yang masuk akal.
- **Harga hidup** bergerak mengikuti peristiwa (panen buruk → beras mahal → warga lapar → bahan pekerjaan bayangan).

### 5.6 Tubuh dan kondisi
- **Luka terlihat** (perban, pincang, bekas) dan dilihat NPC. Menyembunyikan luka = pakaian/ramuan/perilaku.
- **Kelelahan** memengaruhi ketangkasan dan kewaspadaan; kurang tidur = kesalahan.
- **Racun, demam, mabuk** sebagai kondisi yang dapat dimanfaatkan atau diderita.

### 5.7 Keseimbangan Hati: Hangat ↔ Dingin (jiwa game)
Satu meter dua ujung, bukan "bar yang harus penuh".
- **Hangat (温もり):** makan bersama, menolong, tertawa, festival, merawat rumah.
- **Dingin:** membunuh, menipu, mengkhianati, mengabaikan sahabat.
- **Dingin tinggi:** fokus lebih tajam, tidak ragu, keterampilan bayangan naik, tapi NPC merasakan "mata dingin" (kepercayaan turun), insomnia, kesepian, hal-hal ganjil (halusinasi bayangan).
- **Hangat tinggi:** dipercaya, banyak informasi, penyamaran kuat, tetapi ragu saat harus bertindak, pekerjaan bayangan terasa berat.
- **Tidak ada ujung "benar".** Ini cermin kepribadian yang dipilih pemain, dan ia terkait aspirasi (Bagian 5.13).

### 5.8 NPC yang hidup (inti Pilar 3)
Setiap NPC bernama punya data:
- **Jadwal** (tidur, kerja, makan, ibadah, hiburan), dengan variasi hari dan musim.
- **Kebutuhan & keinginan** (uang, obat, balas dendam, cinta, aman).
- **Kepribadian** (pemalu, curiga, ramah, pemarah, tamak) yang memengaruhi reaksi.
- **Ingatan:** apa yang ia lihat/dengar tentang pemain dan orang lain (dengan kepastian dan peluruhan).
- **Hubungan** satu sama lain (keluarga, rival, kreditur, teman) dan dengan pemain (kenal, percaya, takut, berutang).
- **Opini** yang berubah dari tindakan pemain, baik yang disaksikan maupun yang didengar.

Untuk slice: **12 NPC bernama berjadwal penuh + ±20 NPC keramaian** sederhana.

### 5.9 Desas-desus sebagai tinta (menggabungkan Pilar "Tinta" lama)
- **Fakta** (apa, siapa, kapan, di mana, seberapa yakin) disimpan di ingatan NPC dan **menyebar** lewat percakapan pada jaringan hubungan; makin jauh makin kabur dan berubah.
- **Mode "Dengar" (hold):** dunia memudar ke kertas washi; **benang tinta** menunjukkan siapa berbicara dengan siapa dan **desas-desus apa** yang mengalir. Mengintip percakapan, bukan hanya mendeteksi penjaga.
- **Papan Tinta (journal):** pemain menyusun sendiri peta fakta, orang, dan hubungan (mengisi sendiri, tidak otomatis dijawab), mirip *Return of the Obra Dinn*.
- **Rekayasa desas-desus:** menanam kabar palsu, memalsukan surat, menjadi "hantu" legenda untuk menakuti penagih pajak. Kekuatan sosial yang tak terlihat.
- Murah dibangun: graf + daftar fakta + peluruhan.

### 5.10 Pekerjaan bayangan (Ura) dan "kegilaan" sistemik
Bukan daftar misi tetap. Ia dihasilkan dari **kontak**, **kebutuhan NPC**, dan **peristiwa desa**.
- **Kerangka pekerjaan:** *pemberi, tujuan, tenggat, pendekatan yang diizinkan, imbalan, dampak riak*.
- **Pendekatan** bebas (tag): *senyap, sosial, kekerasan, tipu daya, kekacauan, sabotase, penyelamatan, desas-desus*.
- **Dampak riak:** membunuh penagih pajak → warga lega → klan menambah patroli → tetangga kena razia → tuan rumah menaikkan sewa. **Tidak ada aksi tanpa gema.**

**Contoh "kegilaan" (setiap ide dapat menjadi kisah kecil):**
1. Mencuri ikan koi kesayangan hakim desa dan mengembalikannya sebelum fajar sambil menyamar sebagai pembersih kolam.
2. Menukar sake di pernikahan keluarga pedagang dengan teh agar kontrak tidak ditandatangani dalam keadaan mabuk.
3. Menyelundupkan "barang" dalam gerobak tahu melewati pos pemeriksaan saat festival.
4. Memalsukan surat cinta agar dua klan saling curiga.
5. Mematikan semua lentera desa selama tiga menit ketika upacara berlangsung.
6. Membakar gudang beras sebagai alibi, lalu ikut memadamkannya sebagai "pahlawan desa".
7. Menguping rapat tetua dari kolong lantai dan menjual hasilnya ke dua pihak.
8. Menyamar sebagai tabib untuk membuktikan bahwa bangsawan itu sebenarnya sehat (pura-pura sakit demi menghindari perang).
9. Membuat dirimu terlihat sebagai arwah di jembatan agar penagih pajak tak berani lewat.
10. Mengawal diam-diam anak tetangga pulang tanpa ketahuan, lalu menjual obat kepada ibunya keesokan harinya.

### 5.11 Dunia Sengoku yang bergerak
- Kekuatan **klan**, **pajak**, **musim**, **wabah**, **perang di kejauhan**, dan **festival** berjalan sendiri sebagai garis waktu yang bisa digeser pemain, bukan naskah linear.
- **Peta pengaruh**: siapa menguasai distrik mana, siapa menekan siapa. Tindakan pemain menggeser keseimbangan secara halus.
- Desa berubah sepanjang tahun (dekorasi musim, harga, kerumunan, patroli).

### 5.12 Kemajuan tanpa grind
- **Keterampilan lewat pemakaian** (menyelinap, meracik, bicara, melempar).
- **Guru dan teknik:** teknik (termasuk *kuji-in*, Shadow-Meld) diajarkan oleh orang tertentu sebagai **imbalan hubungan/tugas**, bukan pohon XP.
- **Rumah dan alat** berkembang dengan uang dan waktu.
- **Reputasi per lingkaran** (rakyat, pedagang, kuil, samurai, dunia bawah) yang membuka/menutup peluang.

### 5.13 Aspirasi, tahun, dan *nisshi* (jawaban untuk "tujuannya apa?")
Pemain **memilih** (dan boleh mengubah) satu **Aspirasi** yang memberi arah tanpa naskah. Contoh:
- *Menjaga Desa* (menjadi pelindung tak dikenal),
- *Melunasi Utang Keluarga*,
- *Mencari Pembunuh Guru* (alur panjang opsional),
- *Menjadi Bayangan Termasyhur* (legenda di dunia bawah),
- *Pensiun dengan Damai* (berusaha keluar dari dunia shinobi: hal tersulit),
- *Menjadi Pengrajin Terhormat yang Diam-diam Mematikan*.

**Akhir tahun** menutup dengan **Nisshi**: gulungan ukiyo-e yang otomatis menyusun *hidup pemain* (hubungan yang tumbuh, hal gila yang dilakukan, siapa yang mati, siapa yang tahu rahasiamu, berapa hangat/dingin ia). **Ini artefak yang dibagikan pemain** (menggantikan layar Rank S/A/B). Setelah itu: *lanjut hidup*, *mulai sebagai murid pemain sebelumnya* (warisan hubungan/reputasi), atau *mulai hidup baru*.

---

## BAGIAN 6 — Arsitektur Cerita: Sandbox, Bukan Rel

Cerita **muncul**, bukan ditulis menyeluruh. Tiga lapis:

1. **Sistem (mayoritas):** NPC berjadwal + ingatan + desas-desus + dampak riak menghasilkan kejadian tak terduga.
2. **Kisah Kecil (substory, seperti Yakuza):** 30–60 adegan tulisan tangan (5–15 menit) yang dipicu **kondisi dunia** (misal: "kamu pernah menolong si nenek *dan* rentenir menekan keluarganya"). Pendek, lucu atau pedih, tidak berurutan.
3. **Tulang punggung opsional:** satu garis panjang yang dapat diabaikan (misal: misteri kematian guru atau datangnya klan besar), muncul perlahan lewat petunjuk. Tidak pernah memblokir kebebasan.

Aturan: **tidak ada fitur yang mengharuskan pemain menyelesaikan cerita untuk bermain.**

---

## BAGIAN 7 — Nasib Fitur v2.0 (Apa yang Dibuang, Dipindah, Dipertahankan)

| Fitur v2.0 | Keputusan | Peran baru |
|---|---|---|
| Layar kemenangan Rank S/A/B, "gulungan perang" di menara | **Buang** | Ganti dengan *Nisshi* tahunan; menara = salah satu lokasi pekerjaan |
| Shadow-Meld, kekuatan bayangan, manipulasi lentera | **Pertahankan** sebagai alat Ura | Teknik rahasia yang dipelajari dari guru; lentera = juga mata pencaharian pembuat lentera |
| Mata Telinga (riak tinta) | **Perluas** | Menjadi mode **Dengar desas-desus** + deteksi (Bagian 5.9) |
| Iai satu tebasan | **Pertahankan, langka dan berat** | Konfrontasi terakhir yang membawa konsekuensi sosial (saksi, hangat↓, desas-desus) |
| Gema Bayangan (Kage-Echo) | **Bekukan** | Kandidat nanti diubah jadi "alibi/bayangan pengecoh"; jangan dikembangkan sekarang |
| Mode foto ukiyo-e | **Pertahankan** | Hubungkan dengan *Nisshi* |
| Kontrak sosial, penyamaran, 8 zona hitbox v0.7 | **Keluarkan dari pembekuan** | Fondasi Pilar 2 dan 3 |
| Darah tinta + toggle | **Pertahankan** | Sesuaikan: kekerasan harus meninggalkan bukti (noda, bau, saksi) |
| Peta tiga lapis, kaginawa | **Pertahankan** | Jalur Ura |
| Penjaga dengan 5 skenario uji | **Pertahankan** | Tambah skenario kehidupan (Bagian 10) |

**Sudut pandang (keputusan yang saya sarankan Anda tinjau):** untuk game yang berpusat pada *identitas, pakaian, dan kerumunan*, **orang ketiga** biasanya lebih tepat daripada orang pertama (pemain melihat penyamarannya, tubuhnya, bahasa tubuh; kerumunan lebih terbaca; satu investasi animasi karakter menggantikan "tangan orang pertama"). Saya sarankan **orang ketiga sebagai bawaan** dengan kamera orang pertama opsional untuk mengintip/membidik. Jika Anda tetap ingin orang pertama, tuliskan alasannya (misal: imersi) agar AI merancang kemungkinan tubuh terlihat (bayangan, bayangan di air, cermin).

---

## BAGIAN 8 — Arsitektur Teknis untuk Game Seperti Ini

**Prinsip utama: pisahkan "simulasi dunia" dari "tampilan".**

- **Lapisan simulasi** (tanpa grafis): jam, kalender, NPC, jadwal, ingatan, hubungan, desas-desus, ekonomi, peristiwa, pekerjaan. Bisa **diuji tanpa render** (skenario otomatis berhari-hari dalam hitungan detik).
- **Lapisan tampilan**: dunia 3D, animasi, UI, efek. Membaca keadaan simulasi.
- **LOD simulasi:** NPC di luar pandangan hanya dihitung kasar (posisi per jam, status); NPC dekat dihitung penuh.
- **Data-driven:** NPC, jadwal, pekerjaan, peristiwa, kisah kecil, dialog dalam ScriptableObject/JSON, dengan validator (jadwal tak boleh menempatkan NPC di dua tempat).
- **Simpanan (save):** seluruh dunia (ingatan NPC, fakta, hubungan, uang, waktu) **diserialisasi sejak awal**.
- **Alat debug wajib:** percepat waktu, lihat ingatan NPC, lihat graf desas-desus, paksa peristiwa, panen 30 hari simulasi dengan seed tetap.
- **Keputusan engine:** teruskan **Unity 6 + URP** (aset, animasi, Steam). Slice WebGL tetap **dibekukan** sebagai laboratorium tampilan dan sumber ide shader/UX. Jangan menambah sistem kehidupan di dua tempat.
- **Anggaran awal:** desa slice ≈ 80×80 m, 12 NPC berjadwal + 20 keramaian, 1 rumah pemain, 6–8 bangunan bisa dimasuki, 1–2 pekerjaan sampul, 3 pekerjaan bayangan.

**Pelajaran penting:** karena jiwa game kini ada di simulasi, **seni dikerjakan setelah sistem terbukti seru**. Ini membalik urutan "tampilan dulu" yang saya sarankan sebelumnya. Prototipe sistem boleh memakai **kapsul abu-abu** sampai Uji Anekdot lolos.

---

## BAGIAN 9 — Vertical Slice Baru: "Satu Hari, Dua Wajah"

Menggantikan "Wow Slice 15 menit satu misi".

### Isi
- Satu desa kecil, **satu siklus hari penuh (fajar → fajar)**, bisa diulang beberapa hari.
- 12 NPC berjadwal dengan ingatan dan hubungan; ±20 keramaian.
- Pemain punya **kamar sewa**, **satu pekerjaan sampul** (penjual obat), uang, lapar/lelah/luka.
- **Tiga pekerjaan bayangan** dengan banyak pendekatan dan dampak riak yang terlihat **keesokan paginya**.
- **Desas-desus** yang menyebar nyata dan bisa dilihat di mode Dengar.
- **Sambungan Dua Wajah:** minimal tiga cara dunia siang bisa membongkar dunia malam (luka, bau, uang, absen kerja, saksi).
- **Hangat↔Dingin** bekerja dan terasa.
- **Akhir hari:** ringkasan *nisshi* kecil.
- Grafis: **kapsul/greybox boleh**, tampilan gaya ukiyo-e hanya untuk 3 sudut kunci.

### Uji Anekdot (gerbang utama, menggantikan Uji 3 Detik)
Biarkan 5 orang asing bermain 40 menit tanpa panduan. Sesudahnya tanyakan **"ceritakan apa yang terjadi padamu"**. **Lolos jika ≥ 3 dari 5** menceritakan **kejadian spesifik yang tidak kami rancang secara langsung** (misal: "tetanggaku curiga karena bajuku bau sungai, jadi aku membelikannya obat supaya dia diam").
Gagal berarti **sistem belum cukup berinteraksi**, bukan "grafis kurang".

### Kriteria penerimaan teknis
- Simulasi 28 hari dengan seed tetap berjalan tanpa error dan menghasilkan ≥ 10 kejadian sistemik berbeda.
- Tidak ada NPC "terjebak" atau berada di dua tempat; validator jadwal lulus.
- Save/load mengembalikan dunia identik (ingatan, hubungan, uang, waktu).
- Alur "tetangga curiga" dan "saksi melihat pembunuhan" dapat dipicu dan diselesaikan dengan ≥ 3 cara.

---

## BAGIAN 10 — Rencana 90 Hari (Revisi)

| Minggu | Fokus | Keluaran yang diperiksa |
|---|---|---|
| 1 | **Pivot dokumen**: ganti `AGENTS.md` (Bagian 12), tulis `DESIGN_PIVOT.md`, keluarkan arsip v0.7 dari pembekuan, putuskan sudut pandang | Dokumen disetujui |
| 2–3 | **Inti simulasi**: jam/kalender/cuaca, NPC berjadwal (kapsul), validator, alat debug, simulasi 28 hari headless | Laporan simulasi 28 hari |
| 4 | **Ingatan + hubungan + desas-desus**, mode Dengar & Papan Tinta (greybox) | Demo: 1 rumor menyebar 5 NPC |
| 5 | **Identitas & kecurigaan perilaku**: pakaian, zona, saksi, bau, luka | 3 skenario "ketahuan" lulus |
| 6 | **Omote**: kamar, kebutuhan, ekonomi, pekerjaan sampul #1 | Satu hari penuh bisa dijalani |
| 7 | **Ura**: kerangka pekerjaan + 3 pekerjaan + dampak riak | Riak terlihat esok hari |
| 8 | **Sambungan & Hangat/Dingin**, aspirasi, *nisshi* kecil | **Gerbang 1: Uji Anekdot** |
| 9–10 | Perbaiki 10 masalah teratas dari uji; **baru** masukkan alat Ura (Shadow-Meld, lentera, iai) ke dunia hidup | Gerbang 2 |
| 11 | **Seni**: karakter orang ketiga, keramaian terbaca, gaya ukiyo-e pada 3 sudut kunci, audio awal | Screenshot + klip hari-malam |
| 12 | Trailer "dua wajah" (siang hangat ↔ malam dingin), halaman toko, demo 1 hari | **Gerbang 3: Uji Anekdot ulang** |

---

## BAGIAN 11 — Risiko Jujur & Pencegahannya

| Risiko | Mengapa nyata | Pencegahan |
|---|---|---|
| **Rutinitas jadi membosankan ("kerja tanpa makna")** | Game kehidupan sering gagal di sini | Rutinitas pendek (≤ 2 mnt), **selalu menyelipkan informasi/akses/kejutan**, bisa dilewati, tidak menghukum keras |
| **Ruang lingkup meledak** | Simulasi + dunia + animasi + cerita | **Satu desa**, 12 NPC; sistem dulu, seni belakangan; semua konten berbasis data |
| **NPC terasa palsu** | Jadwal robotik | Variasi harian, kepribadian, gumam ucapan, reaksi pada peristiwa |
| **Bug simulasi sulit dilacak** | Banyak sistem saling memengaruhi | Simulasi headless + seed + alat debug sejak minggu 2 |
| **Pemain tak tahu harus apa (sandbox kosong)** | Bebas = bingung | **Aspirasi**, **kontak** yang menawarkan pekerjaan, papan tinta, kejadian harian yang memantik |
| **Kekerasan eksplisit menjauhkan penonton** | Rating dan citra | Gaya cetak tinta; kekerasan punya konsekuensi sosial; toggle |
| **Terlalu mirip AC/Yakuza** | Pembandingan | Fokus pada **satu orang, satu desa, rahasia** dan pada **sambungan dua wajah** |
| **Jam kerja solo** | Skala | Tahap-tahap kecil dengan gerbang; jangan bangun semua pekerjaan sekaligus |

---

## BAGIAN 12 — INSTRUKSI BARU UNTUK AI ANDA (`AGENTS.md` v3)

> Ganti **seluruh isi** `AGENTS.md` dengan bagian ini. Jadikan `CLAUDE.md` satu baris yang menunjuk ke `AGENTS.md`. Hapus Bagian 7 dokumen audit lama sebagai acuan. Berikan prompt di 12.6 satu per sesi.

### 12.1 Peran dan jiwa game (tidak boleh dilupakan)

Kamu adalah **lead systems designer + gameplay engineer** untuk **KAGE-ANA (影穴)**: simulasi kehidupan ganda seorang shinobi di desa Sengoku. **Bukan game misi/stage.** Jiwa game: *hidup seseorang yang bekerja sebagai ninja dan menjalankan berbagai kegilaan tetapi tetap berada dekat dengan lapisan hidup masyarakat*. Cerita **muncul dari sistem** dan kisah-kisah kecil, tidak dari naskah linear.

Fakta saat ini (jangan bantah):
- v2.0 berisi alat Ura yang bagus (bayangan, tinta, iai, gema) tetapi **nol sistem kehidupan** (tidak ada jadwal, ingatan, desas-desus, reputasi, ekonomi, pekerjaan, rumah, tidur, musim, festival).
- Layar kemenangan berperingkat dan misi satu menara **bukan** arah produk.
- Slice WebGL dibekukan sebagai laboratorium tampilan. Produk dikembangkan di **Unity 6 + URP**.
- Mekanik v0.7 (penyamaran, zona sosial, kontrak) dikeluarkan dari pembekuan sebagai fondasi.

### 12.2 Aturan tak boleh dilanggar

1. **Uji Hidup** untuk setiap tugas, jawab tertulis: (a) Apakah ini membuat dunia terasa dihuni orang yang punya hidup? (b) Apakah ini menambah kemungkinan **kisah yang tak dirancang langsung**? (c) Apakah ini memperkuat **sambungan antara dua kehidupan**? Bila ketiganya "tidak", usulkan penundaan, jangan kerjakan.
2. **Sistem dulu, seni belakangan.** Dilarang memoles visual atau menambah efek sebelum Uji Anekdot (Gerbang 1) lolos. Greybox/kapsul sah.
3. **Simulasi terpisah dari tampilan.** Logika dunia tidak boleh bergantung pada objek render. Simulasi harus dapat berjalan **headless** dengan seed tetap.
4. **Semua berbasis data.** NPC, jadwal, pekerjaan, peristiwa, kisah kecil, dialog, harga di ScriptableObject/JSON + validator. Dilarang menaruh literal konten di kode.
5. **Tidak ada layar "menang/peringkat misi".** Penutupan berbentuk *nisshi* (Bagian 5.13). Tidak ada kondisi menang tunggal.
6. **Kekerasan punya harga.** Setiap tindakan kekerasan meninggalkan jejak sistemik (saksi, noda, bau, desas-desus, Hangat↓/Dingin↑, riak sosial). Tidak ada kekerasan "gratis".
7. **Rutinitas harus pendek, bermakna, dan dapat dilewati.** Setiap rutinitas memberi minimal satu: informasi, akses, hubungan, atau kejutan.
8. **Jujur.** Dilarang menulis "authentic", "AAA", "rigged", "ready-to-open", "100%", "photorealistic" tanpa bukti. Komentar menjelaskan apa yang dilakukan kode. Laporan menyebut apa yang **belum** jadi.
9. **Satu basis kode.** Hanya Unity untuk produk. Data kanonis di satu lokasi. Berkas turunan dihasilkan skrip.
10. **Bukti wajib:** tiap tugas diakhiri **laporan simulasi** (headless, seed, N hari, daftar kejadian yang muncul) dan/atau klip dari build nyata; angka FPS hanya valid dengan GPU nyata dan harus menyebut spesifikasinya.
11. **Aset bersih & tercatat** di `ASSETS_LICENSE.md` sebelum dipakai; tidak ada foto wajah nyata; tidak ada aset berlisensi tak jelas.
12. **Cabang kecil, commit jelas**, jangan menghapus berkas pengguna tanpa persetujuan.
13. **Tanya sebelum keputusan besar** (sudut pandang, nada, rating). Hal kecil putuskan dan catat asumsi.
14. **Bahasa:** komunikasi dengan pengguna Bahasa Indonesia; identifier, komentar, nama berkas Bahasa Inggris.

### 12.3 Skema data minimum (rancang di `ARCHITECTURE.md`)

```jsonc
// NPC
{ "id":"npc_obaa", "name":"Obaa-san Tsuru", "personality":["cemas","setia"],
  "schedule":[{"from":"06:00","to":"09:00","place":"rumah_tsuru","activity":"menjemur"}, ...],
  "needs":{"uang":0.7,"keamanan":0.9}, "relations":{"npc_rentenir":-0.8,"player":0.2},
  "knowledge":[], "sleepWindow":["21:00","05:00"] }

// Fakta / desas-desus
{ "id":"fact_001", "subject":"player", "claim":"terlihat berdarah",
  "source":"npc_penjaga1", "certainty":0.8, "decayPerDay":0.1, "spreadRate":0.3 }

// Pekerjaan bayangan
{ "id":"gig_catatan_utang", "giver":"npc_obaa", "goal":"curi catatan utang",
  "deadline":"hari+2", "approaches":["senyap","sosial","tipu daya"],
  "ripples":[{"if":"ketahuan","then":"patroli_pasar+1"},
             {"if":"sukses_senyap","then":"opini(npc_obaa,player)+0.4"}] }
```

### 12.4 Standar penerimaan "Satu Hari, Dua Wajah"

- Simulasi 28 hari headless dengan seed tetap tanpa error; **≥ 10 jenis kejadian sistemik** muncul; validator jadwal lulus.
- Save/load menghasilkan dunia identik.
- Desas-desus menyebar nyata dan terlihat di mode Dengar; minimal satu rumor **berubah isi** saat menyebar.
- Tiga cara dunia siang membongkar dunia malam bekerja (luka, bau/noda, uang aneh, absen kerja, saksi).
- Tiga pekerjaan bayangan dengan ≥ 3 pendekatan masing-masing dan **riak yang terlihat keesokan harinya**.
- Hangat↔Dingin memengaruhi minimal tiga perilaku NPC dan dua kemampuan pemain.
- **Gerbang 1: Uji Anekdot** (≥ 3 dari 5 penguji menceritakan kejadian spesifik yang tidak dirancang langsung).

### 12.5 Gerbang

- **Gerbang 1 (≈ Minggu 8):** Uji Anekdot, tanpa seni khusus.
- **Gerbang 2 (≈ Minggu 10):** alat Ura terintegrasi tidak merusak keseimbangan dua wajah; 5 penguji dapat menjelaskan "apa tujuanmu" dengan kata-kata sendiri.
- **Gerbang 3 (≈ Minggu 12):** Uji Anekdot ulang dengan seni; ≥ 3 dari 5 menyatakan ingin bermain lagi.
Gagal = berhenti menambah fitur dan perbaiki.

### 12.6 Prompt bertahap (berikan satu per sesi)

**L0 — Pivot dokumen**
```
L0. Ganti AGENTS.md dengan isi v3, buat DESIGN_PIVOT.md (visi, pilar, Uji Hidup,
Uji Anekdot, daftar fitur dibuang/dipindah/dipertahankan). Keluarkan arsip v0.7
dari pembekuan (ekstrak ide penyamaran/zona/kontrak ke docs/). Hapus layar
kemenangan berperingkat dari rencana. Tanya saya: sudut pandang (saran: orang
ketiga), nada, tingkat kekerasan. Jangan menulis kode gameplay.
```

**L1 — Inti simulasi (headless)**
```
L1. Di Unity (assembly terpisah KageAna.Sim, tanpa referensi ke render): jam &
kalender (1 hari ≈ 18 mnt nyata, 7 hari/musim, 28 hari/tahun), cuaca, peristiwa
terjadwal, NPC berjadwal dari data, validator jadwal, simulasi headless dengan
seed + laporan teks N hari. Alat debug: percepat waktu, lihat lokasi NPC.
Bukti: laporan simulasi 28 hari. Tidak ada visual selain kapsul.
```

**L2 — Ingatan, hubungan, desas-desus**
```
L2. NPC punya ingatan (fakta + kepastian + peluruhan), graf hubungan, dan
penyebaran desas-desus lewat percakapan terjadwal. Fakta berubah saat menyebar.
Mode Dengar (greybox): benang tinta antar NPC dan isi desas-desus. Papan Tinta
sederhana. Bukti: laporan simulasi yang menunjukkan 1 rumor menyebar dan
berubah, plus tangkapan layar greybox.
```

**L3 — Identitas & kecurigaan perilaku**
```
L3. Sistem pakaian/identitas dan zona sosial (pasar, kuil, kediaman samurai,
dermaga, dunia bawah), kecurigaan berbasis perilaku (lari di keramaian, senjata
terlihat, noda, bau, tempat/jam salah), saksi, dan reputasi per lingkaran.
Gunakan arsip v0.7 sebagai referensi. Bukti: 3 skenario "ketahuan" otomatis
dan 3 skenario "lolos" otomatis.
```

**L4 — Omote: rumah, kebutuhan, uang, pekerjaan sampul**
```
L4. Kamar sewa (tuan rumah berjadwal, sewa jatuh tempo, ruang rahasia), kebutuhan
ringan (lapar, lelah, luka, kebersihan), ekonomi dasar, dan SATU pekerjaan
sampul (penjual obat) dengan rutinitas pendek yang memberi informasi/akses.
Bukti: satu hari penuh dapat dijalani; laporan simulasi harga dan uang.
```

**L5 — Ura: kerangka pekerjaan bayangan + dampak riak**
```
L5. Kerangka pekerjaan (pemberi, tujuan, tenggat, pendekatan, imbalan, riak) dan
3 pekerjaan dari daftar "kegilaan". Integrasikan alat lama sebagai teknik:
Shadow-Meld, manipulasi lentera, iai (langka, berkonsekuensi sosial). Riak harus
terlihat keesokan harinya. Bukti: laporan simulasi 3 hari dengan riak.
```

**L6 — Sambungan dua wajah & Hangat/Dingin**
```
L6. Implementasikan titik rapuh antar kehidupan (luka terlihat, bau/noda, uang
aneh, absen kerja, saksi, kebiasaan) dan meter Hangat↔Dingin dengan dampak ke
NPC dan kemampuan pemain. Bukti: 5 skenario otomatis + laporan.
```

**L7 — Aspirasi & Nisshi**
```
L7. Pilihan Aspirasi (min. 4), pelacakan arah hidup, penutupan tahun berbentuk
Nisshi (ringkasan otomatis bergaya gulungan ukiyo-e: hubungan, hal gila, korban,
siapa tahu rahasiamu). Opsi lanjut/murid/hidup baru. Bukti: Nisshi dari simulasi
headless dan tangkapan layarnya.
```

**L8 — Uji Anekdot (Gerbang 1)**
```
L8. Siapkan build uji dan skrip wawancara. Laporkan hasil 5 penguji apa adanya
(kutipan anekdot, titik bingung, momen bosan). Jangan menambah fitur sebelum
laporan selesai. Usulkan 10 perbaikan teratas.
```

**L9 — Seni untuk dunia hidup**
```
L9. Setelah Gerbang 1: karakter orang ketiga ber-rig (bukan primitif), keramaian
terbaca (siluet peran, pakaian = identitas), gaya ukiyo-e pada 3 sudut kunci,
pagi-ke-malam yang kontras (hangat↔dingin), audio awal. Catat aset di
ASSETS_LICENSE.md. Bukti: klip hari→malam + FPS dengan GPU nyata.
```

**L10 — Toko & demo**
```
L10. Trailer "dua wajah" (siang hangat ↔ malam dingin), kapsul, tangkapan layar,
deskripsi, demo 1 hari, rating IARC, daftar periksa Steam.
```

### 12.7 Format laporan tiap tugas

```
## Ringkasan jujur (apa jadi, apa belum)
## Uji Hidup: (a) dunia dihuni? (b) kisah tak terduga? (c) sambungan dua wajah?
## Bukti (laporan simulasi headless: seed, N hari, kejadian; klip/screenshot; 
##        FPS hanya bila GPU nyata + spesifikasi)
## Perubahan (berkas, data, aset, lisensi)
## Masalah tersisa (jujur)
## Langkah berikutnya (maks. 3, satu prioritas)
```

### 12.8 Daftar periksa selesai

- [ ] Lolos Uji Hidup (tiga pertanyaan dijawab)
- [ ] Logika di lapisan simulasi, dapat dijalankan headless
- [ ] Semua konten di data + validator lulus
- [ ] Laporan simulasi terlampir
- [ ] Tidak ada duplikasi logika/data; tidak ada klaim berlebihan
- [ ] Aset tercatat lisensinya
- [ ] `CHANGELOG.md`/`VERSION` mencerminkan perubahan nyata

---

## BAGIAN 13 — Pertanyaan Keputusan untuk Anda (dengan saran bawaan saya)

| # | Keputusan | Saran saya | Dampak |
|---|---|---|---|
| 1 | Sudut pandang | **Orang ketiga** (+ intip orang pertama opsional) | Identitas/penyamaran terbaca; investasi animasi tunggal |
| 2 | Nada | **Hangat-jenaka di siang, dingin-sunyi di malam** (kontras sebagai jiwa) | Menentukan tulisan, musik, warna |
| 3 | Skala | **Satu desa dalam**, bukan kota luas | Menjaga ruang lingkup |
| 4 | Kekerasan | **Gaya tinta, berharga secara sosial**, toggle | Rating, selera, konsekuensi |
| 5 | Penutupan tahun | ***Nisshi* + lanjut sebagai murid** | Alasan bermain ulang |
| 6 | Sudut sejarah | **Sengoku "rasa" ukiyo-e**, bukan dokumenter | Kebebasan kreatif |

---

## BAGIAN 14 — Langkah Segera (minggu ini)

1. **Setujui atau ubah** keenam keputusan di Bagian 13.
2. **Ganti `AGENTS.md`** dengan Bagian 12 dan berikan prompt **L0** ke AI Anda.
3. **Bekukan** pengembangan efek/visual baru sampai Gerbang 1.
4. Tulis tangan **sepuluh kisah kecil** (satu paragraf masing-masing) berdasarkan daftar "kegilaan" Bagian 5.10. Itu bahan untuk menguji apakah dunia ini seru, jauh sebelum ada grafis.
5. Siapkan 5 calon penguji yang tidak mengenal proyek (Uji Anekdot).

---

## Penutup

Yang Anda gambarkan bukan game stealth yang diperindah. Itu **dunia untuk ditinggali, dengan rahasia di dalamnya**. Kualitas produksi v2.0 tetap berharga: gaya, shader, dan alatnya menjadi *kulit dan perkakas*. Tapi **jantungnya** (orang-orang yang punya jadwal dan ingatan, rumah yang bisa digeledah, dua wajah yang harus dijaga agar tidak retak) belum ada. Bangun jantung itu dulu, dengan kapsul abu-abu bila perlu. Jika seorang asing menceritakan kisah hidupnya di desa itu kepada temannya, **maka game ini sudah punya tujuan.**
