# Kage Ana — GitHub Source Package

This archive is a source-oriented copy prepared for repository upload.

## What was excluded
- Executable installers and binaries (`.exe`, `.dll`, etc.)
- Nested ZIP/other archives
- Windows/Linux launcher and installer scripts (`.bat`, `.cmd`, `.ps1`, `.vbs`, `.sh`)
- Embedded `.git` history and common generated/build folders

These exclusions reduce accidental uploads and common antivirus false positives, but **do not certify the remaining source as malware-free**. Review source code and scan it locally before publishing. If an antivirus flagged a specific file, check the exact detection name and file path.

## Upload guidance
- Do not commit passwords, API keys, tokens, private certificates, or personal data.
- Keep generated builds and installers out of the source repository.
- Use GitHub's secret scanning and repository security features where available.
